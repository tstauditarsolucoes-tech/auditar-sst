const PANEL_SHEET = 'PainelDados';
const CIPA_ELECTIONS_SHEET = 'CipaEleicoes';
const CIPA_VOTERS_SHEET = 'CipaEleitores';
const CIPA_VOTES_SHEET = 'CipaVotos';

function setupAuditar() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Abra este script a partir de uma Planilha Google.');

  ensureSheet_(ss, PANEL_SHEET, [
    'token', 'company_id', 'company_name', 'active', 'updated_at', 'payload_json'
  ]);
  ensureSheet_(ss, CIPA_ELECTIONS_SHEET, [
    'token', 'election_id', 'company_id', 'company_name', 'title',
    'management_period', 'status', 'total_voters', 'updated_at', 'candidates_json'
  ]);
  ensureSheet_(ss, CIPA_VOTERS_SHEET, [
    'election_token', 'voter_hash', 'used'
  ]);
  ensureSheet_(ss, CIPA_VOTES_SHEET, [
    'election_token', 'ballot_id', 'candidate_id'
  ]);

  const props = PropertiesService.getScriptProperties();
  props.setProperty('AUDITAR_SPREADSHEET_ID', ss.getId());
  let key = props.getProperty('AUDITAR_SYNC_KEY');
  if (!key) {
    key = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
    props.setProperty('AUDITAR_SYNC_KEY', key);
  }

  Logger.log('CHAVE DE SINCRONIZACAO: ' + key);
  return key;
}

function doPost(e) {
  try {
    const request = JSON.parse((e.postData && e.postData.contents) || '{}');
    const expectedKey = PropertiesService.getScriptProperties().getProperty('AUDITAR_SYNC_KEY');
    if (!expectedKey) return jsonResponse_({ok: false, message: 'Execute setupAuditar() primeiro.'});

    if (request.action === 'sync') {
      if (request.syncKey !== expectedKey) return jsonResponse_({ok: false, message: 'Chave de sincronização inválida.'});
      if (!request.payload) return jsonResponse_({ok: false, message: 'Payload ausente.'});
      savePanelPayload_(request.payload);
      return jsonResponse_({ok: true, message: 'Painel atualizado.'});
    }

    if (request.action === 'cipa_publish') {
      if (request.syncKey !== expectedKey) return jsonResponse_({ok: false, message: 'Chave de sincronização inválida.'});
      return jsonResponse_(publishCipaElection_(request.payload || {}));
    }

    if (request.action === 'cipa_close') {
      if (request.syncKey !== expectedKey) return jsonResponse_({ok: false, message: 'Chave de sincronização inválida.'});
      return jsonResponse_(closeCipaElection_(String(request.electionToken || '')));
    }

    return jsonResponse_({ok: false, message: 'Requisição inválida.'});
  } catch (err) {
    return jsonResponse_({ok: false, message: String(err)});
  }
}

function doGet(e) {
  const params = (e && e.parameter) || {};

  if (String(params.api || '') === 'cipa_status') {
    return jsonResponse_(getCipaStatus_(String(params.cipa || '').trim()));
  }

  const cipaToken = String(params.cipa || '').trim();
  if (cipaToken) {
    const election = findCipaElection_(cipaToken);
    if (!election) return unavailablePage_('Eleição não encontrada.');
    if (election.status !== 'Aberta') {
      return unavailablePage_(election.status === 'Encerrada' ? 'Esta votação já foi encerrada.' : 'Esta votação ainda não está aberta.');
    }
    const template = HtmlService.createTemplateFromFile('Votacao');
    template.electionJson = safeJsonForHtml_({
      token: election.token,
      companyName: election.companyName,
      title: election.title,
      managementPeriod: election.managementPeriod,
      candidates: election.candidates,
    });
    return template.evaluate()
      .setTitle('Votação CIPA • Auditar SST')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  const companyToken = String(params.empresa || '').trim();
  if (!companyToken) return unavailablePage_('Link inválido.');
  const record = findPanelPayload_(companyToken);
  if (!record) return unavailablePage_('Painel não encontrado.');
  if (!record.active) return unavailablePage_('Este acesso está desativado.');

  const template = HtmlService.createTemplateFromFile('Index');
  template.payloadJson = safeJsonForHtml_(record.payload);
  return template.evaluate()
    .setTitle('Painel Gerencial SST')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function registrarVoto(electionToken, voterCode, candidateId) {
  const token = String(electionToken || '').trim();
  const code = String(voterCode || '').trim().toUpperCase();
  const candidate = String(candidateId || '').trim();
  if (!token || !code || !candidate) return {ok: false, message: 'Preencha o código e escolha um candidato.'};

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const election = findCipaElection_(token);
    if (!election) return {ok: false, message: 'Eleição não encontrada.'};
    if (election.status !== 'Aberta') return {ok: false, message: 'A votação não está aberta.'};
    if (!election.candidates.some(c => String(c.id) === candidate)) {
      return {ok: false, message: 'Candidato inválido.'};
    }

    const voters = getSheet_(CIPA_VOTERS_SHEET);
    const hash = hashCode_(code);
    const lastRow = voters.getLastRow();
    if (lastRow < 2) return {ok: false, message: 'Código de votação inválido.'};
    const rows = voters.getRange(2, 1, lastRow - 1, 3).getValues();
    let targetRow = -1;
    let used = false;
    for (let i = 0; i < rows.length; i++) {
      if (String(rows[i][0]) === token && String(rows[i][1]) === hash) {
        targetRow = i + 2;
        used = rows[i][2] === true || String(rows[i][2]).toLowerCase() === 'true';
        break;
      }
    }
    if (targetRow < 0) return {ok: false, message: 'Código de votação inválido.'};
    if (used) return {ok: false, message: 'Este código já foi utilizado.'};

    // A marca de participação e a cédula ficam em tabelas separadas.
    voters.getRange(targetRow, 3).setValue(true);
    getSheet_(CIPA_VOTES_SHEET).appendRow([
      token,
      Utilities.getUuid().replace(/-/g, ''),
      candidate,
    ]);
    SpreadsheetApp.flush();
    return {ok: true, message: 'Voto registrado com sucesso. Obrigado por participar.'};
  } finally {
    lock.releaseLock();
  }
}

function publishCipaElection_(payload) {
  const election = payload.election || {};
  const company = payload.company || {};
  const candidates = Array.isArray(payload.candidates) ? payload.candidates : [];
  const voters = Array.isArray(payload.voters) ? payload.voters : [];
  const token = String(election.token || '').trim();
  if (!token) return {ok: false, message: 'Token da eleição ausente.'};
  if (!candidates.length) return {ok: false, message: 'Cadastre candidatos antes de publicar.'};
  if (!voters.length) return {ok: false, message: 'Prepare os eleitores antes de publicar.'};

  const existing = findCipaElection_(token);
  if (existing && countVotes_(token) > 0) {
    return {ok: false, message: 'A eleição já recebeu votos e não pode ser republicada.'};
  }

  const electionSheet = getSheet_(CIPA_ELECTIONS_SHEET);
  const values = [
    token,
    String(election.id || ''),
    String(company.id || ''),
    String(company.name || ''),
    String(election.title || 'Eleição CIPA'),
    String(election.managementPeriod || ''),
    'Aberta',
    voters.length,
    new Date().toISOString(),
    JSON.stringify(candidates.map(c => ({
      id: String(c.id || ''),
      name: String(c.name || ''),
      role: String(c.role || ''),
      sector: String(c.sector || ''),
    }))),
  ];
  upsertByToken_(electionSheet, token, values);

  const voterSheet = getSheet_(CIPA_VOTERS_SHEET);
  deleteRowsForToken_(voterSheet, token, 1);
  voters.forEach(v => {
    const accessCode = String(v.accessCode || '').trim().toUpperCase();
    if (accessCode) voterSheet.appendRow([token, hashCode_(accessCode), false]);
  });

  const voteSheet = getSheet_(CIPA_VOTES_SHEET);
  deleteRowsForToken_(voteSheet, token, 1);
  SpreadsheetApp.flush();
  return {ok: true, message: 'Eleição publicada. QR Code e votação online liberados.'};
}

function closeCipaElection_(token) {
  if (!token) return {ok: false, message: 'Eleição inválida.'};
  const sheet = getSheet_(CIPA_ELECTIONS_SHEET);
  const row = findRowByToken_(sheet, token);
  if (row < 0) return {ok: false, message: 'Eleição não encontrada.'};
  sheet.getRange(row, 7).setValue('Encerrada');
  sheet.getRange(row, 9).setValue(new Date().toISOString());
  SpreadsheetApp.flush();
  const status = getCipaStatus_(token);
  status.message = 'Votação encerrada. Apuração liberada.';
  return status;
}

function getCipaStatus_(token) {
  if (!token) return {ok: false, message: 'Eleição inválida.'};
  const election = findCipaElection_(token);
  if (!election) return {ok: false, message: 'Eleição não encontrada.'};

  const voterSheet = getSheet_(CIPA_VOTERS_SHEET);
  const lastRow = voterSheet.getLastRow();
  let eligible = 0;
  let voted = 0;
  if (lastRow >= 2) {
    const rows = voterSheet.getRange(2, 1, lastRow - 1, 3).getValues();
    rows.forEach(row => {
      if (String(row[0]) === token) {
        eligible++;
        if (row[2] === true || String(row[2]).toLowerCase() === 'true') voted++;
      }
    });
  }
  const participation = eligible ? Math.round((voted * 1000) / eligible) / 10 : 0;
  const target50 = Math.ceil(eligible * 0.5);
  const missingFor50 = Math.max(0, target50 - voted);
  const quorumMessage = participation >= 50
    ? 'Participação de 50% atingida.'
    : 'Faltam ' + missingFor50 + ' voto(s) para atingir 50% de participação.';

  const response = {
    ok: true,
    status: election.status,
    eligible: eligible,
    voted: voted,
    participation: participation,
    quorumMessage: quorumMessage,
    results: [],
  };

  if (election.status === 'Encerrada') {
    const counts = {};
    election.candidates.forEach(c => counts[String(c.id)] = 0);
    const voteSheet = getSheet_(CIPA_VOTES_SHEET);
    const voteLast = voteSheet.getLastRow();
    if (voteLast >= 2) {
      voteSheet.getRange(2, 1, voteLast - 1, 3).getValues().forEach(row => {
        if (String(row[0]) === token) {
          const id = String(row[2]);
          counts[id] = (counts[id] || 0) + 1;
        }
      });
    }
    response.results = election.candidates
      .map(c => ({
        id: c.id,
        name: c.name,
        role: c.role,
        sector: c.sector,
        votes: counts[String(c.id)] || 0,
      }))
      .sort((a, b) => b.votes - a.votes || String(a.name).localeCompare(String(b.name)))
      .map((r, i) => Object.assign({position: i + 1}, r));
  }
  return response;
}

function findCipaElection_(token) {
  const sheet = getSheet_(CIPA_ELECTIONS_SHEET);
  const row = findRowByToken_(sheet, token);
  if (row < 0) return null;
  const data = sheet.getRange(row, 1, 1, 10).getValues()[0];
  let candidates = [];
  try { candidates = JSON.parse(String(data[9] || '[]')); } catch (_) {}
  return {
    token: String(data[0]),
    electionId: String(data[1] || ''),
    companyId: String(data[2] || ''),
    companyName: String(data[3] || ''),
    title: String(data[4] || ''),
    managementPeriod: String(data[5] || ''),
    status: String(data[6] || ''),
    totalVoters: Number(data[7] || 0),
    updatedAt: String(data[8] || ''),
    candidates: candidates,
  };
}

function countVotes_(token) {
  const sheet = getSheet_(CIPA_VOTES_SHEET);
  if (sheet.getLastRow() < 2) return 0;
  return sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues()
    .filter(row => String(row[0]) === token).length;
}

function savePanelPayload_(payload) {
  const token = String(payload.accessToken || '').trim();
  if (!token) throw new Error('Token da empresa não informado.');
  const company = payload.company || {};
  const values = [
    token,
    String(company.id || ''),
    String(company.name || ''),
    payload.enabled !== false,
    String(payload.updatedAt || new Date().toISOString()),
    JSON.stringify(payload),
  ];
  upsertByToken_(getSheet_(PANEL_SHEET), token, values);
}

function findPanelPayload_(token) {
  const sheet = getSheet_(PANEL_SHEET);
  const row = findRowByToken_(sheet, token);
  if (row < 0) return null;
  const data = sheet.getRange(row, 1, 1, 6).getValues()[0];
  let payload;
  try { payload = JSON.parse(String(data[5] || '{}')); } catch (_) { return null; }
  return {
    active: data[3] === true || String(data[3]).toLowerCase() === 'true',
    payload: payload,
  };
}

function ensureSheet_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function getSheet_(name) {
  const spreadsheetId = PropertiesService.getScriptProperties().getProperty('AUDITAR_SPREADSHEET_ID');
  if (!spreadsheetId) throw new Error('Execute setupAuditar() primeiro.');
  const ss = SpreadsheetApp.openById(spreadsheetId);
  const sheet = ss.getSheetByName(name);
  if (!sheet) throw new Error('Aba ' + name + ' não encontrada. Execute setupAuditar() novamente.');
  return sheet;
}

function findRowByToken_(sheet, token) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  const values = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(token)) return i + 2;
  }
  return -1;
}

function upsertByToken_(sheet, token, values) {
  const row = findRowByToken_(sheet, token);
  if (row > 0) sheet.getRange(row, 1, 1, values.length).setValues([values]);
  else sheet.appendRow(values);
}

function deleteRowsForToken_(sheet, token, tokenColumn) {
  for (let row = sheet.getLastRow(); row >= 2; row--) {
    if (String(sheet.getRange(row, tokenColumn).getValue()) === String(token)) {
      sheet.deleteRow(row);
    }
  }
}

function hashCode_(code) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(code).trim().toUpperCase(),
    Utilities.Charset.UTF_8
  );
  return bytes.map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
}

function safeJsonForHtml_(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026');
}

function jsonResponse_(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function unavailablePage_(message) {
  const safe = String(message || 'Indisponível.')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<style>body{font-family:Arial,sans-serif;background:#f7f8fa;color:#14265b;display:grid;place-items:center;min-height:90vh;margin:0}' +
    '.box{background:white;padding:28px;border-radius:18px;max-width:420px;box-shadow:0 4px 20px #0001;text-align:center}</style>' +
    '</head><body><div class="box"><h2>Auditar SST</h2><p>' + safe + '</p></div></body></html>'
  );
}
