# Auditar SST v2.2 — gerar APK para teste

O projeto contém um workflow do GitHub Actions em `.github/workflows/build-apk.yml`.

## Primeiro teste recomendado

1. Instalar o APK de teste.
2. Conferir a identidade visual azul-marinho + verde e o ícone da Auditar.
3. Cadastrar uma empresa.
4. Cadastrar os setores da empresa.
5. Deixar Obra/Unidade em branco quando não se aplicar.
6. Abrir Nova vistoria.
7. Escolher um checklist pela biblioteca e testar a busca por categoria.
8. Marcar Conforme / Parcial / Não Conforme / N/A.
9. Confirmar que uma Não Conformidade permanece aberta para acompanhamento.
10. Criar Plano de Ação somente quando necessário.
11. Concluir a ação e depois encerrar a NC após verificação.
12. Gerar PDF e conferir empresa, setor, fotos e status.

## Google Drive

As funções offline continuam independentes do Google Drive. A integração com Drive/planilha gerencial será configurada em etapa posterior.
