# Auditar SST — gerar APK para teste

Este projeto já contém um workflow do GitHub Actions em:

`.github/workflows/build-apk.yml`

Ele executa automaticamente:

1. instala Java;
2. instala Flutter 3.47.2;
3. gera a estrutura Android;
4. adiciona permissões de câmera e internet;
5. baixa as dependências;
6. executa `flutter analyze`;
7. compila o APK de teste;
8. compila o APK release;
9. disponibiliza os dois APKs como artefatos.

## Arquivo indicado para testar primeiro

`Auditar_SST_TESTE.apk`

## Observação sobre Google Drive

O restante do aplicativo funciona sem a configuração do Google Drive.

Para o botão **Vincular Google Drive** funcionar no aparelho real, será
necessário cadastrar o aplicativo Android no Google Cloud e configurar as
credenciais OAuth usando o package name e a assinatura do APK.

Essa configuração pode ser feita depois do primeiro teste das funções offline.

## Primeiro teste recomendado

1. Instalar `Auditar_SST_TESTE.apk`.
2. Cadastrar uma empresa.
3. Criar uma obra/unidade.
4. Criar um checklist editável.
5. Iniciar uma vistoria.
6. Marcar Conforme / Não Conforme / N/A.
7. Tirar fotos.
8. Criar plano de ação.
9. Assinar.
10. Gerar o PDF.
11. Fechar o aplicativo e abrir novamente para confirmar que os dados ficaram salvos.
