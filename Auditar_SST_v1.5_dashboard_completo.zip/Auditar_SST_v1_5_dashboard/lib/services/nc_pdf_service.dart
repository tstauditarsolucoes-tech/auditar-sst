import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../database.dart';

class NcPdfService {
  static const _navy = PdfColor(0.113725, 0.180392, 0.423529);
  static const _green = PdfColor(0.090196, 0.552941, 0.172549);
  static const _red = PdfColors.red700;
  static const _amber = PdfColors.orange800;
  static const _grey = PdfColors.grey700;
  static const _line = PdfColors.grey300;

  static Future<Uint8List> generate(String ncId) async {
    final db = AppDatabase.instance;
    final row = await db.getNonConformityDetailRow(ncId);
    if (row == null) throw Exception('Não conformidade não encontrada.');

    final nc = await db.getNonConformity(ncId);
    if (nc == null) throw Exception('Não conformidade não encontrada.');

    final photos = await db.getPhotosForAnswer(nc.answerId);
    final actions = await db.getActionsForNonConformity(ncId);
    final doc = pw.Document();

    final logo = await _asset('assets/branding/auditar_icon.png');
    final icon = await _asset('assets/branding/auditar_icon.png');

    final date = DateTime.tryParse('${row['inspection_date'] ?? ''}');
    final dateText = date == null
        ? '-'
        : DateFormat('dd/MM/yyyy HH:mm').format(date);

    final statusColor = _statusColor(nc.status);

    final widgets = <pw.Widget>[
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisSize: pw.MainAxisSize.min,
            children: [
              if (logo != null)
                pw.Container(
                  width: 42,
                  height: 42,
                  child: pw.Image(logo, fit: pw.BoxFit.contain),
                ),
              if (logo != null) pw.SizedBox(width: 8),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.RichText(
                    text: pw.TextSpan(
                      children: [
                        pw.TextSpan(
                          text: 'Auditar ',
                          style: pw.TextStyle(
                            fontSize: 17,
                            fontWeight: pw.FontWeight.bold,
                            color: _navy,
                          ),
                        ),
                        pw.TextSpan(
                          text: 'SST',
                          style: pw.TextStyle(
                            fontSize: 17,
                            fontWeight: pw.FontWeight.bold,
                            color: _green,
                          ),
                        ),
                      ],
                    ),
                  ),
                  pw.Text(
                    'SEGURANÇA DO TRABALHO',
                    style: pw.TextStyle(
                      fontSize: 6,
                      fontWeight: pw.FontWeight.bold,
                      color: _green,
                      letterSpacing: .8,
                    ),
                  ),
                ],
              ),
            ],
          ),
          pw.Spacer(),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: pw.BoxDecoration(
              color: _soft(statusColor),
              border: pw.Border.all(color: statusColor),
              borderRadius: pw.BorderRadius.circular(12),
            ),
            child: pw.Text(
              nc.status,
              style: pw.TextStyle(
                fontSize: 8,
                fontWeight: pw.FontWeight.bold,
                color: statusColor,
              ),
            ),
          ),
        ],
      ),
      pw.SizedBox(height: 16),
      pw.Text(
        'Relatório de Não Conformidade',
        style: pw.TextStyle(
          fontSize: 22,
          fontWeight: pw.FontWeight.bold,
          color: _navy,
        ),
      ),
      pw.SizedBox(height: 4),
      pw.Row(
        children: [
          pw.Text(
            nc.code,
            style: pw.TextStyle(
              fontSize: 12,
              fontWeight: pw.FontWeight.bold,
              color: _red,
            ),
          ),
          pw.SizedBox(width: 10),
          pw.Text(
            '${row['company_name'] ?? '-'}',
            style: const pw.TextStyle(fontSize: 9, color: _grey),
          ),
        ],
      ),
      pw.SizedBox(height: 10),
      pw.Container(width: 80, height: 3, color: _green),
      pw.SizedBox(height: 18),
      _section('IDENTIFICAÇÃO'),
      _table([
        ['Empresa', '${row['company_name'] ?? '-'}'],
        if ('${row['company_cnpj'] ?? ''}'.trim().isNotEmpty)
          ['CNPJ', '${row['company_cnpj']}'],
        if ('${row['sector_name'] ?? ''}'.trim().isNotEmpty)
          ['Setor', '${row['sector_name']}'],
        if ('${row['worksite_name'] ?? ''}'.trim().isNotEmpty)
          ['Obra / Unidade', '${row['worksite_name']}'],
        ['Área / Local', '${row['area'] ?? '-'}'],
        ['Data da inspeção', dateText],
        if ('${row['inspection_report_number'] ?? ''}'.trim().isNotEmpty)
          ['Relatório de origem', '${row['inspection_report_number']}'],
        ['Técnico responsável', '${row['technician_name'] ?? '-'}'],
        if ('${row['responsible_name'] ?? ''}'.trim().isNotEmpty)
          ['Responsável da empresa', '${row['responsible_name']}'],
      ]),
      pw.SizedBox(height: 16),
      _section('NÃO CONFORMIDADE'),
      _highlight(
        title: 'Item verificado',
        value: '${row['question_text'] ?? '-'}',
        color: _navy,
        softColor: PdfColors.blue50,
      ),
      if ('${row['question_category'] ?? ''}'.trim().isNotEmpty)
        _box('Categoria', '${row['question_category']}'),
      if ('${row['question_reference'] ?? ''}'.trim().isNotEmpty)
        _box('Referência normativa', '${row['question_reference']}'),
      _box('Situação encontrada', nc.description),
      _highlight(
        title: 'Risco identificado',
        value: nc.riskIdentified.isEmpty ? 'Não informado.' : nc.riskIdentified,
        color: _red,
        softColor: PdfColors.red50,
      ),
      _highlight(
        title: 'Recomendação técnica',
        value: nc.recommendation.isEmpty ? 'Não informada.' : nc.recommendation,
        color: _green,
        softColor: PdfColors.green50,
      ),
      pw.Row(
        children: [
          pw.Expanded(child: _mini('CLASSIFICAÇÃO', nc.classification)),
          pw.SizedBox(width: 8),
          pw.Expanded(child: _mini('STATUS', nc.status)),
          if (nc.verifiedAt != null) ...[
            pw.SizedBox(width: 8),
            pw.Expanded(
              child: _mini(
                'VERIFICADA EM',
                DateFormat('dd/MM/yyyy HH:mm').format(nc.verifiedAt!),
              ),
            ),
          ],
        ],
      ),
      if (nc.verifiedBy.isNotEmpty) ...[
        pw.SizedBox(height: 6),
        _box('Verificada por', nc.verifiedBy),
      ],
      pw.SizedBox(height: 16),
      _section('EVIDÊNCIAS FOTOGRÁFICAS'),
    ];

    if (photos.isEmpty) {
      widgets.add(_empty('Nenhuma evidência fotográfica anexada.'));
    } else {
      for (var i = 0; i < photos.length; i += 2) {
        final left = await _photo(
          photos[i].path,
          'Foto ${i + 1} - ${nc.code}',
        );
        pw.Widget right = pw.SizedBox();
        if (i + 1 < photos.length) {
          right = await _photo(
            photos[i + 1].path,
            'Foto ${i + 2} - ${nc.code}',
          );
        }
        widgets.add(
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(child: left),
              pw.SizedBox(width: 10),
              pw.Expanded(child: right),
            ],
          ),
        );
        widgets.add(pw.SizedBox(height: 8));
      }
    }

    widgets.addAll([
      pw.SizedBox(height: 14),
      _section('PLANO DE AÇÃO VINCULADO'),
    ]);

    if (actions.isEmpty) {
      widgets.add(_empty('Nenhum plano de ação foi criado para esta NC.'));
    } else {
      for (var i = 0; i < actions.length; i++) {
        final action = actions[i];
        final actionColor = _statusColor(action.status);
        widgets.add(
          pw.Container(
            margin: const pw.EdgeInsets.only(bottom: 8),
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: _line),
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Row(
                  children: [
                    pw.Expanded(
                      child: pw.Text(
                        'AÇÃO ${i + 1}',
                        style: pw.TextStyle(
                          fontSize: 9,
                          fontWeight: pw.FontWeight.bold,
                          color: _navy,
                        ),
                      ),
                    ),
                    pw.Container(
                      padding: const pw.EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 3,
                      ),
                      decoration: pw.BoxDecoration(
                        color: _soft(actionColor),
                        border: pw.Border.all(color: actionColor),
                        borderRadius: pw.BorderRadius.circular(9),
                      ),
                      child: pw.Text(
                        action.status,
                        style: pw.TextStyle(
                          fontSize: 6.5,
                          fontWeight: pw.FontWeight.bold,
                          color: actionColor,
                        ),
                      ),
                    ),
                  ],
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  action.correctiveAction,
                  style: const pw.TextStyle(fontSize: 8.5),
                ),
                pw.SizedBox(height: 7),
                pw.Row(
                  children: [
                    pw.Expanded(
                      child: _mini(
                        'RESPONSÁVEL',
                        action.responsible.isEmpty ? '-' : action.responsible,
                      ),
                    ),
                    pw.SizedBox(width: 8),
                    pw.Expanded(child: _mini('PRIORIDADE', action.priority)),
                    pw.SizedBox(width: 8),
                    pw.Expanded(
                      child: _mini(
                        'PRAZO',
                        action.dueDate == null
                            ? '-'
                            : DateFormat('dd/MM/yyyy').format(action.dueDate!),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(34, 34, 34, 40),
        header: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 7),
          decoration: const pw.BoxDecoration(
            border: pw.Border(bottom: pw.BorderSide(color: _line)),
          ),
          child: pw.Row(
            children: [
              if (icon != null)
                pw.Container(
                  width: 22,
                  height: 22,
                  child: pw.Image(icon, fit: pw.BoxFit.contain),
                ),
              if (icon != null) pw.SizedBox(width: 6),
              pw.Expanded(
                child: pw.Text(
                  'AUDITAR SST  |  RELATÓRIO DE NÃO CONFORMIDADE',
                  style: pw.TextStyle(
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold,
                    color: _navy,
                  ),
                ),
              ),
              pw.Text(
                nc.code,
                style: pw.TextStyle(
                  fontSize: 8,
                  fontWeight: pw.FontWeight.bold,
                  color: _red,
                ),
              ),
            ],
          ),
        ),
        footer: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 7),
          decoration: const pw.BoxDecoration(
            border: pw.Border(top: pw.BorderSide(color: _line)),
          ),
          child: pw.Row(
            children: [
              pw.Expanded(
                child: pw.Text(
                  'Auditar SST | ${row['company_name'] ?? ''}',
                  style: const pw.TextStyle(fontSize: 7, color: _grey),
                ),
              ),
              pw.Text(
                'Página ${context.pageNumber} de ${context.pagesCount}',
                style: const pw.TextStyle(fontSize: 7, color: _grey),
              ),
            ],
          ),
        ),
        build: (_) => widgets,
      ),
    );

    return doc.save();
  }

  static Future<pw.ImageProvider?> _asset(String path) async {
    try {
      final data = await rootBundle.load(path);
      return pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }

  static Future<pw.Widget> _photo(String path, String caption) async {
    final file = File(path);
    if (!await file.exists()) {
      return pw.Container(
        height: 145,
        alignment: pw.Alignment.center,
        decoration: pw.BoxDecoration(
          color: PdfColors.grey100,
          border: pw.Border.all(color: _line),
          borderRadius: pw.BorderRadius.circular(5),
        ),
        child: pw.Text(
          'Foto indisponível',
          style: const pw.TextStyle(fontSize: 7.5, color: _grey),
        ),
      );
    }

    final image = pw.MemoryImage(await file.readAsBytes());
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Container(
          height: 145,
          width: double.infinity,
          padding: const pw.EdgeInsets.all(3),
          decoration: pw.BoxDecoration(
            color: PdfColors.grey50,
            border: pw.Border.all(color: _line),
            borderRadius: pw.BorderRadius.circular(5),
          ),
          child: pw.Image(image, fit: pw.BoxFit.contain),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          caption,
          style: pw.TextStyle(
            fontSize: 6.8,
            fontWeight: pw.FontWeight.bold,
            color: _grey,
          ),
        ),
      ],
    );
  }

  static pw.Widget _section(String title) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(bottom: 6),
      margin: const pw.EdgeInsets.only(bottom: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: PdfColors.green300)),
      ),
      child: pw.Text(
        title,
        style: pw.TextStyle(
          fontSize: 11,
          fontWeight: pw.FontWeight.bold,
          color: _navy,
        ),
      ),
    );
  }

  static pw.Widget _table(List<List<String>> rows) {
    return pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        children: rows.asMap().entries.map((entry) {
          final row = entry.value;
          final index = entry.key;
          return pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 9, vertical: 6),
            decoration: pw.BoxDecoration(
              color: index.isEven ? PdfColors.grey50 : PdfColors.white,
              border: index == rows.length - 1
                  ? null
                  : const pw.Border(bottom: pw.BorderSide(color: PdfColors.grey200)),
            ),
            child: pw.Row(
              children: [
                pw.SizedBox(
                  width: 115,
                  child: pw.Text(
                    row[0],
                    style: pw.TextStyle(
                      fontSize: 7.3,
                      fontWeight: pw.FontWeight.bold,
                      color: _grey,
                    ),
                  ),
                ),
                pw.Expanded(
                  child: pw.Text(row[1], style: const pw.TextStyle(fontSize: 8)),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  static pw.Widget _box(String title, String value) {
    return pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 6),
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(5),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            title.toUpperCase(),
            style: pw.TextStyle(
              fontSize: 6.8,
              fontWeight: pw.FontWeight.bold,
              color: _grey,
            ),
          ),
          pw.SizedBox(height: 3),
          pw.Text(
            value.isEmpty ? '-' : value,
            style: const pw.TextStyle(fontSize: 8.5),
          ),
        ],
      ),
    );
  }

  static pw.Widget _highlight({
    required String title,
    required String value,
    required PdfColor color,
    required PdfColor softColor,
  }) {
    return pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 6),
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: softColor,
        border: pw.Border.all(color: color, width: .7),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            title.toUpperCase(),
            style: pw.TextStyle(
              fontSize: 6.8,
              fontWeight: pw.FontWeight.bold,
              color: color,
            ),
          ),
          pw.SizedBox(height: 3),
          pw.Text(value, style: const pw.TextStyle(fontSize: 8.5)),
        ],
      ),
    );
  }

  static pw.Widget _mini(String title, String value) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey50,
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(5),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            title,
            style: pw.TextStyle(
              fontSize: 6.2,
              fontWeight: pw.FontWeight.bold,
              color: _grey,
            ),
          ),
          pw.SizedBox(height: 2),
          pw.Text(value, style: const pw.TextStyle(fontSize: 7.5)),
        ],
      ),
    );
  }

  static pw.Widget _empty(String text) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(5),
      ),
      child: pw.Text(
        text,
        style: const pw.TextStyle(fontSize: 8, color: _grey),
      ),
    );
  }

  static PdfColor _statusColor(String status) {
    if (status == 'Concluído' || status == 'Concluída') return _green;
    if (status == 'Vencida' || status == 'Atrasada') return _red;
    if (status.contains('andamento') || status.contains('verificação')) {
      return _amber;
    }
    if (status == 'Pendente' || status == 'Aberta') return _red;
    return _grey;
  }

  static PdfColor _soft(PdfColor color) {
    if (color == _green) return PdfColors.green50;
    if (color == _red) return PdfColors.red50;
    if (color == _amber) return PdfColors.orange50;
    return PdfColors.grey100;
  }
}
