import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import '../database.dart';
import 'drive_service.dart';
import 'management_panel_service.dart';

class SyncCoordinator extends StatefulWidget {
  final Widget child;

  const SyncCoordinator({
    super.key,
    required this.child,
  });

  @override
  State<SyncCoordinator> createState() => _SyncCoordinatorState();
}

class _SyncCoordinatorState extends State<SyncCoordinator>
    with WidgetsBindingObserver {
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  bool _syncing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _subscription = Connectivity()
        .onConnectivityChanged
        .listen(_handleConnectivity);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _trySync();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _trySync();
    }
  }

  void _handleConnectivity(List<ConnectivityResult> results) {
    final hasNetwork = results.any(
      (result) => result != ConnectivityResult.none,
    );

    if (hasNetwork) {
      _trySync();
    }
  }

  Future<void> _trySync() async {
    if (_syncing) return;

    final connectivity = await Connectivity().checkConnectivity();
    if (!connectivity.any((result) => result != ConnectivityResult.none)) {
      return;
    }

    _syncing = true;

    try {
      await _syncManagementPanelsIfNeeded();
      await _syncDriveIfNeeded();
    } finally {
      _syncing = false;
    }
  }

  Future<void> _syncManagementPanelsIfNeeded() async {
    final db = AppDatabase.instance;
    final autoSync = await db.getSetting(
      'management_panel_auto_sync',
      fallback: 'true',
    );
    final endpoint = await db.getSetting('management_panel_endpoint');
    final syncKey = await db.getSetting('management_panel_sync_key');
    if (autoSync != 'true' ||
        endpoint.trim().isEmpty ||
        syncKey.trim().isEmpty) {
      return;
    }

    final lastValue = await db.getSetting('last_automatic_panel_sync');
    final last = DateTime.tryParse(lastValue);
    if (last != null && DateTime.now().difference(last).inHours < 6) return;

    final companies = await db.getCompanies();
    var attempted = false;
    for (final company in companies) {
      final panel = await db.ensureManagementPanel(company.id);
      if ((panel['enabled'] as int? ?? 1) != 1) continue;
      attempted = true;
      await ManagementPanelService.syncCompany(company);
    }
    if (attempted) {
      await db.setSetting(
        'last_automatic_panel_sync',
        DateTime.now().toIso8601String(),
      );
    }
  }

  Future<void> _syncDriveIfNeeded() async {
    final db = AppDatabase.instance;

    final driveEnabled = await db.getSetting(
      'drive_enabled',
      fallback: 'false',
    );

    final autoUpload = await db.getSetting(
      'drive_auto_upload',
      fallback: 'true',
    );

    if (driveEnabled != 'true' || autoUpload != 'true') {
      return;
    }

    final pending = await db.pendingDriveUploadsCount();
    if (pending == 0) return;

    try {
      // Não abre tela de login. Usa apenas autenticação leve já autorizada.
      await DriveService.syncPending(interactive: false);
    } catch (_) {
      // Os itens continuam na fila para a próxima tentativa.
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
