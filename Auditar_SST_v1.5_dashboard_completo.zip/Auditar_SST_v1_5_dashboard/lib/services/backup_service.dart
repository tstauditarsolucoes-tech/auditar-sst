import 'dart:convert';
import 'dart:io';

import 'package:archive/archive_io.dart';
import 'package:cross_file/cross_file.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../database.dart';

class BackupService {
  static const List<String> _dataFolders = <String>[
    'logos_empresas',
    'fotos_vistorias',
    'fotos_conclusao',
    'assinaturas',
    'relatorios',
  ];

  static Future<void> _copyDirectory(
    Directory source,
    Directory destination,
  ) async {
    if (!await source.exists()) return;

    if (!await destination.exists()) {
      await destination.create(recursive: true);
    }

    await for (final entity in source.list(recursive: false)) {
      final targetPath = p.join(
        destination.path,
        p.basename(entity.path),
      );

      if (entity is File) {
        await entity.copy(targetPath);
      } else if (entity is Directory) {
        await _copyDirectory(
          entity,
          Directory(targetPath),
        );
      }
    }
  }

  static Future<String> createBackup() async {
    final db = AppDatabase.instance;
    final databasePath = await db.databaseFilePath;
    final database = await db.database;

    try {
      await database.rawQuery('PRAGMA wal_checkpoint(FULL)');
    } catch (_) {}

    final documents = await getApplicationDocumentsDirectory();
    final temp = await getTemporaryDirectory();

    final stamp =
        DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());

    final stage = Directory(
      p.join(temp.path, 'auditar_sst_backup_$stamp'),
    );

    if (await stage.exists()) {
      await stage.delete(recursive: true);
    }
    await stage.create(recursive: true);

    final databaseStageDir = Directory(
      p.join(stage.path, 'database'),
    );
    await databaseStageDir.create(recursive: true);

    final sourceDb = File(databasePath);
    if (!await sourceDb.exists()) {
      throw Exception('Banco de dados do aplicativo não encontrado.');
    }

    await sourceDb.copy(
      p.join(databaseStageDir.path, 'auditar_sst.db'),
    );

    for (final folderName in _dataFolders) {
      final source = Directory(
        p.join(documents.path, folderName),
      );

      if (await source.exists()) {
        await _copyDirectory(
          source,
          Directory(p.join(stage.path, folderName)),
        );
      }
    }

    final manifest = <String, Object?>{
      'app': 'Auditar SST',
      'backup_format': 2,
      'created_at': DateTime.now().toIso8601String(),
      'documents_path': documents.path,
      'database_file': 'database/auditar_sst.db',
      'folders': _dataFolders,
    };

    await File(p.join(stage.path, 'manifest.json')).writeAsString(
      const JsonEncoder.withIndent('  ').convert(manifest),
      flush: true,
    );

    final backupDir = Directory(
      p.join(documents.path, 'backups'),
    );
    if (!await backupDir.exists()) {
      await backupDir.create(recursive: true);
    }

    final zipPath = p.join(
      backupDir.path,
      'Auditar_SST_Backup_Completo_$stamp.zip',
    );

    final encoder = ZipFileEncoder();
    encoder.create(zipPath);
    await encoder.addDirectory(
      stage,
      includeDirName: false,
    );
    await encoder.close();

    await stage.delete(recursive: true);

    return zipPath;
  }

  static Future<void> shareBackup() async {
    final backupPath = await createBackup();

    await Share.shareXFiles(
      [XFile(backupPath)],
      subject: 'Backup completo Auditar SST',
      text: 'Backup completo do aplicativo Auditar SST.',
    );
  }

  static Future<bool> restoreBackup() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      allowMultiple: false,
    );

    if (result == null || result.files.single.path == null) {
      return false;
    }

    final selectedPath = result.files.single.path!;
    final selectedFile = File(selectedPath);

    if (!await selectedFile.exists()) {
      throw Exception('Arquivo de backup não encontrado.');
    }

    final temp = await getTemporaryDirectory();
    final restoreDir = Directory(
      p.join(
        temp.path,
        'auditar_sst_restore_${DateTime.now().millisecondsSinceEpoch}',
      ),
    );

    if (await restoreDir.exists()) {
      await restoreDir.delete(recursive: true);
    }
    await restoreDir.create(recursive: true);

    await extractFileToDisk(
      selectedPath,
      restoreDir.path,
    );

    final manifestFile = File(
      p.join(restoreDir.path, 'manifest.json'),
    );
    final restoredDb = File(
      p.join(
        restoreDir.path,
        'database',
        'auditar_sst.db',
      ),
    );

    if (!await manifestFile.exists() || !await restoredDb.exists()) {
      await restoreDir.delete(recursive: true);
      throw Exception(
        'Este arquivo não é um backup completo válido do Auditar SST.',
      );
    }

    final manifest = jsonDecode(
      await manifestFile.readAsString(),
    ) as Map<String, dynamic>;

    final oldDocumentsPath =
        (manifest['documents_path'] as String?) ?? '';

    final db = AppDatabase.instance;
    final targetDatabasePath = await db.databaseFilePath;
    final documents = await getApplicationDocumentsDirectory();

    await db.closeForFileOperation();

    final targetDbFile = File(targetDatabasePath);
    if (await targetDbFile.exists()) {
      await targetDbFile.delete();
    }
    await restoredDb.copy(targetDatabasePath);

    for (final folderName in _dataFolders) {
      final extractedFolder = Directory(
        p.join(restoreDir.path, folderName),
      );

      final targetFolder = Directory(
        p.join(documents.path, folderName),
      );

      if (await targetFolder.exists()) {
        await targetFolder.delete(recursive: true);
      }

      if (await extractedFolder.exists()) {
        await _copyDirectory(
          extractedFolder,
          targetFolder,
        );
      }
    }

    await db.reopen();
    await db.remapStoredPaths(
      oldDocumentsPath: oldDocumentsPath,
      newDocumentsPath: documents.path,
    );

    await restoreDir.delete(recursive: true);

    return true;
  }
}
