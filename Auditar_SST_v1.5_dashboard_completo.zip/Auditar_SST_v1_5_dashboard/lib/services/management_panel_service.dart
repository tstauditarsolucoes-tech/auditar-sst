import 'dart:convert';

import '../database.dart';
import '../models.dart';
import 'apps_script_http.dart';

class ManagementPanelSyncResult {
  final bool success;
  final String message;

  const ManagementPanelSyncResult({
    required this.success,
    required this.message,
  });
}

class ManagementPanelService {
  static Future<String> panelUrlForCompany(String companyId) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty) return '';

    final panel = await db.ensureManagementPanel(companyId);
    final token = '${panel['access_token'] ?? ''}'.trim();
    if (token.isEmpty) return '';

    final separator = endpoint.contains('?') ? '&' : '?';
    return '$endpoint${separator}empresa=${Uri.encodeQueryComponent(token)}';
  }

  static Future<Map<String, Object?>> buildSnapshot(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final panel = await db.ensureManagementPanel(company.id);
    final summary = await db.getDashboardSummary(companyId: company.id);
    final sectorPerformance =
        await db.getCompanySectorPerformance(company.id);
    final trainingSummary =
        await db.getTrainingSummary(companyId: company.id);
    final workers = await db.getWorkers(companyId: company.id);
    final companySectors = await db.getSectors(company.id);
    final trainings = await db.getTrainingControls(companyId: company.id);
    final missingTrainings =
        await db.getMissingRequiredTrainings(companyId: company.id);
    final ncs = await db.getNonConformityRows(
      companyId: company.id,
      includeClosed: false,
    );
    final allNcs = await db.getNonConformityRows(
      companyId: company.id,
      includeClosed: true,
    );
    final actions = await db.getPendingActions(
      companyId: company.id,
      includeCompleted: false,
    );
    final allActions = await db.getPendingActions(
      companyId: company.id,
      includeCompleted: true,
    );
    final inspections =
        await db.getInspectionHistory(companyId: company.id);
    final extinguishers = await db.getSstRecords(
      type: 'EXTINTOR',
      companyId: company.id,
    );
    final safetyObservations = await db.getSstRecords(
      type: 'OBSERVACAO_SEGURANCA',
      companyId: company.id,
    );
    final improvements = await db.getSstRecords(
      type: 'MELHORIA',
      companyId: company.id,
    );
    final snapshotNow = DateTime.now();
    final currentMonthStart =
        DateTime(snapshotNow.year, snapshotNow.month, 1);
    final previousMonthStart =
        DateTime(currentMonthStart.year, currentMonthStart.month - 1, 1);
    final previousMonthEnd =
        currentMonthStart.subtract(const Duration(days: 1));
    final currentMonthSummary = await db.getDashboardSummary(
      companyId: company.id,
      startDate: currentMonthStart,
      endDate: snapshotNow,
    );
    final monthlySummary = await db.getDashboardSummary(
      companyId: company.id,
      startDate: previousMonthStart,
      endDate: previousMonthEnd,
    );
    final monthlyInspections = inspections.where((row) {
      final date = DateTime.tryParse('${row['date'] ?? ''}');
      return date != null &&
          !date.isBefore(previousMonthStart) &&
          date.isBefore(currentMonthStart);
    }).toList();

    final enabled = enabledOverride ?? ((panel['enabled'] as int? ?? 1) == 1);
    final now = DateTime.now();

    Worker? workerFor(String id) {
      for (final worker in workers) {
        if (worker.id == id) return worker;
      }
      return null;
    }

    int daysUntil(DateTime date) {
      final today = DateTime(now.year, now.month, now.day);
      return DateTime(date.year, date.month, date.day).difference(today).inDays;
    }

    Map<String, Object?> cleanSector(Map<String, Object?> row) => {
          'name': '${row['name'] ?? ''}',
          'inspections': _asInt(row['inspections']),
          'conformes': _asInt(row['conformes']),
          'parciais': _asInt(row['parciais']),
          'naoConformes': _asInt(row['nao_conformes']),
          'naoAplicaveis': _asInt(row['nao_aplicaveis']),
          'openNcs': _asInt(row['open_ncs']),
          'overdueNcs': _asInt(row['overdue_ncs']),
          'latestInspection': '${row['latest_inspection'] ?? ''}',
        };

    Map<String, Object?> cleanNc(Map<String, Object?> row) => {
          'code': '${row['code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'classification': '${row['classification'] ?? ''}',
          'description': '${row['description'] ?? ''}',
          'risk': '${row['risk_identified'] ?? ''}',
          'recommendation': '${row['recommendation'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'createdAt': '${row['created_at'] ?? ''}',
          'verifiedAt': '${row['verified_at'] ?? ''}',
          'verifiedBy': '${row['verified_by'] ?? ''}',
          'nextDueDate': '${row['next_due_date'] ?? ''}',
          'openActionCount': _asInt(row['open_action_count']),
        };

    Map<String, Object?> cleanAction(Map<String, Object?> row) => {
          'ncCode': '${row['nc_code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'priority': '${row['priority'] ?? ''}',
          'problem': '${row['non_conformity'] ?? ''}',
          'correctiveAction': '${row['corrective_action'] ?? ''}',
          'responsible': '${row['responsible'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'dueDate': '${row['due_date'] ?? ''}',
          'completionDate': '${row['completion_date'] ?? ''}',
          'completedBy': '${row['completed_by'] ?? ''}',
        };

    Map<String, Object?> cleanInspection(Map<String, Object?> row) => {
          'reportNumber': '${row['report_number'] ?? ''}',
          'date': '${row['date'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'checklistType': '${row['checklist_type'] ?? ''}',
        };

    Map<String, Object?> cleanTraining(TrainingControl training) {
      final worker = workerFor(training.workerId);
      final expiry = training.expiryDate;
      return {
        'id': training.id,
        'worker': worker?.name ?? '',
        'role': worker?.role ?? '',
        'code': training.code,
        'title': training.title,
        'expiryDate': expiry?.toIso8601String() ?? '',
        'daysUntilExpiry': expiry == null ? null : daysUntil(expiry),
        'status': training.statusAt(now),
      };
    }

    Map<String, Object?> cleanMedical(Worker worker) {
      final nextExam = worker.nextMedicalExamDate;
      return {
        'workerId': worker.id,
        'worker': worker.name,
        'role': worker.role,
        'nextExamDate': nextExam?.toIso8601String() ?? '',
        'daysUntilExpiry': nextExam == null ? null : daysUntil(nextExam),
      };
    }

    String sectorNameFor(String? sectorId) {
      if (sectorId == null) return '';
      for (final sector in companySectors) {
        if (sector.id == sectorId) return sector.name;
      }
      return '';
    }

    DateTime? payloadDate(SstRecord record, String key) {
      final raw = '${record.payload[key] ?? ''}'.trim();
      return raw.isEmpty ? null : DateTime.tryParse(raw);
    }

    String extinguisherStatus(SstRecord record) {
      final payload = record.payload;
      if (payload['locationEmpty'] == true) return 'LOCAL SEM EXTINTOR';
      final operational = '${payload['operationalStatus'] ?? ''}'.toUpperCase();
      if (operational == 'INATIVO') return 'INATIVO';
      if (operational == 'EM MANUTENÇÃO' || operational == 'EM MANUTENCAO') {
        return 'EM MANUTENÇÃO';
      }
      final checks = [
        payload['sealOk'],
        payload['gaugeOk'],
        payload['signageOk'],
        payload['accessOk'],
        payload['hoseNozzleOk'],
      ];
      if (checks.any((value) => value == false)) return 'IRREGULAR';
      final expiry = payloadDate(record, 'expiryDate') ?? record.dueDate;
      final hydro = payloadDate(record, 'hydrostaticExpiryDate');
      final today = DateTime(now.year, now.month, now.day);
      DateTime day(DateTime date) => DateTime(date.year, date.month, date.day);
      if ((expiry != null && day(expiry).isBefore(today)) ||
          (hydro != null && day(hydro).isBefore(today))) {
        return 'VENCIDO';
      }
      final dueSoon = [expiry, hydro].whereType<DateTime>().any((date) {
        final days = day(date).difference(today).inDays;
        return days >= 0 && days <= 30;
      });
      return dueSoon ? 'VENCE EM BREVE' : 'EM DIA';
    }

    Map<String, Object?> cleanExtinguisher(SstRecord record) {
      final payload = record.payload;
      return {
        'id': record.id,
        'code': '${payload['code'] ?? record.title}',
        'type': '${payload['extinguisherType'] ?? ''}',
        'capacity': '${payload['capacity'] ?? ''}',
        'sector': '${payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
        'location': '${payload['location'] ?? ''}',
        'manufacturer': '${payload['manufacturer'] ?? ''}',
        'cylinderNumber': '${payload['cylinderNumber'] ?? ''}',
        'rechargeDate': '${payload['rechargeDate'] ?? ''}',
        'expiryDate': '${payload['expiryDate'] ?? record.dueDate?.toIso8601String() ?? ''}',
        'hydrostaticExpiryDate': '${payload['hydrostaticExpiryDate'] ?? ''}',
        'status': extinguisherStatus(record),
        'responsibility': '${payload['responsibility'] ?? ''}',
        'responsibleName': '${payload['responsibleName'] ?? ''}',
        'actionStatus': '${payload['actionStatus'] ?? ''}',
        'locationEmpty': payload['locationEmpty'] == true,
        'lastReplacementReason': '${payload['lastReplacementReason'] ?? ''}',
        'lastReplacementDate': '${payload['lastReplacementDate'] ?? ''}',
        'replacementDetails': '${payload['replacementDetails'] ?? ''}',
        'replacementHistoryCount': payload['replacementHistory'] is List
            ? (payload['replacementHistory'] as List).length
            : 0,
        'lastInspectionDate': '${payload['lastInspectionDate'] ?? record.date.toIso8601String()}',
        'notes': '${payload['notes'] ?? ''}',
      };
    }

    final extinguisherRows = extinguishers.map(cleanExtinguisher).toList();
    int extinguisherCount(String status) => extinguisherRows
        .where((row) => '${row['status']}' == status)
        .length;
    final extinguisherSummary = <String, Object?>{
      'total': extinguisherRows.length,
      'current': extinguisherCount('EM DIA'),
      'dueSoon': extinguisherCount('VENCE EM BREVE'),
      'expired': extinguisherCount('VENCIDO'),
      'irregular': extinguisherCount('IRREGULAR'),
      'maintenance': extinguisherCount('EM MANUTENÇÃO'),
      'missingLocations': extinguisherCount('LOCAL SEM EXTINTOR'),
      'inactive': extinguisherCount('INATIVO'),
    };

    bool safetyClosed(SstRecord record) =>
        record.status.toLowerCase().contains('resolvid') ||
        record.status.toLowerCase().contains('conclu');

    bool safetyOverdue(SstRecord record) {
      final due = record.dueDate;
      if (due == null || safetyClosed(record)) return false;
      final today = DateTime(now.year, now.month, now.day);
      final day = DateTime(due.year, due.month, due.day);
      return day.isBefore(today);
    }

    String safetyKind(SstRecord record) =>
        '${record.payload['observationKind'] ?? 'Condição insegura'}';

    Map<String, Object?> cleanSafetyObservation(SstRecord record) {
      final payload = record.payload;
      return {
        'id': record.id,
        'kind': safetyKind(record),
        'title': record.title,
        'date': record.date.toIso8601String(),
        'dueDate': record.dueDate?.toIso8601String() ?? '',
        'status': record.status,
        'priority': record.priority,
        'overdue': safetyOverdue(record),
        'sector': '${payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
        'location': '${payload['location'] ?? ''}',
        'description': '${payload['description'] ?? ''}',
        'risk': '${payload['risk'] ?? ''}',
        'possibleConsequence': '${payload['possibleConsequence'] ?? ''}',
        'recommendation': '${payload['recommendation'] ?? ''}',
        'immediateAction': '${payload['immediateAction'] ?? ''}',
        'responsible': '${payload['responsible'] ?? ''}',
        'resolvedAt': '${payload['resolvedAt'] ?? ''}',
      };
    }

    final safetyRows = safetyObservations.map(cleanSafetyObservation).toList();
    final safetySummary = <String, Object?>{
      'total': safetyRows.length,
      'open': safetyObservations.where((record) => !safetyClosed(record)).length,
      'resolved': safetyObservations.where(safetyClosed).length,
      'conditions': safetyObservations
          .where((record) => safetyKind(record) == 'Condição insegura')
          .length,
      'acts': safetyObservations
          .where((record) => safetyKind(record) == 'Ato inseguro')
          .length,
      'criticalOpen': safetyObservations
          .where((record) => !safetyClosed(record) && record.priority == 'Crítica')
          .length,
      'overdue': safetyObservations.where(safetyOverdue).length,
      'criticalOrOverdue': safetyObservations
          .where((record) =>
              !safetyClosed(record) &&
              (record.priority == 'Crítica' || safetyOverdue(record)))
          .length,
    };


    bool improvementRealized(SstRecord record) =>
        record.status.toLowerCase().contains('realiz') ||
        record.status.toLowerCase().contains('conclu');

    bool improvementOverdue(SstRecord record) {
      final due = record.dueDate;
      if (due == null || improvementRealized(record)) return false;
      final today = DateTime(now.year, now.month, now.day);
      final day = DateTime(due.year, due.month, due.day);
      return day.isBefore(today);
    }

    DateTime? improvementCompletedDate(SstRecord record) {
      final raw = '${record.payload['completedDate'] ?? ''}'.trim();
      return raw.isEmpty ? null : DateTime.tryParse(raw);
    }

    Map<String, Object?> cleanImprovement(SstRecord record) {
      final payload = record.payload;
      final beforePath = '${payload['beforePhotoPath'] ?? ''}'.trim();
      final afterPath = '${payload['afterPhotoPath'] ?? ''}'.trim();
      return {
        'id': record.id,
        'title': record.title,
        'date': record.date.toIso8601String(),
        'dueDate': record.dueDate?.toIso8601String() ?? '',
        'completedDate': '${payload['completedDate'] ?? ''}',
        'status': record.status,
        'priority': record.priority,
        'overdue': improvementOverdue(record),
        'sector': '${payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
        'location': '${payload['location'] ?? ''}',
        'beforeSituation': '${payload['beforeSituation'] ?? ''}',
        'suggestion': '${payload['suggestion'] ?? ''}',
        'expectedBenefit': '${payload['expectedBenefit'] ?? ''}',
        'workPerformed': '${payload['workPerformed'] ?? ''}',
        'result': '${payload['result'] ?? ''}',
        'responsible': '${payload['responsible'] ?? ''}',
        'hasBeforePhoto': beforePath.isNotEmpty,
        'hasAfterPhoto': afterPath.isNotEmpty,
        'hasBeforeAfter': beforePath.isNotEmpty && afterPath.isNotEmpty,
      };
    }

    final improvementRows = improvements.map(cleanImprovement).toList();
    final improvementSummary = <String, Object?>{
      'total': improvements.length,
      'suggested': improvements.where((record) => record.status == 'Sugerida').length,
      'planned': improvements.where((record) => record.status == 'Planejada').length,
      'inProgress': improvements.where((record) => record.status == 'Em execução').length,
      'realized': improvements.where(improvementRealized).length,
      'overdue': improvements.where(improvementOverdue).length,
      'withBeforeAfter': improvements.where((record) {
        final beforePath = '${record.payload['beforePhotoPath'] ?? ''}'.trim();
        final afterPath = '${record.payload['afterPhotoPath'] ?? ''}'.trim();
        return beforePath.isNotEmpty && afterPath.isNotEmpty;
      }).length,
    };


    DateTime? rowDate(Map<String, Object?> row, String key) {
      final raw = '${row[key] ?? ''}'.trim();
      return raw.isEmpty ? null : DateTime.tryParse(raw);
    }

    DateTime endOfDay(DateTime date) =>
        DateTime(date.year, date.month, date.day, 23, 59, 59, 999);

    int openNcsAt(DateTime asOf) {
      final limit = endOfDay(asOf);
      return allNcs.where((row) {
        final created = rowDate(row, 'created_at');
        if (created == null || created.isAfter(limit)) return false;
        final verified = rowDate(row, 'verified_at');
        final concluded = '${row['status'] ?? ''}'
            .toLowerCase()
            .contains('conclu');
        if (verified != null) return verified.isAfter(limit);
        if (concluded) return false;
        return true;
      }).length;
    }

    int overdueActionsAt(DateTime asOf) {
      final limit = endOfDay(asOf);
      return allActions.where((row) {
        final due = rowDate(row, 'due_date');
        if (due == null || !due.isBefore(limit)) return false;
        final completed = rowDate(row, 'completion_date');
        return completed == null || completed.isAfter(limit);
      }).length;
    }

    int expiredTrainingsAt(DateTime asOf) {
      final limit = endOfDay(asOf);
      final latestByWorkerAndTraining = <String, TrainingControl>{};
      for (final training in trainings) {
        final trainingDate = training.trainingDate;
        if (trainingDate == null || trainingDate.isAfter(limit)) continue;
        final key = '${training.workerId}::${training.code.toUpperCase()}';
        final current = latestByWorkerAndTraining[key];
        if (current == null ||
            (current.trainingDate != null &&
                trainingDate.isAfter(current.trainingDate!))) {
          latestByWorkerAndTraining[key] = training;
        }
      }
      return latestByWorkerAndTraining.values.where((training) {
        final expiry = training.expiryDate;
        return expiry != null && expiry.isBefore(limit);
      }).length;
    }

    int? sstScoreFor(Map<String, int> periodSummary, DateTime asOf) {
      if ((periodSummary['inspections'] ?? 0) <= 0) return null;
      final conformity = periodSummary['conformity'] ?? 0;
      final ncHealth = (100 - openNcsAt(asOf) * 12).clamp(0, 100);
      final actionHealth =
          (100 - overdueActionsAt(asOf) * 20).clamp(0, 100);
      final trainingHealth =
          (100 - expiredTrainingsAt(asOf) * 12).clamp(0, 100);
      return (conformity * .70 +
              ncHealth * .10 +
              actionHealth * .10 +
              trainingHealth * .10)
          .round()
          .clamp(0, 100)
          .toInt();
    }

    final currentOpenNcs = openNcsAt(snapshotNow);
    final previousOpenNcs = openNcsAt(previousMonthEnd);
    final currentOverdueActions = overdueActionsAt(snapshotNow);
    final previousOverdueActions = overdueActionsAt(previousMonthEnd);
    final currentExpiredTrainings = expiredTrainingsAt(snapshotNow);
    final previousExpiredTrainings = expiredTrainingsAt(previousMonthEnd);
    final currentScoreBase = (currentMonthSummary['inspections'] ?? 0) > 0
        ? currentMonthSummary
        : summary;
    final currentSstScore = sstScoreFor(currentScoreBase, snapshotNow);
    final previousSstScore =
        sstScoreFor(monthlySummary, previousMonthEnd);

    final monthlyTrend = <Map<String, Object?>>[];
    for (var offset = 5; offset >= 0; offset--) {
      final monthStart = DateTime(snapshotNow.year, snapshotNow.month - offset, 1);
      final nextMonth = DateTime(monthStart.year, monthStart.month + 1, 1);
      final monthEnd = offset == 0
          ? snapshotNow
          : nextMonth.subtract(const Duration(days: 1));
      final monthSummary = await db.getDashboardSummary(
        companyId: company.id,
        startDate: monthStart,
        endDate: monthEnd,
      );
      monthlyTrend.add({
        'year': monthStart.year,
        'month': monthStart.month,
        'label': '${monthStart.month.toString().padLeft(2, '0')}/${monthStart.year.toString().substring(2)}',
        'inspections': monthSummary['inspections'] ?? 0,
        'conformity': (monthSummary['inspections'] ?? 0) > 0
            ? monthSummary['conformity']
            : null,
        'score': sstScoreFor(monthSummary, monthEnd),
      });
    }

    final recentActivities = <Map<String, Object?>>[];
    void addActivity({
      required DateTime? date,
      required String type,
      required String title,
      String detail = '',
    }) {
      if (date == null) return;
      recentActivities.add({
        'date': date.toIso8601String(),
        'type': type,
        'title': title,
        'detail': detail,
      });
    }

    for (final row in inspections.take(20)) {
      addActivity(
        date: rowDate(row, 'date'),
        type: 'Vistoria',
        title: 'Vistoria realizada',
        detail: [
          '${row['sector_name'] ?? ''}',
          '${row['area'] ?? ''}',
          '${row['report_number'] ?? ''}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final row in allActions) {
      final completed = rowDate(row, 'completion_date');
      if (completed == null) continue;
      addActivity(
        date: completed,
        type: 'Ação',
        title: 'Ação corretiva concluída',
        detail: [
          '${row['nc_code'] ?? ''}',
          '${row['responsible'] ?? row['completed_by'] ?? ''}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final row in allNcs) {
      final verified = rowDate(row, 'verified_at');
      if (verified == null) continue;
      addActivity(
        date: verified,
        type: 'NC',
        title: 'Não conformidade verificada',
        detail: [
          '${row['code'] ?? ''}',
          '${row['sector_name'] ?? ''}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final record in extinguishers) {
      final payload = record.payload;
      final action = '${payload['actionStatus'] ?? ''}'.trim();
      final replacementReason = '${payload['lastReplacementReason'] ?? ''}'.trim();
      final replacementDate = payloadDate(record, 'lastReplacementDate');
      if (replacementDate != null &&
          replacementReason.isNotEmpty &&
          replacementReason != 'Nenhuma') {
        addActivity(
          date: replacementDate,
          type: 'Extintor',
          title: 'Extintor substituído',
          detail: [
            '${payload['code'] ?? record.title}',
            '${payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
            replacementReason,
          ].where((value) => value.trim().isNotEmpty).join(' • '),
        );
      }
      addActivity(
        date: payloadDate(record, 'lastInspectionDate') ?? record.date,
        type: 'Extintor',
        title: payload['locationEmpty'] == true
            ? 'Ponto sem extintor'
            : (action.isNotEmpty ? action : 'Extintor conferido'),
        detail: [
          '${payload['code'] ?? record.title}',
          '${payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
          '${payload['location'] ?? ''}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final record in safetyObservations) {
      addActivity(
        date: record.date,
        type: 'Segurança',
        title: '${safetyKind(record)} registrada',
        detail: [
          record.title,
          '${record.payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final record in improvements) {
      final realized = improvementRealized(record);
      addActivity(
        date: realized ? (improvementCompletedDate(record) ?? record.date) : record.date,
        type: 'Melhoria',
        title: realized ? 'Melhoria realizada' : 'Sugestão de melhoria registrada',
        detail: [
          record.title,
          '${record.payload['sectorName'] ?? sectorNameFor(record.sectorId)}',
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    for (final training in trainings) {
      final trainingDate = training.trainingDate;
      if (trainingDate == null) continue;
      final worker = workerFor(training.workerId);
      addActivity(
        date: trainingDate,
        type: 'Treinamento',
        title: 'Treinamento registrado',
        detail: [
          worker?.name ?? '',
          [training.code, training.title]
              .where((value) => value.trim().isNotEmpty)
              .join(' • '),
        ].where((value) => value.trim().isNotEmpty).join(' • '),
      );
    }
    recentActivities.sort((a, b) {
      final aDate = DateTime.tryParse('${a['date'] ?? ''}') ?? DateTime(1900);
      final bDate = DateTime.tryParse('${b['date'] ?? ''}') ?? DateTime(1900);
      return bDate.compareTo(aDate);
    });

    final workforceDetails = workers.map((worker) {
      final workerTrainings = trainings
          .where((training) => training.workerId == worker.id)
          .toList();
      final missingCount = missingTrainings
          .where((row) => (row['worker'] as Worker).id == worker.id)
          .length;
      final currentCount = workerTrainings
          .where((training) => training.statusAt(now) == 'EM DIA')
          .length;
      final expiredCount = workerTrainings
          .where((training) => training.statusAt(now) == 'VENCIDO')
          .length;
      final pendingCount = workerTrainings
          .where((training) => training.statusAt(now) == 'PENDENTE')
          .length;
      final dueSoonCount = workerTrainings.where((training) {
        final expiry = training.expiryDate;
        if (expiry == null || training.statusAt(now) != 'EM DIA') return false;
        final days = daysUntil(expiry);
        return days >= 0 && days <= 30;
      }).length;
      final trainingStatus = expiredCount > 0
          ? 'VENCIDO'
          : missingCount + pendingCount > 0
              ? 'PENDENTE'
              : dueSoonCount > 0
                  ? 'PRÓXIMO'
                  : 'EM DIA';
      final nextExam = worker.nextMedicalExamDate;
      final medicalDays = nextExam == null ? null : daysUntil(nextExam);
      final medicalStatus = medicalDays == null
          ? 'SEM DATA'
          : medicalDays < 0
              ? 'VENCIDO'
              : medicalDays <= 30
                  ? 'PRÓXIMO'
                  : 'EM DIA';
      return {
        'worker': worker.name,
        'role': worker.role,
        'sector': sectorNameFor(worker.sectorId),
        'trainingStatus': trainingStatus,
        'trainingDetails': '$currentCount em dia • $expiredCount vencido(s) • '
            '${missingCount + pendingCount} pendente(s)',
        'currentTrainings': currentCount,
        'expiredTrainings': expiredCount,
        'pendingTrainings': missingCount + pendingCount,
        'dueSoonTrainings': dueSoonCount,
        'nextExamDate': nextExam?.toIso8601String() ?? '',
        'medicalStatus': medicalStatus,
      };
    }).toList();

    return {
      'schemaVersion': 9,
      'accessToken': '${panel['access_token'] ?? ''}',
      'enabled': enabled,
      'updatedAt': DateTime.now().toIso8601String(),
      'company': {
        'id': company.id,
        'name': company.name,
        'city': company.city ?? '',
        'uf': company.uf ?? '',
        'contact': company.reportRecipient.isNotEmpty
            ? company.reportRecipient
            : (company.contact ?? ''),
      },
      'notifications': {
        'primaryEmail': company.reportEmail,
        'secondaryEmail': company.secondaryReportEmail,
        'monthlyReportEnabled': company.monthlyReportEnabled,
        'monthlyReportDay': company.monthlyReportDay,
        'trainingAlertsEnabled': company.trainingAlertsEnabled,
        'medicalAlertsEnabled': company.medicalAlertsEnabled,
      },
      'summary': summary,
      'periodComparison': {
        'currentStart': currentMonthStart.toIso8601String(),
        'currentEnd': snapshotNow.toIso8601String(),
        'currentSummary': currentMonthSummary,
        'previousStart': previousMonthStart.toIso8601String(),
        'previousEnd': previousMonthEnd.toIso8601String(),
        'previousSummary': monthlySummary,
        'currentMetrics': {
          'openNc': currentOpenNcs,
          'overdueActions': currentOverdueActions,
          'expiredTrainings': currentExpiredTrainings,
          'sstScore': currentSstScore,
        },
        'previousMetrics': {
          'openNc': previousOpenNcs,
          'overdueActions': previousOverdueActions,
          'expiredTrainings': previousExpiredTrainings,
          'sstScore': previousSstScore,
        },
      },
      'sstScore': {
        'value': currentSstScore,
        'previousValue': previousSstScore,
        'isCurrentMonth': (currentMonthSummary['inspections'] ?? 0) > 0,
        'method': 'Indicador gerencial interno Auditar: conformidade, NCs abertas, ações vencidas e treinamentos vencidos.',
      },
      'monthlyTrend': monthlyTrend,
      'recentActivities': recentActivities.take(12).toList(),
      'monthlyReport': {
        'periodStart': previousMonthStart.toIso8601String(),
        'periodEnd': previousMonthEnd.toIso8601String(),
        'summary': monthlySummary,
        'inspections': monthlyInspections.map(cleanInspection).toList(),
      },
      'trainingSummary': trainingSummary,
      'extinguisherSummary': extinguisherSummary,
      'extinguishers': extinguisherRows,
      'companySectors': companySectors
          .map((sector) => {'id': sector.id, 'name': sector.name})
          .toList(),
      'safetyObservationSummary': safetySummary,
      'safetyObservations': safetyRows,
      'improvementSummary': improvementSummary,
      'improvements': improvementRows,
      'workforceSummary': {
        'activeWorkers': workers.length,
        'missingRequiredTrainings': missingTrainings.length,
        'medicalRegular': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          return nextExam != null && daysUntil(nextExam) > 30;
        }).length,
        'medicalDueSoon': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          if (nextExam == null) return false;
          final days = daysUntil(nextExam);
          return days >= 0 && days <= 30;
        }).length,
        'medicalExpired': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          return nextExam != null && daysUntil(nextExam) < 0;
        }).length,
        'medicalNoDate': workers
            .where((worker) => worker.nextMedicalExamDate == null)
            .length,
      },
      'trainingRecords': trainings.map(cleanTraining).toList(),
      'trainingAlerts': trainings.where((training) {
        if (training.trainingDate == null) return true;
        final expiry = training.expiryDate;
        return expiry != null && daysUntil(expiry) <= 30;
      }).map(cleanTraining).toList(),
      'missingRequiredTrainings': missingTrainings.map((row) {
        final worker = row['worker'] as Worker;
        final requirement = row['requirement'] as TrainingRequirement;
        return {
          'workerId': worker.id,
          'worker': worker.name,
          'role': worker.role,
          'code': requirement.code,
          'title': requirement.title,
        };
      }).toList(),
      'medicalExams': workers.map(cleanMedical).toList(),
      'workforceDetails': workforceDetails,
      'medicalAlerts': workers.where((worker) {
        final nextExam = worker.nextMedicalExamDate;
        return nextExam == null || daysUntil(nextExam) <= 30;
      }).map(cleanMedical).toList(),
      'sectors': sectorPerformance.map(cleanSector).toList(),
      'openNonConformities': ncs.take(30).map(cleanNc).toList(),
      'pendingActions': actions.take(30).map(cleanAction).toList(),
      'recentInspections': inspections.take(12).map(cleanInspection).toList(),
    };
  }

  static int _asInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  static Future<ManagementPanelSyncResult> syncCompany(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();

    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message:
            'A publicação web ainda não foi configurada. O painel individual já existe no aplicativo, mas falta a configuração única do link externo.',
      );
    }

    final snapshot = await buildSnapshot(
      company,
      enabledOverride: enabledOverride,
    );

    try {
      final response = await AppsScriptHttp.postJson(
        Uri.parse(endpoint),
        {
          'action': 'sync',
          'syncKey': syncKey,
          'payload': snapshot,
        },
        timeout: const Duration(seconds: 30),
      );

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Servidor respondeu ${response.statusCode}.');
      }

      Map<String, dynamic>? body;
      try {
        body = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {}

      if (body != null && body['ok'] == false) {
        throw Exception('${body['message'] ?? 'Falha na sincronização.'}');
      }

      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Sincronizado',
      );

      return const ManagementPanelSyncResult(
        success: true,
        message: 'Painel gerencial atualizado com sucesso.',
      );
    } catch (e) {
      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Falha',
        error: '$e',
      );
      return ManagementPanelSyncResult(
        success: false,
        message: 'Não foi possível atualizar o painel: $e',
      );
    }
  }

  static Future<ManagementPanelSyncResult> sendTestEmail(
    Company company,
  ) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    )).trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    )).trim();
    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message: 'Configure primeiro a publicação web.',
      );
    }
    if (company.reportEmail.trim().isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message: 'Cadastre o e-mail principal da empresa antes do teste.',
      );
    }
    final snapshot = await buildSnapshot(company);
    try {
      final response = await AppsScriptHttp.postJson(
        Uri.parse(endpoint),
        {
          'action': 'test_notifications',
          'syncKey': syncKey,
          'payload': snapshot,
        },
        timeout: const Duration(seconds: 60),
      );
      final body = jsonDecode(response.body);
      if (response.statusCode < 200 || response.statusCode >= 300 ||
          body is! Map || body['ok'] != true) {
        return ManagementPanelSyncResult(
          success: false,
          message: body is Map
              ? '${body['message'] ?? 'O e-mail de teste não foi enviado.'}'
              : 'O serviço retornou uma resposta inválida.',
        );
      }
      return ManagementPanelSyncResult(
        success: true,
        message: '${body['message'] ?? 'E-mail de teste enviado.'}',
      );
    } catch (error) {
      return ManagementPanelSyncResult(
        success: false,
        message: 'Não foi possível enviar o teste: $error',
      );
    }
  }
}
