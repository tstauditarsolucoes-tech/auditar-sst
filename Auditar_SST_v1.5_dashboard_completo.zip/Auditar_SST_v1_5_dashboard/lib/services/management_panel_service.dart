import 'dart:convert';

import 'package:http/http.dart' as http;

import '../database.dart';
import '../models.dart';

class ManagementPanelSyncResult {
  final bool success;
  final String message;

  const ManagementPanelSyncResult({
    required this.success,
    required this.message,
  });
}

class ManagementPanelService {
  static Future<String> panelUrlForCompany(String companyId) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty) return '';

    final panel = await db.ensureManagementPanel(companyId);
    final token = '${panel['access_token'] ?? ''}'.trim();
    if (token.isEmpty) return '';

    final separator = endpoint.contains('?') ? '&' : '?';
    return '$endpoint${separator}empresa=${Uri.encodeQueryComponent(token)}';
  }

  static Future<Map<String, Object?>> buildSnapshot(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final panel = await db.ensureManagementPanel(company.id);
    final summary = await db.getDashboardSummary(companyId: company.id);
    final sectorPerformance =
        await db.getCompanySectorPerformance(company.id);
    final trainingSummary =
        await db.getTrainingSummary(companyId: company.id);
    final workers = await db.getWorkers(companyId: company.id);
    final companySectors = await db.getSectors(company.id);
    final trainings = await db.getTrainingControls(companyId: company.id);
    final missingTrainings =
        await db.getMissingRequiredTrainings(companyId: company.id);
    final ncs = await db.getNonConformityRows(
      companyId: company.id,
      includeClosed: false,
    );
    final actions = await db.getPendingActions(
      companyId: company.id,
      includeCompleted: false,
    );
    final inspections =
        await db.getInspectionHistory(companyId: company.id);
    final snapshotNow = DateTime.now();
    final currentMonthStart =
        DateTime(snapshotNow.year, snapshotNow.month, 1);
    final previousMonthStart =
        DateTime(currentMonthStart.year, currentMonthStart.month - 1, 1);
    final previousMonthEnd =
        currentMonthStart.subtract(const Duration(days: 1));
    final monthlySummary = await db.getDashboardSummary(
      companyId: company.id,
      startDate: previousMonthStart,
      endDate: previousMonthEnd,
    );
    final monthlyInspections = inspections.where((row) {
      final date = DateTime.tryParse('${row['date'] ?? ''}');
      return date != null &&
          !date.isBefore(previousMonthStart) &&
          date.isBefore(currentMonthStart);
    }).toList();

    final enabled = enabledOverride ?? ((panel['enabled'] as int? ?? 1) == 1);
    final now = DateTime.now();

    Worker? workerFor(String id) {
      for (final worker in workers) {
        if (worker.id == id) return worker;
      }
      return null;
    }

    int daysUntil(DateTime date) {
      final today = DateTime(now.year, now.month, now.day);
      return DateTime(date.year, date.month, date.day).difference(today).inDays;
    }

    Map<String, Object?> cleanSector(Map<String, Object?> row) => {
          'name': '${row['name'] ?? ''}',
          'inspections': _asInt(row['inspections']),
          'conformes': _asInt(row['conformes']),
          'parciais': _asInt(row['parciais']),
          'naoConformes': _asInt(row['nao_conformes']),
          'naoAplicaveis': _asInt(row['nao_aplicaveis']),
          'openNcs': _asInt(row['open_ncs']),
          'overdueNcs': _asInt(row['overdue_ncs']),
          'latestInspection': '${row['latest_inspection'] ?? ''}',
        };

    Map<String, Object?> cleanNc(Map<String, Object?> row) => {
          'code': '${row['code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'classification': '${row['classification'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'createdAt': '${row['created_at'] ?? ''}',
          'nextDueDate': '${row['next_due_date'] ?? ''}',
        };

    Map<String, Object?> cleanAction(Map<String, Object?> row) => {
          'ncCode': '${row['nc_code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'priority': '${row['priority'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'dueDate': '${row['due_date'] ?? ''}',
        };

    Map<String, Object?> cleanInspection(Map<String, Object?> row) => {
          'reportNumber': '${row['report_number'] ?? ''}',
          'date': '${row['date'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'checklistType': '${row['checklist_type'] ?? ''}',
        };

    Map<String, Object?> cleanTraining(TrainingControl training) {
      final worker = workerFor(training.workerId);
      final expiry = training.expiryDate;
      return {
        'id': training.id,
        'worker': worker?.name ?? '',
        'role': worker?.role ?? '',
        'code': training.code,
        'title': training.title,
        'expiryDate': expiry?.toIso8601String() ?? '',
        'daysUntilExpiry': expiry == null ? null : daysUntil(expiry),
        'status': training.statusAt(now),
      };
    }

    Map<String, Object?> cleanMedical(Worker worker) {
      final nextExam = worker.nextMedicalExamDate;
      return {
        'workerId': worker.id,
        'worker': worker.name,
        'role': worker.role,
        'nextExamDate': nextExam?.toIso8601String() ?? '',
        'daysUntilExpiry': nextExam == null ? null : daysUntil(nextExam),
      };
    }

    String sectorNameFor(String? sectorId) {
      if (sectorId == null) return '';
      for (final sector in companySectors) {
        if (sector.id == sectorId) return sector.name;
      }
      return '';
    }

    final workforceDetails = workers.map((worker) {
      final workerTrainings = trainings
          .where((training) => training.workerId == worker.id)
          .toList();
      final missingCount = missingTrainings
          .where((row) => (row['worker'] as Worker).id == worker.id)
          .length;
      final currentCount = workerTrainings
          .where((training) => training.statusAt(now) == 'EM DIA')
          .length;
      final expiredCount = workerTrainings
          .where((training) => training.statusAt(now) == 'VENCIDO')
          .length;
      final pendingCount = workerTrainings
          .where((training) => training.statusAt(now) == 'PENDENTE')
          .length;
      final dueSoonCount = workerTrainings.where((training) {
        final expiry = training.expiryDate;
        if (expiry == null || training.statusAt(now) != 'EM DIA') return false;
        final days = daysUntil(expiry);
        return days >= 0 && days <= 30;
      }).length;
      final trainingStatus = expiredCount > 0
          ? 'VENCIDO'
          : missingCount + pendingCount > 0
              ? 'PENDENTE'
              : dueSoonCount > 0
                  ? 'PRÓXIMO'
                  : 'EM DIA';
      final nextExam = worker.nextMedicalExamDate;
      final medicalDays = nextExam == null ? null : daysUntil(nextExam);
      final medicalStatus = medicalDays == null
          ? 'SEM DATA'
          : medicalDays < 0
              ? 'VENCIDO'
              : medicalDays <= 30
                  ? 'PRÓXIMO'
                  : 'EM DIA';
      return {
        'worker': worker.name,
        'role': worker.role,
        'sector': sectorNameFor(worker.sectorId),
        'trainingStatus': trainingStatus,
        'trainingDetails': '$currentCount em dia • $expiredCount vencido(s) • '
            '${missingCount + pendingCount} pendente(s)',
        'currentTrainings': currentCount,
        'expiredTrainings': expiredCount,
        'pendingTrainings': missingCount + pendingCount,
        'dueSoonTrainings': dueSoonCount,
        'nextExamDate': nextExam?.toIso8601String() ?? '',
        'medicalStatus': medicalStatus,
      };
    }).toList();

    return {
      'schemaVersion': 4,
      'accessToken': '${panel['access_token'] ?? ''}',
      'enabled': enabled,
      'updatedAt': DateTime.now().toIso8601String(),
      'company': {
        'id': company.id,
        'name': company.name,
        'city': company.city ?? '',
        'uf': company.uf ?? '',
        'contact': company.reportRecipient.isNotEmpty
            ? company.reportRecipient
            : (company.contact ?? ''),
      },
      'notifications': {
        'primaryEmail': company.reportEmail,
        'secondaryEmail': company.secondaryReportEmail,
        'monthlyReportEnabled': company.monthlyReportEnabled,
        'monthlyReportDay': company.monthlyReportDay,
        'trainingAlertsEnabled': company.trainingAlertsEnabled,
        'medicalAlertsEnabled': company.medicalAlertsEnabled,
      },
      'summary': summary,
      'monthlyReport': {
        'periodStart': previousMonthStart.toIso8601String(),
        'periodEnd': previousMonthEnd.toIso8601String(),
        'summary': monthlySummary,
        'inspections': monthlyInspections.map(cleanInspection).toList(),
      },
      'trainingSummary': trainingSummary,
      'workforceSummary': {
        'activeWorkers': workers.length,
        'missingRequiredTrainings': missingTrainings.length,
        'medicalRegular': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          return nextExam != null && daysUntil(nextExam) > 30;
        }).length,
        'medicalDueSoon': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          if (nextExam == null) return false;
          final days = daysUntil(nextExam);
          return days >= 0 && days <= 30;
        }).length,
        'medicalExpired': workers.where((worker) {
          final nextExam = worker.nextMedicalExamDate;
          return nextExam != null && daysUntil(nextExam) < 0;
        }).length,
        'medicalNoDate': workers
            .where((worker) => worker.nextMedicalExamDate == null)
            .length,
      },
      'trainingRecords': trainings.map(cleanTraining).toList(),
      'trainingAlerts': trainings.where((training) {
        if (training.trainingDate == null) return true;
        final expiry = training.expiryDate;
        return expiry != null && daysUntil(expiry) <= 30;
      }).map(cleanTraining).toList(),
      'missingRequiredTrainings': missingTrainings.map((row) {
        final worker = row['worker'] as Worker;
        final requirement = row['requirement'] as TrainingRequirement;
        return {
          'workerId': worker.id,
          'worker': worker.name,
          'role': worker.role,
          'code': requirement.code,
          'title': requirement.title,
        };
      }).toList(),
      'medicalExams': workers.map(cleanMedical).toList(),
      'workforceDetails': workforceDetails,
      'medicalAlerts': workers.where((worker) {
        final nextExam = worker.nextMedicalExamDate;
        return nextExam == null || daysUntil(nextExam) <= 30;
      }).map(cleanMedical).toList(),
      'sectors': sectorPerformance.map(cleanSector).toList(),
      'openNonConformities': ncs.take(30).map(cleanNc).toList(),
      'pendingActions': actions.take(30).map(cleanAction).toList(),
      'recentInspections': inspections.take(12).map(cleanInspection).toList(),
    };
  }

  static int _asInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  static Future<ManagementPanelSyncResult> syncCompany(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();

    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message:
            'A publicação web ainda não foi configurada. O painel individual já existe no aplicativo, mas falta a configuração única do link externo.',
      );
    }

    final snapshot = await buildSnapshot(
      company,
      enabledOverride: enabledOverride,
    );

    try {
      final response = await http
          .post(
            Uri.parse(endpoint),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({
              'action': 'sync',
              'syncKey': syncKey,
              'payload': snapshot,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Servidor respondeu ${response.statusCode}.');
      }

      Map<String, dynamic>? body;
      try {
        body = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {}

      if (body != null && body['ok'] == false) {
        throw Exception('${body['message'] ?? 'Falha na sincronização.'}');
      }

      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Sincronizado',
      );

      return const ManagementPanelSyncResult(
        success: true,
        message: 'Painel gerencial atualizado com sucesso.',
      );
    } catch (e) {
      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Falha',
        error: '$e',
      );
      return ManagementPanelSyncResult(
        success: false,
        message: 'Não foi possível atualizar o painel: $e',
      );
    }
  }

  static Future<ManagementPanelSyncResult> sendTestEmail(
    Company company,
  ) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    )).trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    )).trim();
    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message: 'Configure primeiro a publicação web.',
      );
    }
    if (company.reportEmail.trim().isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message: 'Cadastre o e-mail principal da empresa antes do teste.',
      );
    }
    final snapshot = await buildSnapshot(company);
    try {
      final response = await http.post(
        Uri.parse(endpoint),
        headers: const {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'action': 'test_notifications',
          'syncKey': syncKey,
          'payload': snapshot,
        }),
      ).timeout(const Duration(seconds: 60));
      final body = jsonDecode(response.body);
      if (response.statusCode < 200 || response.statusCode >= 300 ||
          body is! Map || body['ok'] != true) {
        return ManagementPanelSyncResult(
          success: false,
          message: body is Map
              ? '${body['message'] ?? 'O e-mail de teste não foi enviado.'}'
              : 'O serviço retornou uma resposta inválida.',
        );
      }
      return ManagementPanelSyncResult(
        success: true,
        message: '${body['message'] ?? 'E-mail de teste enviado.'}',
      );
    } catch (error) {
      return ManagementPanelSyncResult(
        success: false,
        message: 'Não foi possível enviar o teste: $error',
      );
    }
  }
}
