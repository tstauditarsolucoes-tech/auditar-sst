import 'dart:convert';

import 'package:http/http.dart' as http;

import '../database.dart';
import '../models.dart';

class ManagementPanelSyncResult {
  final bool success;
  final String message;

  const ManagementPanelSyncResult({
    required this.success,
    required this.message,
  });
}

class ManagementPanelService {
  static Future<String> panelUrlForCompany(String companyId) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty) return '';

    final panel = await db.ensureManagementPanel(companyId);
    final token = '${panel['access_token'] ?? ''}'.trim();
    if (token.isEmpty) return '';

    final separator = endpoint.contains('?') ? '&' : '?';
    return '$endpoint${separator}empresa=${Uri.encodeQueryComponent(token)}';
  }

  static Future<Map<String, Object?>> buildSnapshot(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final panel = await db.ensureManagementPanel(company.id);
    final summary = await db.getDashboardSummary(companyId: company.id);
    final sectorPerformance =
        await db.getCompanySectorPerformance(company.id);
    final trainingSummary =
        await db.getTrainingSummary(companyId: company.id);
    final ncs = await db.getNonConformityRows(
      companyId: company.id,
      includeClosed: false,
    );
    final actions = await db.getPendingActions(
      companyId: company.id,
      includeCompleted: false,
    );
    final inspections =
        await db.getInspectionHistory(companyId: company.id);

    final enabled = enabledOverride ?? ((panel['enabled'] as int? ?? 1) == 1);

    Map<String, Object?> cleanSector(Map<String, Object?> row) => {
          'name': '${row['name'] ?? ''}',
          'inspections': _asInt(row['inspections']),
          'conformes': _asInt(row['conformes']),
          'parciais': _asInt(row['parciais']),
          'naoConformes': _asInt(row['nao_conformes']),
          'naoAplicaveis': _asInt(row['nao_aplicaveis']),
          'openNcs': _asInt(row['open_ncs']),
          'overdueNcs': _asInt(row['overdue_ncs']),
          'latestInspection': '${row['latest_inspection'] ?? ''}',
        };

    Map<String, Object?> cleanNc(Map<String, Object?> row) => {
          'code': '${row['code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'classification': '${row['classification'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'createdAt': '${row['created_at'] ?? ''}',
          'nextDueDate': '${row['next_due_date'] ?? ''}',
        };

    Map<String, Object?> cleanAction(Map<String, Object?> row) => {
          'ncCode': '${row['nc_code'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'priority': '${row['priority'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'dueDate': '${row['due_date'] ?? ''}',
        };

    Map<String, Object?> cleanInspection(Map<String, Object?> row) => {
          'reportNumber': '${row['report_number'] ?? ''}',
          'date': '${row['date'] ?? ''}',
          'status': '${row['status'] ?? ''}',
          'sector': '${row['sector_name'] ?? ''}',
          'area': '${row['area'] ?? ''}',
          'checklistType': '${row['checklist_type'] ?? ''}',
        };

    return {
      'schemaVersion': 1,
      'accessToken': '${panel['access_token'] ?? ''}',
      'enabled': enabled,
      'updatedAt': DateTime.now().toIso8601String(),
      'company': {
        'id': company.id,
        'name': company.name,
        'city': company.city ?? '',
        'uf': company.uf ?? '',
      },
      'summary': summary,
      'trainingSummary': trainingSummary,
      'sectors': sectorPerformance.map(cleanSector).toList(),
      'openNonConformities': ncs.take(30).map(cleanNc).toList(),
      'pendingActions': actions.take(30).map(cleanAction).toList(),
      'recentInspections': inspections.take(12).map(cleanInspection).toList(),
    };
  }

  static int _asInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  static Future<ManagementPanelSyncResult> syncCompany(
    Company company, {
    bool? enabledOverride,
  }) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();

    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const ManagementPanelSyncResult(
        success: false,
        message:
            'A publicação web ainda não foi configurada. O painel individual já existe no aplicativo, mas falta a configuração única do link externo.',
      );
    }

    final snapshot = await buildSnapshot(
      company,
      enabledOverride: enabledOverride,
    );

    try {
      final response = await http
          .post(
            Uri.parse(endpoint),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({
              'action': 'sync',
              'syncKey': syncKey,
              'payload': snapshot,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Servidor respondeu ${response.statusCode}.');
      }

      Map<String, dynamic>? body;
      try {
        body = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {}

      if (body != null && body['ok'] == false) {
        throw Exception('${body['message'] ?? 'Falha na sincronização.'}');
      }

      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Sincronizado',
      );

      return const ManagementPanelSyncResult(
        success: true,
        message: 'Painel gerencial atualizado com sucesso.',
      );
    } catch (e) {
      await db.updateManagementPanelSync(
        companyId: company.id,
        status: 'Falha',
        error: '$e',
      );
      return ManagementPanelSyncResult(
        success: false,
        message: 'Não foi possível atualizar o painel: $e',
      );
    }
  }
}
