import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models.dart';

class ImprovementPdfService {
  static const navy = PdfColor(0.113725, 0.180392, 0.423529);
  static const green = PdfColor(0.090196, 0.552941, 0.172549);
  static const amber = PdfColor(0.922, 0.565, 0.094);
  static const purple = PdfColor(0.416, 0.294, 0.737);

  static Future<Uint8List> generate({
    required Company company,
    required List<SstRecord> records,
    required List<Sector> sectors,
  }) async {
    final doc = pw.Document();
    final logo = await _asset('assets/branding/auditar_icon.png');
    final sorted = [...records]..sort((a, b) => b.date.compareTo(a.date));
    final suggestions = sorted.where((record) => record.status == 'Sugerida').length;
    final running = sorted
        .where((record) => record.status == 'Planejada' || record.status == 'Em execução')
        .length;
    final realized = sorted.where(_realized).length;
    final withBeforeAfter = sorted.where((record) {
      final before = '${record.payload['beforePhotoPath'] ?? ''}'.trim();
      final after = '${record.payload['afterPhotoPath'] ?? ''}'.trim();
      return before.isNotEmpty && after.isNotEmpty;
    }).length;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(30),
        header: (context) => _header(company, logo),
        footer: (context) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Auditar SST', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
            pw.Text(
              'Página ${context.pageNumber} de ${context.pagesCount}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
            ),
          ],
        ),
        build: (context) => [
          pw.SizedBox(height: 10),
          pw.Text(
            'RELATÓRIO DE MELHORIAS',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: navy),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            'Sugestões, acompanhamento e melhorias realizadas por setor • ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
          pw.SizedBox(height: 14),
          pw.Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              _metric('Total', sorted.length, navy),
              _metric('Sugeridas', suggestions, amber),
              _metric('Em andamento', running, purple),
              _metric('Realizadas', realized, green),
              _metric('Antes + depois', withBeforeAfter, green),
            ],
          ),
          pw.SizedBox(height: 18),
          if (sorted.isEmpty)
            pw.Text('Nenhuma melhoria cadastrada.')
          else
            ...sorted.map((record) => _recordCard(record, sectors)),
        ],
      ),
    );

    return doc.save();
  }

  static pw.Widget _header(Company company, pw.ImageProvider? logo) {
    return pw.Container(
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300)),
      ),
      child: pw.Row(
        children: [
          if (logo != null) ...[
            pw.Image(logo, width: 34, height: 34),
            pw.SizedBox(width: 8),
          ],
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.RichText(
                text: pw.TextSpan(
                  children: [
                    pw.TextSpan(
                      text: 'Auditar ',
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: navy, fontSize: 14),
                    ),
                    pw.TextSpan(
                      text: 'SST',
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: green, fontSize: 14),
                    ),
                  ],
                ),
              ),
              pw.Text(company.name, style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _metric(String label, int value, PdfColor color) => pw.Container(
        width: 90,
        padding: const pw.EdgeInsets.all(8),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: pw.BorderRadius.circular(7),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('$value', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: color)),
            pw.SizedBox(height: 2),
            pw.Text(label, style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700)),
          ],
        ),
      );

  static pw.Widget _recordCard(SstRecord record, List<Sector> sectors) {
    final p = record.payload;
    final sector = _sectorName(record, sectors);
    final location = '${p['location'] ?? ''}'.trim();
    final beforeSituation = '${p['beforeSituation'] ?? ''}'.trim();
    final suggestion = '${p['suggestion'] ?? ''}'.trim();
    final benefit = '${p['expectedBenefit'] ?? ''}'.trim();
    final workPerformed = '${p['workPerformed'] ?? ''}'.trim();
    final result = '${p['result'] ?? ''}'.trim();
    final responsible = '${p['responsible'] ?? ''}'.trim();
    final completedDate = DateTime.tryParse('${p['completedDate'] ?? ''}');
    final beforePhoto = _photo('${p['beforePhotoPath'] ?? ''}');
    final afterPhoto = _photo('${p['afterPhotoPath'] ?? ''}');
    final statusColor = _realized(record)
        ? green
        : record.status == 'Em execução'
            ? purple
            : amber;

    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 10),
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Text(
                  record.title,
                  style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: navy),
                ),
              ),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: pw.BoxDecoration(
                  color: _soft(statusColor),
                  borderRadius: pw.BorderRadius.circular(10),
                ),
                child: pw.Text(
                  record.status,
                  style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: statusColor),
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            [sector, location, 'Prioridade ${record.priority}'].where((value) => value.isNotEmpty).join(' • '),
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
          ),
          pw.SizedBox(height: 7),
          if (beforePhoto != null || afterPhoto != null)
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(child: _photoBox('ANTES', beforePhoto)),
                pw.SizedBox(width: 8),
                pw.Expanded(child: _photoBox('DEPOIS', afterPhoto)),
              ],
            ),
          if (beforePhoto != null || afterPhoto != null) pw.SizedBox(height: 8),
          if (beforeSituation.isNotEmpty) _labelValue('Situação antes', beforeSituation),
          if (suggestion.isNotEmpty) _labelValue('Sugestão / melhoria', suggestion),
          if (benefit.isNotEmpty) _labelValue('Benefício esperado', benefit),
          if (workPerformed.isNotEmpty) _labelValue('O que foi feito', workPerformed),
          if (result.isNotEmpty) _labelValue('Resultado', result),
          if (responsible.isNotEmpty) _labelValue('Responsável', responsible),
          if (record.dueDate != null)
            _labelValue('Prazo', DateFormat('dd/MM/yyyy').format(record.dueDate!)),
          if (completedDate != null)
            _labelValue('Realizada em', DateFormat('dd/MM/yyyy').format(completedDate)),
        ],
      ),
    );
  }

  static pw.Widget _photoBox(String label, pw.MemoryImage? photo) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(label, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: navy)),
          pw.SizedBox(height: 3),
          pw.Container(
            height: 135,
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              border: pw.Border.all(color: PdfColors.grey300),
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: photo == null
                ? pw.Center(
                    child: pw.Text('Foto não registrada', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey500)),
                  )
                : pw.Image(photo, fit: pw.BoxFit.cover),
          ),
        ],
      );

  static pw.Widget _labelValue(String label, String value) => pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 3),
        child: pw.RichText(
          text: pw.TextSpan(
            children: [
              pw.TextSpan(
                text: '$label: ',
                style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: navy),
              ),
              pw.TextSpan(text: value, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey800)),
            ],
          ),
        ),
      );

  static pw.MemoryImage? _photo(String path) {
    final clean = path.trim();
    if (clean.isEmpty) return null;
    final file = File(clean);
    if (!file.existsSync()) return null;
    try {
      return pw.MemoryImage(file.readAsBytesSync());
    } catch (_) {
      return null;
    }
  }

  static bool _realized(SstRecord record) =>
      record.status.toLowerCase().contains('realiz') ||
      record.status.toLowerCase().contains('conclu');

  static String _sectorName(SstRecord record, List<Sector> sectors) {
    final stored = '${record.payload['sectorName'] ?? ''}'.trim();
    if (stored.isNotEmpty) return stored;
    for (final sector in sectors) {
      if (sector.id == record.sectorId) return sector.name;
    }
    return '';
  }

  static PdfColor _soft(PdfColor color) {
    if (color == green) return PdfColors.green50;
    if (color == purple) return PdfColors.purple50;
    return PdfColors.orange50;
  }

  static Future<pw.ImageProvider?> _asset(String path) async {
    try {
      final bytes = await rootBundle.load(path);
      return pw.MemoryImage(bytes.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }
}
