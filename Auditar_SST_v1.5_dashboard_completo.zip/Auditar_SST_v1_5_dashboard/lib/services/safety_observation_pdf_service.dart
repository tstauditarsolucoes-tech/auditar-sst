import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models.dart';

class SafetyObservationPdfService {
  static const navy = PdfColor(0.113725, 0.180392, 0.423529);
  static const green = PdfColor(0.090196, 0.552941, 0.172549);
  static const red = PdfColor(0.788, 0.204, 0.173);
  static const amber = PdfColor(0.922, 0.565, 0.094);

  static Future<Uint8List> generate({
    required Company company,
    required List<SstRecord> records,
    required List<Sector> sectors,
  }) async {
    final doc = pw.Document();
    final logo = await _asset('assets/branding/auditar_icon.png');
    final sorted = [...records]..sort((a, b) => b.date.compareTo(a.date));
    final open = sorted.where((r) => !_closed(r)).length;
    final resolved = sorted.where(_closed).length;
    final acts = sorted.where((r) => _kind(r) == 'Ato inseguro').length;
    final conditions = sorted.where((r) => _kind(r) == 'Condição insegura').length;
    final critical = sorted.where((r) => !_closed(r) && r.priority == 'Crítica').length;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (context) => _header(company, logo),
        footer: (context) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Auditar SST', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
            pw.Text('Página ${context.pageNumber} de ${context.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          ],
        ),
        build: (context) => [
          pw.SizedBox(height: 10),
          pw.Text(
            'RELATÓRIO DE ATOS E CONDIÇÕES INSEGURAS',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: navy),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            'Gerado em ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
          pw.SizedBox(height: 14),
          pw.Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              _metric('Total', sorted.length, navy),
              _metric('Abertos', open, open > 0 ? red : green),
              _metric('Resolvidos', resolved, green),
              _metric('Condições', conditions, amber),
              _metric('Atos', acts, navy),
              _metric('Críticos abertos', critical, critical > 0 ? red : green),
            ],
          ),
          pw.SizedBox(height: 18),
          pw.Text(
            'Registros',
            style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: navy),
          ),
          pw.SizedBox(height: 8),
          if (sorted.isEmpty)
            pw.Text('Nenhum registro cadastrado.')
          else
            ...sorted.map((record) => _recordCard(record, sectors)),
        ],
      ),
    );

    return doc.save();
  }

  static pw.Widget _header(Company company, pw.ImageProvider? logo) {
    return pw.Container(
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300)),
      ),
      child: pw.Row(
        children: [
          if (logo != null) ...[
            pw.Image(logo, width: 34, height: 34),
            pw.SizedBox(width: 8),
          ],
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.RichText(
                text: pw.TextSpan(
                  children: [
                    pw.TextSpan(text: 'Auditar ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: navy, fontSize: 14)),
                    pw.TextSpan(text: 'SST', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: green, fontSize: 14)),
                  ],
                ),
              ),
              pw.Text(company.name, style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _metric(String label, int value, PdfColor color) {
    return pw.Container(
      width: 80,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('$value', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: color)),
          pw.SizedBox(height: 2),
          pw.Text(label, style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700)),
        ],
      ),
    );
  }

  static pw.Widget _recordCard(SstRecord record, List<Sector> sectors) {
    final p = record.payload;
    final kind = _kind(record);
    final sector = _sectorName(record, sectors);
    final location = '${p['location'] ?? ''}'.trim();
    final description = '${p['description'] ?? ''}'.trim();
    final risk = '${p['risk'] ?? ''}'.trim();
    final consequence = '${p['possibleConsequence'] ?? ''}'.trim();
    final recommendation = '${p['recommendation'] ?? ''}'.trim();
    final immediate = '${p['immediateAction'] ?? ''}'.trim();
    final responsible = '${p['responsible'] ?? ''}'.trim();
    final photoPath = '${p['photoPath'] ?? ''}'.trim();
    final statusColor = _closed(record) ? green : (record.priority == 'Crítica' ? red : amber);
    pw.MemoryImage? photo;
    if (photoPath.isNotEmpty) {
      final file = File(photoPath);
      if (file.existsSync()) {
        try {
          photo = pw.MemoryImage(file.readAsBytesSync());
        } catch (_) {}
      }
    }

    final details = <pw.Widget>[
      pw.Row(
        children: [
          pw.Expanded(
            child: pw.Text(record.title, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: navy)),
          ),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: pw.BoxDecoration(
              color: _soft(statusColor),
              borderRadius: pw.BorderRadius.circular(10),
            ),
            child: pw.Text(record.status, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: statusColor)),
          ),
        ],
      ),
      pw.SizedBox(height: 4),
      pw.Text(
        '$kind • ${DateFormat('dd/MM/yyyy').format(record.date)} • Prioridade ${record.priority}',
        style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
      ),
      if (sector.isNotEmpty || location.isNotEmpty) ...[
        pw.SizedBox(height: 3),
        pw.Text([sector, location].where((v) => v.isNotEmpty).join(' • '), style: const pw.TextStyle(fontSize: 8)),
      ],
      if (description.isNotEmpty) ...[
        pw.SizedBox(height: 6),
        _labelValue('Descrição', description),
      ],
      if (risk.isNotEmpty) _labelValue('Risco identificado', risk),
      if (consequence.isNotEmpty) _labelValue('Possível consequência', consequence),
      if (immediate.isNotEmpty) _labelValue('Ação imediata', immediate),
      if (recommendation.isNotEmpty) _labelValue('Recomendação', recommendation),
      if (responsible.isNotEmpty) _labelValue('Responsável', responsible),
      if (record.dueDate != null) _labelValue('Prazo', DateFormat('dd/MM/yyyy').format(record.dueDate!)),
    ];

    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 9),
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: photo == null
          ? pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: details)
          : pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Container(
                  width: 100,
                  height: 82,
                  child: pw.Image(photo, fit: pw.BoxFit.cover),
                ),
                pw.SizedBox(width: 10),
                pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: details)),
              ],
            ),
    );
  }

  static pw.Widget _labelValue(String label, String value) => pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 3),
        child: pw.RichText(
          text: pw.TextSpan(
            children: [
              pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: navy)),
              pw.TextSpan(text: value, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey800)),
            ],
          ),
        ),
      );

  static PdfColor _soft(PdfColor color) {
    if (color == green) return PdfColors.green50;
    if (color == red) return PdfColors.red50;
    if (color == amber) return PdfColors.orange50;
    return PdfColors.blue50;
  }

  static bool _closed(SstRecord record) => record.status.toLowerCase().contains('resolvid');
  static String _kind(SstRecord record) => '${record.payload['observationKind'] ?? 'Condição insegura'}';

  static String _sectorName(SstRecord record, List<Sector> sectors) {
    final stored = '${record.payload['sectorName'] ?? ''}'.trim();
    if (stored.isNotEmpty) return stored;
    for (final sector in sectors) {
      if (sector.id == record.sectorId) return sector.name;
    }
    return '';
  }

  static Future<pw.ImageProvider?> _asset(String path) async {
    try {
      final bytes = await rootBundle.load(path);
      return pw.MemoryImage(bytes.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }
}
