import 'dart:convert';

import 'package:http/http.dart' as http;

import '../database.dart';
import '../models.dart';

class CipaVotingResult {
  final bool success;
  final String message;
  final Map<String, dynamic>? data;

  const CipaVotingResult({
    required this.success,
    required this.message,
    this.data,
  });
}

class CipaVotingService {
  static Future<String> electionUrl(CipaElection election) async {
    final endpoint = (await AppDatabase.instance.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty || election.accessToken.isEmpty) return '';
    final separator = endpoint.contains('?') ? '&' : '?';
    return '$endpoint${separator}cipa=${Uri.encodeQueryComponent(election.accessToken)}';
  }

  static Future<CipaVotingResult> publishElection({
    required Company company,
    required CipaElection election,
  }) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();

    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const CipaVotingResult(
        success: false,
        message:
            'A publicação online ainda não foi configurada. Use a mesma configuração gratuita do Painel Gerencial em Configurações.',
      );
    }

    final candidates = await db.getCipaCandidates(election.id);
    final voters = await db.getCipaVoters(election.id);
    if (candidates.isEmpty) {
      return const CipaVotingResult(
        success: false,
        message: 'Cadastre pelo menos um candidato antes de publicar.',
      );
    }
    if (voters.isEmpty) {
      return const CipaVotingResult(
        success: false,
        message: 'Prepare a lista de eleitores antes de publicar.',
      );
    }

    final payload = {
      'election': {
        'id': election.id,
        'token': election.accessToken,
        'title': election.title,
        'managementPeriod': election.managementPeriod,
        'startDate': election.startDate?.toIso8601String() ?? '',
        'endDate': election.endDate?.toIso8601String() ?? '',
      },
      'company': {
        'id': company.id,
        'name': company.name,
        'city': company.city ?? '',
        'uf': company.uf ?? '',
      },
      'candidates': candidates
          .map(
            (candidate) => {
              'id': candidate.id,
              'name': candidate.name,
              'role': candidate.role,
              'sector': candidate.sector,
            },
          )
          .toList(),
      // O backend transforma os códigos em hash e não precisa guardar nomes.
      'voters': voters
          .map(
            (voter) => {
              'id': voter.id,
              'accessCode': voter.accessCode,
            },
          )
          .toList(),
    };

    try {
      final response = await http
          .post(
            Uri.parse(endpoint),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({
              'action': 'cipa_publish',
              'syncKey': syncKey,
              'payload': payload,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final body = _decode(response.body);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Serviço respondeu ${response.statusCode}.');
      }
      if (body['ok'] != true) {
        throw Exception('${body['message'] ?? 'Não foi possível publicar a eleição.'}');
      }

      await db.setCipaElectionSync(
        electionId: election.id,
        status: 'Sincronizado',
        electionStatus: 'Aberta',
      );
      return CipaVotingResult(
        success: true,
        message: '${body['message'] ?? 'Eleição publicada com sucesso.'}',
        data: body,
      );
    } catch (e) {
      await db.setCipaElectionSync(
        electionId: election.id,
        status: 'Falha',
        error: '$e',
      );
      return CipaVotingResult(
        success: false,
        message: 'Não foi possível publicar a eleição: $e',
      );
    }
  }

  static Future<CipaVotingResult> getStatus(CipaElection election) async {
    final endpoint = (await AppDatabase.instance.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty) {
      return const CipaVotingResult(
        success: false,
        message: 'Publicação online não configurada.',
      );
    }

    try {
      final uri = Uri.parse(endpoint).replace(
        queryParameters: {
          ...Uri.parse(endpoint).queryParameters,
          'api': 'cipa_status',
          'cipa': election.accessToken,
        },
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 20));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Serviço respondeu ${response.statusCode}.');
      }
      final body = _decode(response.body);
      if (body['ok'] != true) {
        throw Exception('${body['message'] ?? 'Status indisponível.'}');
      }
      return CipaVotingResult(
        success: true,
        message: 'Atualizado.',
        data: body,
      );
    } catch (e) {
      return CipaVotingResult(
        success: false,
        message: 'Sem atualização online: $e',
      );
    }
  }

  static Future<CipaVotingResult> closeElection(CipaElection election) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const CipaVotingResult(
        success: false,
        message: 'Publicação online não configurada.',
      );
    }

    try {
      final response = await http
          .post(
            Uri.parse(endpoint),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({
              'action': 'cipa_close',
              'syncKey': syncKey,
              'electionToken': election.accessToken,
            }),
          )
          .timeout(const Duration(seconds: 30));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Serviço respondeu ${response.statusCode}.');
      }
      final body = _decode(response.body);
      if (body['ok'] != true) {
        throw Exception('${body['message'] ?? 'Não foi possível encerrar.'}');
      }
      await db.setCipaElectionSync(
        electionId: election.id,
        status: 'Sincronizado',
        electionStatus: 'Encerrada',
      );
      return CipaVotingResult(
        success: true,
        message: '${body['message'] ?? 'Eleição encerrada.'}',
        data: body,
      );
    } catch (e) {
      await db.setCipaElectionSync(
        electionId: election.id,
        status: 'Falha',
        error: '$e',
      );
      return CipaVotingResult(
        success: false,
        message: 'Não foi possível encerrar: $e',
      );
    }
  }

  static Map<String, dynamic> _decode(String source) {
    try {
      final decoded = jsonDecode(source);
      if (decoded is Map<String, dynamic>) return decoded;
      return {'ok': false, 'message': 'Resposta inválida.'};
    } catch (_) {
      return {'ok': false, 'message': 'Resposta inválida.'};
    }
  }
}
