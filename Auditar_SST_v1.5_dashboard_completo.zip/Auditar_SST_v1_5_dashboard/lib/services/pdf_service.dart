import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../database.dart';
import '../models.dart';

class PdfService {
  static const _navy = PdfColor(0.113725, 0.180392, 0.423529);
  static const _green = PdfColor(0.090196, 0.552941, 0.172549);
  static const _greenSoft = PdfColors.green50;
  static const _red = PdfColors.red700;
  static const _redSoft = PdfColors.red50;
  static const _amber = PdfColors.orange800;
  static const _amberSoft = PdfColors.orange50;
  static const _grey = PdfColors.grey700;
  static const _line = PdfColors.grey300;

  /// Gera o relatório da vistoria.
  ///
  /// [executive] = true gera uma versão resumida para gerência.
  /// O padrão continua sendo o relatório completo para manter compatibilidade
  /// com salvamento local e sincronização já existentes.
  static Future<Uint8List> generateInspectionPdf(
    String inspectionId, {
    bool executive = false,
  }) async {
    final db = AppDatabase.instance;
    final header = await db.getInspectionHeader(inspectionId);

    if (header == null) {
      throw Exception('Vistoria não encontrada.');
    }

    final answers = await db.getAnswers(inspectionId);
    final actions = await db.getActionsForInspection(inspectionId);
    final ncs = await db.getNonConformitiesForInspection(inspectionId);

    final reportFooter = await db.getSetting(
      'report_footer',
      fallback: 'Auditar SST - Segurança do Trabalho',
    );

    final doc = pw.Document();

    final auditarLogo = await _loadAssetImage(
      'assets/branding/auditar_icon.png',
    );
    final auditarIcon = await _loadAssetImage(
      'assets/branding/auditar_icon.png',
    );
    final companyLogo = await _loadImage(
      header['company_logo_path'] as String?,
    );
    final technicianSignature = await _loadImage(
      header['technician_signature_path'] as String?,
    );
    final responsibleSignature = await _loadImage(
      header['responsible_signature_path'] as String?,
    );

    final date = DateTime.tryParse('${header['date'] ?? ''}');
    final dateText = date == null
        ? '-'
        : DateFormat('dd/MM/yyyy HH:mm').format(date);
    final shortDate = date == null
        ? '-'
        : DateFormat('dd/MM/yyyy').format(date);

    final conformes = answers.where((e) => e.status == 'Conforme').length;
    final naoConformes =
        answers.where((e) => e.status == 'Não Conforme').length;
    final parciais = answers.where((e) => e.status == 'Parcial').length;
    final naoAplicaveis =
        answers.where((e) => e.status == 'Não se aplica').length;
    final considered = conformes + parciais + naoConformes;
    final total = answers.length;
    final conformity = considered == 0
        ? 0
        : (conformes / considered * 100).round();

    final reportNumber = ('${header['report_number'] ?? ''}').trim();
    final technicianName = ('${header['technician_name'] ?? ''}').trim();
    final responsibleName = ('${header['responsible_name'] ?? ''}').trim();
    final generalNotes = ('${header['general_notes'] ?? ''}').trim();
    final customConclusion = ('${header['conclusion'] ?? ''}').trim();
    final companyName = ('${header['company_name'] ?? '-'}').trim();
    final sector = ('${header['sector_name'] ?? header['area'] ?? '-'}').trim();
    final area = ('${header['area'] ?? '-'}').trim();
    final checklist = ('${header['checklist_type'] ?? '-'}').trim();
    final worksite = ('${header['worksite_name'] ?? ''}').trim();

    final ncByAnswer = <String, NonConformity>{
      for (final nc in ncs) nc.answerId: nc,
    };

    final conclusion = customConclusion.isNotEmpty
        ? customConclusion
        : _automaticConclusion(
            naoConformes: naoConformes,
            parciais: parciais,
            conformity: conformity,
          );

    // CAPA
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (_) => _coverPage(
          auditarLogo: auditarLogo,
          companyLogo: companyLogo,
          executive: executive,
          companyName: companyName,
          checklist: checklist,
          reportNumber: reportNumber,
          date: shortDate,
          sector: sector,
          worksite: worksite,
          technicianName: technicianName,
        ),
      ),
    );

    final body = <pw.Widget>[
      _pageTitle(
        executive ? 'Resumo executivo' : 'Resumo da inspeção',
        executive
            ? 'Visão objetiva para acompanhamento gerencial.'
            : 'Visão consolidada dos itens avaliados e das pendências encontradas.',
      ),
      pw.SizedBox(height: 14),
      _summaryMetrics(
        conformes: conformes,
        naoConformes: naoConformes,
        parciais: parciais,
        naoAplicaveis: naoAplicaveis,
        conformity: conformity,
      ),
      pw.SizedBox(height: 14),
      _distributionCard(
        conformes: conformes,
        naoConformes: naoConformes,
        parciais: parciais,
        naoAplicaveis: naoAplicaveis,
        total: total,
      ),
      pw.SizedBox(height: 16),
      _inspectionDataCard(
        reportNumber: reportNumber,
        companyName: companyName,
        cnpj: '${header['company_cnpj'] ?? ''}',
        worksite: worksite,
        address: '${header['worksite_address'] ?? ''}',
        sector: sector,
        area: area,
        checklist: checklist,
        dateText: dateText,
        technicianName: technicianName,
      ),
      pw.SizedBox(height: 20),
      _sectionHeader(
        'PONTOS DE ATENÇÃO',
        subtitle: naoConformes == 0 && parciais == 0
            ? 'Nenhum item crítico ou parcial identificado.'
            : 'Itens não conformes e atendimentos parciais priorizados.',
      ),
      pw.SizedBox(height: 8),
    ];

    final issues = answers
        .where((e) => e.status == 'Não Conforme' || e.status == 'Parcial')
        .toList();

    if (issues.isEmpty) {
      body.add(
        _emptyState(
          'Nenhum ponto de atenção registrado nesta inspeção.',
          positive: true,
        ),
      );
    } else {
      for (var index = 0; index < issues.length; index++) {
        final answer = issues[index];
        final photos = await db.getPhotosForAnswer(answer.id);
        final nc = ncByAnswer[answer.id];

        body.add(
          _issueCard(
            answer: answer,
            index: index + 1,
            nc: nc,
          ),
        );

        if (photos.isNotEmpty && !executive) {
          body.add(pw.SizedBox(height: 5));
          body.addAll(
            await _photoRows(
              photos.map((e) => e.path).toList(),
              captionPrefix: answer.status == 'Não Conforme'
                  ? (nc?.code.isNotEmpty == true ? nc!.code : 'NC ${index + 1}')
                  : 'Item parcial ${index + 1}',
            ),
          );
        } else if (photos.isNotEmpty && executive) {
          body.add(
            pw.Padding(
              padding: const pw.EdgeInsets.only(top: 4),
              child: pw.Text(
                '${photos.length} evidência(s) fotográfica(s) anexada(s) no relatório completo.',
                style: const pw.TextStyle(fontSize: 7, color: _grey),
              ),
            ),
          );
        }

        body.add(pw.SizedBox(height: 12));
      }
    }

    body.add(pw.SizedBox(height: 8));
    body.add(
      _sectionHeader(
        'PLANO DE AÇÃO',
        subtitle: 'Acompanhamento das medidas corretivas vinculadas à vistoria.',
      ),
    );
    body.add(pw.SizedBox(height: 8));

    if (actions.isEmpty) {
      body.add(
        _emptyState(
          naoConformes == 0
              ? 'Nenhuma ação corretiva necessária para esta vistoria.'
              : 'Nenhuma ação corretiva foi cadastrada para as pendências desta vistoria.',
          positive: naoConformes == 0,
        ),
      );
    } else {
      for (var i = 0; i < actions.length; i++) {
        body.add(_actionCard(actions[i], i + 1));
        body.add(pw.SizedBox(height: 8));
      }
    }

    // O relatório executivo para aqui na parte operacional detalhada.
    if (!executive) {
      body.add(pw.SizedBox(height: 12));
      body.add(
        _sectionHeader(
          'CHECKLIST COMPLETO',
          subtitle: 'Registro de todos os itens avaliados, inclusive conformes e N/A.',
        ),
      );
      body.add(pw.SizedBox(height: 8));

      for (var i = 0; i < answers.length; i++) {
        final answer = answers[i];
        final photos = await db.getPhotosForAnswer(answer.id);

        body.add(_checklistItemCard(answer, i + 1));

        if (photos.isNotEmpty) {
          body.add(pw.SizedBox(height: 5));
          body.addAll(
            await _photoRows(
              photos.map((e) => e.path).toList(),
              captionPrefix: 'Item ${i + 1}',
              compact: true,
            ),
          );
        }

        body.add(pw.SizedBox(height: 8));
      }

      final completedActions = actions
          .where((action) => action.status == 'Concluído')
          .toList();

      if (completedActions.isNotEmpty) {
        body.add(pw.SizedBox(height: 12));
        body.add(
          _sectionHeader(
            'EVIDÊNCIAS DE CORREÇÃO',
            subtitle: 'Comparativo fotográfico antes e depois das ações concluídas.',
          ),
        );
        body.add(pw.SizedBox(height: 8));

        for (var i = 0; i < completedActions.length; i++) {
          final action = completedActions[i];
          final before = await db.getOriginalPhotosForAction(action.id);
          final after = await db.getCompletionPhotos(action.id);

          body.add(_completedActionHeader(action, i + 1));
          body.add(pw.SizedBox(height: 6));

          final maxCount = before.length > after.length
              ? before.length
              : after.length;

          if (maxCount == 0) {
            body.add(
              _emptyState(
                'Nenhuma evidência de antes/depois anexada.',
              ),
            );
          } else {
            for (var photoIndex = 0; photoIndex < maxCount; photoIndex++) {
              final beforeWidget = photoIndex < before.length
                  ? await _photoBox(
                      path: before[photoIndex].path,
                      caption: 'ANTES',
                      compact: false,
                    )
                  : pw.SizedBox();
              final afterWidget = photoIndex < after.length
                  ? await _photoBox(
                      path: after[photoIndex].path,
                      caption: 'DEPOIS',
                      compact: false,
                    )
                  : pw.SizedBox();

              body.add(
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Expanded(child: beforeWidget),
                    pw.SizedBox(width: 10),
                    pw.Expanded(child: afterWidget),
                  ],
                ),
              );
              body.add(pw.SizedBox(height: 8));
            }
          }
          body.add(pw.SizedBox(height: 10));
        }
      }
    }

    if (generalNotes.isNotEmpty) {
      body.add(pw.SizedBox(height: 16));
      body.add(
        _sectionHeader(
          'OBSERVAÇÕES GERAIS',
          subtitle: 'Informações complementares registradas pelo responsável pela inspeção.',
        ),
      );
      body.add(pw.SizedBox(height: 7));
      body.add(_textCard(generalNotes));
    }

    body.add(pw.SizedBox(height: 16));
    body.add(
      _sectionHeader(
        'CONCLUSÃO',
        subtitle: 'Síntese técnica da situação encontrada.',
      ),
    );
    body.add(pw.SizedBox(height: 7));
    body.add(
      _conclusionCard(
        conclusion,
        positive: naoConformes == 0 && parciais == 0,
        warning: naoConformes == 0 && parciais > 0,
      ),
    );

    body.add(pw.SizedBox(height: 22));
    body.add(
      _sectionHeader(
        'ASSINATURAS',
        subtitle: 'Responsáveis pelo registro e ciência da inspeção.',
      ),
    );
    body.add(pw.SizedBox(height: 14));
    body.add(
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(
            child: _signatureBlock(
              title: 'Técnico responsável',
              name: technicianName,
              signature: technicianSignature,
            ),
          ),
          if (responsibleName.isNotEmpty) ...[
            pw.SizedBox(width: 24),
            pw.Expanded(
              child: _signatureBlock(
                title: 'Responsável da empresa',
                name: responsibleName,
                signature: responsibleSignature,
              ),
            ),
          ],
        ],
      ),
    );
    body.add(pw.SizedBox(height: 16));
    body.add(
      pw.Container(
        width: double.infinity,
        padding: const pw.EdgeInsets.all(10),
        decoration: pw.BoxDecoration(
          color: PdfColors.grey100,
          borderRadius: pw.BorderRadius.circular(6),
        ),
        child: pw.Text(
          'Documento gerado automaticamente pelo Auditar SST. As informações registradas refletem os dados fornecidos durante a inspeção.',
          textAlign: pw.TextAlign.center,
          style: const pw.TextStyle(fontSize: 7.5, color: _grey),
        ),
      ),
    );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(34, 48, 34, 42),
        header: (context) => _runningHeader(
          context: context,
          auditarIcon: auditarIcon,
          companyName: companyName,
          checklist: checklist,
          reportNumber: reportNumber,
        ),
        footer: (context) => _runningFooter(
          context: context,
          reportFooter: reportFooter,
          companyName: companyName,
          reportNumber: reportNumber,
        ),
        build: (_) => body,
      ),
    );

    return doc.save();
  }

  static String _automaticConclusion({
    required int naoConformes,
    required int parciais,
    required int conformity,
  }) {
    if (naoConformes == 0 && parciais == 0) {
      return 'A inspeção foi concluída sem registro de não conformidades ou atendimentos parciais. O índice de conformidade foi de $conformity%. Recomenda-se manter os controles existentes, preservar as boas práticas observadas e realizar acompanhamento periódico.';
    }

    if (naoConformes == 0) {
      return 'A inspeção não identificou não conformidades formais, porém foram registrados $parciais item(ns) com atendimento parcial. Recomenda-se acompanhar esses pontos até a adequação completa, mantendo os controles já existentes.';
    }

    final parcialText = parciais > 0
        ? ' Também foram registrados $parciais item(ns) com atendimento parcial.'
        : '';

    return 'A inspeção identificou $naoConformes não conformidade(s), com índice de conformidade de $conformity%.$parcialText Recomenda-se executar e acompanhar as ações corretivas, respeitando prioridades e prazos, e realizar verificação posterior da eficácia das medidas adotadas.';
  }

  static pw.Widget _coverPage({
    required pw.ImageProvider? auditarLogo,
    required pw.ImageProvider? companyLogo,
    required bool executive,
    required String companyName,
    required String checklist,
    required String reportNumber,
    required String date,
    required String sector,
    required String worksite,
    required String technicianName,
  }) {
    return pw.Column(
      children: [
        pw.Container(height: 12, color: _navy),
        pw.Expanded(
          child: pw.Padding(
            padding: const pw.EdgeInsets.fromLTRB(54, 48, 54, 44),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Row(
                      mainAxisSize: pw.MainAxisSize.min,
                      children: [
                        if (auditarLogo != null)
                          pw.Container(
                            width: 50,
                            height: 50,
                            child: pw.Image(auditarLogo, fit: pw.BoxFit.contain),
                          ),
                        if (auditarLogo != null) pw.SizedBox(width: 10),
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.RichText(
                              text: pw.TextSpan(
                                children: [
                                  pw.TextSpan(
                                    text: 'Auditar ',
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                      fontWeight: pw.FontWeight.bold,
                                      color: _navy,
                                    ),
                                  ),
                                  pw.TextSpan(
                                    text: 'SST',
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                      fontWeight: pw.FontWeight.bold,
                                      color: _green,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            pw.SizedBox(height: 2),
                            pw.Text(
                              'SEGURANÇA DO TRABALHO',
                              style: pw.TextStyle(
                                fontSize: 6.5,
                                fontWeight: pw.FontWeight.bold,
                                color: _green,
                                letterSpacing: 1.0,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    pw.Spacer(),
                    if (companyLogo != null)
                      pw.Container(
                        width: 90,
                        height: 70,
                        alignment: pw.Alignment.topRight,
                        child: pw.Image(companyLogo, fit: pw.BoxFit.contain),
                      ),
                  ],
                ),
                pw.Spacer(),
                pw.Text(
                  executive ? 'Relatório Executivo' : 'Relatório de Inspeção',
                  style: const pw.TextStyle(fontSize: 20, color: _grey),
                ),
                pw.Text(
                  'Segurança do Trabalho',
                  style: pw.TextStyle(
                    fontSize: 34,
                    fontWeight: pw.FontWeight.bold,
                    color: _navy,
                  ),
                ),
                pw.SizedBox(height: 10),
                pw.Container(width: 82, height: 4, color: _green),
                pw.SizedBox(height: 18),
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: pw.BoxDecoration(
                    color: _greenSoft,
                    border: pw.Border.all(color: PdfColors.green200),
                    borderRadius: pw.BorderRadius.circular(14),
                  ),
                  child: pw.Text(
                    checklist.toUpperCase(),
                    style: pw.TextStyle(
                      fontSize: 10,
                      fontWeight: pw.FontWeight.bold,
                      color: _green,
                    ),
                  ),
                ),
                pw.Spacer(),
                pw.Container(
                  width: double.infinity,
                  padding: const pw.EdgeInsets.all(16),
                  decoration: pw.BoxDecoration(
                    color: PdfColors.grey50,
                    border: pw.Border.all(color: _line),
                    borderRadius: pw.BorderRadius.circular(8),
                  ),
                  child: pw.Column(
                    children: [
                      pw.Row(
                        children: [
                          pw.Expanded(
                            child: _coverField('EMPRESA', companyName),
                          ),
                          pw.SizedBox(width: 18),
                          pw.Expanded(
                            child: _coverField(
                              'SETOR / ÁREA',
                              sector.isEmpty ? '-' : sector,
                            ),
                          ),
                        ],
                      ),
                      pw.SizedBox(height: 14),
                      pw.Row(
                        children: [
                          pw.Expanded(
                            child: _coverField(
                              'OBRA / UNIDADE',
                              worksite.isEmpty ? '-' : worksite,
                            ),
                          ),
                          pw.SizedBox(width: 18),
                          pw.Expanded(
                            child: _coverField('DATA DA INSPEÇÃO', date),
                          ),
                        ],
                      ),
                      pw.SizedBox(height: 14),
                      pw.Row(
                        children: [
                          pw.Expanded(
                            child: _coverField(
                              'TÉCNICO RESPONSÁVEL',
                              technicianName.isEmpty ? '-' : technicianName,
                            ),
                          ),
                          pw.SizedBox(width: 18),
                          pw.Expanded(
                            child: _coverField(
                              'Nº DO RELATÓRIO',
                              reportNumber.isEmpty ? '-' : reportNumber,
                              emphasize: true,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                pw.SizedBox(height: 24),
                pw.Text(
                  executive
                      ? 'Documento gerencial - visão resumida da inspeção'
                      : 'Documento técnico gerado automaticamente pelo Auditar SST',
                  style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
                ),
              ],
            ),
          ),
        ),
        pw.Container(height: 7, color: _green),
      ],
    );
  }

  static pw.Widget _coverField(
    String label,
    String value, {
    bool emphasize = false,
  }) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(
            fontSize: 7,
            fontWeight: pw.FontWeight.bold,
            color: _grey,
          ),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          value,
          style: pw.TextStyle(
            fontSize: emphasize ? 11 : 9.5,
            fontWeight: emphasize ? pw.FontWeight.bold : pw.FontWeight.normal,
            color: emphasize ? _navy : PdfColors.black,
          ),
        ),
      ],
    );
  }

  static pw.Widget _runningHeader({
    required pw.Context context,
    required pw.ImageProvider? auditarIcon,
    required String companyName,
    required String checklist,
    required String reportNumber,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: _line)),
      ),
      child: pw.Row(
        children: [
          if (auditarIcon != null)
            pw.Container(
              width: 23,
              height: 23,
              child: pw.Image(auditarIcon, fit: pw.BoxFit.contain),
            ),
          if (auditarIcon != null) pw.SizedBox(width: 7),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'AUDITAR SST  |  $checklist',
                  style: pw.TextStyle(
                    fontSize: 8.5,
                    fontWeight: pw.FontWeight.bold,
                    color: _navy,
                  ),
                ),
                pw.Text(
                  companyName,
                  style: const pw.TextStyle(fontSize: 7, color: _grey),
                ),
              ],
            ),
          ),
          if (reportNumber.isNotEmpty)
            pw.Text(
              reportNumber,
              style: const pw.TextStyle(fontSize: 7.5, color: _grey),
            ),
        ],
      ),
    );
  }

  static pw.Widget _runningFooter({
    required pw.Context context,
    required String reportFooter,
    required String companyName,
    required String reportNumber,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.only(top: 7),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: _line)),
      ),
      child: pw.Row(
        children: [
          pw.Expanded(
            child: pw.Text(
              '$reportFooter  |  $companyName',
              style: const pw.TextStyle(fontSize: 6.8, color: _grey),
            ),
          ),
          if (reportNumber.isNotEmpty)
            pw.Text(
              '$reportNumber  |  ',
              style: const pw.TextStyle(fontSize: 6.8, color: _grey),
            ),
          pw.Text(
            'Página ${context.pageNumber + 1} de ${context.pagesCount + 1}',
            style: const pw.TextStyle(fontSize: 6.8, color: _grey),
          ),
        ],
      ),
    );
  }

  static pw.Widget _pageTitle(String title, String subtitle) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          title,
          style: pw.TextStyle(
            fontSize: 22,
            fontWeight: pw.FontWeight.bold,
            color: _navy,
          ),
        ),
        pw.SizedBox(height: 4),
        pw.Text(
          subtitle,
          style: const pw.TextStyle(fontSize: 9, color: _grey),
        ),
      ],
    );
  }

  static pw.Widget _summaryMetrics({
    required int conformes,
    required int naoConformes,
    required int parciais,
    required int naoAplicaveis,
    required int conformity,
  }) {
    return pw.Row(
      children: [
        pw.Expanded(
          child: _metricCard(
            label: 'Conformes',
            value: '$conformes',
            secondary: '$conformity%',
            color: _green,
            softColor: _greenSoft,
          ),
        ),
        pw.SizedBox(width: 7),
        pw.Expanded(
          child: _metricCard(
            label: 'Não conformes',
            value: '$naoConformes',
            color: _red,
            softColor: _redSoft,
          ),
        ),
        pw.SizedBox(width: 7),
        pw.Expanded(
          child: _metricCard(
            label: 'Parciais',
            value: '$parciais',
            color: _amber,
            softColor: _amberSoft,
          ),
        ),
        pw.SizedBox(width: 7),
        pw.Expanded(
          child: _metricCard(
            label: 'N/A',
            value: '$naoAplicaveis',
            color: _grey,
            softColor: PdfColors.grey100,
          ),
        ),
      ],
    );
  }

  static pw.Widget _metricCard({
    required String label,
    required String value,
    required PdfColor color,
    required PdfColor softColor,
    String? secondary,
  }) {
    return pw.Container(
      height: 78,
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        color: softColor,
        border: pw.Border.all(color: color, width: 0.7),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        mainAxisAlignment: pw.MainAxisAlignment.center,
        children: [
          pw.Text(
            value,
            style: pw.TextStyle(
              fontSize: 18,
              fontWeight: pw.FontWeight.bold,
              color: color,
            ),
          ),
          if (secondary != null)
            pw.Text(
              secondary,
              style: pw.TextStyle(
                fontSize: 8,
                fontWeight: pw.FontWeight.bold,
                color: color,
              ),
            ),
          pw.SizedBox(height: 2),
          pw.Text(
            label,
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              fontSize: 7.2,
              fontWeight: pw.FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _distributionCard({
    required int conformes,
    required int naoConformes,
    required int parciais,
    required int naoAplicaveis,
    required int total,
  }) {
    final segments = <pw.Widget>[];

    if (conformes > 0) {
      segments.add(
        pw.Expanded(
          flex: conformes,
          child: pw.Container(height: 14, color: _green),
        ),
      );
    }
    if (parciais > 0) {
      segments.add(
        pw.Expanded(
          flex: parciais,
          child: pw.Container(height: 14, color: _amber),
        ),
      );
    }
    if (naoConformes > 0) {
      segments.add(
        pw.Expanded(
          flex: naoConformes,
          child: pw.Container(height: 14, color: _red),
        ),
      );
    }
    if (naoAplicaveis > 0) {
      segments.add(
        pw.Expanded(
          flex: naoAplicaveis,
          child: pw.Container(height: 14, color: PdfColors.grey500),
        ),
      );
    }

    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                'Distribuição das respostas',
                style: pw.TextStyle(
                  fontSize: 10,
                  fontWeight: pw.FontWeight.bold,
                  color: _navy,
                ),
              ),
              pw.Text(
                'Total: $total item(ns)',
                style: const pw.TextStyle(fontSize: 8, color: _grey),
              ),
            ],
          ),
          pw.SizedBox(height: 9),
          if (segments.isEmpty)
            pw.Container(height: 14, color: PdfColors.grey200)
          else
            pw.Row(children: segments),
          pw.SizedBox(height: 9),
          pw.Wrap(
            spacing: 14,
            runSpacing: 5,
            children: [
              _legend('Conforme', _green),
              _legend('Parcial', _amber),
              _legend('Não Conforme', _red),
              _legend('N/A', PdfColors.grey500),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _legend(String text, PdfColor color) {
    return pw.Row(
      mainAxisSize: pw.MainAxisSize.min,
      children: [
        pw.Container(width: 7, height: 7, color: color),
        pw.SizedBox(width: 4),
        pw.Text(text, style: const pw.TextStyle(fontSize: 7, color: _grey)),
      ],
    );
  }

  static pw.Widget _inspectionDataCard({
    required String reportNumber,
    required String companyName,
    required String cnpj,
    required String worksite,
    required String address,
    required String sector,
    required String area,
    required String checklist,
    required String dateText,
    required String technicianName,
  }) {
    final rows = <List<String>>[
      ['Empresa', companyName],
      if (cnpj.trim().isNotEmpty) ['CNPJ', cnpj],
      if (worksite.isNotEmpty) ['Obra / Unidade', worksite],
      if (address.trim().isNotEmpty) ['Endereço', address],
      ['Setor', sector.isEmpty ? '-' : sector],
      ['Área / Local', area.isEmpty ? '-' : area],
      ['Checklist', checklist],
      ['Data', dateText],
      ['Técnico responsável', technicianName.isEmpty ? '-' : technicianName],
      if (reportNumber.isNotEmpty) ['Nº do relatório', reportNumber],
    ];

    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        children: rows.asMap().entries.map((entry) {
          final index = entry.key;
          final row = entry.value;
          return pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: pw.BoxDecoration(
              color: index.isEven ? PdfColors.grey50 : PdfColors.white,
              border: index == rows.length - 1
                  ? null
                  : const pw.Border(bottom: pw.BorderSide(color: PdfColors.grey200)),
            ),
            child: pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  width: 115,
                  child: pw.Text(
                    row[0],
                    style: pw.TextStyle(
                      fontSize: 7.5,
                      fontWeight: pw.FontWeight.bold,
                      color: _grey,
                    ),
                  ),
                ),
                pw.Expanded(
                  child: pw.Text(
                    row[1],
                    style: const pw.TextStyle(fontSize: 8.3),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  static pw.Widget _sectionHeader(String title, {String? subtitle}) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(bottom: 6),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: PdfColors.green300, width: 1.2)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            title,
            style: pw.TextStyle(
              fontSize: 12,
              fontWeight: pw.FontWeight.bold,
              color: _navy,
            ),
          ),
          if (subtitle != null) ...[
            pw.SizedBox(height: 2),
            pw.Text(
              subtitle,
              style: const pw.TextStyle(fontSize: 7.5, color: _grey),
            ),
          ],
        ],
      ),
    );
  }

  static pw.Widget _issueCard({
    required InspectionAnswer answer,
    required int index,
    required NonConformity? nc,
  }) {
    final isNc = answer.status == 'Não Conforme';
    final color = isNc ? _red : _amber;
    final soft = isNc ? _redSoft : _amberSoft;

    final title = isNc
        ? (nc?.code.isNotEmpty == true ? nc!.code : 'NÃO CONFORMIDADE $index')
        : 'ATENDIMENTO PARCIAL $index';

    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: soft,
        border: pw.Border.all(color: color, width: 0.8),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold,
                    color: color,
                  ),
                ),
              ),
              _statusBadge(answer.status),
            ],
          ),
          if (answer.questionCategory.isNotEmpty) ...[
            pw.SizedBox(height: 4),
            pw.Text(
              answer.questionCategory,
              style: pw.TextStyle(
                fontSize: 8,
                fontWeight: pw.FontWeight.bold,
                color: _navy,
              ),
            ),
          ],
          if (answer.questionReference.isNotEmpty)
            pw.Text(
              'Referência: ${answer.questionReference}',
              style: const pw.TextStyle(fontSize: 7.3, color: _grey),
            ),
          if (answer.questionText.isNotEmpty) ...[
            pw.SizedBox(height: 5),
            pw.Text(
              answer.questionText,
              style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold),
            ),
          ],
          pw.SizedBox(height: 7),
          _detailLine(
            'Situação encontrada',
            answer.observation.isEmpty ? 'Não informada.' : answer.observation,
          ),
          if (answer.riskIdentified.isNotEmpty)
            _detailLine('Risco identificado', answer.riskIdentified),
          if (answer.recommendation.isNotEmpty)
            _detailLine('Recomendação técnica', answer.recommendation),
          if (nc != null) ...[
            _detailLine('Classificação', nc.classification),
            _detailLine('Status da NC', nc.status),
          ],
        ],
      ),
    );
  }

  static pw.Widget _detailLine(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 3),
      child: pw.RichText(
        text: pw.TextSpan(
          style: const pw.TextStyle(fontSize: 7.8, color: PdfColors.black),
          children: [
            pw.TextSpan(
              text: '$label: ',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  static pw.Widget _actionCard(ActionPlan action, int index) {
    final due = action.dueDate == null
        ? '-'
        : DateFormat('dd/MM/yyyy').format(action.dueDate!);
    final statusColor = _actionStatusColor(action.status);

    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            children: [
              pw.Expanded(
                child: pw.Text(
                  'AÇÃO $index',
                  style: pw.TextStyle(
                    fontSize: 9,
                    fontWeight: pw.FontWeight.bold,
                    color: _navy,
                  ),
                ),
              ),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: pw.BoxDecoration(
                  color: _softFor(statusColor),
                  border: pw.Border.all(color: statusColor, width: 0.6),
                  borderRadius: pw.BorderRadius.circular(9),
                ),
                child: pw.Text(
                  action.status,
                  style: pw.TextStyle(
                    fontSize: 6.8,
                    fontWeight: pw.FontWeight.bold,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            action.nonConformity,
            style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 3),
          pw.Text(
            action.correctiveAction,
            style: const pw.TextStyle(fontSize: 8),
          ),
          pw.SizedBox(height: 7),
          pw.Row(
            children: [
              pw.Expanded(
                child: _miniInfo(
                  'RESPONSÁVEL',
                  action.responsible.isEmpty ? '-' : action.responsible,
                ),
              ),
              pw.SizedBox(width: 10),
              pw.Expanded(child: _miniInfo('PRIORIDADE', action.priority)),
              pw.SizedBox(width: 10),
              pw.Expanded(child: _miniInfo('PRAZO', due)),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _miniInfo(String label, String value) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(
            fontSize: 6.3,
            fontWeight: pw.FontWeight.bold,
            color: _grey,
          ),
        ),
        pw.SizedBox(height: 1),
        pw.Text(value, style: const pw.TextStyle(fontSize: 7.3)),
      ],
    );
  }

  static pw.Widget _checklistItemCard(InspectionAnswer answer, int index) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: 22,
                height: 22,
                alignment: pw.Alignment.center,
                decoration: pw.BoxDecoration(
                  color: PdfColors.grey100,
                  borderRadius: pw.BorderRadius.circular(11),
                ),
                child: pw.Text(
                  '$index',
                  style: pw.TextStyle(
                    fontSize: 7.5,
                    fontWeight: pw.FontWeight.bold,
                    color: _navy,
                  ),
                ),
              ),
              pw.SizedBox(width: 8),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      answer.questionText.isEmpty ? 'Item avaliado' : answer.questionText,
                      style: pw.TextStyle(
                        fontSize: 8.5,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    if (answer.questionCategory.isNotEmpty ||
                        answer.questionReference.isNotEmpty) ...[
                      pw.SizedBox(height: 2),
                      pw.Text(
                        [
                          if (answer.questionCategory.isNotEmpty)
                            answer.questionCategory,
                          if (answer.questionReference.isNotEmpty)
                            answer.questionReference,
                        ].join('  |  '),
                        style: const pw.TextStyle(fontSize: 6.8, color: _grey),
                      ),
                    ],
                  ],
                ),
              ),
              pw.SizedBox(width: 8),
              _statusBadge(answer.status),
            ],
          ),
          if (answer.observation.isNotEmpty ||
              answer.riskIdentified.isNotEmpty ||
              answer.recommendation.isNotEmpty) ...[
            pw.SizedBox(height: 7),
            if (answer.observation.isNotEmpty)
              _detailLine('Observação', answer.observation),
            if (answer.riskIdentified.isNotEmpty)
              _detailLine('Risco', answer.riskIdentified),
            if (answer.recommendation.isNotEmpty)
              _detailLine('Recomendação', answer.recommendation),
          ],
        ],
      ),
    );
  }

  static pw.Widget _completedActionHeader(ActionPlan action, int index) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        color: _greenSoft,
        border: pw.Border.all(color: PdfColors.green300),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'AÇÃO CONCLUÍDA $index',
            style: pw.TextStyle(
              fontSize: 9,
              fontWeight: pw.FontWeight.bold,
              color: _green,
            ),
          ),
          pw.SizedBox(height: 3),
          pw.Text(action.nonConformity, style: const pw.TextStyle(fontSize: 8)),
          pw.Text(
            'Correção: ${action.correctiveAction}',
            style: const pw.TextStyle(fontSize: 8),
          ),
          if (action.completedBy.isNotEmpty)
            pw.Text(
              'Concluído por: ${action.completedBy}',
              style: const pw.TextStyle(fontSize: 7.3, color: _grey),
            ),
          if (action.completionDate != null)
            pw.Text(
              'Data: ${DateFormat('dd/MM/yyyy HH:mm').format(action.completionDate!)}',
              style: const pw.TextStyle(fontSize: 7.3, color: _grey),
            ),
          if (action.completionNote.isNotEmpty)
            pw.Text(
              'Observação: ${action.completionNote}',
              style: const pw.TextStyle(fontSize: 7.3, color: _grey),
            ),
        ],
      ),
    );
  }

  static pw.Widget _textCard(String text) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Text(text, style: const pw.TextStyle(fontSize: 8.5)),
    );
  }

  static pw.Widget _conclusionCard(
    String text, {
    required bool positive,
    required bool warning,
  }) {
    final color = positive ? _green : (warning ? _amber : _red);
    final soft = positive ? _greenSoft : (warning ? _amberSoft : _redSoft);

    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: soft,
        border: pw.Border.all(color: color, width: 0.8),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Text(
        text,
        style: const pw.TextStyle(fontSize: 8.7),
      ),
    );
  }

  static pw.Widget _emptyState(String text, {bool positive = false}) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: positive ? _greenSoft : PdfColors.grey100,
        border: pw.Border.all(
          color: positive ? PdfColors.green300 : _line,
        ),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontSize: 8,
          color: positive ? _green : _grey,
          fontWeight: positive ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );
  }

  static pw.Widget _statusBadge(String status) {
    final color = _statusColor(status);
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: pw.BoxDecoration(
        color: _softFor(color),
        border: pw.Border.all(color: color, width: 0.6),
        borderRadius: pw.BorderRadius.circular(9),
      ),
      child: pw.Text(
        status,
        style: pw.TextStyle(
          fontSize: 6.6,
          fontWeight: pw.FontWeight.bold,
          color: color,
        ),
      ),
    );
  }

  static PdfColor _statusColor(String status) {
    switch (status) {
      case 'Conforme':
        return _green;
      case 'Parcial':
        return _amber;
      case 'Não Conforme':
        return _red;
      default:
        return _grey;
    }
  }

  static PdfColor _actionStatusColor(String status) {
    if (status == 'Concluído' || status == 'Concluída') return _green;
    if (status == 'Vencida' || status == 'Atrasada') return _red;
    if (status.contains('andamento') || status.contains('verificação')) {
      return _amber;
    }
    return _grey;
  }

  static PdfColor _softFor(PdfColor color) {
    if (color == _green) return _greenSoft;
    if (color == _red) return _redSoft;
    if (color == _amber) return _amberSoft;
    return PdfColors.grey100;
  }

  static Future<List<pw.Widget>> _photoRows(
    List<String> paths, {
    required String captionPrefix,
    bool compact = false,
  }) async {
    final widgets = <pw.Widget>[];

    for (var i = 0; i < paths.length; i += 2) {
      final left = await _photoBox(
        path: paths[i],
        caption: '$captionPrefix - Foto ${i + 1}',
        compact: compact,
      );

      pw.Widget right = pw.SizedBox();
      if (i + 1 < paths.length) {
        right = await _photoBox(
          path: paths[i + 1],
          caption: '$captionPrefix - Foto ${i + 2}',
          compact: compact,
        );
      }

      widgets.add(
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(child: left),
            pw.SizedBox(width: 10),
            pw.Expanded(child: right),
          ],
        ),
      );
      widgets.add(pw.SizedBox(height: 7));
    }

    return widgets;
  }

  static Future<pw.ImageProvider?> _loadAssetImage(String assetPath) async {
    try {
      final data = await rootBundle.load(assetPath);
      return pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }

  static Future<pw.ImageProvider?> _loadImage(String? path) async {
    if (path == null || path.isEmpty) return null;
    final file = File(path);
    if (!await file.exists()) return null;
    return pw.MemoryImage(await file.readAsBytes());
  }

  static Future<pw.Widget> _photoBox({
    required String path,
    required String caption,
    required bool compact,
  }) async {
    final image = await _loadImage(path);
    final height = compact ? 112.0 : 145.0;

    if (image == null) {
      return pw.Container(
        height: height,
        alignment: pw.Alignment.center,
        decoration: pw.BoxDecoration(
          color: PdfColors.grey100,
          border: pw.Border.all(color: _line),
          borderRadius: pw.BorderRadius.circular(5),
        ),
        child: pw.Text(
          'Foto indisponível',
          style: const pw.TextStyle(fontSize: 7.5, color: _grey),
        ),
      );
    }

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Container(
          height: height,
          width: double.infinity,
          padding: const pw.EdgeInsets.all(3),
          decoration: pw.BoxDecoration(
            color: PdfColors.grey50,
            border: pw.Border.all(color: _line),
            borderRadius: pw.BorderRadius.circular(5),
          ),
          child: pw.Image(image, fit: pw.BoxFit.contain),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          caption,
          style: pw.TextStyle(
            fontSize: 6.8,
            fontWeight: pw.FontWeight.bold,
            color: _grey,
          ),
        ),
      ],
    );
  }

  static pw.Widget _signatureBlock({
    required String title,
    required String name,
    required pw.ImageProvider? signature,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: _line),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Column(
        children: [
          pw.Container(
            height: 55,
            alignment: pw.Alignment.bottomCenter,
            child: signature == null
                ? pw.SizedBox()
                : pw.Image(
                    signature,
                    height: 50,
                    fit: pw.BoxFit.contain,
                  ),
          ),
          pw.Container(height: 1, color: PdfColors.grey600),
          pw.SizedBox(height: 5),
          pw.Text(
            name.isEmpty ? '-' : name,
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              fontSize: 8.5,
              fontWeight: pw.FontWeight.bold,
              color: _navy,
            ),
          ),
          pw.SizedBox(height: 2),
          pw.Text(
            title,
            textAlign: pw.TextAlign.center,
            style: const pw.TextStyle(fontSize: 7, color: _grey),
          ),
        ],
      ),
    );
  }
}
