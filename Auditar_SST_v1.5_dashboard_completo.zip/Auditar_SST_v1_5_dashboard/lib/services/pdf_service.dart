import 'dart:io';
import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../database.dart';

class PdfService {
  static Future<Uint8List> generateInspectionPdf(
    String inspectionId,
  ) async {
    final db = AppDatabase.instance;

    final header =
        await db.getInspectionHeader(inspectionId);

    if (header == null) {
      throw Exception('Vistoria não encontrada.');
    }

    final answers = await db.getAnswers(inspectionId);
    final actions =
        await db.getActionsForInspection(inspectionId);

    final reportFooter = await db.getSetting(
      'report_footer',
      fallback:
          'Relatório de Inspeção de Segurança do Trabalho',
    );

    final doc = pw.Document();

    final companyLogo = await _loadImage(
      header['company_logo_path'] as String?,
    );

    final technicianSignature = await _loadImage(
      header['technician_signature_path'] as String?,
    );

    final responsibleSignature = await _loadImage(
      header['responsible_signature_path'] as String?,
    );

    final date =
        DateTime.tryParse('${header['date'] ?? ''}');

    final dateText = date == null
        ? '-'
        : DateFormat('dd/MM/yyyy HH:mm').format(date);

    final conformes =
        answers.where((e) => e.status == 'Conforme').length;

    final naoConformes = answers
        .where((e) => e.status == 'Não Conforme')
        .length;

    final naoAplicaveis = answers
        .where((e) => e.status == 'Não se aplica')
        .length;

    final considered = conformes + naoConformes;

    final conformity = considered == 0
        ? 0
        : (conformes / considered * 100).round();

    final reportNumber =
        ('${header['report_number'] ?? ''}').trim();

    final technicianName =
        ('${header['technician_name'] ?? ''}').trim();

    final responsibleName =
        ('${header['responsible_name'] ?? ''}').trim();

    final generalNotes =
        ('${header['general_notes'] ?? ''}').trim();

    final conclusion =
        ('${header['conclusion'] ?? ''}').trim();

    final body = <pw.Widget>[
      _firstPageHeader(
        companyLogo: companyLogo,
        companyName: '${header['company_name'] ?? '-'}',
        reportNumber: reportNumber,
      ),
      pw.SizedBox(height: 14),
      pw.Table(
        border:
            pw.TableBorder.all(color: PdfColors.grey400),
        columnWidths: const {
          0: pw.FlexColumnWidth(1.35),
          1: pw.FlexColumnWidth(3.65),
        },
        children: [
          _row(
            'Nº do relatório',
            reportNumber.isEmpty ? '-' : reportNumber,
          ),
          _row(
            'Empresa',
            '${header['company_name'] ?? '-'}',
          ),
          if (('${header['company_cnpj'] ?? ''}')
              .trim()
              .isNotEmpty)
            _row(
              'CNPJ',
              '${header['company_cnpj']}',
            ),
          _row(
            'Obra / Unidade',
            '${header['worksite_name'] ?? '-'}',
          ),
          if (('${header['worksite_address'] ?? ''}')
              .trim()
              .isNotEmpty)
            _row(
              'Endereço',
              '${header['worksite_address']}',
            ),
          _row(
            'Setor / Área',
            '${header['area'] ?? '-'}',
          ),
          _row(
            'Checklist',
            '${header['checklist_type'] ?? '-'}',
          ),
          _row('Data', dateText),
          _row(
            'Técnico responsável',
            technicianName.isEmpty
                ? '-'
                : technicianName,
          ),
        ],
      ),
      pw.SizedBox(height: 18),
      _sectionTitle('RESUMO DA VISTORIA'),
      pw.SizedBox(height: 8),
      pw.Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _metric('Conformes', '$conformes'),
          _metric(
            'Não conformes',
            '$naoConformes',
          ),
          _metric(
            'Não aplicáveis',
            '$naoAplicaveis',
          ),
          _metric(
            'Conformidade',
            '$conformity%',
          ),
        ],
      ),
      pw.SizedBox(height: 20),
      _sectionTitle(
        'NÃO CONFORMIDADES E EVIDÊNCIAS',
      ),
      pw.SizedBox(height: 8),
    ];

    final nonConforming = answers
        .where((e) => e.status == 'Não Conforme')
        .toList();

    if (nonConforming.isEmpty) {
      body.add(
        pw.Text(
          'Nenhuma não conformidade registrada.',
        ),
      );
    } else {
      for (var ncIndex = 0;
          ncIndex < nonConforming.length;
          ncIndex++) {
        final answer = nonConforming[ncIndex];
        final number = ncIndex + 1;
        final photos =
            await db.getPhotosForAnswer(answer.id);

        body.add(
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(9),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              border: pw.Border.all(
                color: PdfColors.grey400,
              ),
            ),
            child: pw.Column(
              crossAxisAlignment:
                  pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'NÃO CONFORMIDADE $number',
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
                if (answer.questionCategory.isNotEmpty)
                  pw.Text(
                    answer.questionCategory,
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 9,
                    ),
                  ),
                if (answer
                    .questionReference.isNotEmpty)
                  pw.Text(
                    'Referência: ${answer.questionReference}',
                    style:
                        const pw.TextStyle(fontSize: 8),
                  ),
                if (answer.questionText.isNotEmpty) ...[
                  pw.SizedBox(height: 4),
                  pw.Text(
                    'Item verificado: ${answer.questionText}',
                    style:
                        const pw.TextStyle(fontSize: 8),
                  ),
                ],
                pw.SizedBox(height: 6),
                pw.Text(
                  'Descrição: ${answer.observation.isEmpty ? "-" : answer.observation}',
                ),
                pw.Text(
                  'Risco identificado: ${answer.riskIdentified.isEmpty ? "-" : answer.riskIdentified}',
                ),
                pw.Text(
                  'Recomendação técnica: ${answer.recommendation.isEmpty ? "-" : answer.recommendation}',
                ),
              ],
            ),
          ),
        );

        if (photos.isNotEmpty) {
          body.add(pw.SizedBox(height: 6));
          body.add(
            pw.Text(
              'Evidências fotográficas:',
              style: pw.TextStyle(
                fontWeight: pw.FontWeight.bold,
                fontSize: 9,
              ),
            ),
          );
          body.add(pw.SizedBox(height: 5));

          for (var i = 0; i < photos.length; i += 2) {
            final left = await _photoBox(
              path: photos[i].path,
              caption:
                  'Foto ${i + 1} — NC $number',
            );

            pw.Widget? right;

            if (i + 1 < photos.length) {
              right = await _photoBox(
                path: photos[i + 1].path,
                caption:
                    'Foto ${i + 2} — NC $number',
              );
            }

            body.add(
              pw.Row(
                crossAxisAlignment:
                    pw.CrossAxisAlignment.start,
                children: [
                  pw.Expanded(child: left),
                  pw.SizedBox(width: 10),
                  pw.Expanded(
                    child:
                        right ?? pw.SizedBox(),
                  ),
                ],
              ),
            );
            body.add(pw.SizedBox(height: 8));
          }
        } else {
          body.add(
            pw.Padding(
              padding:
                  const pw.EdgeInsets.only(top: 5),
              child: pw.Text(
                'Sem evidência fotográfica.',
                style: const pw.TextStyle(
                  fontSize: 8,
                  color: PdfColors.grey700,
                ),
              ),
            ),
          );
        }

        body.add(pw.SizedBox(height: 12));
      }
    }

    body.add(pw.SizedBox(height: 6));
    body.add(_sectionTitle('PLANO DE AÇÃO'));
    body.add(pw.SizedBox(height: 8));

    if (actions.isEmpty) {
      body.add(
        pw.Text(
          'Nenhuma ação corretiva registrada.',
        ),
      );
    } else {
      body.add(
        pw.Table.fromTextArray(
          headers: const [
            'Não conformidade',
            'Ação corretiva',
            'Responsável',
            'Prioridade',
            'Prazo',
            'Status',
          ],
          data: actions.map((action) {
            final due = action.dueDate == null
                ? '-'
                : DateFormat('dd/MM/yyyy')
                    .format(action.dueDate!);

            return [
              action.nonConformity,
              action.correctiveAction,
              action.responsible.isEmpty
                  ? '-'
                  : action.responsible,
              action.priority,
              due,
              action.status,
            ];
          }).toList(),
          headerStyle: pw.TextStyle(
            fontWeight: pw.FontWeight.bold,
            fontSize: 7.5,
          ),
          cellStyle:
              const pw.TextStyle(fontSize: 6.8),
          headerDecoration: const pw.BoxDecoration(
            color: PdfColors.grey300,
          ),
          cellAlignment: pw.Alignment.topLeft,
        ),
      );
    }

    final completedActions = actions
        .where((action) => action.status == 'Concluído')
        .toList();

    if (completedActions.isNotEmpty) {
      body.add(pw.SizedBox(height: 20));
      body.add(
        _sectionTitle(
          'EVIDÊNCIAS DE CORREÇÃO — ANTES / DEPOIS',
        ),
      );
      body.add(pw.SizedBox(height: 8));

      for (var i = 0;
          i < completedActions.length;
          i++) {
        final action = completedActions[i];

        final before = await db
            .getOriginalPhotosForAction(action.id);

        final after =
            await db.getCompletionPhotos(action.id);

        body.add(
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(8),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(
                color: PdfColors.grey400,
              ),
            ),
            child: pw.Column(
              crossAxisAlignment:
                  pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'AÇÃO CONCLUÍDA ${i + 1}',
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 10,
                  ),
                ),
                pw.SizedBox(height: 4),
                pw.Text(
                  action.nonConformity,
                  style:
                      const pw.TextStyle(fontSize: 8),
                ),
                pw.Text(
                  'Correção: ${action.correctiveAction}',
                  style:
                      const pw.TextStyle(fontSize: 8),
                ),
                if (action.completedBy.isNotEmpty)
                  pw.Text(
                    'Confirmação: ${action.completedBy}',
                    style:
                        const pw.TextStyle(fontSize: 8),
                  ),
                if (action.completionDate != null)
                  pw.Text(
                    'Data da conclusão: ${DateFormat('dd/MM/yyyy HH:mm').format(action.completionDate!)}',
                    style:
                        const pw.TextStyle(fontSize: 8),
                  ),
                if (action.completionNote.isNotEmpty)
                  pw.Text(
                    'Observação: ${action.completionNote}',
                    style:
                        const pw.TextStyle(fontSize: 8),
                  ),
              ],
            ),
          ),
        );

        body.add(pw.SizedBox(height: 7));

        final max = before.length > after.length
            ? before.length
            : after.length;

        if (max == 0) {
          body.add(
            pw.Text(
              'Nenhuma evidência fotográfica de antes/depois registrada.',
              style: const pw.TextStyle(
                fontSize: 8,
                color: PdfColors.grey700,
              ),
            ),
          );
        } else {
          for (var photoIndex = 0;
              photoIndex < max;
              photoIndex++) {
            final beforeWidget =
                photoIndex < before.length
                    ? await _photoBox(
                        path:
                            before[photoIndex].path,
                        caption: 'ANTES',
                      )
                    : pw.SizedBox();

            final afterWidget =
                photoIndex < after.length
                    ? await _photoBox(
                        path:
                            after[photoIndex].path,
                        caption: 'DEPOIS',
                      )
                    : pw.SizedBox();

            body.add(
              pw.Row(
                crossAxisAlignment:
                    pw.CrossAxisAlignment.start,
                children: [
                  pw.Expanded(
                    child: beforeWidget,
                  ),
                  pw.SizedBox(width: 10),
                  pw.Expanded(
                    child: afterWidget,
                  ),
                ],
              ),
            );

            body.add(pw.SizedBox(height: 8));
          }
        }

        body.add(pw.SizedBox(height: 12));
      }
    }

    if (generalNotes.isNotEmpty) {
      body.add(pw.SizedBox(height: 18));
      body.add(
        _sectionTitle('OBSERVAÇÕES GERAIS'),
      );
      body.add(pw.SizedBox(height: 7));
      body.add(pw.Text(generalNotes));
    }

    if (conclusion.isNotEmpty) {
      body.add(pw.SizedBox(height: 18));
      body.add(_sectionTitle('CONCLUSÃO'));
      body.add(pw.SizedBox(height: 7));
      body.add(pw.Text(conclusion));
    }

    body.add(pw.SizedBox(height: 26));
    body.add(_sectionTitle('ASSINATURAS'));
    body.add(pw.SizedBox(height: 12));

    body.add(
      pw.Row(
        crossAxisAlignment:
            pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(
            child: _signatureBlock(
              title: 'Técnico responsável',
              name: technicianName,
              signature: technicianSignature,
            ),
          ),
          if (responsibleName.isNotEmpty) ...[
            pw.SizedBox(width: 24),
            pw.Expanded(
              child: _signatureBlock(
                title:
                    'Responsável da empresa',
                name: responsibleName,
                signature:
                    responsibleSignature,
              ),
            ),
          ],
        ],
      ),
    );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(
          32,
          32,
          32,
          40,
        ),
        footer: (context) => pw.Container(
          padding:
              const pw.EdgeInsets.only(top: 6),
          decoration: const pw.BoxDecoration(
            border: pw.Border(
              top: pw.BorderSide(
                color: PdfColors.grey400,
              ),
            ),
          ),
          child: pw.Row(
            mainAxisAlignment:
                pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Expanded(
                child: pw.Text(
                  reportFooter,
                  style: const pw.TextStyle(
                    fontSize: 7,
                    color: PdfColors.grey700,
                  ),
                ),
              ),
              pw.SizedBox(width: 8),
              pw.Text(
                'Página ${context.pageNumber} de ${context.pagesCount}',
                style: const pw.TextStyle(
                  fontSize: 7,
                  color: PdfColors.grey700,
                ),
              ),
            ],
          ),
        ),
        build: (context) => body,
      ),
    );

    return doc.save();
  }

  static Future<pw.ImageProvider?> _loadImage(
    String? path,
  ) async {
    if (path == null || path.isEmpty) return null;

    final file = File(path);

    if (!await file.exists()) return null;

    return pw.MemoryImage(
      await file.readAsBytes(),
    );
  }

  static Future<pw.Widget> _photoBox({
    required String path,
    required String caption,
  }) async {
    final image = await _loadImage(path);

    if (image == null) {
      return pw.Container(
        height: 145,
        alignment: pw.Alignment.center,
        decoration: pw.BoxDecoration(
          border:
              pw.Border.all(color: PdfColors.grey400),
        ),
        child: pw.Text(
          'Foto indisponível',
          style: const pw.TextStyle(fontSize: 8),
        ),
      );
    }

    return pw.Column(
      crossAxisAlignment:
          pw.CrossAxisAlignment.start,
      children: [
        pw.Container(
          height: 150,
          width: double.infinity,
          decoration: pw.BoxDecoration(
            border: pw.Border.all(
              color: PdfColors.grey400,
            ),
          ),
          child: pw.Image(
            image,
            fit: pw.BoxFit.contain,
          ),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          caption,
          style: pw.TextStyle(
            fontSize: 7,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
      ],
    );
  }

  static pw.Widget _firstPageHeader({
    required pw.ImageProvider? companyLogo,
    required String companyName,
    required String reportNumber,
  }) {
    final title = pw.Column(
      crossAxisAlignment:
          pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'RELATÓRIO DE INSPEÇÃO DE SEGURANÇA',
          style: pw.TextStyle(
            fontSize: 17,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
        pw.SizedBox(height: 3),
        pw.Text(
          companyName,
          style: pw.TextStyle(
            fontSize: 11,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
        if (reportNumber.isNotEmpty)
          pw.Text(
            'Relatório: $reportNumber',
            style:
                const pw.TextStyle(fontSize: 8),
          ),
      ],
    );

    if (companyLogo == null) {
      return title;
    }

    return pw.Row(
      crossAxisAlignment:
          pw.CrossAxisAlignment.start,
      children: [
        pw.Container(
          width: 76,
          height: 60,
          alignment: pw.Alignment.topLeft,
          child: pw.Image(
            companyLogo,
            fit: pw.BoxFit.contain,
            alignment: pw.Alignment.topLeft,
          ),
        ),
        pw.SizedBox(width: 12),
        pw.Expanded(child: title),
      ],
    );
  }

  static pw.Widget _sectionTitle(String text) {
    return pw.Container(
      width: double.infinity,
      padding:
          const pw.EdgeInsets.symmetric(
        vertical: 5,
        horizontal: 7,
      ),
      decoration: const pw.BoxDecoration(
        color: PdfColors.grey200,
      ),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontSize: 11,
          fontWeight: pw.FontWeight.bold,
        ),
      ),
    );
  }

  static pw.TableRow _row(
    String label,
    String value,
  ) {
    return pw.TableRow(
      children: [
        pw.Padding(
          padding: const pw.EdgeInsets.all(6),
          child: pw.Text(
            label,
            style: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              fontSize: 8,
            ),
          ),
        ),
        pw.Padding(
          padding: const pw.EdgeInsets.all(6),
          child: pw.Text(
            value,
            style:
                const pw.TextStyle(fontSize: 8),
          ),
        ),
      ],
    );
  }

  static pw.Widget _metric(
    String label,
    String value,
  ) {
    return pw.Container(
      width: 112,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border:
            pw.Border.all(color: PdfColors.grey400),
      ),
      child: pw.Column(
        crossAxisAlignment:
            pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            value,
            style: pw.TextStyle(
              fontSize: 15,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.Text(
            label,
            style:
                const pw.TextStyle(fontSize: 8),
          ),
        ],
      ),
    );
  }

  static pw.Widget _signatureBlock({
    required String title,
    required String name,
    required pw.ImageProvider? signature,
  }) {
    return pw.Column(
      children: [
        pw.Container(
          height: 55,
          alignment: pw.Alignment.bottomCenter,
          child: signature == null
              ? pw.SizedBox()
              : pw.Image(
                  signature,
                  height: 50,
                  fit: pw.BoxFit.contain,
                ),
        ),
        pw.Container(
          height: 1,
          color: PdfColors.grey700,
        ),
        pw.SizedBox(height: 4),
        pw.Text(
          name.isEmpty ? '-' : name,
          textAlign: pw.TextAlign.center,
          style:
              const pw.TextStyle(fontSize: 9),
        ),
        pw.Text(
          title,
          textAlign: pw.TextAlign.center,
          style: const pw.TextStyle(
            fontSize: 8,
            color: PdfColors.grey700,
          ),
        ),
      ],
    );
  }
}
