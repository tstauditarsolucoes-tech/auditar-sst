import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;

import '../database.dart';
import '../models.dart';
import 'management_panel_service.dart';

class AiAssistantReply {
  final bool success;
  final String message;
  final Map<String, dynamic> result;

  const AiAssistantReply({
    required this.success,
    required this.message,
    this.result = const {},
  });
}

class AiAssistantService {
  static Future<AiAssistantReply> analyzeCompanyPriorities(
    Company company,
  ) async {
    try {
      final snapshot = await ManagementPanelService.buildSnapshot(company);
      return _send({
        'mode': 'company_priorities',
        'companyData': {
          'empresa': company.name,
          'resumoGeral': snapshot['summary'],
          'resumoTreinamentos': snapshot['trainingSummary'],
          'resumoTrabalhadores': snapshot['workforceSummary'],
          'setores': snapshot['sectors'],
          'naoConformidadesAbertas': snapshot['openNonConformities'],
          'acoesPendentes': snapshot['pendingActions'],
          'vistoriasRecentes': snapshot['recentInspections'],
        },
      });
    } catch (error) {
      return AiAssistantReply(
        success: false,
        message: 'Não foi possível preparar os indicadores da empresa: $error',
      );
    }
  }

  static Future<AiAssistantReply> analyzeChecklistPhotos({
    required Inspection inspection,
    required String companyName,
    required ChecklistItem item,
    required List<String> photoPaths,
    String technicianContext = '',
  }) async {
    if (photoPaths.isEmpty) {
      return const AiAssistantReply(
        success: false,
        message: 'Adicione pelo menos uma foto antes de analisar.',
      );
    }

    try {
      final images = <String>[];
      var totalBytes = 0;
      for (final path in photoPaths.take(4)) {
        final file = File(path);
        if (!await file.exists()) continue;
        final originalBytes = await file.readAsBytes();
        final bytes = _prepareImage(originalBytes);
        totalBytes += bytes.length;
        if (totalBytes > 10000000) {
          return const AiAssistantReply(
            success: false,
            message:
                'As fotos ficaram muito grandes para uma única análise. Use menos fotos.',
          );
        }
        images.add(
          'data:image/jpeg;base64,${base64Encode(bytes)}',
        );
      }
      if (images.isEmpty) {
        return const AiAssistantReply(
          success: false,
          message: 'Não foi possível abrir as fotos selecionadas.',
        );
      }

      return _send({
        'mode': 'checklist_photo',
        'companyName': companyName,
        'area': inspection.area,
        'question': item.text,
        'category': item.category,
        'reference': item.reference,
        'technicianContext': technicianContext.trim(),
        'images': images,
      });
    } catch (error) {
      return AiAssistantReply(
        success: false,
        message: 'Não foi possível preparar as fotos: $error',
      );
    }
  }

  static Future<AiAssistantReply> suggestReportConclusion(
    String inspectionId,
  ) async {
    final db = AppDatabase.instance;
    final header = await db.getInspectionHeader(inspectionId);
    if (header == null) {
      return const AiAssistantReply(
        success: false,
        message: 'Não encontrei os dados desta vistoria.',
      );
    }
    final answers = await db.getAnswers(inspectionId);
    final ncs = await db.getNonConformitiesForInspection(inspectionId);
    final actions = await db.getActionsForInspection(inspectionId);

    final counts = <String, int>{};
    for (final answer in answers) {
      counts[answer.status] = (counts[answer.status] ?? 0) + 1;
    }

    return _send({
      'mode': 'report_conclusion',
      'inspectionData': {
        'empresa': '${header['company_name'] ?? ''}',
        'unidade': '${header['worksite_name'] ?? ''}',
        'setor': '${header['sector_name'] ?? ''}',
        'area': '${header['area'] ?? ''}',
        'tipoChecklist': '${header['checklist_type'] ?? ''}',
        'data': '${header['date'] ?? ''}',
        'resultados': counts,
        'naoConformidades': ncs.take(20).map((nc) => {
              'codigo': nc.code,
              'descricao': nc.description,
              'risco': nc.riskIdentified,
              'recomendacao': nc.recommendation,
              'prioridade': nc.classification,
              'situacao': nc.status,
            }).toList(),
        'planosDeAcao': actions.take(20).map((action) => {
              'naoConformidade': action.nonConformity,
              'acao': action.correctiveAction,
              'prioridade': action.priority,
              'prazo': action.dueDate?.toIso8601String() ?? '',
              'situacao': action.status,
            }).toList(),
      },
    });
  }

  static Future<AiAssistantReply> _send(
    Map<String, Object?> payload,
  ) async {
    final db = AppDatabase.instance;
    final endpoint = (await db.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await db.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();

    if (endpoint.isEmpty || syncKey.isEmpty) {
      return const AiAssistantReply(
        success: false,
        message:
            'Configure primeiro a publicação web em Configurações. Ela também faz a conexão segura com a IA.',
      );
    }

    try {
      final response = await http
          .post(
            Uri.parse(endpoint),
            headers: const {
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode({
              'action': 'ai_assistant',
              'syncKey': syncKey,
              'payload': payload,
            }),
          )
          .timeout(const Duration(seconds: 120));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        return AiAssistantReply(
          success: false,
          message: 'O serviço respondeu com erro ${response.statusCode}.',
        );
      }

      final decoded = jsonDecode(
        utf8.decode(response.bodyBytes),
      ) as Map<String, dynamic>;
      if (decoded['ok'] != true) {
        return AiAssistantReply(
          success: false,
          message: '${decoded['message'] ?? 'A análise não foi concluída.'}',
        );
      }
      final result = decoded['result'];
      if (result is! Map) {
        return const AiAssistantReply(
          success: false,
          message: 'A IA retornou uma resposta incompleta.',
        );
      }
      return AiAssistantReply(
        success: true,
        message: 'Sugestão preparada para sua revisão.',
        result: Map<String, dynamic>.from(result),
      );
    } on SocketException {
      return const AiAssistantReply(
        success: false,
        message: 'A IA precisa de internet. A vistoria continua funcionando offline.',
      );
    } on FormatException {
      return const AiAssistantReply(
        success: false,
        message: 'O serviço retornou uma resposta inválida.',
      );
    } catch (error) {
      return AiAssistantReply(
        success: false,
        message: 'Não foi possível consultar a IA: $error',
      );
    }
  }

  static Uint8List _prepareImage(Uint8List originalBytes) {
    final decoded = img.decodeImage(originalBytes);
    if (decoded == null) {
      throw const FormatException('formato de imagem não reconhecido');
    }

    var prepared = img.bakeOrientation(decoded);
    if (prepared.width > 1280 || prepared.height > 1280) {
      prepared = prepared.width >= prepared.height
          ? img.copyResize(prepared, width: 1280)
          : img.copyResize(prepared, height: 1280);
    }

    // Copia somente os pixels para uma imagem nova. Assim, EXIF, localização
    // e outros metadados do arquivo original não chegam ao codificador.
    final sanitized = img.Image(
      width: prepared.width,
      height: prepared.height,
      numChannels: 3,
    );
    img.compositeImage(sanitized, prepared);
    return Uint8List.fromList(img.encodeJpg(sanitized, quality: 72));
  }
}
