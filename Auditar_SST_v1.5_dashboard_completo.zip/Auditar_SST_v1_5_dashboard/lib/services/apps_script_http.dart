import 'dart:convert';

import 'package:http/http.dart' as http;

/// Cliente HTTP para publicações do Google Apps Script.
///
/// O ContentService responde às chamadas POST com um redirecionamento para
/// googleusercontent.com. O cliente padrão não acompanha esse redirecionamento
/// quando a requisição original é POST, portanto ele precisa ser tratado aqui.
class AppsScriptHttp {
  static const Set<int> _redirectCodes = {301, 302, 303, 307, 308};

  static Future<http.Response> postJson(
    Uri endpoint,
    Object? payload, {
    Duration timeout = const Duration(seconds: 30),
  }) async {
    final client = http.Client();
    var uri = endpoint;
    var method = 'POST';
    final encodedBody = jsonEncode(payload);

    try {
      for (var redirectCount = 0; redirectCount <= 5; redirectCount++) {
        final request = http.Request(method, uri)
          ..followRedirects = false
          ..headers['Accept'] = 'application/json';

        if (method == 'POST') {
          request.headers['Content-Type'] =
              'application/json; charset=utf-8';
          request.body = encodedBody;
        }

        final streamed = await client.send(request).timeout(timeout);
        final response = await http.Response.fromStream(streamed);

        if (!_redirectCodes.contains(response.statusCode)) {
          return response;
        }

        final location = response.headers['location'];
        if (location == null || location.trim().isEmpty) {
          return response;
        }

        uri = uri.resolve(location);
        if (response.statusCode == 301 ||
            response.statusCode == 302 ||
            response.statusCode == 303) {
          method = 'GET';
        }
      }

      return http.Response(
        'A publicação web excedeu o limite de redirecionamentos.',
        508,
      );
    } finally {
      client.close();
    }
  }
}
