import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  static Future<Directory> _folder(String folder) async {
    final baseDir = await getApplicationDocumentsDirectory();
    final targetDir = Directory(p.join(baseDir.path, folder));

    if (!await targetDir.exists()) {
      await targetDir.create(recursive: true);
    }

    return targetDir;
  }

  static Future<String> persistImage(
    String sourcePath, {
    required String folder,
  }) async {
    final targetDir = await _folder(folder);

    final ext =
        p.extension(sourcePath).isEmpty ? '.jpg' : p.extension(sourcePath);

    final targetPath = p.join(
      targetDir.path,
      '${const Uuid().v4()}$ext',
    );

    final copied = await File(sourcePath).copy(targetPath);
    return copied.path;
  }

  static Future<String> persistPngBytes(
    Uint8List bytes, {
    required String folder,
  }) async {
    final targetDir = await _folder(folder);
    final targetPath = p.join(
      targetDir.path,
      '${const Uuid().v4()}.png',
    );

    final file = File(targetPath);
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }
}
