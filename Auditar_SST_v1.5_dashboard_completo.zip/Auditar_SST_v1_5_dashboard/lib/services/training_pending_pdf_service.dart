import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models.dart';

class TrainingPendingPdfService {
  static const navy = PdfColor(0.113725, 0.180392, 0.423529);
  static const green = PdfColor(0.090196, 0.552941, 0.172549);
  static const red = PdfColor(0.788, 0.204, 0.173);
  static const amber = PdfColor(0.922, 0.565, 0.094);

  static Future<Uint8List> generate({
    required Company company,
    required List<Map<String, String>> rows,
  }) async {
    final doc = pw.Document();
    final logo = await _asset('assets/branding/auditar_icon.png');
    final expired = rows.where((row) => row['status'] == 'VENCIDO').length;
    final missing = rows.where((row) => row['status'] == 'SEM REGISTRO').length;
    final pending = rows.where((row) => row['status'] == 'PENDENTE').length;
    final soon = rows.where((row) => row['status'] == 'VENCE EM BREVE').length;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(28),
        header: (_) => _header(company, logo),
        footer: (context) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              'Auditar SST • Controle de treinamentos',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
            ),
            pw.Text(
              'Página ${context.pageNumber} de ${context.pagesCount}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
            ),
          ],
        ),
        build: (_) => [
          pw.SizedBox(height: 10),
          pw.Text(
            'RELATÓRIO DE PENDÊNCIAS DE TREINAMENTO',
            style: pw.TextStyle(
              fontSize: 18,
              fontWeight: pw.FontWeight.bold,
              color: navy,
            ),
          ),
          pw.SizedBox(height: 3),
          pw.Text(
            'Gerado em ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
          pw.SizedBox(height: 12),
          pw.Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              _metric('Total', rows.length, navy),
              _metric('Sem registro', missing, missing > 0 ? amber : green),
              _metric('Pendentes', pending, pending > 0 ? amber : green),
              _metric('Vencidos', expired, expired > 0 ? red : green),
              _metric('Vence em 30 dias', soon, soon > 0 ? amber : green),
            ],
          ),
          pw.SizedBox(height: 14),
          if (rows.isEmpty)
            pw.Container(
              padding: const pw.EdgeInsets.all(14),
              decoration: pw.BoxDecoration(
                color: PdfColor(0.91, 0.97, 0.92),
                borderRadius: pw.BorderRadius.circular(7),
              ),
              child: pw.Text(
                'Nenhuma pendência de treinamento registrada para esta empresa.',
                style: pw.TextStyle(color: green, fontWeight: pw.FontWeight.bold),
              ),
            )
          else
            pw.TableHelper.fromTextArray(
              headers: const [
                'Colaborador',
                'Cargo / setor',
                'Treinamento',
                'Situação',
                'Validade',
              ],
              data: rows
                  .map(
                    (row) => [
                      row['worker'] ?? '-',
                      [row['role'], row['sector']]
                          .where((value) => (value ?? '').isNotEmpty)
                          .join(' • '),
                      row['training'] ?? '-',
                      row['status'] ?? '-',
                      (row['expiry'] ?? '').isEmpty ? '-' : row['expiry']!,
                    ],
                  )
                  .toList(),
              headerStyle: pw.TextStyle(
                color: PdfColors.white,
                fontSize: 8,
                fontWeight: pw.FontWeight.bold,
              ),
              headerDecoration: const pw.BoxDecoration(color: navy),
              cellStyle: const pw.TextStyle(fontSize: 7.5),
              cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
              border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
              columnWidths: const {
                0: pw.FlexColumnWidth(1.6),
                1: pw.FlexColumnWidth(1.4),
                2: pw.FlexColumnWidth(2.0),
                3: pw.FlexColumnWidth(1.0),
                4: pw.FlexColumnWidth(0.8),
              },
            ),
        ],
      ),
    );
    return doc.save();
  }

  static pw.Widget _header(Company company, pw.ImageProvider? logo) {
    return pw.Container(
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300)),
      ),
      child: pw.Row(
        children: [
          if (logo != null) ...[
            pw.Image(logo, width: 32, height: 32),
            pw.SizedBox(width: 8),
          ],
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.RichText(
                  text: pw.TextSpan(
                    children: [
                      pw.TextSpan(
                        text: 'Auditar ',
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          color: navy,
                          fontSize: 14,
                        ),
                      ),
                      pw.TextSpan(
                        text: 'SST',
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          color: green,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                pw.Text(
                  [
                    company.name,
                    if ((company.cnpj ?? '').trim().isNotEmpty)
                      'CNPJ ${company.cnpj}',
                  ].join(' • '),
                  style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _metric(String label, int value, PdfColor color) {
    return pw.Container(
      width: 105,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(7),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            '$value',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: color,
            ),
          ),
          pw.SizedBox(height: 2),
          pw.Text(label, style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700)),
        ],
      ),
    );
  }

  static Future<pw.ImageProvider?> _asset(String path) async {
    try {
      final data = await rootBundle.load(path);
      return pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }
}
