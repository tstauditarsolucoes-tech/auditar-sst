import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import 'apps_script_http.dart';

class WorkerImportCandidate {
  final Worker worker;
  final bool isNew;
  final int sourceLine;

  const WorkerImportCandidate({
    required this.worker,
    required this.isNew,
    required this.sourceLine,
  });
}

class WorkerImportPreview {
  final String fileName;
  final List<WorkerImportCandidate> candidates;
  final int invalidRows;
  final int duplicateRows;
  final int ambiguousRows;
  final List<String> unknownSectors;
  final List<Worker> activeWorkersNotInFile;

  const WorkerImportPreview({
    required this.fileName,
    required this.candidates,
    required this.invalidRows,
    required this.duplicateRows,
    required this.ambiguousRows,
    required this.unknownSectors,
    required this.activeWorkersNotInFile,
  });

  int get newCount => candidates.where((row) => row.isNew).length;
  int get updateCount => candidates.where((row) => !row.isNew).length;
}

class WorkerImportException implements Exception {
  final String message;

  const WorkerImportException(this.message);

  @override
  String toString() => message;
}

class WorkerImportService {
  static Future<WorkerImportPreview?> pickAndPrepare({
    required String companyId,
    required List<Sector> sectors,
  }) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;

    final selected = result.files.single;
    Uint8List? bytes = selected.bytes;
    if (bytes == null && selected.path != null) {
      bytes = await File(selected.path!).readAsBytes();
    }
    if (bytes == null || bytes.isEmpty) {
      throw const WorkerImportException(
        'Não foi possível abrir o arquivo selecionado.',
      );
    }

    final table = await _readPdf(bytes);
    return _prepare(
      fileName: selected.name,
      table: table,
      companyId: companyId,
      sectors: sectors,
    );
  }

  static Future<List<List<String>>> _readPdf(Uint8List bytes) async {
    if (bytes.length > 12000000) {
      throw const WorkerImportException(
        'O PDF ultrapassa 12 MB. Gere uma lista menor ou um PDF mais leve.',
      );
    }
    final endpoint = (await AppDatabase.instance.getSetting(
      'management_panel_endpoint',
      fallback: '',
    ))
        .trim();
    final syncKey = (await AppDatabase.instance.getSetting(
      'management_panel_sync_key',
      fallback: '',
    ))
        .trim();
    if (endpoint.isEmpty || syncKey.isEmpty) {
      throw const WorkerImportException(
        'Configure primeiro a publicação web em Configurações. Ela faz a leitura segura do PDF.',
      );
    }

    try {
      final response = await AppsScriptHttp.postJson(
        Uri.parse(endpoint),
        {
          'action': 'ai_assistant',
          'syncKey': syncKey,
          'payload': {
            'mode': 'employee_pdf_import',
            'document': 'data:application/pdf;base64,${base64Encode(bytes)}',
          },
        },
        timeout: const Duration(seconds: 180),
      );
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw WorkerImportException(
          'O serviço respondeu com erro ${response.statusCode}.',
        );
      }
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is! Map || decoded['ok'] != true) {
        throw WorkerImportException(
          decoded is Map
              ? '${decoded['message'] ?? 'A leitura do PDF não foi concluída.'}'
              : 'A leitura do PDF retornou uma resposta inválida.',
        );
      }
      final result = decoded['result'];
      final employees = result is Map ? result['employees'] : null;
      if (employees is! List || employees.isEmpty) {
        throw const WorkerImportException(
          'Não encontrei funcionários com nome e cargo no PDF.',
        );
      }
      return <List<String>>[
        const ['Nome', 'Cargo', 'Setor'],
        ...employees.whereType<Map>().map(
              (employee) => <String>[
                '${employee['name'] ?? ''}'.trim(),
                '${employee['role'] ?? ''}'.trim(),
                '${employee['sector'] ?? ''}'.trim(),
              ],
            ),
      ];
    } on SocketException {
      throw const WorkerImportException(
        'A leitura do PDF precisa de internet. Tente novamente quando estiver conectado.',
      );
    } on FormatException {
      throw const WorkerImportException(
        'O serviço retornou uma resposta inválida ao ler o PDF.',
      );
    } on WorkerImportException {
      rethrow;
    } catch (error) {
      throw WorkerImportException('Não foi possível ler o PDF: $error');
    }
  }

  static Future<WorkerImportPreview> _prepare({
    required String fileName,
    required List<List<String>> table,
    required String companyId,
    required List<Sector> sectors,
  }) async {
    if (table.isEmpty) {
      throw const WorkerImportException('O PDF não contém uma lista válida.');
    }

    final header = _findHeader(table);
    if (header == null) {
      throw const WorkerImportException(
        'Não encontrei Nome e Cargo na lista reconhecida do PDF.',
      );
    }

    final existing = await AppDatabase.instance.getWorkers(
      companyId: companyId,
      onlyActive: false,
    );
    final existingByCpf = <String, Worker>{};
    final existingByName = <String, List<Worker>>{};
    for (final worker in existing) {
      final cpf = _digits(worker.cpf);
      if (cpf.length == 11) existingByCpf[cpf] = worker;
      existingByName
          .putIfAbsent(_normalize(worker.name), () => <Worker>[])
          .add(worker);
    }
    final sectorByName = {
      for (final sector in sectors) _normalize(sector.name): sector,
    };

    final candidates = <WorkerImportCandidate>[];
    final importedKeys = <String>{};
    final importedExistingIds = <String>{};
    final unknownSectors = <String>{};
    var invalidRows = 0;
    var duplicateRows = 0;
    var ambiguousRows = 0;

    for (var rowIndex = header.rowIndex + 1;
        rowIndex < table.length;
        rowIndex++) {
      final row = table[rowIndex];
      final name = _cell(row, header.nameColumn).trim();
      final role = _cell(row, header.roleColumn).trim();
      if (name.isEmpty && role.isEmpty) continue;
      if (name.isEmpty || role.isEmpty) {
        invalidRows++;
        continue;
      }

      final cpfDigits = _digits(_cell(row, header.cpfColumn));
      final validCpf = cpfDigits.length == 11 ? cpfDigits : '';
      final normalizedName = _normalize(name);
      final identity = validCpf.isNotEmpty
          ? 'cpf:$validCpf'
          : 'nome:$normalizedName';
      if (!importedKeys.add(identity)) {
        duplicateRows++;
        continue;
      }

      Worker? matched;
      if (validCpf.isNotEmpty) matched = existingByCpf[validCpf];
      if (matched == null) {
        final sameName = existingByName[normalizedName] ?? const <Worker>[];
        if (sameName.length == 1) {
          matched = sameName.first;
        } else if (sameName.length > 1) {
          final sameRole = sameName
              .where((worker) => _normalize(worker.role) == _normalize(role))
              .toList();
          if (sameRole.length == 1) {
            matched = sameRole.first;
          } else {
            ambiguousRows++;
            importedExistingIds.addAll(sameName.map((worker) => worker.id));
            continue;
          }
        }
      }

      final sectorName = _cell(row, header.sectorColumn).trim();
      final importedSector = sectorName.isEmpty
          ? null
          : sectorByName[_normalize(sectorName)];
      if (sectorName.isNotEmpty && importedSector == null) {
        unknownSectors.add(sectorName);
      }
      final admission = _parseDate(_cell(row, header.admissionColumn));
      final active = _parseActive(_cell(row, header.statusColumn));

      final worker = Worker(
        id: matched?.id ?? const Uuid().v4(),
        companyId: companyId,
        sectorId: importedSector?.id ?? matched?.sectorId,
        name: name,
        cpf: validCpf.isNotEmpty ? validCpf : (matched?.cpf ?? ''),
        role: role,
        admissionDate: admission ?? matched?.admissionDate,
        lastMedicalExamDate: matched?.lastMedicalExamDate,
        nextMedicalExamDate: matched?.nextMedicalExamDate,
        asoPath: matched?.asoPath ?? '',
        active: active,
      );
      candidates.add(
        WorkerImportCandidate(
          worker: worker,
          isNew: matched == null,
          sourceLine: rowIndex + 1,
        ),
      );
      if (matched != null) importedExistingIds.add(matched.id);
    }

    if (candidates.isEmpty) {
      throw const WorkerImportException(
        'Nenhum trabalhador válido foi encontrado. Nome e Cargo são obrigatórios.',
      );
    }

    final missing = existing
        .where(
          (worker) => worker.active && !importedExistingIds.contains(worker.id),
        )
        .toList();

    return WorkerImportPreview(
      fileName: fileName,
      candidates: candidates,
      invalidRows: invalidRows,
      duplicateRows: duplicateRows,
      ambiguousRows: ambiguousRows,
      unknownSectors: unknownSectors.toList()..sort(),
      activeWorkersNotInFile: missing,
    );
  }

  static _HeaderMap? _findHeader(List<List<String>> table) {
    final limit = table.length < 15 ? table.length : 15;
    for (var rowIndex = 0; rowIndex < limit; rowIndex++) {
      final row = table[rowIndex];
      int? find(Set<String> aliases) {
        for (var column = 0; column < row.length; column++) {
          final header = _normalize(row[column]);
          if (aliases.contains(header)) return column;
        }
        return null;
      }

      final name = find(const {
        'nome',
        'nome completo',
        'nome do funcionario',
        'funcionario',
        'colaborador',
        'empregado',
      });
      final role = find(const {
        'cargo',
        'funcao',
        'cargo funcao',
        'cargo/funcao',
        'ocupacao',
      });
      if (name == null || role == null) continue;
      return _HeaderMap(
        rowIndex: rowIndex,
        nameColumn: name,
        roleColumn: role,
        cpfColumn: find(const {'cpf', 'cpf do funcionario'}),
        sectorColumn: find(const {
          'setor',
          'departamento',
          'area',
          'lotacao',
          'unidade setor',
        }),
        admissionColumn: find(const {
          'admissao',
          'data admissao',
          'data de admissao',
          'dt admissao',
        }),
        statusColumn: find(const {
          'status',
          'situacao',
          'ativo',
          'situacao do funcionario',
        }),
      );
    }
    return null;
  }

  static String _cell(List<String> row, int? column) {
    if (column == null || column < 0 || column >= row.length) return '';
    return row[column];
  }

  static String _digits(String value) =>
      value.replaceAll(RegExp(r'[^0-9]'), '');

  static bool _parseActive(String value) {
    final clean = _normalize(value);
    if (clean.isEmpty) return true;
    return !{
      'inativo',
      'desligado',
      'demitido',
      'nao',
      '0',
    }.contains(clean);
  }

  static DateTime? _parseDate(String value) {
    final clean = value.trim();
    if (clean.isEmpty) return null;
    final direct = DateTime.tryParse(clean);
    if (direct != null) return direct;
    final parts = clean.split(RegExp(r'[/.-]'));
    if (parts.length == 3) {
      final first = int.tryParse(parts[0]);
      final month = int.tryParse(parts[1]);
      final last = int.tryParse(parts[2]);
      if (first != null && month != null && last != null) {
        final year = parts[0].length == 4 ? first : last;
        final day = parts[0].length == 4 ? last : first;
        if (year >= 1900 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
          return DateTime(year, month, day);
        }
      }
    }
    final serial = num.tryParse(clean.replaceAll(',', '.'));
    if (serial != null && serial >= 20000 && serial <= 80000) {
      return DateTime(1899, 12, 30).add(Duration(days: serial.floor()));
    }
    return null;
  }

  static String _normalize(String value) {
    var clean = value.trim().toLowerCase();
    const accents = {
      'á': 'a', 'à': 'a', 'â': 'a', 'ã': 'a', 'ä': 'a',
      'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
      'í': 'i', 'ì': 'i', 'î': 'i', 'ï': 'i',
      'ó': 'o', 'ò': 'o', 'ô': 'o', 'õ': 'o', 'ö': 'o',
      'ú': 'u', 'ù': 'u', 'û': 'u', 'ü': 'u',
      'ç': 'c',
    };
    accents.forEach((from, to) => clean = clean.replaceAll(from, to));
    return clean
        .replaceAll(RegExp(r'[^a-z0-9/]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }
}

class _HeaderMap {
  final int rowIndex;
  final int nameColumn;
  final int roleColumn;
  final int? cpfColumn;
  final int? sectorColumn;
  final int? admissionColumn;
  final int? statusColumn;

  const _HeaderMap({
    required this.rowIndex,
    required this.nameColumn,
    required this.roleColumn,
    this.cpfColumn,
    this.sectorColumn,
    this.admissionColumn,
    this.statusColumn,
  });
}
