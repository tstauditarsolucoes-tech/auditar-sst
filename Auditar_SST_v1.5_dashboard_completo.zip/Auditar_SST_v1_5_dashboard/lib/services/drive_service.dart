import 'dart:io';

import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:uuid/uuid.dart';

import '../database.dart';
import 'report_file_service.dart';

class DriveConnectResult {
  final String email;
  final String rootFolderId;

  const DriveConnectResult({
    required this.email,
    required this.rootFolderId,
  });
}

class DriveUploadResult {
  final bool uploaded;
  final bool queued;
  final String message;

  const DriveUploadResult({
    required this.uploaded,
    required this.queued,
    required this.message,
  });
}

class DriveService {
  static const List<String> scopes = <String>[
    drive.DriveApi.driveFileScope,
  ];

  static Future<void>? _initialization;

  static Future<void> _initialize() {
    return _initialization ??= GoogleSignIn.instance.initialize();
  }

  static String _escapeQuery(String value) {
    return value.replaceAll("'", "\\'");
  }

  static Future<GoogleSignInAccount> _authenticate() async {
    await _initialize();

    if (!GoogleSignIn.instance.supportsAuthenticate()) {
      throw Exception(
        'Este aparelho não oferece o fluxo de autenticação Google esperado.',
      );
    }

    return GoogleSignIn.instance.authenticate();
  }

  static Future<GoogleSignInAccount?> _lightweightAccount() async {
    await _initialize();

    final attempt = GoogleSignIn.instance.attemptLightweightAuthentication();
    if (attempt == null) return null;

    try {
      return await attempt;
    } catch (_) {
      return null;
    }
  }

  static Future<GoogleSignInClientAuthorization> _authorization(
    GoogleSignInAccount account, {
    required bool interactive,
  }) async {
    var authorization =
        await account.authorizationClient.authorizationForScopes(scopes);

    if (authorization != null) return authorization;

    if (!interactive) {
      throw Exception(
        'A autorização do Google Drive precisa ser renovada pelo usuário.',
      );
    }

    authorization =
        await account.authorizationClient.authorizeScopes(scopes);

    return authorization;
  }

  static Future<String> _findOrCreateFolder({
    required drive.DriveApi api,
    required String name,
    String? parentId,
  }) async {
    final escaped = _escapeQuery(name);

    final parentQuery =
        parentId == null ? '' : " and '$parentId' in parents";

    final list = await api.files.list(
      q: "name = '$escaped' "
          "and mimeType = 'application/vnd.google-apps.folder' "
          "and trashed = false"
          "$parentQuery",
      spaces: 'drive',
      $fields: 'files(id,name)',
      pageSize: 10,
    );

    final files = list.files ?? const <drive.File>[];

    if (files.isNotEmpty && files.first.id != null) {
      return files.first.id!;
    }

    final metadata = drive.File()
      ..name = name
      ..mimeType = 'application/vnd.google-apps.folder';

    if (parentId != null) {
      metadata.parents = [parentId];
    }

    final created = await api.files.create(
      metadata,
      $fields: 'id,name',
    );

    if (created.id == null) {
      throw Exception('Não foi possível criar a pasta no Google Drive.');
    }

    return created.id!;
  }

  static Future<DriveConnectResult> connect() async {
    final account = await _authenticate();
    final authorization = await _authorization(account, interactive: true);
    final client = authorization.authClient(scopes: scopes);

    try {
      final api = drive.DriveApi(client);

      final rootFolderId = await _findOrCreateFolder(
        api: api,
        name: 'Auditar SST',
      );

      final db = AppDatabase.instance;
      await db.setSetting('drive_enabled', 'true');
      await db.setSetting('drive_account_email', account.email);
      await db.setSetting('drive_root_folder_id', rootFolderId);
      await db.setSetting('drive_auto_upload', 'true');

      return DriveConnectResult(
        email: account.email,
        rootFolderId: rootFolderId,
      );
    } finally {
      client.close();
    }
  }

  static Future<void> disconnect() async {
    await _initialize();

    try {
      await GoogleSignIn.instance.disconnect();
    } catch (_) {}

    final db = AppDatabase.instance;
    await db.setSetting('drive_enabled', 'false');
    await db.setSetting('drive_account_email', '');
    await db.setSetting('drive_root_folder_id', '');
  }

  static Future<String> _uploadLocalPdf({
    required String localPath,
    required String fileName,
    required String companyName,
    required bool interactive,
  }) async {
    final account = interactive
        ? await _authenticate()
        : await _lightweightAccount();

    if (account == null) {
      throw Exception(
        'Conta Google indisponível para sincronização automática.',
      );
    }

    final authorization = await _authorization(
      account,
      interactive: interactive,
    );
    final client = authorization.authClient(scopes: scopes);

    try {
      final api = drive.DriveApi(client);
      final db = AppDatabase.instance;

      var rootFolderId = await db.getSetting(
        'drive_root_folder_id',
        fallback: '',
      );

      if (rootFolderId.isEmpty) {
        rootFolderId = await _findOrCreateFolder(
          api: api,
          name: 'Auditar SST',
        );
        await db.setSetting(
          'drive_root_folder_id',
          rootFolderId,
        );
      }

      final companyFolderId = await _findOrCreateFolder(
        api: api,
        name: companyName.trim().isEmpty
            ? 'Sem empresa'
            : companyName.trim(),
        parentId: rootFolderId,
      );

      final file = File(localPath);

      if (!await file.exists()) {
        throw Exception('Arquivo local do relatório não encontrado.');
      }

      final media = drive.Media(
        file.openRead(),
        await file.length(),
      );

      final metadata = drive.File()
        ..name = fileName
        ..mimeType = 'application/pdf'
        ..parents = [companyFolderId];

      final uploaded = await api.files.create(
        metadata,
        uploadMedia: media,
        $fields: 'id,name,webViewLink',
      );

      if (uploaded.id == null) {
        throw Exception('O Drive não confirmou o envio do relatório.');
      }

      return uploaded.id!;
    } finally {
      client.close();
    }
  }

  static Future<DriveUploadResult> saveReportToDrive(
    String inspectionId, {
    bool interactive = true,
  }) async {
    final db = AppDatabase.instance;

    final enabled = await db.getSetting(
      'drive_enabled',
      fallback: 'false',
    );

    if (enabled != 'true') {
      return const DriveUploadResult(
        uploaded: false,
        queued: false,
        message: 'Google Drive não está vinculado.',
      );
    }

    final previous = await db.getDriveUploadForInspection(
      inspectionId,
    );

    if (previous != null &&
        previous['status'] == 'Enviado') {
      return const DriveUploadResult(
        uploaded: true,
        queued: false,
        message: 'Este relatório já foi salvo no Google Drive.',
      );
    }

    final header = await db.getInspectionHeader(inspectionId);

    if (header == null) {
      throw Exception('Vistoria não encontrada.');
    }

    final localPath =
        await ReportFileService.savePdfLocally(inspectionId);

    final fileName = File(localPath).uri.pathSegments.last;
    final companyName =
        '${header['company_name'] ?? 'Sem empresa'}';

    final queueId = previous == null
        ? const Uuid().v4()
        : '${previous['id']}';

    try {
      await _uploadLocalPdf(
        localPath: localPath,
        fileName: fileName,
        companyName: companyName,
        interactive: interactive,
      );

      if (previous == null) {
        await db.enqueueDriveUpload(
          id: queueId,
          inspectionId: inspectionId,
          localPath: localPath,
          fileName: fileName,
          companyName: companyName,
          status: 'Enviado',
        );
      } else {
        await db.markDriveUploadSent(queueId);
      }

      return const DriveUploadResult(
        uploaded: true,
        queued: false,
        message: 'Relatório salvo no Google Drive.',
      );
    } catch (e) {
      await db.enqueueDriveUpload(
        id: queueId,
        inspectionId: inspectionId,
        localPath: localPath,
        fileName: fileName,
        companyName: companyName,
        status: 'Pendente',
        lastError: e.toString(),
      );

      return const DriveUploadResult(
        uploaded: false,
        queued: true,
        message:
            'Sem conexão ou autorização no momento. O relatório ficou salvo no celular e aguardará sincronização.',
      );
    }
  }

  static Future<int> syncPending({bool interactive = false}) async {
    final db = AppDatabase.instance;
    final rows = await db.getPendingDriveUploads();
    var sent = 0;

    for (final row in rows) {
      final id = '${row['id']}';

      try {
        await _uploadLocalPdf(
          localPath: '${row['local_path']}',
          fileName: '${row['file_name']}',
          companyName: '${row['company_name'] ?? 'Sem empresa'}',
          interactive: interactive,
        );

        await db.markDriveUploadSent(id);
        sent++;
      } catch (e) {
        await db.markDriveUploadFailed(
          id,
          e.toString(),
        );
      }
    }

    return sent;
  }
}
