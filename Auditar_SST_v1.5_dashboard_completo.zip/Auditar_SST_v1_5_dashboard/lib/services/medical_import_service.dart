import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

import '../database.dart';
import '../models.dart';
import 'apps_script_http.dart';

class MedicalImportCandidate {
  final Worker worker;
  final DateTime? importedLastExam;
  final DateTime? importedNextExam;

  const MedicalImportCandidate({
    required this.worker,
    required this.importedLastExam,
    required this.importedNextExam,
  });
}

class MedicalImportPreview {
  final String fileName;
  final List<MedicalImportCandidate> candidates;
  final List<String> unmatchedNames;
  final int ambiguousRows;
  final int invalidRows;

  const MedicalImportPreview({
    required this.fileName,
    required this.candidates,
    required this.unmatchedNames,
    required this.ambiguousRows,
    required this.invalidRows,
  });
}

class MedicalImportException implements Exception {
  final String message;

  const MedicalImportException(this.message);

  @override
  String toString() => message;
}

class MedicalImportService {
  static Future<MedicalImportPreview?> pickAndPrepare({
    required String companyId,
  }) async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
      withData: true,
    );
    if (picked == null || picked.files.isEmpty) return null;
    final selected = picked.files.single;
    Uint8List? bytes = selected.bytes;
    if (bytes == null && selected.path != null) {
      bytes = await File(selected.path!).readAsBytes();
    }
    if (bytes == null || bytes.isEmpty) {
      throw const MedicalImportException('Não foi possível abrir o PDF.');
    }
    if (bytes.length > 12000000) {
      throw const MedicalImportException('O PDF ultrapassa o limite de 12 MB.');
    }

    final extracted = await _extractPdf(bytes);
    final workers = await AppDatabase.instance.getWorkers(
      companyId: companyId,
      onlyActive: true,
    );
    final byName = <String, List<Worker>>{};
    for (final worker in workers) {
      byName.putIfAbsent(_normalize(worker.name), () => []).add(worker);
    }

    final candidates = <MedicalImportCandidate>[];
    final unmatched = <String>{};
    final usedWorkers = <String>{};
    var ambiguous = 0;
    var invalid = 0;
    for (final record in extracted) {
      final name = '${record['name'] ?? ''}'.trim();
      final role = '${record['role'] ?? ''}'.trim();
      final lastExam = _parseDate('${record['lastExamDate'] ?? ''}');
      final nextExam = _parseDate('${record['nextExamDate'] ?? ''}');
      if (name.isEmpty || (lastExam == null && nextExam == null)) {
        invalid++;
        continue;
      }
      final sameName = byName[_normalize(name)] ?? const <Worker>[];
      Worker? matched;
      if (sameName.length == 1) {
        matched = sameName.first;
      } else if (sameName.length > 1 && role.isNotEmpty) {
        final sameRole = sameName.where(
          (worker) => AppDatabase.normalizeRoleKey(worker.role) ==
              AppDatabase.normalizeRoleKey(role),
        ).toList();
        if (sameRole.length == 1) matched = sameRole.first;
      }
      if (matched == null) {
        if (sameName.length > 1) {
          ambiguous++;
        } else {
          unmatched.add(name);
        }
        continue;
      }
      if (!usedWorkers.add(matched.id)) continue;
      candidates.add(
        MedicalImportCandidate(
          worker: Worker(
            id: matched.id,
            companyId: matched.companyId,
            sectorId: matched.sectorId,
            name: matched.name,
            cpf: matched.cpf,
            role: matched.role,
            admissionDate: matched.admissionDate,
            lastMedicalExamDate: lastExam ?? matched.lastMedicalExamDate,
            nextMedicalExamDate: nextExam ?? matched.nextMedicalExamDate,
            asoPath: matched.asoPath,
            active: matched.active,
          ),
          importedLastExam: lastExam,
          importedNextExam: nextExam,
        ),
      );
    }
    if (candidates.isEmpty) {
      throw const MedicalImportException(
        'Nenhum periódico pôde ser associado aos trabalhadores cadastrados.',
      );
    }
    return MedicalImportPreview(
      fileName: selected.name,
      candidates: candidates,
      unmatchedNames: unmatched.toList()..sort(),
      ambiguousRows: ambiguous,
      invalidRows: invalid,
    );
  }

  static Future<List<Map<String, dynamic>>> _extractPdf(
    Uint8List bytes,
  ) async {
    final endpoint = (await AppDatabase.instance.getSetting(
      'management_panel_endpoint',
      fallback: '',
    )).trim();
    final syncKey = (await AppDatabase.instance.getSetting(
      'management_panel_sync_key',
      fallback: '',
    )).trim();
    if (endpoint.isEmpty || syncKey.isEmpty) {
      throw const MedicalImportException(
        'Configure primeiro a publicação web e o Assistente IA.',
      );
    }
    try {
      final response = await AppsScriptHttp.postJson(
        Uri.parse(endpoint),
        {
          'action': 'ai_assistant',
          'syncKey': syncKey,
          'payload': {
            'mode': 'medical_pdf_import',
            'document': 'data:application/pdf;base64,${base64Encode(bytes)}',
          },
        },
        timeout: const Duration(seconds: 180),
      );
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (response.statusCode < 200 || response.statusCode >= 300 ||
          decoded is! Map || decoded['ok'] != true) {
        throw MedicalImportException(
          decoded is Map
              ? '${decoded['message'] ?? 'A leitura do PDF não foi concluída.'}'
              : 'A leitura do PDF retornou uma resposta inválida.',
        );
      }
      final result = decoded['result'];
      final records = result is Map ? result['records'] : null;
      if (records is! List || records.isEmpty) {
        throw const MedicalImportException(
          'Não encontrei nomes e datas de periódicos no PDF.',
        );
      }
      return records
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
    } on SocketException {
      throw const MedicalImportException('A importação do PDF precisa de internet.');
    } on MedicalImportException {
      rethrow;
    } catch (error) {
      throw MedicalImportException('Não foi possível ler o PDF: $error');
    }
  }

  static DateTime? _parseDate(String value) {
    final match = RegExp(r'^(\d{4})-(\d{2})-(\d{2})')
        .firstMatch(value.trim());
    if (match == null) return null;
    final year = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final day = int.parse(match.group(3)!);
    if (month < 1 || month > 12 || day < 1 || day > 31) return null;
    final parsed = DateTime(year, month, day);
    if (parsed.year != year || parsed.month != month || parsed.day != day) {
      return null;
    }
    return parsed;
  }

  static String _normalize(String value) {
    var normalized = value.trim().toUpperCase();
    const replacements = {
      'Á': 'A', 'À': 'A', 'Â': 'A', 'Ã': 'A', 'Ä': 'A',
      'É': 'E', 'È': 'E', 'Ê': 'E', 'Ë': 'E',
      'Í': 'I', 'Ì': 'I', 'Î': 'I', 'Ï': 'I',
      'Ó': 'O', 'Ò': 'O', 'Ô': 'O', 'Õ': 'O', 'Ö': 'O',
      'Ú': 'U', 'Ù': 'U', 'Û': 'U', 'Ü': 'U',
      'Ç': 'C',
    };
    replacements.forEach(
      (source, target) => normalized = normalized.replaceAll(source, target),
    );
    return normalized.replaceAll(RegExp(r'[^A-Z0-9]'), '');
  }
}
