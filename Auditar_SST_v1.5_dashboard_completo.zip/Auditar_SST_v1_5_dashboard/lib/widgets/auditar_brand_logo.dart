import 'package:flutter/material.dart';

import '../brand.dart';

class AuditarBrandLogo extends StatelessWidget {
  const AuditarBrandLogo({
    super.key,
    this.compact = false,
    this.onDark = false,
    this.iconSize = 38,
  });

  final bool compact;
  final bool onDark;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final primaryText = onDark ? Colors.white : AuditarBrand.navy;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (iconSize > 0) ...[
          ClipOval(
            child: Image.asset(
              AuditarBrand.iconAsset,
              width: iconSize,
              height: iconSize,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 9),
        ],
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                style: TextStyle(
                  color: primaryText,
                  fontWeight: FontWeight.w900,
                  fontSize: compact ? 17 : 20,
                  height: 1,
                ),
                children: const [
                  TextSpan(text: 'Auditar '),
                  TextSpan(
                    text: 'SST',
                    style: TextStyle(color: AuditarBrand.green),
                  ),
                ],
              ),
            ),
            if (!compact) ...[
              const SizedBox(height: 4),
              Text(
                'SEGURANÇA DO TRABALHO',
                style: TextStyle(
                  color: onDark ? Colors.white70 : AuditarBrand.greenDark,
                  fontSize: 8.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .7,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}
