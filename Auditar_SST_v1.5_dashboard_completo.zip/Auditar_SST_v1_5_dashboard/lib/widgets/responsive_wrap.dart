import 'package:flutter/material.dart';

/// Lays out card-like children in as many columns as safely fit and
/// automatically drops to fewer columns on narrow screens.
///
/// Unlike a fixed GridView, the children keep their natural height, which
/// avoids bottom overflows when labels wrap or the system font is larger.
class ResponsiveWrap extends StatelessWidget {
  final List<Widget> children;
  final double minItemWidth;
  final double spacing;
  final double runSpacing;
  final int maxColumns;

  const ResponsiveWrap({
    super.key,
    required this.children,
    this.minItemWidth = 150,
    this.spacing = 8,
    this.runSpacing = 8,
    this.maxColumns = 4,
  });

  @override
  Widget build(BuildContext context) {
    if (children.isEmpty) return const SizedBox.shrink();

    return LayoutBuilder(
      builder: (context, constraints) {
        final available = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : minItemWidth;
        var columns = ((available + spacing) / (minItemWidth + spacing)).floor();
        if (columns < 1) columns = 1;
        if (columns > maxColumns) columns = maxColumns;
        if (columns > children.length) columns = children.length;

        final width = columns <= 1
            ? available
            : (available - spacing * (columns - 1)) / columns;

        return Wrap(
          spacing: spacing,
          runSpacing: runSpacing,
          children: children
              .map((child) => SizedBox(width: width, child: child))
              .toList(growable: false),
        );
      },
    );
  }
}
