class ChecklistQuestion {
  final String id;
  final String category;
  final String text;
  final String reference;
  final String priority;

  const ChecklistQuestion({
    required this.id,
    required this.category,
    required this.text,
    required this.reference,
    required this.priority,
  });
}

const generalChecklist = <ChecklistQuestion>[
  ChecklistQuestion(id: 'q01', category: 'Organização e limpeza', text: 'A área está limpa, organizada e com circulação desobstruída?', reference: 'NR-01', priority: 'Média'),
  ChecklistQuestion(id: 'q02', category: 'EPI', text: 'Os trabalhadores utilizam os EPIs necessários para a atividade?', reference: 'NR-06', priority: 'Alta'),
  ChecklistQuestion(id: 'q03', category: 'Máquinas', text: 'As máquinas possuem proteções e dispositivos de segurança adequados?', reference: 'NR-12', priority: 'Crítica'),
  ChecklistQuestion(id: 'q04', category: 'Elétrica', text: 'As instalações elétricas estão protegidas e sem improvisações aparentes?', reference: 'NR-10', priority: 'Alta'),
  ChecklistQuestion(id: 'q05', category: 'Prevenção contra incêndio', text: 'Extintores, acessos e rotas de saída estão livres e sinalizados?', reference: 'NR-23', priority: 'Alta'),
  ChecklistQuestion(id: 'q06', category: 'Ergonomia', text: 'As condições de trabalho evitam postura inadequada e esforço excessivo?', reference: 'NR-17', priority: 'Média'),
  ChecklistQuestion(id: 'q07', category: 'Sinalização', text: 'Os riscos e áreas restritas estão devidamente sinalizados?', reference: 'NR-26', priority: 'Média'),
  ChecklistQuestion(id: 'q08', category: 'Trabalho em altura', text: 'Quando aplicável, existem medidas de prevenção e proteção contra quedas?', reference: 'NR-35', priority: 'Crítica'),
];

ChecklistQuestion? questionById(String id) {
  for (final q in generalChecklist) {
    if (q.id == id) return q;
  }
  return null;
}
