import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'services/sync_coordinator.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AuditarSstApp());
}

class AuditarSstApp extends StatelessWidget {
  const AuditarSstApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF668A12);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Auditar SST',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF6F7F3),
        appBarTheme: const AppBarTheme(
          backgroundColor: green,
          foregroundColor: Colors.white,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
      home: const SyncCoordinator(child: SplashScreen()),
    );
  }
}
