import 'package:flutter/material.dart';

import '../brand.dart';
import '../database.dart';
import '../widgets/auditar_brand_logo.dart';
import 'action_plan_screen.dart';
import 'checklist_templates_screen.dart';
import 'cipa_screen.dart';
import 'companies_screen.dart';
import 'dashboard_screen.dart';
import 'history_screen.dart';
import 'new_inspection_screen.dart';
import 'non_conformities_screen.dart';
import 'routine_hub_screen.dart';
import 'settings_screen.dart';
import 'trainings_screen.dart';
import 'workers_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, int> summary = {};
  Map<String, int> routineSummary = {};
  int openNcs = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final result = await AppDatabase.instance.getDashboardSummary();
    final ncRows = await AppDatabase.instance.getNonConformityRows(
      includeClosed: false,
    );
    final routine = await AppDatabase.instance.getRoutineTodaySummary();

    if (!mounted) return;
    setState(() {
      summary = result;
      routineSummary = routine;
      openNcs = ncRows.length;
      loading = false;
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _refresh();
  }

  void _bottomNav(int index) {
    if (index == 0) return;
    if (index == 1) {
      _open(const CompaniesScreen());
    } else if (index == 2) {
      _open(const HistoryScreen());
    } else {
      _showMore();
    }
  }

  void _showMore() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) => FractionallySizedBox(
        heightFactor: .82,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
          children: [
              ListTile(
                leading: const Icon(Icons.bar_chart_rounded),
                title: const Text('Indicadores'),
                subtitle: const Text('Acompanhar desempenho e evolução'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(const DashboardScreen());
                },
              ),
              ListTile(
                leading: const Icon(Icons.fact_check_outlined),
                title: const Text('Biblioteca de checklists'),
                subtitle: const Text('Checklists prontos e editáveis'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(const ChecklistTemplatesScreen());
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu_book_outlined),
                title: const Text('Checklists das NRs'),
                subtitle: const Text('NR-01, NR-06, NR-07, NR-10 e outras'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(
                    const ChecklistTemplatesScreen(
                      initialCategory: 'Normas Regulamentadoras',
                      title: 'Checklists das NRs',
                    ),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.how_to_vote_outlined),
                title: const Text('CIPA'),
                subtitle: const Text('Eleições e votação por QR Code'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(const CipaScreen());
                },
              ),
              ListTile(
                leading: const Icon(Icons.dashboard_customize_outlined),
                title: const Text('Rotina SST'),
                subtitle: const Text('Agenda, DDS, APR/PT, incidentes e equipamentos'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(const RoutineHubScreen());
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings_outlined),
                title: const Text('Configurações'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _open(const SettingsScreen());
                },
              ),
            ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inspections = summary['inspections'] ?? 0;
    final conformity = summary['conformity'] ?? 0;
    final pending = summary['pending'] ?? 0;
    final overdue = summary['ncOverdue'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: const AuditarBrandLogo(
          compact: true,
          onDark: true,
          iconSize: 34,
        ),
        actions: [
          IconButton(
            tooltip: 'Configurações',
            onPressed: () => _open(const SettingsScreen()),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 26),
                children: [
                  _heroCard(
                    inspections: inspections,
                    conformity: conformity,
                    openNcs: openNcs,
                    overdue: overdue,
                    pending: pending,
                  ),
                  const SizedBox(height: 12),
                  _newInspectionCard(),
                  const SizedBox(height: 12),
                  _routineTodayCard(),
                  const SizedBox(height: 20),
                  _sectionHeader('Acesso rápido', 'Rotina de vistoria'),
                  const SizedBox(height: 10),
                  _quickGrid([
                    _QuickData(
                      'Empresas',
                      Icons.business_outlined,
                      AuditarBrand.navy,
                      () => _open(const CompaniesScreen()),
                    ),
                    _QuickData(
                      'Não conformidades',
                      Icons.warning_amber_rounded,
                      const Color(0xFFD93025),
                      () => _open(const NonConformitiesScreen()),
                    ),
                    _QuickData(
                      'Plano de ação',
                      Icons.assignment_turned_in_outlined,
                      const Color(0xFFF29D18),
                      () => _open(const ActionPlanScreen()),
                    ),
                    _QuickData(
                      'Indicadores',
                      Icons.bar_chart_rounded,
                      AuditarBrand.greenDark,
                      () => _open(const DashboardScreen()),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  _sectionHeader('Gestão SST', 'Ferramentas do sistema'),
                  const SizedBox(height: 10),
                  _managementTile(
                    icon: Icons.dashboard_customize_outlined,
                    title: 'Rotina SST',
                    subtitle: 'Agenda, DDS, APR/PT, incidentes e equipamentos',
                    onTap: () => _open(const RoutineHubScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.groups_rounded,
                    title: 'Trabalhadores',
                    subtitle: 'Cadastro por empresa, setor e função',
                    onTap: () => _open(const WorkersScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.school_outlined,
                    title: 'Treinamentos',
                    subtitle: 'NRs em dia, pendentes e vencidas',
                    onTap: () => _open(const TrainingsScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.how_to_vote_outlined,
                    title: 'CIPA',
                    subtitle: 'Eleições, QR Code e acompanhamento de votos',
                    onTap: () => _open(const CipaScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.history_rounded,
                    title: 'Vistorias e relatórios',
                    subtitle: 'Histórico, reabertura e PDFs',
                    onTap: () => _open(const HistoryScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.fact_check_outlined,
                    title: 'Biblioteca de checklists',
                    subtitle: 'Checklists prontos organizados por tipo',
                    onTap: () => _open(const ChecklistTemplatesScreen()),
                  ),
                  const SizedBox(height: 8),
                  _managementTile(
                    icon: Icons.menu_book_outlined,
                    title: 'Checklists das NRs',
                    subtitle: 'Auditoria rápida por Norma Regulamentadora',
                    onTap: () => _open(
                      const ChecklistTemplatesScreen(
                        initialCategory: 'Normas Regulamentadoras',
                        title: 'Checklists das NRs',
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Center(
                    child: Text(
                      'Auditar SST • versão 3.2.2',
                      style: TextStyle(fontSize: 10.5, color: Colors.black45),
                    ),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: _bottomNav,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Início',
          ),
          NavigationDestination(
            icon: Icon(Icons.business_outlined),
            selectedIcon: Icon(Icons.business),
            label: 'Empresas',
          ),
          NavigationDestination(
            icon: Icon(Icons.fact_check_outlined),
            selectedIcon: Icon(Icons.fact_check),
            label: 'Inspeções',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_rounded),
            label: 'Mais',
          ),
        ],
      ),
    );
  }

  Widget _heroCard({
    required int inspections,
    required int conformity,
    required int openNcs,
    required int overdue,
    required int pending,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AuditarBrand.navy, AuditarBrand.navyDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220C1B43),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Visão geral',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Segurança em números',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _heroMetric('$inspections', 'Vistorias'),
                          const SizedBox(width: 20),
                          _heroMetric('$openNcs', 'NC abertas'),
                          const SizedBox(width: 20),
                          _heroMetric('$overdue', 'Vencidas'),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 88,
                  height: 88,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 82,
                        height: 82,
                        child: CircularProgressIndicator(
                          value: conformity / 100,
                          strokeWidth: 8,
                          color: AuditarBrand.green,
                          backgroundColor: Colors.white24,
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '$conformity%',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Text(
                            'Conforme',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 9.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              height: 1,
              color: Colors.white12,
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.assignment_late_outlined,
                    size: 18, color: Colors.white70),
                const SizedBox(width: 7),
                Text(
                  '$pending ações pendentes',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _heroMetric(String value, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white60,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _newInspectionCard() {
    return Material(
      color: AuditarBrand.greenDark,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _open(const NewInspectionScreen()),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          child: Row(
            children: [
              CircleAvatar(
                radius: 23,
                backgroundColor: Colors.white24,
                child: Icon(
                  Icons.add_task_rounded,
                  color: Colors.white,
                  size: 27,
                ),
              ),
              SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Nova vistoria',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Iniciar uma inspeção de segurança',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  size: 18, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }

  Widget _routineTodayCard() {
    final agenda = routineSummary['agendaToday'] ?? 0;
    final actions = routineSummary['actionsOverdue'] ?? 0;
    final trainings = routineSummary['trainingsDue'] ?? 0;
    final equipment = routineSummary['equipmentDue'] ?? 0;
    final verify = routineSummary['ncVerification'] ?? 0;
    final attention = actions + trainings + equipment + verify;

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _open(const RoutineHubScreen()),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF3FA),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.today_outlined, color: AuditarBrand.navy),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Resumo do dia', style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                      '$agenda na agenda • $attention itens pedindo atenção',
                      style: const TextStyle(fontSize: 11.5, color: Colors.black54),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, String subtitle) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: AuditarBrand.navy,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Text(
          subtitle,
          style: const TextStyle(
            color: Colors.black45,
            fontSize: 10.5,
          ),
        ),
      ],
    );
  }

  Widget _quickGrid(List<_QuickData> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = 9.0;
        final width = (constraints.maxWidth - gap) / 2;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: items
              .map(
                (item) => SizedBox(
                  width: width,
                  child: Card(
                    margin: EdgeInsets.zero,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: item.onTap,
                      child: Padding(
                        padding: const EdgeInsets.all(13),
                        child: Row(
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: item.color.withOpacity(.10),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: Icon(
                                item.icon,
                                color: item.color,
                                size: 21,
                              ),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  item.title,
                                  maxLines: 1,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }

  Widget _managementTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: const Color(0xFFEFF3FA),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: AuditarBrand.navy),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class _QuickData {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _QuickData(this.title, this.icon, this.color, this.onTap);
}
