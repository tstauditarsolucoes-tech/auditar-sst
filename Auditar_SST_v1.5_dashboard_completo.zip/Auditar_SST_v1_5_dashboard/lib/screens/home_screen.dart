import 'package:flutter/material.dart';

import '../brand.dart';
import '../database.dart';
import '../widgets/auditar_brand_logo.dart';
import 'action_plan_screen.dart';
import 'checklist_templates_screen.dart';
import 'cipa_screen.dart';
import 'companies_screen.dart';
import 'dashboard_screen.dart';
import 'history_screen.dart';
import 'improvements_screen.dart';
import 'new_inspection_screen.dart';
import 'non_conformities_screen.dart';
import 'routine_hub_screen.dart';
import 'settings_screen.dart';
import 'trainings_screen.dart';
import 'workers_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, int> summary = {};
  Map<String, int> routineSummary = {};
  int openNcs = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final result = await AppDatabase.instance.getDashboardSummary();
    final ncRows = await AppDatabase.instance.getNonConformityRows(
      includeClosed: false,
    );
    final routine = await AppDatabase.instance.getRoutineTodaySummary();

    if (!mounted) return;
    setState(() {
      summary = result;
      routineSummary = routine;
      openNcs = ncRows.length;
      loading = false;
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _refresh();
  }

  void _bottomNav(int index) {
    if (index == 0) return;
    if (index == 1) {
      _open(const CompaniesScreen());
    } else if (index == 2) {
      _open(const HistoryScreen());
    } else {
      _showMore();
    }
  }


  void _showManagement() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) => FractionallySizedBox(
        heightFactor: .78,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(8, 4, 8, 10),
              child: Text(
                'Gestão SST',
                style: TextStyle(
                  color: AuditarBrand.navy,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_customize_outlined),
              title: const Text('Rotina SST'),
              subtitle: const Text('Agenda, DDS, APR/PT, incidentes e equipamentos'),
              onTap: () { Navigator.pop(sheetContext); _open(const RoutineHubScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.auto_awesome_outlined),
              title: const Text('Melhorias'),
              subtitle: const Text('Sugestões e melhorias realizadas por empresa e setor'),
              onTap: () { Navigator.pop(sheetContext); _open(const ImprovementsScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.groups_rounded),
              title: const Text('Trabalhadores'),
              subtitle: const Text('Cadastro por empresa, setor e função'),
              onTap: () { Navigator.pop(sheetContext); _open(const WorkersScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.school_outlined),
              title: const Text('Treinamentos'),
              subtitle: const Text('NRs em dia, pendentes e vencidas'),
              onTap: () { Navigator.pop(sheetContext); _open(const TrainingsScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.how_to_vote_outlined),
              title: const Text('CIPA'),
              subtitle: const Text('Eleições, QR Code e acompanhamento de votos'),
              onTap: () { Navigator.pop(sheetContext); _open(const CipaScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.fact_check_outlined),
              title: const Text('Biblioteca de checklists'),
              subtitle: const Text('Modelos prontos e checklists das NRs'),
              onTap: () { Navigator.pop(sheetContext); _open(const ChecklistTemplatesScreen()); },
            ),
            ListTile(
              leading: const Icon(Icons.bar_chart_rounded),
              title: const Text('Indicadores'),
              subtitle: const Text('Desempenho, evolução e filtros'),
              onTap: () { Navigator.pop(sheetContext); _open(const DashboardScreen()); },
            ),
          ],
        ),
      ),
    );
  }

  void _showMore() {
    showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.dashboard_customize_outlined),
              title: const Text('Gestão SST'),
              subtitle: const Text('Cadastros, controles, CIPA, checklists e rotina'),
              onTap: () {
                Navigator.pop(sheetContext);
                _showManagement();
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('Configurações'),
              onTap: () {
                Navigator.pop(sheetContext);
                _open(const SettingsScreen());
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inspections = summary['inspections'] ?? 0;
    final conformity = summary['conformity'] ?? 0;
    final pending = summary['pending'] ?? 0;
    final overdue = summary['ncOverdue'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: const AuditarBrandLogo(
          compact: true,
          onDark: true,
          iconSize: 34,
        ),
        actions: [
          IconButton(
            tooltip: 'Configurações',
            onPressed: () => _open(const SettingsScreen()),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 26),
                children: [
                  _overviewCard(
                    inspections: inspections,
                    conformity: conformity,
                    openNcs: openNcs,
                    overdue: overdue,
                    pending: pending,
                  ),
                  const SizedBox(height: 12),
                  _newInspectionCard(),
                  const SizedBox(height: 12),
                  _routineTodayCard(),
                  const SizedBox(height: 22),
                  _sectionHeader(
                    'Acesso rápido',
                    'Principais ferramentas da rotina de vistoria',
                  ),
                  const SizedBox(height: 10),
                  _quickGrid([
                    _QuickData(
                      'Empresas',
                      Icons.business_outlined,
                      AuditarBrand.navy,
                      () => _open(const CompaniesScreen()),
                    ),
                    _QuickData(
                      'Vistorias',
                      Icons.fact_check_outlined,
                      AuditarBrand.info,
                      () => _open(const HistoryScreen()),
                    ),
                    _QuickData(
                      'Não conformidades',
                      Icons.warning_amber_rounded,
                      AuditarBrand.danger,
                      () => _open(const NonConformitiesScreen()),
                    ),
                    _QuickData(
                      'Plano de ação',
                      Icons.assignment_turned_in_outlined,
                      AuditarBrand.warning,
                      () => _open(const ActionPlanScreen()),
                    ),
                  ]),
                  const SizedBox(height: 18),
                  _managementTile(
                    icon: Icons.dashboard_customize_outlined,
                    title: 'Gestão SST',
                    subtitle: 'Melhorias, trabalhadores, treinamentos, CIPA, checklists, rotina e indicadores',
                    onTap: _showManagement,
                  ),
                  const SizedBox(height: 16),
                  const Center(
                    child: Text(
                      'Auditar SST • versão 3.20.1',
                      style: TextStyle(fontSize: 10.5, color: Colors.black45),
                    ),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: _bottomNav,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Início',
          ),
          NavigationDestination(
            icon: Icon(Icons.business_outlined),
            selectedIcon: Icon(Icons.business),
            label: 'Empresas',
          ),
          NavigationDestination(
            icon: Icon(Icons.fact_check_outlined),
            selectedIcon: Icon(Icons.fact_check),
            label: 'Vistorias',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_rounded),
            label: 'Mais',
          ),
        ],
      ),
    );
  }

  Widget _overviewCard({
    required int inspections,
    required int conformity,
    required int openNcs,
    required int overdue,
    required int pending,
  }) {
    final progressColor = conformity >= 80
        ? AuditarBrand.greenDark
        : conformity >= 60
            ? AuditarBrand.warning
            : AuditarBrand.danger;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15, 15, 15, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Visão geral',
                        style: TextStyle(
                          color: AuditarBrand.neutral,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 3),
                      const Text(
                        'Segurança em números',
                        style: TextStyle(
                          color: AuditarBrand.navyDark,
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        inspections == 0
                            ? 'Faça a primeira vistoria para gerar indicadores.'
                            : 'Acompanhe rapidamente a situação das vistorias.',
                        style: const TextStyle(
                          color: AuditarBrand.neutral,
                          fontSize: 10.5,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 68,
                  height: 68,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 62,
                        height: 62,
                        child: CircularProgressIndicator(
                          value: conformity.clamp(0, 100) / 100,
                          strokeWidth: 6,
                          color: progressColor,
                          backgroundColor: AuditarBrand.line,
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '$conformity%',
                            style: const TextStyle(
                              color: AuditarBrand.navyDark,
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const Text(
                            'conforme',
                            style: TextStyle(
                              color: AuditarBrand.neutral,
                              fontSize: 8.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            LayoutBuilder(
              builder: (context, constraints) {
                const gap = 9.0;
                final itemWidth = (constraints.maxWidth - gap) / 2;
                return Wrap(
                  spacing: gap,
                  runSpacing: gap,
                  children: [
                    _overviewMetric(
                      width: itemWidth,
                      value: '$inspections',
                      label: 'Vistorias',
                      icon: Icons.fact_check_outlined,
                      color: AuditarBrand.info,
                    ),
                    _overviewMetric(
                      width: itemWidth,
                      value: '$openNcs',
                      label: 'NC abertas',
                      icon: Icons.warning_amber_rounded,
                      color: AuditarBrand.danger,
                    ),
                    _overviewMetric(
                      width: itemWidth,
                      value: '$pending',
                      label: 'Ações pendentes',
                      icon: Icons.pending_actions_outlined,
                      color: AuditarBrand.warning,
                    ),
                    _overviewMetric(
                      width: itemWidth,
                      value: '$overdue',
                      label: 'Vencidas',
                      icon: Icons.event_busy_outlined,
                      color: overdue > 0 ? AuditarBrand.danger : AuditarBrand.greenDark,
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _overviewMetric({
    required double width,
    required String value,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    return SizedBox(
      width: width,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(.075),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: color.withOpacity(.10)),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withOpacity(.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 19),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: const TextStyle(
                      color: AuditarBrand.navyDark,
                      fontSize: 17,
                      height: 1,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AuditarBrand.neutral,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _newInspectionCard() {
    return Material(
      color: AuditarBrand.greenDark,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _open(const NewInspectionScreen()),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 15, vertical: 13),
          child: Row(
            children: [
              SizedBox(
                width: 42,
                height: 42,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                  child: Icon(
                    Icons.add_task_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Nova vistoria',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Iniciar vistoria de segurança',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_rounded, size: 21, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }

  Widget _routineTodayCard() {
    final agenda = routineSummary['agendaToday'] ?? 0;
    final actions = routineSummary['actionsOverdue'] ?? 0;
    final trainings = routineSummary['trainingsDue'] ?? 0;
    final missingRequired = routineSummary['missingRequiredTrainings'] ?? 0;
    final newWorkersToTrain = routineSummary['newWorkersToTrain'] ?? 0;
    final medical = routineSummary['medicalDue'] ?? 0;
    final equipment = routineSummary['equipmentDue'] ?? 0;
    final verify = routineSummary['ncVerification'] ?? 0;
    final attention =
        actions + trainings + missingRequired + medical + equipment + verify;

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _open(const RoutineHubScreen()),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AuditarBrand.navySoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.today_outlined,
                  color: AuditarBrand.navy,
                  size: 22,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Resumo do dia',
                      style: TextStyle(
                        color: AuditarBrand.navyDark,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Wrap(
                      spacing: 7,
                      runSpacing: 5,
                      children: [
                        _routineBadge(
                          Icons.calendar_today_outlined,
                          '$agenda na agenda',
                          AuditarBrand.info,
                        ),
                        _routineBadge(
                          attention > 0
                              ? Icons.notifications_active_outlined
                              : Icons.check_circle_outline_rounded,
                          attention > 0
                              ? '$attention pedindo atenção'
                              : 'Nenhuma pendência hoje',
                          attention > 0
                              ? AuditarBrand.warning
                              : AuditarBrand.greenDark,
                        ),
                        if (newWorkersToTrain > 0)
                          _routineBadge(
                            Icons.person_add_alt_1_outlined,
                            '$newWorkersToTrain novo(s) para treinar',
                            AuditarBrand.warning,
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 4),
              const Icon(
                Icons.chevron_right_rounded,
                color: AuditarBrand.neutral,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _routineBadge(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 9.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: AuditarBrand.navy,
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: const TextStyle(
            color: AuditarBrand.neutral,
            fontSize: 10.5,
          ),
        ),
      ],
    );
  }

  Widget _quickGrid(List<_QuickData> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = 9.0;
        final width = (constraints.maxWidth - gap) / 2;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: items
              .map(
                (item) => SizedBox(
                  width: width,
                  height: 76,
                  child: Card(
                    margin: EdgeInsets.zero,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: item.onTap,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 11,
                          vertical: 10,
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: item.color.withOpacity(.10),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: Icon(
                                item.icon,
                                color: item.color,
                                size: 21,
                              ),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                item.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Color(0xFF182230),
                                  fontSize: 11.5,
                                  height: 1.15,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }

  Widget _managementTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        onTap: onTap,
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AuditarBrand.navySoft,
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(icon, color: AuditarBrand.navy, size: 21),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: AuditarBrand.navyDark,
            fontSize: 13,
            fontWeight: FontWeight.w800,
          ),
        ),
        subtitle: Text(
          subtitle,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 10.5),
        ),
        trailing: const Icon(
          Icons.chevron_right_rounded,
          color: AuditarBrand.neutral,
        ),
      ),
    );
  }
}

class _QuickData {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _QuickData(this.title, this.icon, this.color, this.onTap);
}
