import 'package:flutter/material.dart';

import '../database.dart';
import 'action_plan_screen.dart';
import 'checklist_templates_screen.dart';
import 'companies_screen.dart';
import 'dashboard_screen.dart';
import 'history_screen.dart';
import 'new_inspection_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int pending = 0;
  int overdue = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final summary = await AppDatabase.instance.getDashboardSummary();

    if (mounted) {
      setState(() {
        pending = summary['pending'] ?? 0;
        overdue = summary['overdue'] ?? 0;
      });
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Auditar SST'),
        actions: [
          IconButton(
            tooltip: 'Configurações',
            onPressed: () => _open(const SettingsScreen()),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 28,
                      child: Icon(
                        Icons.health_and_safety,
                        size: 32,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SEGURANÇA DO TRABALHO',
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Vistorias e planos de ação',
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Funciona offline e mantém o histórico no aparelho.',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const Icon(Icons.warning_amber_rounded),
                title: Text('$pending pendência(s) aberta(s)'),
                subtitle: Text(
                  overdue == 0
                      ? 'Nenhuma ação vencida'
                      : '$overdue ação(ões) vencida(s)',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(const ActionPlanScreen()),
              ),
            ),
            const SizedBox(height: 10),
            _menu(
              'Nova vistoria',
              'Empresa → checklist → fotos → relatório',
              Icons.playlist_add_check,
              () => _open(const NewInspectionScreen()),
            ),
            _menu(
              'Empresas e obras',
              'Cadastros, logos e locais',
              Icons.business,
              () => _open(const CompaniesScreen()),
            ),
            _menu(
              'Checklists editáveis',
              'Criar, editar e organizar perguntas',
              Icons.fact_check,
              () => _open(const ChecklistTemplatesScreen()),
            ),
            _menu(
              'Plano de ação',
              'Pendências e Antes/Depois',
              Icons.assignment_late,
              () => _open(const ActionPlanScreen()),
            ),
            _menu(
              'Indicadores',
              'Conformidade e acompanhamento',
              Icons.bar_chart,
              () => _open(const DashboardScreen()),
            ),
            _menu(
              'Relatórios',
              'Histórico e PDFs',
              Icons.picture_as_pdf,
              () => _open(const HistoryScreen()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menu(
    String title,
    String subtitle,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Card(
      child: ListTile(
        minTileHeight: 76,
        leading: Icon(icon, size: 31),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
