import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import 'checklist_items_screen.dart';
import 'checklist_preview_screen.dart';

class ChecklistTemplatesScreen extends StatefulWidget {
  final String? initialCategory;
  final String? title;

  const ChecklistTemplatesScreen({
    super.key,
    this.initialCategory,
    this.title,
  });

  @override
  State<ChecklistTemplatesScreen> createState() =>
      _ChecklistTemplatesScreenState();
}

class _ChecklistTemplatesScreenState
    extends State<ChecklistTemplatesScreen> {
  final searchController = TextEditingController();

  List<ChecklistTemplate> templates = [];
  final Map<String, Map<String, int>> stats = {};

  bool loading = true;
  bool showInactive = false;
  String selectedCategory = 'Todos';

  @override
  void initState() {
    super.initState();
    selectedCategory = widget.initialCategory ?? 'Todos';
    searchController.addListener(_refreshFilter);
    _load();
  }

  @override
  void dispose() {
    searchController.removeListener(_refreshFilter);
    searchController.dispose();
    super.dispose();
  }

  void _refreshFilter() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    final result =
        await AppDatabase.instance.getChecklistTemplates(
      onlyActive: false,
    );

    final loadedStats = <String, Map<String, int>>{};

    for (final template in result) {
      loadedStats[template.id] =
          await AppDatabase.instance
              .getChecklistTemplateStats(template.id);
    }

    if (!mounted) return;

    setState(() {
      templates = result;
      stats
        ..clear()
        ..addAll(loadedStats);
      loading = false;
    });
  }

  List<String> get categories {
    final values = templates
        .map((template) => template.category.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    return ['Todos', ...values];
  }

  List<ChecklistTemplate> get filteredTemplates {
    final query =
        searchController.text.trim().toLowerCase();

    return templates.where((template) {
      if (!showInactive && !template.active) {
        return false;
      }

      if (selectedCategory != 'Todos' &&
          template.category != selectedCategory) {
        return false;
      }

      if (query.isEmpty) return true;

      return template.name.toLowerCase().contains(query) ||
          template.category.toLowerCase().contains(query) ||
          template.reference.toLowerCase().contains(query);
    }).toList();
  }

  Future<void> _addTemplate() async {
    final name = TextEditingController();
    final category = TextEditingController();
    final reference = TextEditingController();

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Criar checklist'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: name,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'Nome do checklist *',
                  hintText:
                      'Ex.: Checklist de Produção',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: category,
                decoration: const InputDecoration(
                  labelText: 'Categoria',
                  hintText:
                      'Ex.: Fábrica, Obra, Máquinas...',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: reference,
                decoration: const InputDecoration(
                  labelText: 'Norma / Referência',
                  hintText:
                      'Ex.: NR-12, NR-18 ou Interno',
                ),
              ),
              const SizedBox(height: 12),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Depois de criar, você poderá adicionar e editar as perguntas.',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton.icon(
            onPressed: () =>
                Navigator.pop(context, true),
            icon: const Icon(Icons.add),
            label: const Text('Criar'),
          ),
        ],
      ),
    );

    if (save != true ||
        name.text.trim().isEmpty) {
      return;
    }

    final template = ChecklistTemplate(
      id: const Uuid().v4(),
      name: name.text.trim(),
      category: category.text.trim(),
      reference: reference.text.trim(),
    );

    await AppDatabase.instance
        .insertChecklistTemplate(template);

    await _load();

    if (!mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            ChecklistItemsScreen(template: template),
      ),
    );

    await _load();
  }

  Future<void> _editTemplate(
    ChecklistTemplate template,
  ) async {
    final name =
        TextEditingController(text: template.name);
    final category =
        TextEditingController(text: template.category);
    final reference =
        TextEditingController(text: template.reference);

    bool active = template.active;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) =>
            AlertDialog(
          title: const Text('Editar checklist'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText:
                        'Nome do checklist *',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(
                    labelText: 'Categoria',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: reference,
                  decoration: const InputDecoration(
                    labelText:
                        'Norma / Referência',
                  ),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title:
                      const Text('Checklist ativo'),
                  subtitle: const Text(
                    'Somente checklists ativos aparecem em novas vistorias.',
                  ),
                  value: active,
                  onChanged: (value) {
                    setDialogState(
                      () => active = value,
                    );
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (save != true ||
        name.text.trim().isEmpty) {
      return;
    }

    await AppDatabase.instance
        .updateChecklistTemplate(
      ChecklistTemplate(
        id: template.id,
        name: name.text.trim(),
        category: category.text.trim(),
        reference: reference.text.trim(),
        active: active,
      ),
    );

    await _load();
  }

  Future<void> _duplicate(
    ChecklistTemplate template,
  ) async {
    await AppDatabase.instance
        .duplicateChecklistTemplate(template.id);

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Checklist duplicado. Edite a cópia como quiser.',
        ),
      ),
    );
  }

  Future<void> _delete(
    ChecklistTemplate template,
  ) async {
    if (template.id == 'template-geral-sst' ||
        template.id.startsWith('ready-')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Os checklists da biblioteca não são apagados. Desative o modelo ou duplique para criar uma versão própria.',
          ),
        ),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir checklist?'),
        content: Text(
          'O modelo “${template.name}” será removido. '
          'As vistorias antigas continuam com as perguntas que foram usadas nelas.',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await AppDatabase.instance
          .deleteChecklistTemplate(template.id);

      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = filteredTemplates;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title ?? 'Biblioteca de checklists'),
      ),
      floatingActionButton:
          FloatingActionButton(
        onPressed: _addTemplate,
        tooltip: 'Criar checklist',
        child: const Icon(Icons.add),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding:
                  const EdgeInsets.fromLTRB(
                12,
                12,
                12,
                92,
              ),
              children: [
                Card(
                  child: Padding(
                    padding:
                        const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Checklists prontos + personalizados',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(
                                fontWeight:
                                    FontWeight.bold,
                              ),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          'Use a biblioteca pronta no dia a dia ou crie versões próprias. '
                          'Todos os modelos podem ser editados, duplicados e adaptados.',
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          onPressed: _addTemplate,
                          icon:
                              const Icon(Icons.add),
                          label: const Text(
                            'NOVO CHECKLIST',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: searchController,
                  decoration: InputDecoration(
                    labelText: 'Pesquisar checklist',
                    prefixIcon:
                        const Icon(Icons.search),
                    suffixIcon:
                        searchController.text.isEmpty
                            ? null
                            : IconButton(
                                tooltip:
                                    'Limpar pesquisa',
                                onPressed: () {
                                  searchController
                                      .clear();
                                },
                                icon: const Icon(
                                  Icons.close,
                                ),
                              ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 44,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: categories.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(width: 7),
                    itemBuilder: (context, index) {
                      final category = categories[index];
                      final selected = selectedCategory == category;
                      return FilterChip(
                        showCheckmark: false,
                        backgroundColor: Colors.white,
                        selectedColor: AuditarBrand.greenSoft,
                        side: BorderSide(
                          color: selected
                              ? AuditarBrand.green
                              : AuditarBrand.line,
                        ),
                        label: Text(
                          category,
                          style: TextStyle(
                            color: selected
                                ? AuditarBrand.greenDark
                                : AuditarBrand.navy,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        selected: selected,
                        onSelected: (_) {
                          setState(() {
                            selectedCategory = category;
                          });
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(height: 4),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(
                    'Mostrar checklists desativados',
                  ),
                  value: showInactive,
                  onChanged: (value) {
                    setState(
                      () => showInactive = value,
                    );
                  },
                ),
                if (visible.isEmpty)
                  const Padding(
                    padding:
                        EdgeInsets.symmetric(
                      vertical: 36,
                    ),
                    child: Center(
                      child: Text(
                        'Nenhum checklist encontrado.',
                      ),
                    ),
                  )
                else
                  ...visible.map((template) {
                    final templateStats =
                        stats[template.id] ??
                            const {
                              'total': 0,
                              'active': 0,
                              'inactive': 0,
                            };

                    final meta = <String>[
                      if (template.category.isNotEmpty) template.category,
                      if (template.reference.isNotEmpty) template.reference,
                      '${templateStats['active']} itens',
                      if (!template.active) 'Desativado',
                    ];

                    return Card(
                      margin:
                          const EdgeInsets.only(
                        bottom: 9,
                      ),
                      child: ListTile(
                          dense: true,
                          contentPadding: const EdgeInsets.fromLTRB(
                            12,
                            7,
                            4,
                            7,
                          ),
                          leading: CircleAvatar(
                            radius: 19,
                            child: Icon(
                              template.active
                                  ? Icons.fact_check
                                  : Icons
                                      .visibility_off_outlined,
                            ),
                          ),
                          title: Text(
                            template.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style:
                                const TextStyle(
                              fontWeight:
                                  FontWeight.w600,
                            ),
                          ),
                          subtitle: Text(
                            meta.join(' • '),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          onTap: () =>
                              Navigator.of(context)
                                  .push(
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          ChecklistItemsScreen(
                                        template:
                                            template,
                                      ),
                                    ),
                                  )
                                  .then(
                                    (_) => _load(),
                                  ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value ==
                                  'questions') {
                                Navigator.of(context)
                                    .push(
                                      MaterialPageRoute(
                                        builder: (_) =>
                                            ChecklistItemsScreen(
                                          template:
                                              template,
                                        ),
                                      ),
                                    )
                                    .then(
                                      (_) => _load(),
                                    );
                              } else if (value ==
                                  'preview') {
                                Navigator.of(context)
                                    .push(
                                      MaterialPageRoute(
                                        builder: (_) =>
                                            ChecklistPreviewScreen(
                                          template:
                                              template,
                                        ),
                                      ),
                                    );
                              } else if (value ==
                                  'edit') {
                                _editTemplate(
                                  template,
                                );
                              } else if (value ==
                                  'copy') {
                                _duplicate(
                                  template,
                                );
                              } else if (value ==
                                  'delete') {
                                _delete(template);
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'questions',
                                child: Text(
                                  'Editar perguntas',
                                ),
                              ),
                              PopupMenuItem(
                                value: 'preview',
                                child: Text(
                                  'Visualizar checklist',
                                ),
                              ),
                              PopupMenuItem(
                                value: 'edit',
                                child: Text(
                                  'Editar dados',
                                ),
                              ),
                              PopupMenuItem(
                                value: 'copy',
                                child: Text(
                                  'Duplicar checklist',
                                ),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child:
                                    Text('Excluir'),
                              ),
                            ],
                          ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }
}
