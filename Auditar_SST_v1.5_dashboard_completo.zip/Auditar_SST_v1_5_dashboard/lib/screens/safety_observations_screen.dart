import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';
import '../services/ai_assistant_service.dart';
import '../services/management_panel_service.dart';
import '../services/safety_observation_pdf_service.dart';
import '../services/storage_service.dart';

class SafetyObservationsScreen extends StatefulWidget {
  final Company company;

  const SafetyObservationsScreen({
    super.key,
    required this.company,
  });

  @override
  State<SafetyObservationsScreen> createState() => _SafetyObservationsScreenState();
}

class _SafetyObservationsScreenState extends State<SafetyObservationsScreen> {
  bool loading = true;
  bool generatingReport = false;
  List<SstRecord> records = [];
  List<Sector> sectors = [];
  String statusFilter = 'Todos';
  String kindFilter = 'Todos';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final results = await Future.wait([
      AppDatabase.instance.getSstRecords(
        type: 'OBSERVACAO_SEGURANCA',
        companyId: widget.company.id,
      ),
      AppDatabase.instance.getSectors(widget.company.id, onlyActive: false),
    ]);
    if (!mounted) return;
    setState(() {
      records = results[0] as List<SstRecord>;
      sectors = results[1] as List<Sector>;
      loading = false;
    });
  }

  String _kind(SstRecord record) =>
      '${record.payload['observationKind'] ?? 'Condição insegura'}';

  String _sectorName(SstRecord record) {
    final stored = '${record.payload['sectorName'] ?? ''}'.trim();
    if (stored.isNotEmpty) return stored;
    for (final sector in sectors) {
      if (sector.id == record.sectorId) return sector.name;
    }
    return '';
  }

  bool _isClosed(SstRecord record) =>
      record.status.toLowerCase().contains('resolvid') ||
      record.status.toLowerCase().contains('conclu');

  bool _isOverdue(SstRecord record) {
    final due = record.dueDate;
    if (due == null || _isClosed(record)) return false;
    final today = DateTime.now();
    final base = DateTime(today.year, today.month, today.day);
    final date = DateTime(due.year, due.month, due.day);
    return date.isBefore(base);
  }

  List<SstRecord> get _visibleRecords {
    return records.where((record) {
      if (kindFilter != 'Todos' && _kind(record) != kindFilter) return false;
      if (statusFilter == 'Abertos' && _isClosed(record)) return false;
      if (statusFilter == 'Resolvidos' && !_isClosed(record)) return false;
      return true;
    }).toList();
  }

  int get _openCount => records.where((r) => !_isClosed(r)).length;
  int get _criticalCount => records
      .where((r) => !_isClosed(r) && r.priority == 'Crítica')
      .length;

  Future<void> _edit([SstRecord? record]) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => SafetyObservationFormScreen(
          company: widget.company,
          sectors: sectors.where((s) => s.active).toList(),
          existing: record,
        ),
      ),
    );
    if (saved == true) await _load();
  }

  Future<void> _delete(SstRecord record) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir registro?'),
        content: Text('O registro “${record.title}” será removido.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteSstRecord(record.id);
    await ManagementPanelService.syncCompany(widget.company);
    await _load();
  }

  Future<void> _shareReport() async {
    if (records.isEmpty || generatingReport) return;
    setState(() => generatingReport = true);
    try {
      final bytes = await SafetyObservationPdfService.generate(
        company: widget.company,
        records: records,
        sectors: sectors,
      );
      final safeCompany = widget.company.name
          .replaceAll(RegExp(r'[^A-Za-z0-9À-ÿ _-]'), '')
          .trim()
          .replaceAll(RegExp(r'\s+'), '_');
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'Relatorio_Atos_Condicoes_${safeCompany.isEmpty ? 'Empresa' : safeCompany}.pdf',
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível gerar o relatório: $error')),
      );
    } finally {
      if (mounted) setState(() => generatingReport = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visibleRecords;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Atos e condições inseguras', maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Gerar relatório PDF',
            onPressed: records.isEmpty || generatingReport ? null : _shareReport,
            icon: generatingReport
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.picture_as_pdf_outlined),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 100),
                children: [
                  _summary(),
                  const SizedBox(height: 12),
                  _filters(),
                  const SizedBox(height: 12),
                  if (visible.isEmpty)
                    _empty()
                  else
                    ...visible.map(_card),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Novo registro'),
      ),
    );
  }

  Widget _summary() {
    final conditions = records.where((r) => _kind(r) == 'Condição insegura').length;
    final acts = records.where((r) => _kind(r) == 'Ato inseguro').length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Resumo da empresa',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w900,
            color: AuditarBrand.navy,
          ),
        ),
        const SizedBox(height: 8),
        ResponsiveWrap(
          minItemWidth: 112,
          maxColumns: 4,
          children: [
            _metric('Abertos', _openCount, Icons.warning_amber_rounded, const Color(0xFFD93025)),
            _metric('Críticos', _criticalCount, Icons.priority_high_rounded, const Color(0xFFD93025)),
            _metric('Condições', conditions, Icons.factory_outlined, const Color(0xFFF29D18)),
            _metric('Atos', acts, Icons.person_search_outlined, AuditarBrand.navy),
          ],
        ),
      ],
    );
  }

  Widget _metric(String label, int value, IconData icon, Color color) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 11),
        child: Column(
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(height: 4),
            Text(
              '$value',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: color),
            ),
            const SizedBox(height: 2),
            Text(label, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9.5, height: 1.1)),
          ],
        ),
      ),
    );
  }

  Widget _filters() {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              isExpanded: true,
              value: kindFilter,
              decoration: const InputDecoration(
                labelText: 'Tipo',
                isDense: true,
              ),
              items: const ['Todos', 'Condição insegura', 'Ato inseguro']
                  .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
              onChanged: (value) => setState(() => kindFilter = value ?? 'Todos'),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Wrap(
                spacing: 7,
                runSpacing: 7,
                children: ['Todos', 'Abertos', 'Resolvidos'].map((value) {
                  final selected = statusFilter == value;
                  return ChoiceChip(
                    label: Text(value),
                    selected: selected,
                    onSelected: (_) => setState(() => statusFilter = value),
                    labelStyle: TextStyle(
                      fontSize: 11.5,
                      fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                      color: selected ? Colors.white : AuditarBrand.navyDark,
                    ),
                    selectedColor: AuditarBrand.greenDark,
                    backgroundColor: Colors.white,
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _empty() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            Icon(Icons.health_and_safety_outlined, size: 52, color: AuditarBrand.navy.withOpacity(.25)),
            const SizedBox(height: 10),
            const Text(
              'Nenhum registro encontrado.',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            const Text(
              'Registre atos e condições inseguras encontrados durante as visitas.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(SstRecord record) {
    final payload = record.payload;
    final kind = _kind(record);
    final photoPath = '${payload['photoPath'] ?? ''}';
    final location = '${payload['location'] ?? ''}'.trim();
    final sector = _sectorName(record);
    final risk = '${payload['risk'] ?? ''}'.trim();
    final overdue = _isOverdue(record);
    final color = _priorityColor(record.priority, overdue: overdue);

    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Card(
        margin: EdgeInsets.zero,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _edit(record),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (photoPath.isNotEmpty && File(photoPath).existsSync())
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      File(photoPath),
                      width: 72,
                      height: 72,
                      fit: BoxFit.cover,
                    ),
                  )
                else
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: color.withOpacity(.10),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      kind == 'Ato inseguro' ? Icons.person_search_outlined : Icons.warning_amber_rounded,
                      color: color,
                    ),
                  ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              record.title,
                              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
                            ),
                          ),
                          _chip(overdue ? 'Vencido' : record.status, overdue ? const Color(0xFFD93025) : _statusColor(record.status)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        kind,
                        style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 11.5),
                      ),
                      const SizedBox(height: 4),
                      if (sector.isNotEmpty || location.isNotEmpty)
                        Text(
                          [sector, location].where((v) => v.isNotEmpty).join(' • '),
                          style: const TextStyle(color: Colors.black54, fontSize: 11.5),
                        ),
                      if (risk.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Risco: $risk',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11.5),
                        ),
                      ],
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 10,
                        runSpacing: 4,
                        children: [
                          _meta(Icons.calendar_today_outlined, DateFormat('dd/MM/yyyy').format(record.date)),
                          _meta(Icons.flag_outlined, record.priority),
                          if (record.dueDate != null)
                            _meta(Icons.event_outlined, 'Prazo ${DateFormat('dd/MM/yyyy').format(record.dueDate!)}'),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') _edit(record);
                    if (value == 'delete') _delete(record);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('Editar')),
                    PopupMenuItem(value: 'delete', child: Text('Excluir')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
        decoration: BoxDecoration(
          color: color.withOpacity(.10),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          text,
          style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: color),
        ),
      );

  Widget _meta(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12.5, color: Colors.black45),
          const SizedBox(width: 3),
          Text(text, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
        ],
      );

  Color _priorityColor(String priority, {bool overdue = false}) {
    if (overdue || priority == 'Crítica') return const Color(0xFFD93025);
    if (priority == 'Alta') return const Color(0xFFE56B16);
    if (priority == 'Média') return const Color(0xFFF29D18);
    return AuditarBrand.navy;
  }

  Color _statusColor(String status) {
    if (status.toLowerCase().contains('resolvid')) return AuditarBrand.greenDark;
    if (status.toLowerCase().contains('tratamento')) return const Color(0xFFF29D18);
    return const Color(0xFFD93025);
  }
}

class SafetyObservationFormScreen extends StatefulWidget {
  final Company company;
  final List<Sector> sectors;
  final SstRecord? existing;

  const SafetyObservationFormScreen({
    super.key,
    required this.company,
    required this.sectors,
    this.existing,
  });

  @override
  State<SafetyObservationFormScreen> createState() => _SafetyObservationFormScreenState();
}

class _SafetyObservationFormScreenState extends State<SafetyObservationFormScreen> {
  final formKey = GlobalKey<FormState>();
  final picker = ImagePicker();
  late final TextEditingController title;
  late final TextEditingController location;
  late final TextEditingController description;
  late final TextEditingController risk;
  late final TextEditingController consequence;
  late final TextEditingController recommendation;
  late final TextEditingController immediateAction;
  late final TextEditingController responsible;
  late final TextEditingController notes;

  String observationKind = 'Condição insegura';
  String? sectorId;
  String status = 'Aberto';
  String priority = 'Média';
  DateTime date = DateTime.now();
  DateTime? dueDate;
  String photoPath = '';
  bool saving = false;
  bool analyzingWithAi = false;

  @override
  void initState() {
    super.initState();
    final record = widget.existing;
    final payload = record?.payload ?? const <String, dynamic>{};
    title = TextEditingController(text: record?.title ?? '');
    location = TextEditingController(text: '${payload['location'] ?? ''}');
    description = TextEditingController(text: '${payload['description'] ?? ''}');
    risk = TextEditingController(text: '${payload['risk'] ?? ''}');
    consequence = TextEditingController(text: '${payload['possibleConsequence'] ?? ''}');
    recommendation = TextEditingController(text: '${payload['recommendation'] ?? ''}');
    immediateAction = TextEditingController(text: '${payload['immediateAction'] ?? ''}');
    responsible = TextEditingController(text: '${payload['responsible'] ?? ''}');
    notes = TextEditingController(text: '${payload['notes'] ?? ''}');
    observationKind = '${payload['observationKind'] ?? 'Condição insegura'}';
    sectorId = record?.sectorId;
    status = record?.status ?? 'Aberto';
    priority = record?.priority ?? 'Média';
    date = record?.date ?? DateTime.now();
    dueDate = record?.dueDate;
    photoPath = '${payload['photoPath'] ?? ''}';
  }

  @override
  void dispose() {
    title.dispose();
    location.dispose();
    description.dispose();
    risk.dispose();
    consequence.dispose();
    recommendation.dispose();
    immediateAction.dispose();
    responsible.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDate(DateTime? current) => showDatePicker(
        context: context,
        initialDate: current ?? DateTime.now(),
        firstDate: DateTime(2020),
        lastDate: DateTime(DateTime.now().year + 10),
      );

  Future<void> _pickPhoto(ImageSource source) async {
    final image = await picker.pickImage(
      source: source,
      imageQuality: 82,
      maxWidth: 1800,
    );
    if (image == null) return;
    final persisted = await StorageService.persistImage(
      image.path,
      folder: 'observacoes_seguranca',
    );
    if (!mounted) return;
    setState(() => photoPath = persisted);
  }

  Future<void> _analyzeWithAi() async {
    if (photoPath.isEmpty || analyzingWithAi) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tire ou escolha uma foto antes de analisar.'),
        ),
      );
      return;
    }

    setState(() => analyzingWithAi = true);
    final technicianContext = [
      if (title.text.trim().isNotEmpty) 'Título atual: ${title.text.trim()}',
      if (description.text.trim().isNotEmpty)
        'Descrição do técnico: ${description.text.trim()}',
      if (risk.text.trim().isNotEmpty) 'Risco já identificado: ${risk.text.trim()}',
      if (consequence.text.trim().isNotEmpty)
        'Possível consequência informada: ${consequence.text.trim()}',
    ].join('\n');

    final reply = await AiAssistantService.analyzeSafetyObservationPhoto(
      company: widget.company,
      observationKind: observationKind,
      sectorName: _sectorName(),
      location: location.text.trim(),
      photoPath: photoPath,
      technicianContext: technicianContext,
    );
    if (mounted) setState(() => analyzingWithAi = false);
    if (!mounted) return;

    if (!reply.success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(reply.message)),
      );
      return;
    }

    final result = reply.result;
    final suggestedTitle = '${result['title'] ?? ''}'.trim();
    final suggestedDescription = '${result['description'] ?? ''}'.trim();
    final suggestedRisk = '${result['risk'] ?? ''}'.trim();
    final suggestedConsequence =
        '${result['possibleConsequence'] ?? ''}'.trim();
    final suggestedRecommendation =
        '${result['recommendation'] ?? ''}'.trim();
    final suggestedImmediateAction =
        '${result['immediateAction'] ?? ''}'.trim();
    final correctiveAction = '${result['correctiveAction'] ?? ''}'.trim();
    final responsibleProfile = '${result['responsibleProfile'] ?? ''}'.trim();
    final rawDeadline = result['suggestedDeadlineDays'];
    final suggestedDeadlineDays = rawDeadline is num
        ? rawDeadline.toInt()
        : int.tryParse('$rawDeadline');
    final suggestedPriority = '${result['priority'] ?? 'Média'}'.trim();
    final confidence = '${result['confidence'] ?? 'Média'}'.trim();
    final references = (result['likelyReferences'] as List? ?? const [])
        .map((value) => '$value')
        .where((value) => value.trim().isNotEmpty)
        .toList();
    final checks = (result['checksRequired'] as List? ?? const [])
        .map((value) => '$value')
        .where((value) => value.trim().isNotEmpty)
        .toList();

    final useSuggestion = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sugestão da IA'),
        content: SizedBox(
          width: 620,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.amber.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Rascunho de apoio. Confirme presencialmente o que aparece na foto e edite o texto antes de salvar o registro.',
                    style: TextStyle(fontSize: 12.5),
                  ),
                ),
                const SizedBox(height: 12),
                _aiSuggestionField('Título / resumo', suggestedTitle),
                _aiSuggestionField('Situação observada', suggestedDescription),
                _aiSuggestionField('Risco identificado', suggestedRisk),
                _aiSuggestionField(
                  'Possível consequência',
                  suggestedConsequence,
                ),
                _aiSuggestionField(
                  'Ação imediata sugerida',
                  suggestedImmediateAction,
                ),
                _aiSuggestionField(
                  'Recomendação / medida corretiva',
                  [
                    if (suggestedRecommendation.isNotEmpty)
                      suggestedRecommendation,
                    if (correctiveAction.isNotEmpty) correctiveAction,
                  ].join('\n'),
                ),
                if (responsibleProfile.isNotEmpty ||
                    suggestedDeadlineDays != null)
                  _aiSuggestionField(
                    'Tratativa inicial',
                    [
                      if (responsibleProfile.isNotEmpty)
                        'Responsável sugerido: $responsibleProfile',
                      if (suggestedDeadlineDays != null)
                        'Prazo inicial sugerido: $suggestedDeadlineDays dia(s)',
                    ].join('\n'),
                  ),
                _aiSuggestionField(
                  'Prioridade sugerida',
                  '$suggestedPriority • confiança $confidence',
                ),
                if (references.isNotEmpty)
                  _aiSuggestionField(
                    'Referências prováveis para conferir',
                    references.join(' • '),
                  ),
                if (checks.isNotEmpty)
                  _aiSuggestionField(
                    'Confirmar presencialmente',
                    checks.map((value) => '• $value').join('\n'),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Não usar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Usar e editar'),
          ),
        ],
      ),
    );

    if (useSuggestion != true || !mounted) return;
    setState(() {
      if (suggestedTitle.isNotEmpty) title.text = suggestedTitle;
      if (suggestedDescription.isNotEmpty) {
        description.text = suggestedDescription;
      }
      if (suggestedRisk.isNotEmpty) risk.text = suggestedRisk;
      if (suggestedConsequence.isNotEmpty) {
        consequence.text = suggestedConsequence;
      }
      if (suggestedImmediateAction.isNotEmpty) {
        immediateAction.text = suggestedImmediateAction;
      }
      final treatment = [
        if (suggestedRecommendation.isNotEmpty) suggestedRecommendation,
        if (correctiveAction.isNotEmpty) correctiveAction,
      ].join('\n');
      if (treatment.isNotEmpty) recommendation.text = treatment;
      if (responsible.text.trim().isEmpty && responsibleProfile.isNotEmpty) {
        responsible.text = responsibleProfile;
      }
      if (dueDate == null && suggestedDeadlineDays != null) {
        dueDate = DateTime(date.year, date.month, date.day)
            .add(Duration(days: suggestedDeadlineDays));
      }
      if (const ['Baixa', 'Média', 'Alta', 'Crítica']
          .contains(suggestedPriority)) {
        priority = suggestedPriority;
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Sugestão aplicada. Revise os campos antes de salvar.'),
      ),
    );
  }

  String _sectorName() {
    for (final sector in widget.sectors) {
      if (sector.id == sectorId) return sector.name;
    }
    return '';
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false) || saving) return;
    setState(() => saving = true);
    final now = DateTime.now();
    final resolvedAt = status == 'Resolvido'
        ? '${widget.existing?.payload['resolvedAt'] ?? now.toIso8601String()}'
        : '';
    final payload = <String, dynamic>{
      'observationKind': observationKind,
      'sectorName': _sectorName(),
      'location': location.text.trim(),
      'description': description.text.trim(),
      'risk': risk.text.trim(),
      'possibleConsequence': consequence.text.trim(),
      'recommendation': recommendation.text.trim(),
      'immediateAction': immediateAction.text.trim(),
      'responsible': responsible.text.trim(),
      'photoPath': photoPath,
      'notes': notes.text.trim(),
      'resolvedAt': resolvedAt,
      'updatedAt': now.toIso8601String(),
    };
    final record = SstRecord(
      id: widget.existing?.id ?? const Uuid().v4(),
      companyId: widget.company.id,
      sectorId: sectorId,
      type: 'OBSERVACAO_SEGURANCA',
      title: title.text.trim(),
      date: date,
      dueDate: dueDate,
      status: status,
      priority: priority,
      payload: payload,
    );
    await AppDatabase.instance.upsertSstRecord(record);
    await ManagementPanelService.syncCompany(widget.company);
    if (!mounted) return;
    setState(() => saving = false);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'Novo registro de segurança' : 'Editar registro', maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 110),
          children: [
            _section('Classificação'),
            DropdownButtonFormField<String>(
              isExpanded: true,
              value: observationKind,
              decoration: const InputDecoration(labelText: 'Tipo de registro *'),
              items: const ['Condição insegura', 'Ato inseguro']
                  .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
              onChanged: (value) => setState(() => observationKind = value ?? observationKind),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              isExpanded: true,
              value: sectorId ?? '',
              decoration: const InputDecoration(labelText: 'Setor'),
              items: [
                const DropdownMenuItem<String>(value: '', child: Text('Sem setor específico')),
                ...widget.sectors.map((sector) => DropdownMenuItem(value: sector.id, child: Text(sector.name))),
              ],
              onChanged: (value) => setState(() => sectorId = value == null || value.isEmpty ? null : value),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: location,
              decoration: const InputDecoration(labelText: 'Local exato'),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: title,
              decoration: const InputDecoration(
                labelText: 'Título / resumo *',
                hintText: 'Ex.: Trabalhador sem óculos de proteção',
              ),
              validator: (value) => value == null || value.trim().isEmpty ? 'Informe um resumo.' : null,
            ),
            const SizedBox(height: 14),
            _section('O que foi observado'),
            TextFormField(
              controller: description,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Descrição *'),
              validator: (value) => value == null || value.trim().isEmpty ? 'Descreva o que foi observado.' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: risk,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Risco identificado',
                hintText: 'Ex.: projeção de partículas, queda, choque elétrico',
              ),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: consequence,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Possível consequência'),
            ),
            const SizedBox(height: 14),
            _section('Evidência'),
            _photoCard(),
            const SizedBox(height: 14),
            _section('Tratativa'),
            TextFormField(
              controller: immediateAction,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Ação imediata realizada',
                hintText: 'Ex.: trabalhador orientado no local',
              ),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: recommendation,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Recomendação / medida corretiva'),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: responsible,
              decoration: const InputDecoration(labelText: 'Responsável pela tratativa'),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final first = _dateField('Data do registro', date, () async {
                  final picked = await _pickDate(date);
                  if (picked != null) setState(() => date = picked);
                });
                final second = _dateField('Prazo', dueDate, () async {
                  final picked = await _pickDate(dueDate ?? date);
                  if (picked != null) setState(() => dueDate = picked);
                }, optional: true);
                if (constraints.maxWidth < 430) {
                  return Column(children: [first, const SizedBox(height: 10), second]);
                }
                return Row(children: [Expanded(child: first), const SizedBox(width: 8), Expanded(child: second)]);
              },
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final priorityField = DropdownButtonFormField<String>(
                  isExpanded: true,
                  value: priority,
                  decoration: const InputDecoration(labelText: 'Prioridade'),
                  items: const ['Baixa', 'Média', 'Alta', 'Crítica']
                      .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                      .toList(),
                  onChanged: (value) => setState(() => priority = value ?? priority),
                );
                final statusField = DropdownButtonFormField<String>(
                  isExpanded: true,
                  value: status,
                  decoration: const InputDecoration(labelText: 'Situação'),
                  items: const ['Aberto', 'Em tratamento', 'Resolvido']
                      .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                      .toList(),
                  onChanged: (value) => setState(() => status = value ?? status),
                );
                if (constraints.maxWidth < 430) {
                  return Column(children: [priorityField, const SizedBox(height: 10), statusField]);
                }
                return Row(children: [Expanded(child: priorityField), const SizedBox(width: 8), Expanded(child: statusField)]);
              },
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: notes,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Observações adicionais'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(
            onPressed: saving ? null : _save,
            icon: saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_outlined),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(saving ? 'Salvando...' : 'Salvar registro'),
            ),
          ),
        ),
      ),
    );
  }

  Widget _photoCard() {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            if (photoPath.isNotEmpty && File(photoPath).existsSync()) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(photoPath),
                  width: double.infinity,
                  height: 190,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 10),
            ],
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.camera),
                    icon: const Icon(Icons.photo_camera_outlined),
                    label: const Text('Câmera'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Galeria'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.tonalIcon(
                onPressed: photoPath.isEmpty || analyzingWithAi
                    ? null
                    : _analyzeWithAi,
                icon: analyzingWithAi
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.auto_awesome_outlined),
                label: Text(
                  analyzingWithAi
                      ? 'Analisando foto...'
                      : 'Analisar foto com IA',
                ),
              ),
            ),
            const SizedBox(height: 5),
            const Text(
              'Ao tocar, a foto é reduzida e enviada sem metadados ao Gemini. A IA cria apenas um rascunho: confirme a situação no local. Evite rostos, crachás, documentos e outros dados pessoais.',
              style: TextStyle(fontSize: 11.5, color: Colors.black54),
            ),
            if (photoPath.isNotEmpty)
              TextButton.icon(
                onPressed: () => setState(() => photoPath = ''),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Remover foto'),
              ),
          ],
        ),
      ),
    );
  }

  Widget _aiSuggestionField(String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
          ),
          const SizedBox(height: 3),
          SelectableText(value, style: const TextStyle(height: 1.35)),
        ],
      ),
    );
  }

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: const TextStyle(
            color: AuditarBrand.navy,
            fontSize: 15,
            fontWeight: FontWeight.w900,
          ),
        ),
      );

  Widget _dateField(
    String label,
    DateTime? value,
    VoidCallback onTap, {
    bool optional = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: const Icon(Icons.calendar_today_outlined, size: 18),
        ),
        child: Text(
          value == null ? (optional ? 'Sem prazo' : '-') : DateFormat('dd/MM/yyyy').format(value),
        ),
      ),
    );
  }
}
