import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/nc_pdf_service.dart';
import 'action_detail_screen.dart';
import 'create_action_screen.dart';

class NonConformityDetailScreen extends StatefulWidget {
  final String ncId;

  const NonConformityDetailScreen({super.key, required this.ncId});

  @override
  State<NonConformityDetailScreen> createState() => _NonConformityDetailScreenState();
}

class _NonConformityDetailScreenState extends State<NonConformityDetailScreen> {
  Map<String, Object?>? row;
  NonConformity? nc;
  List<EvidencePhoto> photos = [];
  List<ActionPlan> actions = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    await db.syncNonConformityStatus(widget.ncId);
    final loadedNc = await db.getNonConformity(widget.ncId);
    final loadedRow = await db.getNonConformityDetailRow(widget.ncId);
    if (loadedNc == null || loadedRow == null) {
      if (mounted) Navigator.pop(context);
      return;
    }
    final loadedPhotos = await db.getPhotosForAnswer(loadedNc.answerId);
    final loadedActions = await db.getActionsForNonConformity(widget.ncId);
    if (!mounted) return;
    setState(() {
      nc = loadedNc;
      row = loadedRow;
      photos = loadedPhotos;
      actions = loadedActions;
      loading = false;
    });
  }

  Future<void> _createAction() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => CreateActionScreen(ncId: widget.ncId)),
    );
    if (changed == true) await _load();
  }

  Future<void> _sharePdf() async {
    final bytes = await NcPdfService.generate(widget.ncId);
    await Printing.sharePdf(
      bytes: bytes,
      filename: '${nc?.code ?? 'NC'}.pdf',
    );
  }

  Future<void> _verifyAndClose() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Verificar e concluir NC'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Confirme somente após verificar no local que as ações corretivas foram realmente executadas.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Verificado por *',
                hintText: 'Nome do responsável pela verificação',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isEmpty) return;
              Navigator.pop(dialogContext, true);
            },
            child: const Text('Concluir NC'),
          ),
        ],
      ),
    );

    if (confirmed != true) {
      controller.dispose();
      return;
    }

    final verifiedBy = controller.text.trim();
    controller.dispose();
    await AppDatabase.instance.verifyNonConformity(
      ncId: widget.ncId,
      verifiedBy: verifiedBy,
    );
    await _load();
  }

  Future<void> _reopenNc() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reabrir não conformidade?'),
        content: const Text(
          'A NC voltará para acompanhamento e o status será calculado conforme os planos de ação vinculados.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Reabrir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.reopenNonConformity(widget.ncId);
    await _load();
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Vencida':
        return const Color(0xFFD93025);
      case 'Pendente':
        return const Color(0xFFF29D18);
      case 'Em andamento':
        return AuditarBrand.navy;
      case 'Aguardando verificação':
        return const Color(0xFF7B61A8);
      case 'Concluída':
        return AuditarBrand.greenDark;
      default:
        return Colors.blueGrey;
    }
  }

  String _statusHelp(String status) {
    switch (status) {
      case 'Pendente':
        return 'A NC está aberta e ainda precisa de ação corretiva ou início do tratamento.';
      case 'Em andamento':
        return 'Existe pelo menos uma ação corretiva sendo executada.';
      case 'Vencida':
        return 'Existe ação corretiva com prazo ultrapassado.';
      case 'Aguardando verificação':
        return 'Todas as ações foram concluídas. Falta a verificação final do TST/responsável.';
      case 'Concluída':
        return 'A correção foi verificada e a NC está encerrada no histórico.';
      default:
        return '';
    }
  }

  Widget _field(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 10.5, color: Colors.black54, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(value.trim().isEmpty ? '-' : value),
        ],
      ),
    );
  }

  Widget _actionCard(ActionPlan action) {
    final due = action.dueDate;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final overdue = due != null && action.status != 'Concluído' &&
        DateTime(due.year, due.month, due.day).isBefore(today);
    final color = action.status == 'Concluído'
        ? AuditarBrand.greenDark
        : overdue
            ? const Color(0xFFD93025)
            : action.status == 'Em andamento'
                ? AuditarBrand.navy
                : const Color(0xFFF29D18);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        leading: CircleAvatar(
          backgroundColor: color.withValues(alpha: .10),
          child: Icon(
            action.status == 'Concluído' ? Icons.task_alt : Icons.assignment_outlined,
            color: color,
          ),
        ),
        title: Text(
          action.correctiveAction,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          [
            if (action.responsible.trim().isNotEmpty) 'Responsável: ${action.responsible}',
            'Prioridade: ${action.priority}',
            due == null ? 'Sem prazo' : 'Prazo: ${DateFormat('dd/MM/yyyy').format(due)}${overdue ? ' • VENCIDA' : ''}',
            'Status: ${action.status}',
          ].join('\n'),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => ActionDetailScreen(actionId: action.id)))
            .then((_) => _load()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final current = nc!;
    final detail = row!;
    final statusColor = _statusColor(current.status);

    return Scaffold(
      appBar: AppBar(
        title: Text(current.code),
        actions: [
          IconButton(
            tooltip: 'Compartilhar PDF da NC',
            onPressed: _sharePdf,
            icon: const Icon(Icons.share_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
          children: [
            Container(
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: .08),
                border: Border.all(color: statusColor.withValues(alpha: .22)),
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, color: statusColor),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          current.status,
                          style: TextStyle(color: statusColor, fontWeight: FontWeight.w800, fontSize: 15),
                        ),
                        const SizedBox(height: 3),
                        Text(_statusHelp(current.status), style: const TextStyle(fontSize: 11.5)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Dados da não conformidade',
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AuditarBrand.navy),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF2F4F7),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(current.classification, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 10.5)),
                        ),
                      ],
                    ),
                    const Divider(height: 22),
                    _field('Empresa', '${detail['company_name'] ?? '-'}'),
                    if ('${detail['sector_name'] ?? ''}'.trim().isNotEmpty)
                      _field('Setor', '${detail['sector_name']}'),
                    if ('${detail['worksite_name'] ?? ''}'.trim().isNotEmpty)
                      _field('Obra / Unidade', '${detail['worksite_name']}'),
                    _field('Área / Local', '${detail['area'] ?? '-'}'),
                    _field('Item verificado', '${detail['question_text'] ?? '-'}'),
                    if ('${detail['question_reference'] ?? ''}'.trim().isNotEmpty)
                      _field('Referência', '${detail['question_reference']}'),
                    _field('Situação encontrada', current.description),
                    _field('Risco identificado', current.riskIdentified),
                    _field('Recomendação técnica', current.recommendation),
                    if (current.verifiedAt != null) ...[
                      _field('Verificada por', current.verifiedBy),
                      _field('Data da verificação', DateFormat('dd/MM/yyyy HH:mm').format(current.verifiedAt!)),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Evidências da vistoria', style: TextStyle(fontWeight: FontWeight.w800, color: AuditarBrand.navy)),
                    const SizedBox(height: 10),
                    if (photos.isEmpty)
                      const Text('Nenhuma foto anexada.')
                    else
                      SizedBox(
                        height: 145,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: photos.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, index) {
                            final file = File(photos[index].path);
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: file.existsSync()
                                  ? Image.file(file, width: 145, height: 145, fit: BoxFit.cover)
                                  : Container(
                                      width: 145,
                                      color: const Color(0xFFF1F3F5),
                                      alignment: Alignment.center,
                                      child: const Text('Foto indisponível'),
                                    ),
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Planos de ação',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
                  ),
                ),
                if (current.status != 'Concluída')
                  TextButton.icon(
                    onPressed: _createAction,
                    icon: const Icon(Icons.add),
                    label: const Text('Nova ação'),
                  ),
              ],
            ),
            if (actions.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text('Nenhuma ação corretiva vinculada a esta NC.'),
                      const SizedBox(height: 10),
                      FilledButton.icon(
                        onPressed: current.status == 'Concluída' ? null : _createAction,
                        icon: const Icon(Icons.add_task),
                        label: const Text('Criar plano de ação'),
                      ),
                    ],
                  ),
                ),
              )
            else
              ...actions.map(_actionCard),
            const SizedBox(height: 16),
            if (current.status == 'Aguardando verificação')
              FilledButton.icon(
                onPressed: _verifyAndClose,
                icon: const Icon(Icons.verified_outlined),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('VERIFICAR E CONCLUIR NC'),
                ),
              ),
            if (current.status == 'Concluída')
              OutlinedButton.icon(
                onPressed: _reopenNc,
                icon: const Icon(Icons.replay),
                label: const Text('REABRIR NÃO CONFORMIDADE'),
              ),
          ],
        ),
      ),
    );
  }
}
