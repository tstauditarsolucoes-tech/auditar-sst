import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';

class SstRecordFormScreen extends StatefulWidget {
  final String type;
  final String? companyId;
  final SstRecord? record;

  const SstRecordFormScreen({
    super.key,
    required this.type,
    this.companyId,
    this.record,
  });

  @override
  State<SstRecordFormScreen> createState() => _SstRecordFormScreenState();
}

class _SstRecordFormScreenState extends State<SstRecordFormScreen> {
  final formKey = GlobalKey<FormState>();
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final responsibleController = TextEditingController();
  final locationController = TextEditingController();
  final participantsController = TextEditingController();
  final risksController = TextEditingController();
  final controlsController = TextEditingController();
  final causesController = TextEditingController();
  final measuresController = TextEditingController();
  final tagController = TextEditingController();
  final notesController = TextEditingController();

  bool loading = true;
  List<Company> companies = [];
  List<Sector> sectors = [];
  String? selectedCompanyId;
  String? selectedSectorId;
  DateTime date = DateTime.now();
  DateTime? dueDate;
  String status = 'Pendente';
  String priority = 'Média';
  String subtype = '';

  @override
  void initState() {
    super.initState();
    final r = widget.record;
    if (r != null) {
      titleController.text = r.title;
      selectedCompanyId = r.companyId;
      selectedSectorId = r.sectorId;
      date = r.date;
      dueDate = r.dueDate;
      status = r.status;
      priority = r.priority;
      final p = r.payload;
      descriptionController.text = '${p['description'] ?? ''}';
      responsibleController.text = '${p['responsible'] ?? p['instructor'] ?? ''}';
      locationController.text = '${p['location'] ?? ''}';
      participantsController.text = '${p['participants'] ?? ''}';
      risksController.text = '${p['risks'] ?? ''}';
      controlsController.text = '${p['controls'] ?? ''}';
      causesController.text = '${p['causes'] ?? ''}';
      measuresController.text = '${p['measures'] ?? ''}';
      tagController.text = '${p['tag'] ?? ''}';
      notesController.text = '${p['notes'] ?? ''}';
      subtype = '${p['subtype'] ?? ''}';
    } else {
      selectedCompanyId = widget.companyId;
      subtype = _defaultSubtype();
      status = _statuses().first;
    }
    _load();
  }

  @override
  void dispose() {
    for (final c in [
      titleController,
      descriptionController,
      responsibleController,
      locationController,
      participantsController,
      risksController,
      controlsController,
      causesController,
      measuresController,
      tagController,
      notesController,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final loaded = await AppDatabase.instance.getCompanies(onlyActive: false);
    if (selectedCompanyId == null && loaded.isNotEmpty) selectedCompanyId = loaded.first.id;
    await _loadSectors(selectedCompanyId, notify: false);
    if (!mounted) return;
    setState(() {
      companies = loaded;
      loading = false;
    });
  }

  Future<void> _loadSectors(String? companyId, {bool notify = true}) async {
    final loaded = companyId == null ? <Sector>[] : await AppDatabase.instance.getSectors(companyId);
    if (selectedSectorId != null && !loaded.any((s) => s.id == selectedSectorId)) {
      selectedSectorId = null;
    }
    if (!mounted) return;
    if (notify) {
      setState(() => sectors = loaded);
    } else {
      sectors = loaded;
    }
  }

  Future<void> _pickDate({required bool due}) async {
    final initial = due ? (dueDate ?? date) : date;
    final value = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (value == null || !mounted) return;
    setState(() {
      if (due) {
        dueDate = value;
      } else {
        date = value;
      }
    });
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    if (selectedCompanyId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cadastre ou selecione uma empresa.')));
      return;
    }
    final payload = <String, dynamic>{
      'description': descriptionController.text.trim(),
      'responsible': responsibleController.text.trim(),
      'location': locationController.text.trim(),
      'participants': participantsController.text.trim(),
      'risks': risksController.text.trim(),
      'controls': controlsController.text.trim(),
      'causes': causesController.text.trim(),
      'measures': measuresController.text.trim(),
      'tag': tagController.text.trim(),
      'notes': notesController.text.trim(),
      'subtype': subtype,
    };
    final record = SstRecord(
      id: widget.record?.id ?? const Uuid().v4(),
      companyId: selectedCompanyId,
      sectorId: selectedSectorId,
      type: widget.type,
      title: titleController.text.trim(),
      date: date,
      dueDate: dueDate,
      status: status,
      priority: priority,
      payload: payload,
    );
    await AppDatabase.instance.upsertSstRecord(record);
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.record == null ? 'Novo ${_shortTitle()}' : 'Editar ${_shortTitle()}')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: formKey,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 110),
                children: [
                  _section('Identificação'),
                  if (widget.companyId == null)
                    DropdownButtonFormField<String>(
                      value: selectedCompanyId,
                      decoration: const InputDecoration(labelText: 'Empresa *'),
                      items: companies.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
                      onChanged: (value) async {
                        setState(() {
                          selectedCompanyId = value;
                          selectedSectorId = null;
                        });
                        await _loadSectors(value);
                      },
                    )
                  else
                    _infoCompany(),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: selectedSectorId ?? '',
                    decoration: const InputDecoration(labelText: 'Setor'),
                    items: [
                      const DropdownMenuItem<String>(value: '', child: Text('Sem setor específico')),
                      ...sectors.map((s) => DropdownMenuItem<String>(value: s.id, child: Text(s.name))),
                    ],
                    onChanged: (value) => setState(() => selectedSectorId = (value == null || value.isEmpty) ? null : value),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: titleController,
                    decoration: InputDecoration(labelText: '${_titleLabel()} *'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Preencha este campo.' : null,
                  ),
                  const SizedBox(height: 14),
                  ..._specificFields(),
                  const SizedBox(height: 14),
                  _section('Controle'),
                  Row(
                    children: [
                      Expanded(child: _dateField(_dateLabel(), date, () => _pickDate(due: false))),
                      const SizedBox(width: 8),
                      Expanded(child: _dateField(_dueLabel(), dueDate, () => _pickDate(due: true), optional: true)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: status,
                          decoration: const InputDecoration(labelText: 'Situação'),
                          items: _statuses().map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                          onChanged: (v) => setState(() => status = v ?? status),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: priority,
                          decoration: const InputDecoration(labelText: 'Prioridade'),
                          items: const ['Baixa', 'Média', 'Alta', 'Crítica']
                              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                              .toList(),
                          onChanged: (v) => setState(() => priority = v ?? priority),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(
            onPressed: loading ? null : _save,
            icon: const Icon(Icons.save_outlined),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Text('Salvar registro'),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCompany() {
    final name = companies.where((c) => c.id == selectedCompanyId).map((c) => c.name).firstOrNull ?? 'Empresa';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFFF0F3F8), borderRadius: BorderRadius.circular(14)),
      child: Row(children: [const Icon(Icons.business_outlined, color: AuditarBrand.navy), const SizedBox(width: 8), Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)))]),
    );
  }

  List<Widget> _specificFields() {
    final items = <Widget>[];
    void add(Widget w) {
      if (items.isNotEmpty) items.add(const SizedBox(height: 10));
      items.add(w);
    }

    if (widget.type == 'AGENDA') {
      add(TextFormField(controller: descriptionController, maxLines: 3, decoration: const InputDecoration(labelText: 'Descrição / lembrete')));
      add(TextFormField(controller: responsibleController, decoration: const InputDecoration(labelText: 'Responsável')));
    } else if (widget.type == 'DDS') {
      add(TextFormField(controller: responsibleController, decoration: const InputDecoration(labelText: 'Instrutor / responsável')));
      add(TextFormField(controller: participantsController, maxLines: 4, decoration: const InputDecoration(labelText: 'Participantes', hintText: 'Um nome por linha ou observação da lista')));
      add(TextFormField(controller: notesController, maxLines: 3, decoration: const InputDecoration(labelText: 'Observações / conteúdo abordado')));
    } else if (widget.type == 'APR_PT') {
      add(DropdownButtonFormField<String>(
        value: subtype.isEmpty ? 'APR' : subtype,
        decoration: const InputDecoration(labelText: 'Documento'),
        items: const ['APR', 'PT'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => subtype = v ?? 'APR'),
      ));
      add(TextFormField(controller: locationController, decoration: const InputDecoration(labelText: 'Local da atividade')));
      add(TextFormField(controller: responsibleController, decoration: const InputDecoration(labelText: 'Responsável pela atividade')));
      add(TextFormField(controller: risksController, maxLines: 4, decoration: const InputDecoration(labelText: 'Riscos identificados')));
      add(TextFormField(controller: controlsController, maxLines: 4, decoration: const InputDecoration(labelText: 'Medidas de controle')));
    } else if (widget.type == 'INCIDENTE') {
      add(DropdownButtonFormField<String>(
        value: subtype.isEmpty ? 'Quase acidente' : subtype,
        decoration: const InputDecoration(labelText: 'Tipo'),
        items: const ['Acidente', 'Incidente', 'Quase acidente'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => subtype = v ?? 'Quase acidente'),
      ));
      add(TextFormField(controller: locationController, decoration: const InputDecoration(labelText: 'Local')));
      add(TextFormField(controller: descriptionController, maxLines: 4, decoration: const InputDecoration(labelText: 'Descrição do ocorrido')));
      add(TextFormField(controller: causesController, maxLines: 3, decoration: const InputDecoration(labelText: 'Causas / fatores contribuintes')));
      add(TextFormField(controller: measuresController, maxLines: 3, decoration: const InputDecoration(labelText: 'Medidas adotadas / recomendadas')));
    } else if (widget.type == 'EQUIPAMENTO') {
      add(TextFormField(controller: tagController, decoration: const InputDecoration(labelText: 'TAG / patrimônio / identificação')));
      add(TextFormField(controller: locationController, decoration: const InputDecoration(labelText: 'Local / setor de uso')));
      add(TextFormField(controller: responsibleController, decoration: const InputDecoration(labelText: 'Responsável')));
      add(TextFormField(controller: notesController, maxLines: 3, decoration: const InputDecoration(labelText: 'Observações de inspeção / manutenção')));
    }
    return items;
  }

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(color: AuditarBrand.navy, fontSize: 15, fontWeight: FontWeight.w800)),
      );

  Widget _dateField(String label, DateTime? value, VoidCallback onTap, {bool optional = false}) => InkWell(
        onTap: onTap,
        child: InputDecorator(
          decoration: InputDecoration(labelText: label, suffixIcon: const Icon(Icons.calendar_today_outlined, size: 18)),
          child: Text(value == null ? (optional ? 'Opcional' : '-') : DateFormat('dd/MM/yyyy').format(value)),
        ),
      );

  String _shortTitle() {
    switch (widget.type) {
      case 'AGENDA': return 'compromisso';
      case 'DDS': return 'DDS';
      case 'APR_PT': return 'APR / PT';
      case 'INCIDENTE': return 'registro';
      case 'EQUIPAMENTO': return 'equipamento';
      default: return 'registro';
    }
  }

  String _titleLabel() {
    switch (widget.type) {
      case 'AGENDA': return 'Compromisso';
      case 'DDS': return 'Tema do DDS';
      case 'APR_PT': return 'Atividade';
      case 'INCIDENTE': return 'Resumo do ocorrido';
      case 'EQUIPAMENTO': return 'Equipamento / máquina';
      default: return 'Título';
    }
  }

  String _dateLabel() {
    if (widget.type == 'EQUIPAMENTO') return 'Última inspeção';
    return 'Data';
  }

  String _dueLabel() {
    if (widget.type == 'EQUIPAMENTO') return 'Próx. inspeção';
    if (widget.type == 'APR_PT') return 'Validade';
    return 'Prazo';
  }

  String _defaultSubtype() {
    if (widget.type == 'APR_PT') return 'APR';
    if (widget.type == 'INCIDENTE') return 'Quase acidente';
    return '';
  }

  List<String> _statuses() {
    switch (widget.type) {
      case 'AGENDA': return ['Programado', 'Em andamento', 'Concluído'];
      case 'DDS': return ['Programado', 'Realizado', 'Cancelado'];
      case 'APR_PT': return ['Rascunho', 'Liberado', 'Encerrado'];
      case 'INCIDENTE': return ['Aberto', 'Em análise', 'Concluído'];
      case 'EQUIPAMENTO': return ['Em dia', 'Atenção', 'Interditado', 'Inativo'];
      default: return ['Pendente', 'Concluído'];
    }
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
