import 'package:flutter/material.dart';

import '../brand.dart';
import '../database.dart';
import 'sst_records_screen.dart';

class RoutineHubScreen extends StatefulWidget {
  final String? companyId;

  const RoutineHubScreen({super.key, this.companyId});

  @override
  State<RoutineHubScreen> createState() => _RoutineHubScreenState();
}

class _RoutineHubScreenState extends State<RoutineHubScreen> {
  bool loading = true;
  Map<String, int> summary = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getRoutineTodaySummary(companyId: widget.companyId);
    if (!mounted) return;
    setState(() {
      summary = result;
      loading = false;
    });
  }

  Future<void> _open(String type) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SstRecordsScreen(type: type, companyId: widget.companyId)),
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rotina SST')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
                children: [
                  const Text('Resumo do dia', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                  const SizedBox(height: 10),
                  _summaryCard(),
                  const SizedBox(height: 20),
                  const Text('Ferramentas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                  const SizedBox(height: 10),
                  _tool('AGENDA', 'Agenda SST', 'Inspeções, reuniões, treinamentos e prazos.', Icons.calendar_month_outlined, AuditarBrand.navy),
                  _tool('DDS', 'DDS', 'Temas, participantes e histórico por empresa.', Icons.record_voice_over_outlined, AuditarBrand.greenDark),
                  _tool('APR_PT', 'APR / PT', 'Atividade, riscos, controles, responsável e validade.', Icons.assignment_outlined, const Color(0xFFF29D18)),
                  _tool('INCIDENTE', 'Acidentes e incidentes', 'Acidente, incidente e quase acidente com acompanhamento.', Icons.health_and_safety_outlined, const Color(0xFFD93025)),
                  _tool('EQUIPAMENTO', 'Equipamentos e máquinas', 'Cadastro, identificação e próxima inspeção.', Icons.precision_manufacturing_outlined, const Color(0xFF6A4BBC)),
                ],
              ),
            ),
    );
  }

  Widget _summaryCard() {
    final items = [
      ('Agenda hoje', summary['agendaToday'] ?? 0, Icons.today_outlined, AuditarBrand.navy),
      ('Ações vencidas', summary['actionsOverdue'] ?? 0, Icons.warning_amber_rounded, const Color(0xFFD93025)),
      ('Treinamentos a verificar', summary['trainingsDue'] ?? 0, Icons.school_outlined, const Color(0xFFF29D18)),
      ('Novos para treinar', summary['newWorkersToTrain'] ?? 0, Icons.person_add_alt_1_outlined, const Color(0xFFF29D18)),
      ('Obrigatórios sem registro', summary['missingRequiredTrainings'] ?? 0, Icons.report_gmailerrorred_outlined, const Color(0xFFD93025)),
      ('Exames a verificar', summary['medicalDue'] ?? 0, Icons.medical_information_outlined, const Color(0xFF6A4BBC)),
      ('Equipamentos a verificar', summary['equipmentDue'] ?? 0, Icons.build_circle_outlined, const Color(0xFF6A4BBC)),
      ('NCs para verificar', summary['ncVerification'] ?? 0, Icons.fact_check_outlined, AuditarBrand.greenDark),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = 8.0;
        final twoColumns = constraints.maxWidth >= 360;
        final itemWidth = twoColumns ? (constraints.maxWidth - gap) / 2 : constraints.maxWidth;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: items.map((item) => SizedBox(
            width: itemWidth,
            height: 72,
            child: Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: item.$4.withValues(alpha: .10),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(item.$3, size: 19, color: item.$4),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('${item.$2}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: item.$4)),
                          Text(item.$1, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, height: 1.15)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )).toList(),
        );
      },
    );
  }

  Widget _tool(String type, String title, String subtitle, IconData icon, Color color) => Padding(
        padding: const EdgeInsets.only(bottom: 9),
        child: Card(
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            leading: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: color),
            ),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(subtitle, style: const TextStyle(fontSize: 11.5)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _open(type),
          ),
        ),
      );
}
