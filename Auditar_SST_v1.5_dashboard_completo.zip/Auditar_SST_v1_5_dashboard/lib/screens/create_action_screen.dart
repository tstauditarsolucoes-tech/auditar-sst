import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';

class CreateActionScreen extends StatefulWidget {
  final String ncId;

  const CreateActionScreen({super.key, required this.ncId});

  @override
  State<CreateActionScreen> createState() => _CreateActionScreenState();
}

class _CreateActionScreenState extends State<CreateActionScreen> {
  final actionController = TextEditingController();
  final responsibleController = TextEditingController();
  NonConformity? nc;
  String priority = 'Média';
  DateTime? dueDate;
  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    actionController.dispose();
    responsibleController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final loaded = await AppDatabase.instance.getNonConformity(widget.ncId);
    if (!mounted) return;
    if (loaded == null) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      nc = loaded;
      priority = loaded.classification;
      loading = false;
    });
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: DateTime(now.year + 5),
      initialDate: dueDate ?? now,
    );
    if (selected != null && mounted) setState(() => dueDate = selected);
  }

  Future<void> _save() async {
    final current = nc;
    if (current == null || saving) return;
    if (actionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe a ação corretiva.')),
      );
      return;
    }

    setState(() => saving = true);
    try {
      final action = ActionPlan(
        id: const Uuid().v4(),
        inspectionId: current.inspectionId,
        answerId: current.answerId,
        ncId: current.id,
        nonConformity: current.description,
        correctiveAction: actionController.text.trim(),
        responsible: responsibleController.text.trim(),
        priority: priority,
        dueDate: dueDate,
        status: 'Pendente',
      );
      await AppDatabase.instance.insertAction(action);
      await AppDatabase.instance.syncNonConformityStatus(current.id);
      if (!mounted) return;
      Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  String get dueLabel {
    final d = dueDate;
    if (d == null) return 'Definir prazo';
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Novo plano de ação')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.warning_amber_rounded),
              title: Text(nc!.code, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(nc!.description),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: actionController,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Ação corretiva *'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: responsibleController,
            decoration: const InputDecoration(labelText: 'Responsável pela ação'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            isExpanded: true,
            value: priority,
            decoration: const InputDecoration(labelText: 'Prioridade'),
            items: const [
              DropdownMenuItem(value: 'Baixa', child: Text('Baixa')),
              DropdownMenuItem(value: 'Média', child: Text('Média')),
              DropdownMenuItem(value: 'Alta', child: Text('Alta')),
              DropdownMenuItem(value: 'Crítica', child: Text('Crítica')),
            ],
            onChanged: (value) {
              if (value != null) setState(() => priority = value);
            },
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickDate,
            icon: const Icon(Icons.calendar_month),
            label: Text(dueLabel),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: saving ? null : _save,
            icon: const Icon(Icons.add_task),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(saving ? 'Salvando...' : 'Criar plano de ação'),
            ),
          ),
        ],
      ),
    );
  }
}
