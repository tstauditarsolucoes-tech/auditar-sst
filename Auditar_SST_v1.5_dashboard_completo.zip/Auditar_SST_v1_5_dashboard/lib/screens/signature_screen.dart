import 'dart:io';

import 'package:flutter/material.dart';
import 'package:signature/signature.dart';

import '../database.dart';
import '../services/storage_service.dart';
import 'report_screen.dart';

class SignatureScreen extends StatefulWidget {
  final String inspectionId;
  final String companyName;
  final String technicianName;
  final bool preserveExisting;

  const SignatureScreen({
    super.key,
    required this.inspectionId,
    required this.companyName,
    required this.technicianName,
    this.preserveExisting = false,
  });

  @override
  State<SignatureScreen> createState() => _SignatureScreenState();
}

class _SignatureScreenState extends State<SignatureScreen> {
  late final TextEditingController technicianName;
  final responsibleName = TextEditingController();
  final generalNotes = TextEditingController();
  final conclusion = TextEditingController();

  String? existingTechnicianSignaturePath;
  String? existingResponsibleSignaturePath;
  bool loading = true;

  final technicianSignature = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );

  final responsibleSignature = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );

  @override
  void initState() {
    super.initState();

    technicianName = TextEditingController(
      text: widget.technicianName,
    );

    _loadExisting();
  }

  Future<void> _loadExisting() async {
    final header = await AppDatabase.instance.getInspectionHeader(
      widget.inspectionId,
    );
    final ncs = await AppDatabase.instance.getNonConformitiesForInspection(
      widget.inspectionId,
    );
    final defaultConclusion = ncs.isEmpty
        ? 'Não foram identificadas não conformidades nesta vistoria. Recomenda-se manter os controles e acompanhar os itens avaliados.'
        : 'Foram identificadas ${ncs.length} não conformidade(s). Recomenda-se acompanhar as correções e os planos de ação vinculados, quando aplicáveis.';

    if (header != null) {
      final oldTechnician =
          ('${header['technician_name'] ?? ''}').trim();
      final oldResponsible =
          ('${header['responsible_name'] ?? ''}').trim();
      final oldNotes = ('${header['general_notes'] ?? ''}').trim();
      final oldConclusion = ('${header['conclusion'] ?? ''}').trim();

      if (oldTechnician.isNotEmpty) {
        technicianName.text = oldTechnician;
      }
      responsibleName.text = oldResponsible;
      generalNotes.text = oldNotes;

      conclusion.text = oldConclusion.isNotEmpty
          ? oldConclusion
          : defaultConclusion;

      if (widget.preserveExisting) {
        existingTechnicianSignaturePath =
            header['technician_signature_path'] as String?;
        existingResponsibleSignaturePath =
            header['responsible_signature_path'] as String?;
      }
    } else {
      conclusion.text = defaultConclusion;
    }

    if (mounted) {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    technicianName.dispose();
    responsibleName.dispose();
    generalNotes.dispose();
    conclusion.dispose();
    technicianSignature.dispose();
    responsibleSignature.dispose();
    super.dispose();
  }

  Future<String?> _saveSignature(
    SignatureController controller,
  ) async {
    if (controller.isEmpty) return null;

    final bytes = await controller.toPngBytes(
      height: 320,
      width: 900,
    );

    if (bytes == null) return null;

    return StorageService.persistPngBytes(
      bytes,
      folder: 'assinaturas',
    );
  }

  bool _validExistingSignature(String? path) {
    return path != null &&
        path.isNotEmpty &&
        File(path).existsSync();
  }

  Future<void> _finish() async {
    final technician = technicianName.text.trim();
    final responsible = responsibleName.text.trim();

    if (technician.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Informe o nome do técnico.'),
        ),
      );
      return;
    }

    final hasExistingTechnician =
        _validExistingSignature(existingTechnicianSignaturePath);

    if (technicianSignature.isEmpty && !hasExistingTechnician) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Colete a assinatura do técnico.'),
        ),
      );
      return;
    }

    final hasExistingResponsible =
        _validExistingSignature(existingResponsibleSignaturePath);

    if (responsible.isNotEmpty &&
        responsibleSignature.isEmpty &&
        !hasExistingResponsible) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Assine como responsável da empresa ou deixe o nome em branco.',
          ),
        ),
      );
      return;
    }

    final newTechnicianPath =
        await _saveSignature(technicianSignature);

    final newResponsiblePath = responsible.isEmpty
        ? null
        : await _saveSignature(responsibleSignature);

    final technicianPath = newTechnicianPath ??
        (hasExistingTechnician
            ? existingTechnicianSignaturePath
            : null);

    final responsiblePath = responsible.isEmpty
        ? null
        : newResponsiblePath ??
            (hasExistingResponsible
                ? existingResponsibleSignaturePath
                : null);

    await AppDatabase.instance.updateInspectionFinalData(
      inspectionId: widget.inspectionId,
      technicianName: technician,
      responsibleName: responsible,
      technicianSignaturePath: technicianPath,
      responsibleSignaturePath: responsiblePath,
      generalNotes: generalNotes.text.trim(),
      conclusion: conclusion.text.trim(),
    );

    await AppDatabase.instance.setSetting(
      'default_technician',
      technician,
    );

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ReportScreen(
          inspectionId: widget.inspectionId,
          title: widget.companyName,
        ),
      ),
    );
  }

  Widget _existingSignaturePreview({
    required String title,
    required String? path,
  }) {
    if (!_validExistingSignature(path)) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Image.file(
            File(path!),
            height: 80,
            width: double.infinity,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 4),
          const Text(
            'Se não assinar novamente, esta assinatura será mantida.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _signatureCard({
    required String title,
    required String subtitle,
    required SignatureController controller,
    required bool required,
    String? existingPath,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              required ? '$title *' : title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 10),
            _existingSignaturePreview(
              title: 'Assinatura já registrada',
              path: existingPath,
            ),
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              clipBehavior: Clip.antiAlias,
              child: Signature(
                controller: controller,
                height: 180,
                backgroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: controller.clear,
              icon: const Icon(Icons.delete_outline),
              label: const Text('LIMPAR NOVA ASSINATURA'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Finalizar vistoria'),
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(12),
        child: FilledButton.icon(
          onPressed: _finish,
          icon: const Icon(Icons.check_circle),
          label: const Padding(
            padding: EdgeInsets.symmetric(vertical: 14),
            child: Text('FINALIZAR E GERAR RELATÓRIO'),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (widget.preserveExisting)
            const Card(
              child: ListTile(
                leading: Icon(Icons.history),
                title: Text(
                  'Revisando relatório existente',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  'As assinaturas anteriores serão mantidas se você não coletar novas.',
                ),
              ),
            ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'REVISÃO FINAL',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: technicianName,
                    decoration: const InputDecoration(
                      labelText: 'Técnico responsável *',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: responsibleName,
                    decoration: const InputDecoration(
                      labelText: 'Responsável da empresa (opcional)',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: generalNotes,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Observações gerais da vistoria',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: conclusion,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'Conclusão do relatório',
                    ),
                  ),
                ],
              ),
            ),
          ),
          _signatureCard(
            title: 'Assinatura do técnico',
            subtitle: widget.preserveExisting
                ? 'Assine novamente somente se desejar substituir a assinatura anterior.'
                : 'Assine com o dedo dentro da área.',
            controller: technicianSignature,
            required: true,
            existingPath: existingTechnicianSignaturePath,
          ),
          _signatureCard(
            title: 'Assinatura do responsável da empresa',
            subtitle:
                'Opcional. Use quando houver responsável acompanhando a vistoria.',
            controller: responsibleSignature,
            required: false,
            existingPath: existingResponsibleSignaturePath,
          ),
        ],
      ),
    );
  }
}
