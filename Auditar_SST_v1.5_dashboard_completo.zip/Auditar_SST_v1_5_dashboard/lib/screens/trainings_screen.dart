import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:printing/printing.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';
import '../services/training_pending_pdf_service.dart';
import '../services/ai_assistant_service.dart';
import 'training_requirements_screen.dart';

class TrainingsScreen extends StatefulWidget {
  final String? companyId;

  const TrainingsScreen({super.key, this.companyId});

  @override
  State<TrainingsScreen> createState() => _TrainingsScreenState();
}

class _TrainingsScreenState extends State<TrainingsScreen> {
  final searchController = TextEditingController();
  List<TrainingControl> trainings = [];
  List<Worker> workers = [];
  List<Company> companies = [];
  List<Sector> sectors = [];
  List<TrainingRequirement> requirements = [];
  List<Map<String, Object?>> missingRequiredRows = [];
  Map<String, Map<String, int>> companySummaries = {};
  Map<String, int> companyMissing = {};
  Map<String, int> companyNewWorkers = {};
  final GlobalKey historyKey = GlobalKey();
  bool loading = true;
  String query = '';
  String statusFilter = 'TODOS';
  int missingRequired = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final companyRows = await AppDatabase.instance.getCompanies();

    if (widget.companyId == null) {
      final summaries = <String, Map<String, int>>{};
      final missingByCompany = <String, int>{};
      final newByCompany = <String, int>{};
      for (final company in companyRows) {
        summaries[company.id] =
            await AppDatabase.instance.getTrainingSummary(companyId: company.id);
        final missing = await AppDatabase.instance.getMissingRequiredTrainings(
          companyId: company.id,
        );
        missingByCompany[company.id] = missing.length;
        final companyWorkers =
            await AppDatabase.instance.getWorkers(companyId: company.id);
        final companyTrainings =
            await AppDatabase.instance.getTrainingControls(companyId: company.id);
        final workerById = {for (final worker in companyWorkers) worker.id: worker};
        final newIds = <String>{};
        for (final row in missing) {
          final worker = row['worker'];
          if (worker is Worker && _isNewAdmission(worker)) newIds.add(worker.id);
        }
        for (final training in companyTrainings) {
          final worker = workerById[training.workerId];
          if (worker == null || !_isNewAdmission(worker)) continue;
          final status = training.statusAt(DateTime.now());
          final days = training.expiryDate?.difference(DateTime.now()).inDays;
          if (status == 'PENDENTE' ||
              status == 'VENCIDO' ||
              (status == 'EM DIA' && days != null && days >= 0 && days <= 30)) {
            newIds.add(worker.id);
          }
        }
        newByCompany[company.id] = newIds.length;
      }
      if (!mounted) return;
      setState(() {
        companies = companyRows;
        workers = [];
        trainings = [];
        sectors = [];
        requirements = [];
        missingRequiredRows = [];
        missingRequired = 0;
        companySummaries = summaries;
        companyMissing = missingByCompany;
        companyNewWorkers = newByCompany;
        loading = false;
      });
      return;
    }

    final companyId = widget.companyId!;
    final workerRows = await AppDatabase.instance.getWorkers(companyId: companyId);
    final trainingRows =
        await AppDatabase.instance.getTrainingControls(companyId: companyId);
    final missingRows =
        await AppDatabase.instance.getMissingRequiredTrainings(companyId: companyId);
    final requirementRows =
        await AppDatabase.instance.getTrainingRequirements(companyId: companyId);
    final sectorRows = await AppDatabase.instance.getSectors(companyId);
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      trainings = trainingRows;
      sectors = sectorRows;
      requirements = requirementRows;
      missingRequiredRows = missingRows;
      missingRequired = missingRows.length;
      loading = false;
    });
  }

  Future<void> _openRequirements() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrainingRequirementsScreen(companyId: widget.companyId),
      ),
    );
    await _load();
  }

  Worker? _worker(String id) {
    for (final worker in workers) {
      if (worker.id == id) return worker;
    }
    return null;
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sector(String? id) {
    if (id == null) return null;
    for (final sector in sectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  String _status(TrainingControl training) => training.statusAt(DateTime.now());

  bool _expiringSoon(TrainingControl training) {
    if (_status(training) != 'EM DIA' || training.expiryDate == null) return false;
    final days = training.expiryDate!.difference(DateTime.now()).inDays;
    return days >= 0 && days <= 30;
  }

  Company? get _currentCompany {
    final companyId = widget.companyId;
    if (companyId == null) return null;
    return _company(companyId);
  }

  bool _isNewAdmission(Worker worker) {
    final admission = worker.admissionDate;
    if (admission == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final date = DateTime(admission.year, admission.month, admission.day);
    final days = today.difference(date).inDays;
    return days >= 0 && days <= 30;
  }

  int _daysSinceAdmission(Worker worker) {
    final admission = worker.admissionDate;
    if (admission == null) return -1;
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day)
        .difference(DateTime(admission.year, admission.month, admission.day))
        .inDays;
  }

  bool _sameTraining(TrainingControl training, String code, String title) {
    final wantedCode = AppDatabase.normalizeTrainingKey(code);
    final wantedTitle = AppDatabase.normalizeTrainingKey(title);
    final recordCode = AppDatabase.normalizeTrainingKey(training.code);
    final recordTitle = AppDatabase.normalizeTrainingKey(training.title);
    if (wantedCode.isNotEmpty && recordCode == wantedCode) return true;
    return wantedTitle.isNotEmpty && recordTitle == wantedTitle;
  }

  TrainingControl? _latestTraining(String workerId, String code, String title) {
    TrainingControl? latest;
    for (final training in trainings.where(
      (item) => item.workerId == workerId && _sameTraining(item, code, title),
    )) {
      if (latest == null ||
          (training.trainingDate ?? DateTime(1900)).isAfter(
            latest.trainingDate ?? DateTime(1900),
          )) {
        latest = training;
      }
    }
    return latest;
  }

  bool _workerNeedsTraining(Worker worker, String code, String title) {
    final requirement = _matchingRequirement(worker.id, code, title);
    if (requirement == null) return false;
    final latest = _latestTraining(worker.id, code, title);
    if (latest == null) return true;
    final status = _status(latest);
    return status == 'PENDENTE' || status == 'VENCIDO' || _expiringSoon(latest);
  }

  List<Map<String, String>> get _pendingRows {
    final rows = <Map<String, String>>[];
    for (final item in missingRequiredRows) {
      final worker = item['worker'];
      final requirement = item['requirement'];
      if (worker is! Worker || requirement is! TrainingRequirement) continue;
      rows.add({
        'workerId': worker.id,
        'worker': worker.name,
        'role': worker.role,
        'sector': _sector(worker.sectorId)?.name ?? '',
        'training': requirement.code.isEmpty
            ? requirement.title
            : '${requirement.code} • ${requirement.title}',
        'status': 'SEM REGISTRO',
        'expiry': '',
      });
    }
    for (final training in trainings) {
      final status = _status(training);
      final soon = _expiringSoon(training);
      if (status == 'EM DIA' && !soon) continue;
      final worker = _worker(training.workerId);
      if (worker == null) continue;
      rows.add({
        'workerId': worker.id,
        'worker': worker.name,
        'role': worker.role,
        'sector': _sector(worker.sectorId)?.name ?? '',
        'training': training.code.isEmpty
            ? training.title
            : '${training.code} • ${training.title}',
        'status': soon ? 'VENCE EM BREVE' : status,
        'expiry': training.expiryDate == null
            ? ''
            : DateFormat('dd/MM/yyyy').format(training.expiryDate!),
      });
    }
    const order = {
      'VENCIDO': 0,
      'SEM REGISTRO': 1,
      'PENDENTE': 2,
      'VENCE EM BREVE': 3,
    };
    rows.sort((a, b) {
      final byStatus = (order[a['status']] ?? 9).compareTo(order[b['status']] ?? 9);
      if (byStatus != 0) return byStatus;
      return (a['worker'] ?? '').compareTo(b['worker'] ?? '');
    });
    return rows;
  }

  List<Worker> get _newWorkersNeedingTraining {
    final ids = _pendingRows.map((row) => row['workerId']).whereType<String>().toSet();
    final rows = workers.where((worker) => ids.contains(worker.id) && _isNewAdmission(worker)).toList();
    rows.sort((a, b) => (b.admissionDate ?? DateTime(1900)).compareTo(a.admissionDate ?? DateTime(1900)));
    return rows;
  }

  List<Map<String, String>> _needsForWorker(String workerId) =>
      _pendingRows.where((row) => row['workerId'] == workerId).toList();

  List<String> get _rolesWithoutRequirements {
    final configured = requirements
        .where((item) => item.active)
        .map((item) => AppDatabase.normalizeRoleKey(item.role))
        .where((role) => role.isNotEmpty)
        .toSet();
    final result = workers
        .map((worker) => worker.role.trim())
        .where((role) => role.isNotEmpty &&
            !configured.contains(AppDatabase.normalizeRoleKey(role)))
        .toSet()
        .toList()
      ..sort();
    return result;
  }

  Color _pendingColor(String status) {
    switch (status) {
      case 'VENCIDO':
        return const Color(0xFFD93025);
      case 'VENCE EM BREVE':
        return const Color(0xFF8A5A00);
      default:
        return const Color(0xFFF29D18);
    }
  }

  List<Map<String, Object?>> get _aiPendingData => _pendingRows.map((row) {
        final worker = _worker(row['workerId'] ?? '');
        final rawTraining = row['training'] ?? '';
        final separator = rawTraining.indexOf(' • ');
        final code = separator > 0 ? rawTraining.substring(0, separator) : '';
        final title = separator > 0 ? rawTraining.substring(separator + 3) : rawTraining;
        return <String, Object?>{
          'workerId': row['workerId'] ?? '',
          'workerName': row['worker'] ?? '',
          'role': row['role'] ?? '',
          'sector': row['sector'] ?? '',
          'admissionDays': worker == null ? -1 : _daysSinceAdmission(worker),
          'isNewAdmission': worker != null && _isNewAdmission(worker),
          'trainingCode': code,
          'trainingTitle': title,
          'status': row['status'] ?? '',
          'expiryDate': row['expiry'] ?? '',
        };
      }).toList();

  List<Map<String, Object?>> get _aiTrainingMatrix => requirements
      .where((item) => item.active)
      .map((item) => <String, Object?>{
            'role': item.role,
            'code': item.code,
            'title': item.title,
            'validityMonths': item.validityMonths,
          })
      .toList();

  Map<String, Object?> get _aiTrainingSummary => {
        'activeWorkers': workers.where((worker) => worker.active).length,
        'trainingRecords': trainings.length,
        'current': _count('EM DIA'),
        'pending': _count('PENDENTE'),
        'expired': _count('VENCIDO'),
        'expiringSoon': trainings.where(_expiringSoon).length,
        'missingRequired': missingRequiredRows.length,
        'newWorkersNeedingTraining': _newWorkersNeedingTraining.length,
        'rolesWithoutMatrix': _rolesWithoutRequirements.length,
      };

  Future<void> _openTrainingAi() async {
    final company = _currentCompany;
    if (company == null) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Assistente IA de treinamentos',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              Text(
                'Analisa somente ${company.name}. A matriz por cargo continua sendo a fonte que define quais treinamentos são obrigatórios.',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 14),
              _aiOptionTile(
                icon: Icons.priority_high_rounded,
                title: 'Priorizar pendências',
                subtitle: 'Mostra quem e o que precisa de atenção primeiro.',
                onTap: () {
                  Navigator.pop(sheetContext);
                  _runTrainingAi('prioritize');
                },
              ),
              _aiOptionTile(
                icon: Icons.groups_outlined,
                title: 'Sugerir turmas',
                subtitle: 'Agrupa colaboradores que precisam do mesmo treinamento.',
                onTap: () {
                  Navigator.pop(sheetContext);
                  _runTrainingAi('groups');
                },
              ),
              _aiOptionTile(
                icon: Icons.calendar_month_outlined,
                title: 'Planejar próximos treinamentos',
                subtitle: 'Sugere uma ordem prática para organizar as próximas ações.',
                onTap: () {
                  Navigator.pop(sheetContext);
                  _runTrainingAi('plan');
                },
              ),
              const SizedBox(height: 4),
              const Text(
                'A IA não cria obrigações legais e não altera registros automaticamente.',
                style: TextStyle(fontSize: 10.5, color: Colors.black54),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _aiOptionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(
            backgroundColor: AuditarBrand.navySoft,
            child: Icon(icon, color: AuditarBrand.navy),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
        ),
      );

  Future<void> _runTrainingAi(String objective) async {
    final company = _currentCompany;
    if (company == null) return;
    if (_pendingRows.isEmpty && objective != 'plan') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não há pendências para a IA analisar nesta empresa.')),
      );
      return;
    }

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 16),
            Expanded(child: Text('Analisando os treinamentos desta empresa...')),
          ],
        ),
      ),
    );

    final reply = await AiAssistantService.analyzeTrainingManagement(
      company: company,
      objective: objective,
      summary: _aiTrainingSummary,
      pendencies: _aiPendingData,
      trainingMatrix: _aiTrainingMatrix,
      rolesWithoutRequirements: _rolesWithoutRequirements,
    );
    if (mounted) Navigator.of(context, rootNavigator: true).pop();
    if (!mounted) return;
    if (!reply.success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(reply.message)),
      );
      return;
    }
    await _showTrainingAiResult(objective, reply.result);
  }

  Future<void> _showTrainingAiResult(
    String objective,
    Map<String, dynamic> result,
  ) async {
    final priorities = (result['priorities'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    final groups = (result['suggestedGroups'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    final plan = (result['plan'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    final gaps = (result['dataGaps'] as List? ?? const []).map((item) => '$item').toList();
    final title = objective == 'groups'
        ? 'Turmas sugeridas pela IA'
        : objective == 'plan'
            ? 'Planejamento sugerido pela IA'
            : 'Prioridades sugeridas pela IA';

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.88,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text(
                      '${result['summary'] ?? 'Análise concluída.'}',
                      style: const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(14),
                  children: [
                    if (priorities.isNotEmpty) ...[
                      const Text('Prioridades', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                      const SizedBox(height: 7),
                      ...priorities.map((item) {
                        final urgency = '${item['urgency'] ?? 'Média'}';
                        final color = urgency == 'Alta'
                            ? const Color(0xFFD93025)
                            : urgency == 'Baixa'
                                ? AuditarBrand.greenDark
                                : const Color(0xFFF29D18);
                        return Card(
                          margin: const EdgeInsets.only(bottom: 7),
                          child: ListTile(
                            leading: Icon(Icons.flag_outlined, color: color),
                            title: Text('${item['title'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                            subtitle: Text('${item['detail'] ?? ''}'),
                            trailing: _statusChip(urgency.toUpperCase(), color),
                          ),
                        );
                      }),
                      const SizedBox(height: 10),
                    ],
                    if (groups.isNotEmpty) ...[
                      const Text('Turmas sugeridas', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                      const SizedBox(height: 7),
                      ...groups.map((group) {
                        final rawIds = (group['participantIds'] as List? ?? const []).map((item) => '$item').toSet();
                        final code = '${group['trainingCode'] ?? ''}'.trim();
                        final trainingTitle = '${group['trainingTitle'] ?? ''}'.trim();
                        final validWorkers = workers.where((worker) =>
                            rawIds.contains(worker.id) &&
                            _workerNeedsTraining(worker, code, trainingTitle)).toList();
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  [code, trainingTitle].where((v) => v.isNotEmpty).join(' • '),
                                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
                                ),
                                const SizedBox(height: 4),
                                Text('${validWorkers.length} participante(s) • ${group['reason'] ?? ''}', style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
                                if (validWorkers.isNotEmpty) ...[
                                  const SizedBox(height: 5),
                                  Text(validWorkers.take(5).map((worker) => worker.name).join(', ') + (validWorkers.length > 5 ? '...' : ''), style: const TextStyle(fontSize: 11.5)),
                                ],
                                const SizedBox(height: 8),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: FilledButton.tonalIcon(
                                    onPressed: validWorkers.isEmpty || trainingTitle.isEmpty
                                        ? null
                                        : () {
                                            Navigator.pop(sheetContext);
                                            _addTrainingBatch(
                                              initialCode: code,
                                              initialTitle: trainingTitle,
                                              initialWorkerIds: validWorkers.map((worker) => worker.id).toSet(),
                                            );
                                          },
                                    icon: const Icon(Icons.group_add_outlined, size: 18),
                                    label: const Text('Preparar turma'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                      const SizedBox(height: 10),
                    ],
                    if (plan.isNotEmpty) ...[
                      const Text('Próximas ações', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                      const SizedBox(height: 7),
                      ...plan.map((item) => Card(
                            margin: const EdgeInsets.only(bottom: 7),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: AuditarBrand.navySoft,
                                child: Text('${item['order'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                              ),
                              title: Text('${item['action'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text([
                                '${item['training'] ?? ''}',
                                '${item['reason'] ?? ''}',
                              ].where((v) => v.isNotEmpty).join('\n')),
                            ),
                          )),
                    ],
                    if (gaps.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      const Text('Dados para conferir', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
                      const SizedBox(height: 6),
                      ...gaps.map((gap) => ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            leading: const Icon(Icons.info_outline, size: 20),
                            title: Text(gap),
                          )),
                    ],
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF5F7FA),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${result['warning'] ?? 'Sugestão de apoio. Confirme antes de registrar ou agendar treinamentos.'}',
                        style: const TextStyle(fontSize: 10.5, color: Colors.black54),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showNewWorkers() async {
    final rows = _newWorkersNeedingTraining;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.82,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Novos para treinar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          SizedBox(height: 3),
                          Text('Admitidos nos últimos 30 dias com treinamento pendente.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                        ],
                      ),
                    ),
                    FilledButton.icon(
                      onPressed: rows.isEmpty ? null : () {
                        Navigator.pop(sheetContext);
                        _addTrainingBatch();
                      },
                      icon: const Icon(Icons.groups_rounded, size: 18),
                      label: const Text('Criar turma'),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: rows.isEmpty
                    ? const Center(child: Text('Nenhum novo colaborador com treinamento pendente.'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: rows.length,
                        itemBuilder: (context, index) {
                          final worker = rows[index];
                          final needs = _needsForWorker(worker.id);
                          final days = _daysSinceAdmission(worker);
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ExpansionTile(
                              leading: CircleAvatar(
                                backgroundColor: const Color(0xFFFFF1DC),
                                child: Text('${needs.length}', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF8A5A00))),
                              ),
                              title: Text(worker.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text([
                                worker.role,
                                _sector(worker.sectorId)?.name ?? '',
                                if (days >= 0) 'admitido há $days dia(s)',
                              ].where((v) => v.isNotEmpty).join(' • ')),
                              children: needs.map((need) {
                                final status = need['status'] ?? '';
                                return ListTile(
                                  dense: true,
                                  leading: Icon(Icons.school_outlined, color: _pendingColor(status)),
                                  title: Text(need['training'] ?? '-'),
                                  trailing: _statusChip(status, _pendingColor(status)),
                                );
                              }).toList(),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showPendencies() async {
    final rows = _pendingRows;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.86,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Quem precisa treinar agora', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text('${rows.length} pendência(s) desta empresa.', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: rows.isEmpty ? null : () {
                              Navigator.pop(sheetContext);
                              _sharePendingReport();
                            },
                            icon: const Icon(Icons.picture_as_pdf_outlined),
                            label: const Text('Relatório PDF'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: rows.isEmpty ? null : () {
                              Navigator.pop(sheetContext);
                              _addTrainingBatch();
                            },
                            icon: const Icon(Icons.groups_rounded),
                            label: const Text('Criar turma'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: rows.isEmpty
                    ? const Center(child: Text('Nenhuma pendência de treinamento.'))
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: rows.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 7),
                        itemBuilder: (context, index) {
                          final row = rows[index];
                          final status = row['status'] ?? '';
                          return Card(
                            margin: EdgeInsets.zero,
                            child: ListTile(
                              leading: Icon(Icons.school_outlined, color: _pendingColor(status)),
                              title: Text(row['worker'] ?? '-', style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text([
                                row['training'] ?? '',
                                row['role'] ?? '',
                                row['sector'] ?? '',
                                if ((row['expiry'] ?? '').isNotEmpty) 'validade ${row['expiry']}',
                              ].where((v) => v.isNotEmpty).join(' • ')),
                              trailing: _statusChip(status, _pendingColor(status)),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _sharePendingReport() async {
    final company = _currentCompany;
    if (company == null) return;
    final rows = _pendingRows;
    final bytes = await TrainingPendingPdfService.generate(
      company: company,
      rows: rows,
    );
    final safe = company.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
    await Printing.sharePdf(
      bytes: bytes,
      filename: 'Treinamentos_Pendentes_$safe.pdf',
    );
  }

  Future<void> _scrollToHistory() async {
    final target = historyKey.currentContext;
    if (target == null) return;
    await Scrollable.ensureVisible(
      target,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOut,
    );
  }

  List<TrainingControl> get filteredTrainings {
    final clean = query.trim().toLowerCase();
    final rows = trainings.where((training) {
      final baseStatus = _status(training);
      final displayStatus = _expiringSoon(training) ? 'VENCE EM BREVE' : baseStatus;
      if (statusFilter != 'TODOS' && displayStatus != statusFilter) return false;
      final worker = _worker(training.workerId);
      final sector = worker == null ? '' : (_sector(worker.sectorId)?.name ?? '');
      if (clean.isEmpty) return true;
      return '${training.code} ${training.title} ${worker?.name ?? ''} ${worker?.role ?? ''} $sector'
          .toLowerCase()
          .contains(clean);
    }).toList();
    rows.sort((a, b) =>
        (b.trainingDate ?? DateTime(1900)).compareTo(a.trainingDate ?? DateTime(1900)));
    return rows;
  }

  int _count(String status) => trainings.where((t) => _status(t) == status).length;

  TrainingRequirement? _matchingRequirement(
    String workerId,
    String code,
    String title,
  ) {
    final worker = _worker(workerId);
    if (worker == null) return null;
    final role = AppDatabase.normalizeRoleKey(worker.role);
    final codeKey = AppDatabase.normalizeTrainingKey(code);
    final titleKey = AppDatabase.normalizeTrainingKey(title);
    for (final requirement in requirements) {
      if (requirement.companyId != worker.companyId ||
          AppDatabase.normalizeRoleKey(requirement.role) != role) {
        continue;
      }
      final requirementCode =
          AppDatabase.normalizeTrainingKey(requirement.code);
      final requirementTitle =
          AppDatabase.normalizeTrainingKey(requirement.title);
      if ((requirementCode.isNotEmpty && requirementCode == codeKey) ||
          (requirementCode.isEmpty && requirementTitle == titleKey)) {
        return requirement;
      }
    }
    return null;
  }

  DateTime _addMonths(DateTime date, int months) {
    final target = DateTime(date.year, date.month + months, 1);
    final lastDay = DateTime(target.year, target.month + 1, 0).day;
    return DateTime(
      target.year,
      target.month,
      date.day.clamp(1, lastDay).toInt(),
    );
  }

  Future<void> _addTrainingBatch({
    String initialCode = '',
    String initialTitle = '',
    Set<String>? initialWorkerIds,
  }) async {
    final companyId = widget.companyId;
    if (companyId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Abra os treinamentos dentro de uma empresa para usar o lançamento em lote.'),
        ),
      );
      return;
    }
    final companyWorkers = workers
        .where((worker) => worker.companyId == companyId)
        .toList();
    if (companyWorkers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre ou importe os trabalhadores primeiro.')),
      );
      return;
    }

    final codeController = TextEditingController(text: initialCode);
    final titleController = TextEditingController(text: initialTitle);
    final notesController = TextEditingController();
    final selectedWorkers = <String>{...?initialWorkerIds};
    DateTime trainingDate = DateTime.now();
    DateTime? commonExpiry;
    String roleFilter = 'TODOS';
    String? selectedTemplateKey;

    final roles = companyWorkers
        .map((worker) => worker.role.trim())
        .where((role) => role.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    final templateByKey = <String, TrainingRequirement>{};
    for (final requirement in requirements.where(
      (item) => item.companyId == companyId && item.active,
    )) {
      final key = AppDatabase.normalizeTrainingKey(
        requirement.code.isNotEmpty ? requirement.code : requirement.title,
      );
      if (key.isNotEmpty) templateByKey.putIfAbsent(key, () => requirement);
    }
    final templateKeys = templateByKey.keys.toList()
      ..sort((a, b) {
        final first = templateByKey[a]!;
        final second = templateByKey[b]!;
        return '${first.code} ${first.title}'
            .compareTo('${second.code} ${second.title}');
      });
    final initialKey = AppDatabase.normalizeTrainingKey(
      initialCode.trim().isNotEmpty ? initialCode : initialTitle,
    );
    if (initialKey.isNotEmpty && templateByKey.containsKey(initialKey)) {
      selectedTemplateKey = initialKey;
    }
    selectedWorkers.removeWhere((id) => !companyWorkers.any((worker) => worker.id == id));

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocalState) {
          final visibleWorkers = companyWorkers.where((worker) {
            return roleFilter == 'TODOS' || worker.role == roleFilter;
          }).toList();
          final allVisibleSelected = visibleWorkers.isNotEmpty &&
              visibleWorkers.every((worker) => selectedWorkers.contains(worker.id));
          return AlertDialog(
            title: const Text('Registrar treinamento em lote'),
            content: SizedBox(
              width: 620,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (templateKeys.isNotEmpty) ...[
                      DropdownButtonFormField<String>(
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Escolher da matriz',
                          prefixIcon: Icon(Icons.rule_folder_outlined),
                        ),
                        hint: const Text('Selecione ou preencha manualmente'),
                        items: templateKeys.map((key) {
                          final requirement = templateByKey[key]!;
                          return DropdownMenuItem(
                            value: key,
                            child: Text(
                              requirement.code.isEmpty
                                  ? requirement.title
                                  : '${requirement.code} • ${requirement.title}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (key) {
                          final requirement = templateByKey[key];
                          if (requirement == null) return;
                          final automaticallySelected = companyWorkers
                              .where((worker) => _workerNeedsTraining(
                                    worker,
                                    requirement.code,
                                    requirement.title,
                                  ))
                              .map((worker) => worker.id)
                              .toSet();
                          setLocalState(() {
                            selectedTemplateKey = key;
                            codeController.text = requirement.code;
                            titleController.text = requirement.title;
                            selectedWorkers
                              ..clear()
                              ..addAll(automaticallySelected);
                            roleFilter = 'TODOS';
                          });
                        },
                      ),
                      if (selectedTemplateKey != null) ...[
                        const SizedBox(height: 6),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            '${selectedWorkers.length} trabalhador(es) que precisam deste treinamento foram marcados automaticamente.',
                            style: const TextStyle(fontSize: 11.5, color: Colors.black54),
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                    ],
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final codeField = TextField(
                          controller: codeController,
                          decoration: const InputDecoration(
                            labelText: 'NR / Código',
                            hintText: 'Ex.: NR-06',
                          ),
                        );
                        final titleField = TextField(
                          controller: titleController,
                          decoration: const InputDecoration(
                            labelText: 'Treinamento *',
                          ),
                        );
                        if (constraints.maxWidth < 430) {
                          return Column(
                            children: [codeField, const SizedBox(height: 10), titleField],
                          );
                        }
                        return Row(
                          children: [
                            Expanded(flex: 2, child: codeField),
                            const SizedBox(width: 8),
                            Expanded(flex: 3, child: titleField),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    _dateTile(
                      title: 'Data do treinamento',
                      date: trainingDate,
                      emptyText: '',
                      onPick: () async {
                        final picked = await showDatePicker(
                          context: dialogContext,
                          initialDate: trainingDate,
                          firstDate: DateTime(2000),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (picked != null) {
                          setLocalState(() => trainingDate = picked);
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    _dateTile(
                      title: 'Vencimento comum (opcional)',
                      date: commonExpiry,
                      emptyText: 'Usar a validade da matriz de cada cargo',
                      onPick: () async {
                        final picked = await showDatePicker(
                          context: dialogContext,
                          initialDate: commonExpiry ??
                              DateTime(
                                trainingDate.year + 1,
                                trainingDate.month,
                                trainingDate.day,
                              ),
                          firstDate: trainingDate,
                          lastDate: DateTime.now().add(const Duration(days: 3650)),
                        );
                        if (picked != null) {
                          setLocalState(() => commonExpiry = picked);
                        }
                      },
                      onClear: commonExpiry == null
                          ? null
                          : () => setLocalState(() => commonExpiry = null),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: notesController,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Observações da turma',
                      ),
                    ),
                    const Divider(height: 24),
                    DropdownButtonFormField<String>(
                      isExpanded: true,
                      value: roleFilter,
                      decoration: const InputDecoration(
                        labelText: 'Filtrar participantes por cargo',
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: 'TODOS',
                          child: Text('Todos os cargos'),
                        ),
                        ...roles.map(
                          (role) => DropdownMenuItem(
                            value: role,
                            child: Text(role, overflow: TextOverflow.ellipsis),
                          ),
                        ),
                      ],
                      onChanged: (value) => setLocalState(
                        () => roleFilter = value ?? 'TODOS',
                      ),
                    ),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      value: allVisibleSelected,
                      title: Text(
                        'Selecionar todos os exibidos (${visibleWorkers.length})',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text('${selectedWorkers.length} participante(s) selecionado(s)'),
                      onChanged: (checked) => setLocalState(() {
                        if (checked == true) {
                          selectedWorkers.addAll(visibleWorkers.map((worker) => worker.id));
                        } else {
                          selectedWorkers.removeAll(visibleWorkers.map((worker) => worker.id));
                        }
                      }),
                    ),
                    Container(
                      height: 260,
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFD7DCE5)),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: ListView.builder(
                        itemCount: visibleWorkers.length,
                        itemBuilder: (context, index) {
                          final worker = visibleWorkers[index];
                          return CheckboxListTile(
                            dense: true,
                            value: selectedWorkers.contains(worker.id),
                            title: Text(worker.name),
                            subtitle: Text(worker.role),
                            onChanged: (checked) => setLocalState(() {
                              if (checked == true) {
                                selectedWorkers.add(worker.id);
                              } else {
                                selectedWorkers.remove(worker.id);
                              }
                            }),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Cancelar'),
              ),
              FilledButton.icon(
                onPressed: () {
                  if (titleController.text.trim().isEmpty ||
                      selectedWorkers.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Informe o treinamento e selecione os participantes.'),
                      ),
                    );
                    return;
                  }
                  if (commonExpiry != null &&
                      commonExpiry!.isBefore(trainingDate)) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('O vencimento não pode ser anterior ao treinamento.'),
                      ),
                    );
                    return;
                  }
                  Navigator.pop(dialogContext, true);
                },
                icon: const Icon(Icons.groups_rounded),
                label: Text('Registrar ${selectedWorkers.length}'),
              ),
            ],
          );
        },
      ),
    );

    if (saved == true) {
      final code = codeController.text.trim().toUpperCase();
      final title = titleController.text.trim();
      final records = <TrainingControl>[];
      for (final workerId in selectedWorkers) {
        TrainingControl? existing;
        for (final current in trainings.where((item) => item.workerId == workerId)) {
          final sameCode = code.isNotEmpty &&
              AppDatabase.normalizeTrainingKey(current.code) ==
                  AppDatabase.normalizeTrainingKey(code);
          final sameTitle = AppDatabase.normalizeTrainingKey(current.title) ==
              AppDatabase.normalizeTrainingKey(title);
          if (!sameCode && !sameTitle) continue;
          if (existing == null ||
              (current.trainingDate ?? DateTime(1900)).isAfter(
                existing.trainingDate ?? DateTime(1900),
              )) {
            existing = current;
          }
        }
        final requirement = _matchingRequirement(workerId, code, title);
        final expiry = commonExpiry ??
            (requirement != null && requirement.validityMonths > 0
                ? _addMonths(trainingDate, requirement.validityMonths)
                : null);
        records.add(
          TrainingControl(
            id: existing?.id ?? const Uuid().v4(),
            workerId: workerId,
            code: code,
            title: title,
            trainingDate: trainingDate,
            expiryDate: expiry,
            certificatePath: existing?.certificatePath ?? '',
            notes: notesController.text.trim(),
          ),
        );
      }
      await AppDatabase.instance.upsertTrainingControlsBatch(records);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Treinamento registrado para ${records.length} participante(s).'),
          ),
        );
      }
      await _load();
    }
    codeController.dispose();
    titleController.dispose();
    notesController.dispose();
  }

  Future<void> _editTraining([TrainingControl? training]) async {
    if (workers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre um trabalhador antes de adicionar treinamentos.')),
      );
      return;
    }

    String selectedWorkerId = training?.workerId ?? workers.first.id;
    final codeController = TextEditingController(text: training?.code ?? '');
    final titleController = TextEditingController(text: training?.title ?? '');
    final notesController = TextEditingController(text: training?.notes ?? '');
    DateTime? trainingDate = training?.trainingDate;
    DateTime? expiryDate = training?.expiryDate;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            final selectedWorker = _worker(selectedWorkerId);
            final workerRequirements = requirements.where((requirement) =>
                selectedWorker != null &&
                requirement.companyId == selectedWorker.companyId &&
                AppDatabase.normalizeRoleKey(requirement.role) ==
                    AppDatabase.normalizeRoleKey(selectedWorker.role)).toList();
            return AlertDialog(
              title: Text(training == null ? 'Adicionar treinamento' : 'Editar treinamento'),
              content: SizedBox(
                width: 540,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButtonFormField<String>(
                        isExpanded: true,
                        value: selectedWorkerId,
                        decoration: const InputDecoration(
                          labelText: 'Trabalhador *',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                        items: workers
                            .map(
                              (worker) => DropdownMenuItem(
                                value: worker.id,
                                child: Text(worker.name, overflow: TextOverflow.ellipsis),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          if (value != null) setLocalState(() => selectedWorkerId = value);
                        },
                      ),
                      const SizedBox(height: 10),
                      if (workerRequirements.isNotEmpty) ...[
                        DropdownButtonFormField<String>(
                          isExpanded: true,
                          decoration: const InputDecoration(
                            labelText: 'Escolher da matriz do cargo',
                            prefixIcon: Icon(Icons.rule_folder_outlined),
                          ),
                          hint: const Text('Selecione um treinamento obrigatório'),
                          items: workerRequirements
                              .map((requirement) => DropdownMenuItem(
                                    value: requirement.id,
                                    child: Text(
                                      requirement.code.isEmpty
                                          ? requirement.title
                                          : '${requirement.code} • ${requirement.title}',
                                    ),
                                  ))
                              .toList(),
                          onChanged: (id) {
                            final matches = workerRequirements
                                .where((item) => item.id == id);
                            if (matches.isEmpty) return;
                            final requirement = matches.first;
                            setLocalState(() {
                              codeController.text = requirement.code;
                              titleController.text = requirement.title;
                              if (trainingDate != null &&
                                  requirement.validityMonths > 0) {
                                expiryDate = _addMonths(
                                  trainingDate!,
                                  requirement.validityMonths,
                                );
                              }
                            });
                          },
                        ),
                        const SizedBox(height: 10),
                      ],
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final codeField = TextField(
                            controller: codeController,
                            decoration: const InputDecoration(
                              labelText: 'NR / Código',
                              hintText: 'Ex.: NR-06',
                            ),
                          );
                          final titleField = TextField(
                            controller: titleController,
                            decoration: const InputDecoration(
                              labelText: 'Treinamento *',
                              hintText: 'Ex.: Uso de EPI',
                            ),
                          );
                          if (constraints.maxWidth < 430) {
                            return Column(
                              children: [codeField, const SizedBox(height: 10), titleField],
                            );
                          }
                          return Row(
                            children: [
                              Expanded(flex: 2, child: codeField),
                              const SizedBox(width: 8),
                              Expanded(flex: 3, child: titleField),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                      _dateTile(
                        title: 'Data do treinamento',
                        date: trainingDate,
                        emptyText: 'Pendente / ainda não realizado',
                        onPick: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: trainingDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) {
                            setLocalState(() {
                              trainingDate = picked;
                              final requirement = _matchingRequirement(
                                selectedWorkerId,
                                codeController.text,
                                titleController.text,
                              );
                              if (expiryDate == null &&
                                  requirement != null &&
                                  requirement.validityMonths > 0) {
                                expiryDate = _addMonths(
                                  picked,
                                  requirement.validityMonths,
                                );
                              }
                            });
                          }
                        },
                        onClear: trainingDate == null ? null : () => setLocalState(() => trainingDate = null),
                      ),
                      const SizedBox(height: 8),
                      _dateTile(
                        title: 'Vencimento / validade',
                        date: expiryDate,
                        emptyText: 'Sem vencimento informado',
                        onPick: () async {
                          final base = trainingDate ?? DateTime.now();
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: expiryDate ?? DateTime(base.year + 1, base.month, base.day),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) setLocalState(() => expiryDate = picked);
                        },
                        onClear: expiryDate == null ? null : () => setLocalState(() => expiryDate = null),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: notesController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Observações',
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF4F6FA),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          'Dica: para registrar um treinamento obrigatório ainda não realizado, deixe a data do treinamento em branco. Ele aparecerá como PENDENTE.',
                          style: TextStyle(fontSize: 11.5, color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () async {
                    final title = titleController.text.trim();
                    if (title.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Informe o nome do treinamento.')),
                      );
                      return;
                    }
                    if (trainingDate != null &&
                        expiryDate != null &&
                        expiryDate!.isBefore(trainingDate!)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('O vencimento não pode ser anterior ao treinamento.')),
                      );
                      return;
                    }
                    DateTime? effectiveExpiry = expiryDate;
                    final requirement = _matchingRequirement(
                      selectedWorkerId,
                      codeController.text,
                      title,
                    );
                    if (effectiveExpiry == null &&
                        trainingDate != null &&
                        requirement != null &&
                        requirement.validityMonths > 0) {
                      effectiveExpiry = _addMonths(
                        trainingDate!,
                        requirement.validityMonths,
                      );
                    }
                    final record = TrainingControl(
                      id: training?.id ?? const Uuid().v4(),
                      workerId: selectedWorkerId,
                      code: codeController.text.trim(),
                      title: title,
                      trainingDate: trainingDate,
                      expiryDate: effectiveExpiry,
                      certificatePath: training?.certificatePath ?? '',
                      notes: notesController.text.trim(),
                    );
                    if (training == null) {
                      await AppDatabase.instance.insertTrainingControl(record);
                    } else {
                      await AppDatabase.instance.updateTrainingControl(record);
                    }
                    if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    codeController.dispose();
    titleController.dispose();
    notesController.dispose();
    if (saved == true) await _load();
  }

  Widget _dateTile({
    required String title,
    required DateTime? date,
    required String emptyText,
    required VoidCallback onPick,
    VoidCallback? onClear,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onPick,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: const Color(0xFFD7DCE5)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_month_outlined, color: AuditarBrand.navy),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text(
                    date == null ? emptyText : DateFormat('dd/MM/yyyy').format(date),
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            if (onClear != null)
              IconButton(
                tooltip: 'Limpar',
                onPressed: onClear,
                icon: const Icon(Icons.close, size: 19),
              )
            else
              const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteTraining(TrainingControl training) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir treinamento?'),
        content: Text('Deseja excluir ${training.code.isEmpty ? training.title : '${training.code} - ${training.title}'}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteTrainingControl(training.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Treinamentos')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (widget.companyId == null) return _buildCompanyPicker();

    final company = _currentCompany;
    final current = _count('EM DIA');
    final pending = _count('PENDENTE');
    final expired = _count('VENCIDO');
    final expiringSoon = trainings.where(_expiringSoon).length;
    final newWorkers = _newWorkersNeedingTraining.length;
    final totalPendencies = _pendingRows.length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Treinamentos'),
        actions: [
          IconButton(
            tooltip: 'Matriz por cargo',
            onPressed: _openRequirements,
            icon: const Icon(Icons.rule_folder_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
          children: [
            Card(
              color: AuditarBrand.navySoft,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    const Icon(Icons.business_outlined, color: AuditarBrand.navy, size: 28),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            company?.name ?? 'Empresa',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navyDark),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            [
                              if ((company?.cnpj ?? '').trim().isNotEmpty) 'CNPJ ${company!.cnpj}',
                              'controle individual desta empresa',
                            ].join(' • '),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11.5, color: Colors.black54),
                          ),
                        ],
                      ),
                    ),
                    _statusChip(
                      company?.trainingAlertsEnabled == true ? 'AVISOS ATIVOS' : 'AVISOS INATIVOS',
                      company?.trainingAlertsEnabled == true ? AuditarBrand.greenDark : const Color(0xFF7B8495),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            ResponsiveWrap(
              minItemWidth: 138,
              maxColumns: 4,
              children: [
                _metric('Em dia', current, AuditarBrand.greenDark, Icons.check_circle_outline),
                _metric('Pendências', missingRequired + pending, const Color(0xFFF29D18), Icons.pending_actions_outlined),
                _metric('Vencidos', expired, const Color(0xFFD93025), Icons.event_busy_outlined),
                _metric('Vence em 30 dias', expiringSoon, const Color(0xFF8A5A00), Icons.schedule_outlined),
              ],
            ),
            const SizedBox(height: 10),
            Card(
              color: const Color(0xFFF3F5FF),
              child: ListTile(
                onTap: _openTrainingAi,
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFE2E7FF),
                  child: Icon(Icons.auto_awesome_outlined, color: AuditarBrand.navy),
                ),
                title: const Text(
                  'Assistente IA de treinamentos',
                  style: TextStyle(fontWeight: FontWeight.w900, color: AuditarBrand.navyDark),
                ),
                subtitle: const Text(
                  'Prioriza pendências, sugere turmas e ajuda a planejar os próximos treinamentos.',
                ),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
            if (_rolesWithoutRequirements.isNotEmpty) ...[
              const SizedBox(height: 10),
              Card(
                color: const Color(0xFFFFF8E8),
                child: ListTile(
                  onTap: _openRequirements,
                  leading: const Icon(Icons.rule_folder_outlined, color: Color(0xFF8A5A00)),
                  title: Text(
                    _rolesWithoutRequirements.length == 1
                        ? '1 cargo ainda está sem matriz de treinamento'
                        : '${_rolesWithoutRequirements.length} cargos ainda estão sem matriz de treinamento',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    '${_rolesWithoutRequirements.take(3).join(', ')}${_rolesWithoutRequirements.length > 3 ? '...' : ''}. Configure para o app identificar automaticamente os treinamentos necessários.',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                ),
              ),
            ],
            if (newWorkers > 0) ...[
              const SizedBox(height: 8),
              Material(
                color: const Color(0xFFFFF8EE),
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: _showNewWorkers,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                    child: Row(
                      children: [
                        const Icon(Icons.person_add_alt_1_outlined, color: Color(0xFF8A5A00), size: 20),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            newWorkers == 1
                                ? '1 novo colaborador com treinamento pendente'
                                : '$newWorkers novos colaboradores com treinamento pendente',
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: Color(0xFF6D4900)),
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: Color(0xFF8A5A00), size: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 14),
            const Text(
              'Controle de treinamentos',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            const SizedBox(height: 8),
            ResponsiveWrap(
              minItemWidth: 145,
              maxColumns: 2,
              children: [
                _trainingActionCard(
                  icon: Icons.person_add_alt_1_outlined,
                  title: 'Novos para treinar',
                  subtitle: '$newWorkers colaborador(es)',
                  color: const Color(0xFF8A5A00),
                  onTap: _showNewWorkers,
                ),
                _trainingActionCard(
                  icon: Icons.notification_important_outlined,
                  title: 'Pendências',
                  subtitle: '$totalPendencies item(ns)',
                  color: totalPendencies > 0 ? const Color(0xFFD93025) : AuditarBrand.greenDark,
                  onTap: _showPendencies,
                ),
                _trainingActionCard(
                  icon: Icons.groups_rounded,
                  title: 'Criar turma',
                  subtitle: 'Selecionar quem precisa',
                  color: AuditarBrand.navy,
                  onTap: _addTrainingBatch,
                ),
                _trainingActionCard(
                  icon: Icons.history_rounded,
                  title: 'Histórico',
                  subtitle: '${trainings.length} registro(s)',
                  color: AuditarBrand.navy,
                  onTap: _scrollToHistory,
                ),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => _editTraining(),
                icon: const Icon(Icons.school_outlined),
                label: const Text('Novo registro de treinamento'),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                onTap: _openRequirements,
                leading: const Icon(Icons.rule_folder_outlined, color: AuditarBrand.navy),
                title: const Text('Treinamentos obrigatórios por cargo', style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: const Text('A matriz é exclusiva desta empresa e define automaticamente o que cada cargo precisa.'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              key: historyKey,
              child: const Text(
                'Histórico de treinamentos',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: searchController,
              onChanged: (value) => setState(() => query = value),
              decoration: InputDecoration(
                hintText: 'Buscar colaborador ou treinamento',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          searchController.clear();
                          setState(() => query = '');
                        },
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: ['TODOS', 'EM DIA', 'VENCE EM BREVE', 'PENDENTE', 'VENCIDO']
                  .map((status) {
                    final selected = statusFilter == status;
                    return ChoiceChip(
                      label: Text(status == 'TODOS' ? 'Todos' : status),
                      selected: selected,
                      labelStyle: TextStyle(
                        fontSize: 11,
                        fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                        color: selected ? Colors.white : AuditarBrand.navyDark,
                      ),
                      selectedColor: AuditarBrand.greenDark,
                      backgroundColor: Colors.white,
                      side: const BorderSide(color: Color(0xFFD7DCE5)),
                      onSelected: (_) => setState(() => statusFilter = status),
                    );
                  })
                  .toList(),
            ),
            const SizedBox(height: 10),
            if (filteredTrainings.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(22),
                  child: Text('Nenhum treinamento encontrado.'),
                ),
              )
            else
              ...filteredTrainings.map((training) {
                final worker = _worker(training.workerId);
                final status = _status(training);
                final displayStatus = _expiringSoon(training) ? 'VENCE EM BREVE' : status;
                final color = displayStatus == 'EM DIA'
                    ? AuditarBrand.greenDark
                    : displayStatus == 'VENCIDO'
                        ? const Color(0xFFD93025)
                        : const Color(0xFFF29D18);
                final sector = worker == null ? null : _sector(worker.sectorId)?.name;
                return Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => _editTraining(training),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  training.code.isEmpty ? training.title : '${training.code} • ${training.title}',
                                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                                ),
                              ),
                              _statusChip(displayStatus, color),
                              PopupMenuButton<String>(
                                onSelected: (value) {
                                  if (value == 'edit') _editTraining(training);
                                  if (value == 'delete') _deleteTraining(training);
                                },
                                itemBuilder: (context) => const [
                                  PopupMenuItem(value: 'edit', child: Text('Editar')),
                                  PopupMenuItem(value: 'delete', child: Text('Excluir')),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(worker?.name ?? 'Colaborador não encontrado', style: const TextStyle(fontWeight: FontWeight.w600)),
                          if ((worker?.role ?? '').isNotEmpty)
                            Text(
                              [worker!.role, if ((sector ?? '').isNotEmpty) sector!].join(' • '),
                              style: const TextStyle(fontSize: 12, color: Colors.black54),
                            ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 12,
                            runSpacing: 5,
                            children: [
                              _dateInfo('Treinamento', training.trainingDate),
                              _dateInfo('Validade', training.expiryDate),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildCompanyPicker() {
    final activeCompanies = companies.where((company) => company.active).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Treinamentos')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              color: AuditarBrand.navySoft,
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.business_outlined, color: AuditarBrand.navy, size: 27),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Controle individual por empresa', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AuditarBrand.navyDark)),
                          SizedBox(height: 4),
                          Text('Escolha a empresa. Matriz, colaboradores, pendências e histórico ficam separados.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (activeCompanies.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(22), child: Text('Cadastre uma empresa antes de controlar treinamentos.')))
            else
              ...activeCompanies.map((company) {
                final summary = companySummaries[company.id] ?? const <String, int>{};
                final missing = companyMissing[company.id] ?? 0;
                final newWorkers = companyNewWorkers[company.id] ?? 0;
                final attention = missing + (summary['pending'] ?? 0) + (summary['expired'] ?? 0) + (summary['expiringSoon'] ?? 0);
                return Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  child: ListTile(
                    onTap: () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => TrainingsScreen(companyId: company.id)),
                      );
                      await _load();
                    },
                    leading: CircleAvatar(
                      backgroundColor: attention > 0 ? const Color(0xFFFFF1DC) : const Color(0xFFE8F5EA),
                      child: Icon(
                        attention > 0 ? Icons.school_outlined : Icons.check_circle_outline,
                        color: attention > 0 ? const Color(0xFF8A5A00) : AuditarBrand.greenDark,
                      ),
                    ),
                    title: Text(company.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text([
                      if ((company.cnpj ?? '').trim().isNotEmpty) 'CNPJ ${company.cnpj}',
                      attention == 0 ? 'Treinamentos sem alerta' : '$attention item(ns) para atenção',
                      if (newWorkers > 0) '$newWorkers novo(s) para treinar',
                    ].join(' • ')),
                    trailing: const Icon(Icons.chevron_right),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _trainingActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 108),
      child: Card(
        margin: EdgeInsets.zero,
        child: InkWell(
          onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 7),
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(fontSize: 10.5, color: Colors.black54), maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ),
          ),
        ),
      ),
    );
  }

  Widget _metric(String label, int value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 21),
            const SizedBox(height: 3),
            Text('$value', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: color)),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 10.5, height: 1.15, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.11),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: color),
      ),
    );
  }

  Widget _dateInfo(String label, DateTime? date) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.calendar_today_outlined, size: 13, color: Colors.black45),
        const SizedBox(width: 4),
        Text(
          '$label: ${date == null ? '-' : DateFormat('dd/MM/yyyy').format(date)}',
          style: const TextStyle(fontSize: 11.5, color: Colors.black54),
        ),
      ],
    );
  }
}
