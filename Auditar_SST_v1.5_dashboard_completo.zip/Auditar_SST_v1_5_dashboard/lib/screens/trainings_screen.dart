import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/medical_import_service.dart';
import 'compliance_alerts_screen.dart';
import 'training_requirements_screen.dart';

class TrainingsScreen extends StatefulWidget {
  final String? companyId;

  const TrainingsScreen({super.key, this.companyId});

  @override
  State<TrainingsScreen> createState() => _TrainingsScreenState();
}

class _TrainingsScreenState extends State<TrainingsScreen> {
  final searchController = TextEditingController();
  List<TrainingControl> trainings = [];
  List<Worker> workers = [];
  List<Company> companies = [];
  List<Sector> sectors = [];
  List<TrainingRequirement> requirements = [];
  bool loading = true;
  String query = '';
  String statusFilter = 'TODOS';
  int missingRequired = 0;
  int medicalDue = 0;
  bool importingMedical = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final companyRows = await AppDatabase.instance.getCompanies();
    final workerRows = await AppDatabase.instance.getWorkers(
      companyId: widget.companyId,
    );
    final trainingRows = await AppDatabase.instance.getTrainingControls(
      companyId: widget.companyId,
    );
    final missingRows = await AppDatabase.instance.getMissingRequiredTrainings(
      companyId: widget.companyId,
    );
    final requirementRows = await AppDatabase.instance.getTrainingRequirements(
      companyId: widget.companyId,
    );
    final sectorRows = <Sector>[];
    for (final company in companyRows) {
      sectorRows.addAll(await AppDatabase.instance.getSectors(company.id));
    }
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      trainings = trainingRows;
      sectors = sectorRows;
      requirements = requirementRows;
      missingRequired = missingRows.length;
      final today = DateTime.now();
      medicalDue = workerRows.where((worker) {
        final date = worker.nextMedicalExamDate;
        if (date == null) return true;
        return DateTime(date.year, date.month, date.day)
                .difference(DateTime(today.year, today.month, today.day))
                .inDays <=
            30;
      }).length;
      loading = false;
    });
  }

  Future<void> _openAlerts() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ComplianceAlertsScreen(companyId: widget.companyId),
      ),
    );
    await _load();
  }

  Future<void> _openRequirements() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrainingRequirementsScreen(companyId: widget.companyId),
      ),
    );
    await _load();
  }

  Future<void> _importMedicalPdf() async {
    final companyId = widget.companyId;
    if (companyId == null || importingMedical) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Atualizar periódicos por PDF'),
        content: const Text(
          'O PDF será lido pela IA gratuita do Gemini. Use somente um arquivo autorizado com nome e datas dos exames. Evite diagnósticos, resultados clínicos, CPF ou outras informações médicas.\n\nVocê poderá conferir tudo antes de atualizar.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('Escolher PDF'),
          ),
        ],
      ),
    );
    if (accepted != true || !mounted) return;
    setState(() => importingMedical = true);
    try {
      final preview = await MedicalImportService.pickAndPrepare(
        companyId: companyId,
      );
      if (preview == null || !mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Conferir periódicos'),
          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    preview.fileName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text('${preview.candidates.length} trabalhador(es) serão atualizados.'),
                  if (preview.unmatchedNames.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${preview.unmatchedNames.length} nome(s) não foram encontrados no cadastro: ${preview.unmatchedNames.take(8).join(', ')}${preview.unmatchedNames.length > 8 ? '...' : ''}',
                      style: const TextStyle(color: Color(0xFFF29D18)),
                    ),
                  ],
                  if (preview.ambiguousRows > 0 || preview.invalidRows > 0) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${preview.ambiguousRows} nome(s) ambíguos e ${preview.invalidRows} linha(s) sem data válida foram ignorados.',
                      style: const TextStyle(color: Color(0xFFD93025)),
                    ),
                  ],
                  const Divider(height: 22),
                  ...preview.candidates.take(20).map((entry) {
                    final last = entry.importedLastExam == null
                        ? '-'
                        : DateFormat('dd/MM/yyyy').format(entry.importedLastExam!);
                    final next = entry.importedNextExam == null
                        ? '-'
                        : DateFormat('dd/MM/yyyy').format(entry.importedNextExam!);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        '• ${entry.worker.name} — último: $last • próximo: $next',
                      ),
                    );
                  }),
                  if (preview.candidates.length > 20)
                    Text('... e mais ${preview.candidates.length - 20}.'),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Confirmar atualização'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      await AppDatabase.instance.upsertWorkersFromImport(
        companyId: companyId,
        workers: preview.candidates.map((entry) => entry.worker).toList(),
      );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Periódicos atualizados para ${preview.candidates.length} trabalhador(es).',
            ),
          ),
        );
      }
    } on MedicalImportException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    } finally {
      if (mounted) setState(() => importingMedical = false);
    }
  }

  Worker? _worker(String id) {
    for (final worker in workers) {
      if (worker.id == id) return worker;
    }
    return null;
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sector(String? id) {
    if (id == null) return null;
    for (final sector in sectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  String _status(TrainingControl training) => training.statusAt(DateTime.now());

  bool _expiringSoon(TrainingControl training) {
    if (_status(training) != 'EM DIA' || training.expiryDate == null) return false;
    final days = training.expiryDate!.difference(DateTime.now()).inDays;
    return days >= 0 && days <= 30;
  }

  List<TrainingControl> get filteredTrainings {
    final clean = query.trim().toLowerCase();
    return trainings.where((training) {
      final status = _status(training);
      if (statusFilter != 'TODOS' && status != statusFilter) return false;
      final worker = _worker(training.workerId);
      final company = worker == null ? '' : (_company(worker.companyId)?.name ?? '');
      final sector = worker == null ? '' : (_sector(worker.sectorId)?.name ?? '');
      if (clean.isEmpty) return true;
      return '${training.code} ${training.title} ${worker?.name ?? ''} ${worker?.role ?? ''} $company $sector'
          .toLowerCase()
          .contains(clean);
    }).toList();
  }

  int _count(String status) => trainings.where((t) => _status(t) == status).length;

  TrainingRequirement? _matchingRequirement(
    String workerId,
    String code,
    String title,
  ) {
    final worker = _worker(workerId);
    if (worker == null) return null;
    final role = AppDatabase.normalizeRoleKey(worker.role);
    final codeKey = AppDatabase.normalizeTrainingKey(code);
    final titleKey = AppDatabase.normalizeTrainingKey(title);
    for (final requirement in requirements) {
      if (requirement.companyId != worker.companyId ||
          AppDatabase.normalizeRoleKey(requirement.role) != role) {
        continue;
      }
      final requirementCode =
          AppDatabase.normalizeTrainingKey(requirement.code);
      final requirementTitle =
          AppDatabase.normalizeTrainingKey(requirement.title);
      if ((requirementCode.isNotEmpty && requirementCode == codeKey) ||
          (requirementCode.isEmpty && requirementTitle == titleKey)) {
        return requirement;
      }
    }
    return null;
  }

  DateTime _addMonths(DateTime date, int months) {
    final target = DateTime(date.year, date.month + months, 1);
    final lastDay = DateTime(target.year, target.month + 1, 0).day;
    return DateTime(
      target.year,
      target.month,
      date.day.clamp(1, lastDay).toInt(),
    );
  }

  Future<void> _addTrainingBatch() async {
    final companyId = widget.companyId;
    if (companyId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Abra os treinamentos dentro de uma empresa para usar o lançamento em lote.'),
        ),
      );
      return;
    }
    final companyWorkers = workers
        .where((worker) => worker.companyId == companyId)
        .toList();
    if (companyWorkers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre ou importe os trabalhadores primeiro.')),
      );
      return;
    }

    final codeController = TextEditingController();
    final titleController = TextEditingController();
    final notesController = TextEditingController();
    final selectedWorkers = <String>{};
    DateTime trainingDate = DateTime.now();
    DateTime? commonExpiry;
    String roleFilter = 'TODOS';

    final roles = companyWorkers
        .map((worker) => worker.role.trim())
        .where((role) => role.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    final templateByKey = <String, TrainingRequirement>{};
    for (final requirement in requirements.where(
      (item) => item.companyId == companyId && item.active,
    )) {
      final key = AppDatabase.normalizeTrainingKey(
        requirement.code.isNotEmpty ? requirement.code : requirement.title,
      );
      if (key.isNotEmpty) templateByKey.putIfAbsent(key, () => requirement);
    }
    final templateKeys = templateByKey.keys.toList()
      ..sort((a, b) {
        final first = templateByKey[a]!;
        final second = templateByKey[b]!;
        return '${first.code} ${first.title}'
            .compareTo('${second.code} ${second.title}');
      });

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocalState) {
          final visibleWorkers = companyWorkers.where((worker) {
            return roleFilter == 'TODOS' || worker.role == roleFilter;
          }).toList();
          final allVisibleSelected = visibleWorkers.isNotEmpty &&
              visibleWorkers.every((worker) => selectedWorkers.contains(worker.id));
          return AlertDialog(
            title: const Text('Registrar treinamento em lote'),
            content: SizedBox(
              width: 620,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (templateKeys.isNotEmpty) ...[
                      DropdownButtonFormField<String>(
                        decoration: const InputDecoration(
                          labelText: 'Escolher da matriz',
                          prefixIcon: Icon(Icons.rule_folder_outlined),
                        ),
                        hint: const Text('Selecione ou preencha manualmente'),
                        items: templateKeys.map((key) {
                          final requirement = templateByKey[key]!;
                          return DropdownMenuItem(
                            value: key,
                            child: Text(
                              requirement.code.isEmpty
                                  ? requirement.title
                                  : '${requirement.code} • ${requirement.title}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (key) {
                          final requirement = templateByKey[key];
                          if (requirement == null) return;
                          setLocalState(() {
                            codeController.text = requirement.code;
                            titleController.text = requirement.title;
                          });
                        },
                      ),
                      const SizedBox(height: 10),
                    ],
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: TextField(
                            controller: codeController,
                            decoration: const InputDecoration(
                              labelText: 'NR / Código',
                              hintText: 'Ex.: NR-06',
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          flex: 3,
                          child: TextField(
                            controller: titleController,
                            decoration: const InputDecoration(
                              labelText: 'Treinamento *',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    _dateTile(
                      title: 'Data do treinamento',
                      date: trainingDate,
                      emptyText: '',
                      onPick: () async {
                        final picked = await showDatePicker(
                          context: dialogContext,
                          initialDate: trainingDate,
                          firstDate: DateTime(2000),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (picked != null) {
                          setLocalState(() => trainingDate = picked);
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    _dateTile(
                      title: 'Vencimento comum (opcional)',
                      date: commonExpiry,
                      emptyText: 'Usar a validade da matriz de cada cargo',
                      onPick: () async {
                        final picked = await showDatePicker(
                          context: dialogContext,
                          initialDate: commonExpiry ??
                              DateTime(
                                trainingDate.year + 1,
                                trainingDate.month,
                                trainingDate.day,
                              ),
                          firstDate: trainingDate,
                          lastDate: DateTime.now().add(const Duration(days: 3650)),
                        );
                        if (picked != null) {
                          setLocalState(() => commonExpiry = picked);
                        }
                      },
                      onClear: commonExpiry == null
                          ? null
                          : () => setLocalState(() => commonExpiry = null),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: notesController,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Observações da turma',
                      ),
                    ),
                    const Divider(height: 24),
                    DropdownButtonFormField<String>(
                      value: roleFilter,
                      decoration: const InputDecoration(
                        labelText: 'Filtrar participantes por cargo',
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: 'TODOS',
                          child: Text('Todos os cargos'),
                        ),
                        ...roles.map(
                          (role) => DropdownMenuItem(
                            value: role,
                            child: Text(role, overflow: TextOverflow.ellipsis),
                          ),
                        ),
                      ],
                      onChanged: (value) => setLocalState(
                        () => roleFilter = value ?? 'TODOS',
                      ),
                    ),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      value: allVisibleSelected,
                      title: Text(
                        'Selecionar todos os exibidos (${visibleWorkers.length})',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text('${selectedWorkers.length} participante(s) selecionado(s)'),
                      onChanged: (checked) => setLocalState(() {
                        if (checked == true) {
                          selectedWorkers.addAll(visibleWorkers.map((worker) => worker.id));
                        } else {
                          selectedWorkers.removeAll(visibleWorkers.map((worker) => worker.id));
                        }
                      }),
                    ),
                    Container(
                      height: 260,
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFD7DCE5)),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: ListView.builder(
                        itemCount: visibleWorkers.length,
                        itemBuilder: (context, index) {
                          final worker = visibleWorkers[index];
                          return CheckboxListTile(
                            dense: true,
                            value: selectedWorkers.contains(worker.id),
                            title: Text(worker.name),
                            subtitle: Text(worker.role),
                            onChanged: (checked) => setLocalState(() {
                              if (checked == true) {
                                selectedWorkers.add(worker.id);
                              } else {
                                selectedWorkers.remove(worker.id);
                              }
                            }),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Cancelar'),
              ),
              FilledButton.icon(
                onPressed: () {
                  if (titleController.text.trim().isEmpty ||
                      selectedWorkers.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Informe o treinamento e selecione os participantes.'),
                      ),
                    );
                    return;
                  }
                  if (commonExpiry != null &&
                      commonExpiry!.isBefore(trainingDate)) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('O vencimento não pode ser anterior ao treinamento.'),
                      ),
                    );
                    return;
                  }
                  Navigator.pop(dialogContext, true);
                },
                icon: const Icon(Icons.groups_rounded),
                label: Text('Registrar ${selectedWorkers.length}'),
              ),
            ],
          );
        },
      ),
    );

    if (saved == true) {
      final code = codeController.text.trim().toUpperCase();
      final title = titleController.text.trim();
      final records = <TrainingControl>[];
      for (final workerId in selectedWorkers) {
        TrainingControl? existing;
        for (final current in trainings.where((item) => item.workerId == workerId)) {
          final sameCode = code.isNotEmpty &&
              AppDatabase.normalizeTrainingKey(current.code) ==
                  AppDatabase.normalizeTrainingKey(code);
          final sameTitle = AppDatabase.normalizeTrainingKey(current.title) ==
              AppDatabase.normalizeTrainingKey(title);
          if (!sameCode && !sameTitle) continue;
          if (existing == null ||
              (current.trainingDate ?? DateTime(1900)).isAfter(
                existing.trainingDate ?? DateTime(1900),
              )) {
            existing = current;
          }
        }
        final requirement = _matchingRequirement(workerId, code, title);
        final expiry = commonExpiry ??
            (requirement != null && requirement.validityMonths > 0
                ? _addMonths(trainingDate, requirement.validityMonths)
                : null);
        records.add(
          TrainingControl(
            id: existing?.id ?? const Uuid().v4(),
            workerId: workerId,
            code: code,
            title: title,
            trainingDate: trainingDate,
            expiryDate: expiry,
            certificatePath: existing?.certificatePath ?? '',
            notes: notesController.text.trim(),
          ),
        );
      }
      await AppDatabase.instance.upsertTrainingControlsBatch(records);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Treinamento registrado para ${records.length} participante(s).'),
          ),
        );
      }
      await _load();
    }
    codeController.dispose();
    titleController.dispose();
    notesController.dispose();
  }

  Future<void> _editTraining([TrainingControl? training]) async {
    if (workers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre um trabalhador antes de adicionar treinamentos.')),
      );
      return;
    }

    String selectedWorkerId = training?.workerId ?? workers.first.id;
    final codeController = TextEditingController(text: training?.code ?? '');
    final titleController = TextEditingController(text: training?.title ?? '');
    final notesController = TextEditingController(text: training?.notes ?? '');
    DateTime? trainingDate = training?.trainingDate;
    DateTime? expiryDate = training?.expiryDate;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            final selectedWorker = _worker(selectedWorkerId);
            final workerRequirements = requirements.where((requirement) =>
                selectedWorker != null &&
                requirement.companyId == selectedWorker.companyId &&
                AppDatabase.normalizeRoleKey(requirement.role) ==
                    AppDatabase.normalizeRoleKey(selectedWorker.role)).toList();
            return AlertDialog(
              title: Text(training == null ? 'Adicionar treinamento' : 'Editar treinamento'),
              content: SizedBox(
                width: 540,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButtonFormField<String>(
                        value: selectedWorkerId,
                        decoration: const InputDecoration(
                          labelText: 'Trabalhador *',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                        items: workers
                            .map(
                              (worker) => DropdownMenuItem(
                                value: worker.id,
                                child: Text(worker.name, overflow: TextOverflow.ellipsis),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          if (value != null) setLocalState(() => selectedWorkerId = value);
                        },
                      ),
                      const SizedBox(height: 10),
                      if (workerRequirements.isNotEmpty) ...[
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(
                            labelText: 'Escolher da matriz do cargo',
                            prefixIcon: Icon(Icons.rule_folder_outlined),
                          ),
                          hint: const Text('Selecione um treinamento obrigatório'),
                          items: workerRequirements
                              .map((requirement) => DropdownMenuItem(
                                    value: requirement.id,
                                    child: Text(
                                      requirement.code.isEmpty
                                          ? requirement.title
                                          : '${requirement.code} • ${requirement.title}',
                                    ),
                                  ))
                              .toList(),
                          onChanged: (id) {
                            final matches = workerRequirements
                                .where((item) => item.id == id);
                            if (matches.isEmpty) return;
                            final requirement = matches.first;
                            setLocalState(() {
                              codeController.text = requirement.code;
                              titleController.text = requirement.title;
                              if (trainingDate != null &&
                                  requirement.validityMonths > 0) {
                                expiryDate = _addMonths(
                                  trainingDate!,
                                  requirement.validityMonths,
                                );
                              }
                            });
                          },
                        ),
                        const SizedBox(height: 10),
                      ],
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: codeController,
                              decoration: const InputDecoration(
                                labelText: 'NR / Código',
                                hintText: 'Ex.: NR-06',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 3,
                            child: TextField(
                              controller: titleController,
                              decoration: const InputDecoration(
                                labelText: 'Treinamento *',
                                hintText: 'Ex.: Uso de EPI',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _dateTile(
                        title: 'Data do treinamento',
                        date: trainingDate,
                        emptyText: 'Pendente / ainda não realizado',
                        onPick: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: trainingDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) {
                            setLocalState(() {
                              trainingDate = picked;
                              final requirement = _matchingRequirement(
                                selectedWorkerId,
                                codeController.text,
                                titleController.text,
                              );
                              if (expiryDate == null &&
                                  requirement != null &&
                                  requirement.validityMonths > 0) {
                                expiryDate = _addMonths(
                                  picked,
                                  requirement.validityMonths,
                                );
                              }
                            });
                          }
                        },
                        onClear: trainingDate == null ? null : () => setLocalState(() => trainingDate = null),
                      ),
                      const SizedBox(height: 8),
                      _dateTile(
                        title: 'Vencimento / validade',
                        date: expiryDate,
                        emptyText: 'Sem vencimento informado',
                        onPick: () async {
                          final base = trainingDate ?? DateTime.now();
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: expiryDate ?? DateTime(base.year + 1, base.month, base.day),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) setLocalState(() => expiryDate = picked);
                        },
                        onClear: expiryDate == null ? null : () => setLocalState(() => expiryDate = null),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: notesController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Observações',
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF4F6FA),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          'Dica: para registrar um treinamento obrigatório ainda não realizado, deixe a data do treinamento em branco. Ele aparecerá como PENDENTE.',
                          style: TextStyle(fontSize: 11.5, color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () async {
                    final title = titleController.text.trim();
                    if (title.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Informe o nome do treinamento.')),
                      );
                      return;
                    }
                    if (trainingDate != null &&
                        expiryDate != null &&
                        expiryDate!.isBefore(trainingDate!)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('O vencimento não pode ser anterior ao treinamento.')),
                      );
                      return;
                    }
                    DateTime? effectiveExpiry = expiryDate;
                    final requirement = _matchingRequirement(
                      selectedWorkerId,
                      codeController.text,
                      title,
                    );
                    if (effectiveExpiry == null &&
                        trainingDate != null &&
                        requirement != null &&
                        requirement.validityMonths > 0) {
                      effectiveExpiry = _addMonths(
                        trainingDate!,
                        requirement.validityMonths,
                      );
                    }
                    final record = TrainingControl(
                      id: training?.id ?? const Uuid().v4(),
                      workerId: selectedWorkerId,
                      code: codeController.text.trim(),
                      title: title,
                      trainingDate: trainingDate,
                      expiryDate: effectiveExpiry,
                      certificatePath: training?.certificatePath ?? '',
                      notes: notesController.text.trim(),
                    );
                    if (training == null) {
                      await AppDatabase.instance.insertTrainingControl(record);
                    } else {
                      await AppDatabase.instance.updateTrainingControl(record);
                    }
                    if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    codeController.dispose();
    titleController.dispose();
    notesController.dispose();
    if (saved == true) await _load();
  }

  Widget _dateTile({
    required String title,
    required DateTime? date,
    required String emptyText,
    required VoidCallback onPick,
    VoidCallback? onClear,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onPick,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: const Color(0xFFD7DCE5)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_month_outlined, color: AuditarBrand.navy),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text(
                    date == null ? emptyText : DateFormat('dd/MM/yyyy').format(date),
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            if (onClear != null)
              IconButton(
                tooltip: 'Limpar',
                onPressed: onClear,
                icon: const Icon(Icons.close, size: 19),
              )
            else
              const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteTraining(TrainingControl training) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir treinamento?'),
        content: Text('Deseja excluir ${training.code.isEmpty ? training.title : '${training.code} - ${training.title}'}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteTrainingControl(training.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final current = _count('EM DIA');
    final pending = _count('PENDENTE');
    final expired = _count('VENCIDO');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Treinamentos'),
        actions: [
          if (widget.companyId != null)
            IconButton(
              tooltip: 'Treinamento em lote',
              onPressed: _addTrainingBatch,
              icon: const Icon(Icons.group_add_outlined),
            ),
          if (widget.companyId != null)
            IconButton(
              tooltip: 'Atualizar periódicos por PDF',
              onPressed: importingMedical ? null : _importMedicalPdf,
              icon: const Icon(Icons.health_and_safety_outlined),
            ),
          IconButton(
            tooltip: 'Matriz por cargo',
            onPressed: _openRequirements,
            icon: const Icon(Icons.rule_folder_outlined),
          ),
          IconButton(
            tooltip: 'Avisos SST',
            onPressed: _openAlerts,
            icon: const Icon(Icons.notifications_active_outlined),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                children: [
                  Row(
                    children: [
                      Expanded(child: _metric('Em dia', current, AuditarBrand.greenDark, Icons.check_circle_outline)),
                      const SizedBox(width: 7),
                      Expanded(child: _metric('Pendentes', pending, const Color(0xFFF29D18), Icons.pending_actions_outlined)),
                      const SizedBox(width: 7),
                      Expanded(child: _metric('Vencidos', expired, const Color(0xFFD93025), Icons.event_busy_outlined)),
                    ],
                  ),
                  if (missingRequired > 0 || medicalDue > 0) ...[
                    const SizedBox(height: 10),
                    Card(
                      color: const Color(0xFFFFF6E7),
                      child: ListTile(
                        onTap: _openAlerts,
                        leading: const Icon(
                          Icons.notifications_active_outlined,
                          color: Color(0xFFF29D18),
                        ),
                        title: const Text(
                          'Avisos que precisam de atenção',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          '$missingRequired treinamento(s) obrigatório(s) sem registro • $medicalDue periódico(s) vencido(s), próximo(s) ou sem data',
                        ),
                        trailing: const Icon(Icons.chevron_right),
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  if (widget.companyId != null) ...[
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'Registrar uma turma inteira',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Escolha o treinamento, a data e marque todos os participantes de uma vez.',
                              style: TextStyle(fontSize: 12.5),
                            ),
                            const SizedBox(height: 9),
                            OutlinedButton.icon(
                              onPressed: _addTrainingBatch,
                              icon: const Icon(Icons.groups_rounded),
                              label: const Text('TREINAMENTO EM LOTE'),
                            ),
                            const SizedBox(height: 7),
                            OutlinedButton.icon(
                              onPressed: importingMedical ? null : _importMedicalPdf,
                              icon: const Icon(Icons.health_and_safety_outlined),
                              label: Text(
                                importingMedical
                                    ? 'LENDO PDF...'
                                    : 'ATUALIZAR PERIÓDICOS POR PDF',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: searchController,
                    onChanged: (value) => setState(() => query = value),
                    decoration: InputDecoration(
                      hintText: 'Buscar trabalhador ou treinamento',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchController.clear();
                                setState(() => query = '');
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: ['TODOS', 'EM DIA', 'PENDENTE', 'VENCIDO']
                          .map(
                            (status) => Padding(
                              padding: const EdgeInsets.only(right: 7),
                              child: ChoiceChip(
                                label: Text(status == 'TODOS' ? 'Todos' : status),
                                selected: statusFilter == status,
                                onSelected: (_) => setState(() => statusFilter = status),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (filteredTrainings.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(22),
                        child: Text('Nenhum treinamento encontrado.'),
                      ),
                    )
                  else
                    ...filteredTrainings.map((training) {
                      final worker = _worker(training.workerId);
                      final status = _status(training);
                      final color = status == 'EM DIA'
                          ? AuditarBrand.greenDark
                          : status == 'VENCIDO'
                              ? const Color(0xFFD93025)
                              : const Color(0xFFF29D18);
                      final company = worker == null ? null : _company(worker.companyId)?.name;
                      final sector = worker == null ? null : _sector(worker.sectorId)?.name;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _editTraining(training),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        training.code.isEmpty ? training.title : '${training.code} • ${training.title}',
                                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                                      ),
                                    ),
                                    _statusChip(_expiringSoon(training) ? 'VENCE EM BREVE' : status, color),
                                    PopupMenuButton<String>(
                                      onSelected: (value) {
                                        if (value == 'edit') _editTraining(training);
                                        if (value == 'delete') _deleteTraining(training);
                                      },
                                      itemBuilder: (context) => const [
                                        PopupMenuItem(value: 'edit', child: Text('Editar')),
                                        PopupMenuItem(value: 'delete', child: Text('Excluir')),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(worker?.name ?? 'Trabalhador não encontrado', style: const TextStyle(fontWeight: FontWeight.w600)),
                                if ((worker?.role ?? '').isNotEmpty)
                                  Text(worker!.role, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                if (company != null)
                                  Text(
                                    [company, sector].whereType<String>().where((v) => v.isNotEmpty).join(' • '),
                                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                                  ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 12,
                                  runSpacing: 5,
                                  children: [
                                    _dateInfo('Treinamento', training.trainingDate),
                                    _dateInfo('Validade', training.expiryDate),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editTraining(),
        icon: const Icon(Icons.school_outlined),
        label: const Text('Adicionar'),
      ),
    );
  }

  Widget _metric(String label, int value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 21),
            const SizedBox(height: 4),
            Text('$value', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: color)),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.11),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: color),
      ),
    );
  }

  Widget _dateInfo(String label, DateTime? date) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.calendar_today_outlined, size: 13, color: Colors.black45),
        const SizedBox(width: 4),
        Text(
          '$label: ${date == null ? '-' : DateFormat('dd/MM/yyyy').format(date)}',
          style: const TextStyle(fontSize: 11.5, color: Colors.black54),
        ),
      ],
    );
  }
}
