import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';

class TrainingsScreen extends StatefulWidget {
  final String? companyId;

  const TrainingsScreen({super.key, this.companyId});

  @override
  State<TrainingsScreen> createState() => _TrainingsScreenState();
}

class _TrainingsScreenState extends State<TrainingsScreen> {
  final searchController = TextEditingController();
  List<TrainingControl> trainings = [];
  List<Worker> workers = [];
  List<Company> companies = [];
  List<Sector> sectors = [];
  bool loading = true;
  String query = '';
  String statusFilter = 'TODOS';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final companyRows = await AppDatabase.instance.getCompanies();
    final workerRows = await AppDatabase.instance.getWorkers(
      companyId: widget.companyId,
    );
    final trainingRows = await AppDatabase.instance.getTrainingControls(
      companyId: widget.companyId,
    );
    final sectorRows = <Sector>[];
    for (final company in companyRows) {
      sectorRows.addAll(await AppDatabase.instance.getSectors(company.id));
    }
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      trainings = trainingRows;
      sectors = sectorRows;
      loading = false;
    });
  }

  Worker? _worker(String id) {
    for (final worker in workers) {
      if (worker.id == id) return worker;
    }
    return null;
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sector(String? id) {
    if (id == null) return null;
    for (final sector in sectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  String _status(TrainingControl training) => training.statusAt(DateTime.now());

  bool _expiringSoon(TrainingControl training) {
    if (_status(training) != 'EM DIA' || training.expiryDate == null) return false;
    final days = training.expiryDate!.difference(DateTime.now()).inDays;
    return days >= 0 && days <= 30;
  }

  List<TrainingControl> get filteredTrainings {
    final clean = query.trim().toLowerCase();
    return trainings.where((training) {
      final status = _status(training);
      if (statusFilter != 'TODOS' && status != statusFilter) return false;
      final worker = _worker(training.workerId);
      final company = worker == null ? '' : (_company(worker.companyId)?.name ?? '');
      final sector = worker == null ? '' : (_sector(worker.sectorId)?.name ?? '');
      if (clean.isEmpty) return true;
      return '${training.code} ${training.title} ${worker?.name ?? ''} ${worker?.role ?? ''} $company $sector'
          .toLowerCase()
          .contains(clean);
    }).toList();
  }

  int _count(String status) => trainings.where((t) => _status(t) == status).length;

  Future<void> _editTraining([TrainingControl? training]) async {
    if (workers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre um trabalhador antes de adicionar treinamentos.')),
      );
      return;
    }

    String selectedWorkerId = training?.workerId ?? workers.first.id;
    final codeController = TextEditingController(text: training?.code ?? '');
    final titleController = TextEditingController(text: training?.title ?? '');
    final notesController = TextEditingController(text: training?.notes ?? '');
    DateTime? trainingDate = training?.trainingDate;
    DateTime? expiryDate = training?.expiryDate;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            return AlertDialog(
              title: Text(training == null ? 'Adicionar treinamento' : 'Editar treinamento'),
              content: SizedBox(
                width: 540,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButtonFormField<String>(
                        value: selectedWorkerId,
                        decoration: const InputDecoration(
                          labelText: 'Trabalhador *',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                        items: workers
                            .map(
                              (worker) => DropdownMenuItem(
                                value: worker.id,
                                child: Text(worker.name, overflow: TextOverflow.ellipsis),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          if (value != null) setLocalState(() => selectedWorkerId = value);
                        },
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: codeController,
                              decoration: const InputDecoration(
                                labelText: 'NR / Código',
                                hintText: 'Ex.: NR-06',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 3,
                            child: TextField(
                              controller: titleController,
                              decoration: const InputDecoration(
                                labelText: 'Treinamento *',
                                hintText: 'Ex.: Uso de EPI',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _dateTile(
                        title: 'Data do treinamento',
                        date: trainingDate,
                        emptyText: 'Pendente / ainda não realizado',
                        onPick: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: trainingDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) setLocalState(() => trainingDate = picked);
                        },
                        onClear: trainingDate == null ? null : () => setLocalState(() => trainingDate = null),
                      ),
                      const SizedBox(height: 8),
                      _dateTile(
                        title: 'Vencimento / validade',
                        date: expiryDate,
                        emptyText: 'Sem vencimento informado',
                        onPick: () async {
                          final base = trainingDate ?? DateTime.now();
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: expiryDate ?? DateTime(base.year + 1, base.month, base.day),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) setLocalState(() => expiryDate = picked);
                        },
                        onClear: expiryDate == null ? null : () => setLocalState(() => expiryDate = null),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: notesController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Observações',
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF4F6FA),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          'Dica: para registrar um treinamento obrigatório ainda não realizado, deixe a data do treinamento em branco. Ele aparecerá como PENDENTE.',
                          style: TextStyle(fontSize: 11.5, color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () async {
                    final title = titleController.text.trim();
                    if (title.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Informe o nome do treinamento.')),
                      );
                      return;
                    }
                    if (trainingDate != null &&
                        expiryDate != null &&
                        expiryDate!.isBefore(trainingDate!)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('O vencimento não pode ser anterior ao treinamento.')),
                      );
                      return;
                    }
                    final record = TrainingControl(
                      id: training?.id ?? const Uuid().v4(),
                      workerId: selectedWorkerId,
                      code: codeController.text.trim(),
                      title: title,
                      trainingDate: trainingDate,
                      expiryDate: expiryDate,
                      certificatePath: training?.certificatePath ?? '',
                      notes: notesController.text.trim(),
                    );
                    if (training == null) {
                      await AppDatabase.instance.insertTrainingControl(record);
                    } else {
                      await AppDatabase.instance.updateTrainingControl(record);
                    }
                    if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    codeController.dispose();
    titleController.dispose();
    notesController.dispose();
    if (saved == true) await _load();
  }

  Widget _dateTile({
    required String title,
    required DateTime? date,
    required String emptyText,
    required VoidCallback onPick,
    VoidCallback? onClear,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onPick,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: const Color(0xFFD7DCE5)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_month_outlined, color: AuditarBrand.navy),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text(
                    date == null ? emptyText : DateFormat('dd/MM/yyyy').format(date),
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            if (onClear != null)
              IconButton(
                tooltip: 'Limpar',
                onPressed: onClear,
                icon: const Icon(Icons.close, size: 19),
              )
            else
              const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteTraining(TrainingControl training) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir treinamento?'),
        content: Text('Deseja excluir ${training.code.isEmpty ? training.title : '${training.code} - ${training.title}'}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteTrainingControl(training.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final current = _count('EM DIA');
    final pending = _count('PENDENTE');
    final expired = _count('VENCIDO');

    return Scaffold(
      appBar: AppBar(title: const Text('Treinamentos')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                children: [
                  Row(
                    children: [
                      Expanded(child: _metric('Em dia', current, AuditarBrand.greenDark, Icons.check_circle_outline)),
                      const SizedBox(width: 7),
                      Expanded(child: _metric('Pendentes', pending, const Color(0xFFF29D18), Icons.pending_actions_outlined)),
                      const SizedBox(width: 7),
                      Expanded(child: _metric('Vencidos', expired, const Color(0xFFD93025), Icons.event_busy_outlined)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: searchController,
                    onChanged: (value) => setState(() => query = value),
                    decoration: InputDecoration(
                      hintText: 'Buscar trabalhador ou treinamento',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchController.clear();
                                setState(() => query = '');
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: ['TODOS', 'EM DIA', 'PENDENTE', 'VENCIDO']
                          .map(
                            (status) => Padding(
                              padding: const EdgeInsets.only(right: 7),
                              child: ChoiceChip(
                                label: Text(status == 'TODOS' ? 'Todos' : status),
                                selected: statusFilter == status,
                                onSelected: (_) => setState(() => statusFilter = status),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (filteredTrainings.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(22),
                        child: Text('Nenhum treinamento encontrado.'),
                      ),
                    )
                  else
                    ...filteredTrainings.map((training) {
                      final worker = _worker(training.workerId);
                      final status = _status(training);
                      final color = status == 'EM DIA'
                          ? AuditarBrand.greenDark
                          : status == 'VENCIDO'
                              ? const Color(0xFFD93025)
                              : const Color(0xFFF29D18);
                      final company = worker == null ? null : _company(worker.companyId)?.name;
                      final sector = worker == null ? null : _sector(worker.sectorId)?.name;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _editTraining(training),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        training.code.isEmpty ? training.title : '${training.code} • ${training.title}',
                                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                                      ),
                                    ),
                                    _statusChip(_expiringSoon(training) ? 'VENCE EM BREVE' : status, color),
                                    PopupMenuButton<String>(
                                      onSelected: (value) {
                                        if (value == 'edit') _editTraining(training);
                                        if (value == 'delete') _deleteTraining(training);
                                      },
                                      itemBuilder: (context) => const [
                                        PopupMenuItem(value: 'edit', child: Text('Editar')),
                                        PopupMenuItem(value: 'delete', child: Text('Excluir')),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(worker?.name ?? 'Trabalhador não encontrado', style: const TextStyle(fontWeight: FontWeight.w600)),
                                if ((worker?.role ?? '').isNotEmpty)
                                  Text(worker!.role, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                if (company != null)
                                  Text(
                                    [company, sector].whereType<String>().where((v) => v.isNotEmpty).join(' • '),
                                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                                  ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 12,
                                  runSpacing: 5,
                                  children: [
                                    _dateInfo('Treinamento', training.trainingDate),
                                    _dateInfo('Validade', training.expiryDate),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editTraining(),
        icon: const Icon(Icons.school_outlined),
        label: const Text('Adicionar'),
      ),
    );
  }

  Widget _metric(String label, int value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 21),
            const SizedBox(height: 4),
            Text('$value', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: color)),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.11),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: color),
      ),
    );
  }

  Widget _dateInfo(String label, DateTime? date) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.calendar_today_outlined, size: 13, color: Colors.black45),
        const SizedBox(width: 4),
        Text(
          '$label: ${date == null ? '-' : DateFormat('dd/MM/yyyy').format(date)}',
          style: const TextStyle(fontSize: 11.5, color: Colors.black54),
        ),
      ],
    );
  }
}
