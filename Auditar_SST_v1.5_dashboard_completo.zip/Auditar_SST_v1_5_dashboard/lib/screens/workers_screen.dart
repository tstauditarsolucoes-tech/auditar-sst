import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/worker_import_service.dart';

class WorkersScreen extends StatefulWidget {
  final String? companyId;
  final bool startImport;

  const WorkersScreen({
    super.key,
    this.companyId,
    this.startImport = false,
  });

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  final searchController = TextEditingController();
  List<Worker> workers = [];
  List<Company> companies = [];
  List<Sector> allSectors = [];
  bool loading = true;
  bool importing = false;
  bool autoImportOpened = false;
  String query = '';

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    await _load();
    if (!mounted || !widget.startImport || autoImportOpened) return;
    autoImportOpened = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _importWorkers();
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final companyRows = await AppDatabase.instance.getCompanies();
    final workerRows = await AppDatabase.instance.getWorkers(
      companyId: widget.companyId,
    );
    final sectorRows = <Sector>[];
    for (final company in companyRows) {
      sectorRows.addAll(await AppDatabase.instance.getSectors(company.id));
    }
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      allSectors = sectorRows;
      loading = false;
    });
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sector(String? id) {
    if (id == null) return null;
    for (final sector in allSectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  List<Worker> get filteredWorkers {
    final clean = query.trim().toLowerCase();
    if (clean.isEmpty) return workers;
    return workers.where((worker) {
      final company = _company(worker.companyId)?.name ?? '';
      final sector = _sector(worker.sectorId)?.name ?? '';
      return '${worker.name} ${worker.role} ${worker.cpf} $company $sector'
          .toLowerCase()
          .contains(clean);
    }).toList();
  }

  Future<void> _importWorkers() async {
    final companyId = widget.companyId;
    if (companyId == null || importing) return;

    final privacyAccepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Importar lista do RH'),
        content: const Text(
          'Selecione o PDF atualizado com Nome e Cargo. O documento será lido pela IA gratuita do Gemini. Use somente uma lista autorizada e evite PDFs com CPF, salário, dados médicos ou outras informações confidenciais.\n\nDepois da leitura, você verá quem será incluído, atualizado e retirado da lista ativa antes de confirmar.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('Escolher PDF'),
          ),
        ],
      ),
    );
    if (privacyAccepted != true || !mounted) return;

    setState(() => importing = true);
    try {
      final sectors = allSectors
          .where((sector) => sector.companyId == companyId)
          .toList();
      final preview = await WorkerImportService.pickAndPrepare(
        companyId: companyId,
        sectors: sectors,
      );
      if (preview == null || !mounted) return;
      final deactivateMissing = await _showImportPreview(preview);
      if (deactivateMissing == null || !mounted) return;

      await AppDatabase.instance.upsertWorkersFromImport(
        companyId: companyId,
        workers: preview.candidates.map((row) => row.worker).toList(),
        deactivateMissing: deactivateMissing,
      );
      await _load();
      if (!mounted) return;
      final removed = deactivateMissing
          ? preview.activeWorkersNotInFile.length
          : 0;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Importação concluída: ${preview.newCount} novo(s), '
            '${preview.updateCount} atualizado(s) e $removed retirado(s) da lista ativa.',
          ),
        ),
      );
    } on WorkerImportException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.message)),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível importar a lista: $error')),
      );
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<bool?> _showImportPreview(WorkerImportPreview preview) {
    var deactivateMissing = true;
    return showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocalState) => AlertDialog(
          title: const Text('Conferir atualização'),
          content: SizedBox(
            width: 620,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    preview.fileName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      Chip(label: Text('${preview.newCount} novos')),
                      Chip(label: Text('${preview.updateCount} atualizados')),
                      Chip(
                        label: Text(
                          '${preview.activeWorkersNotInFile.length} fora da lista',
                        ),
                      ),
                      if (preview.invalidRows > 0)
                        Chip(label: Text('${preview.invalidRows} incompletos')),
                      if (preview.duplicateRows > 0)
                        Chip(label: Text('${preview.duplicateRows} duplicados')),
                    ],
                  ),
                  if (preview.ambiguousRows > 0) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${preview.ambiguousRows} nome(s) não foram alterados porque existem pessoas iguais e não foi possível diferenciá-las pelo cargo. Elas continuarão ativas para conferência manual.',
                      style: const TextStyle(color: Color(0xFFD93025)),
                    ),
                  ],
                  if (preview.unknownSectors.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      'Setores não encontrados no app: ${preview.unknownSectors.join(', ')}. O trabalhador será mantido sem alterar o setor.',
                      style: const TextStyle(color: Color(0xFFF29D18)),
                    ),
                  ],
                  const Divider(height: 24),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    value: deactivateMissing,
                    onChanged: (value) => setLocalState(
                      () => deactivateMissing = value ?? true,
                    ),
                    title: const Text(
                      'Retirar da lista ativa quem não está no PDF',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: const Text(
                      'O histórico de treinamentos continuará guardado e a pessoa poderá ser reativada se voltar a aparecer em uma lista futura.',
                    ),
                  ),
                  if (deactivateMissing &&
                      preview.activeWorkersNotInFile.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    const Text(
                      'Serão retirados da lista ativa:',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    ...preview.activeWorkersNotInFile.take(12).map(
                          (worker) => Text('• ${worker.name} — ${worker.role}'),
                        ),
                    if (preview.activeWorkersNotInFile.length > 12)
                      Text(
                        '... e mais ${preview.activeWorkersNotInFile.length - 12}.',
                      ),
                  ],
                  const Divider(height: 24),
                  const Text(
                    'Amostra da lista reconhecida:',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 5),
                  ...preview.candidates.take(15).map(
                        (row) => Text(
                          '• ${row.worker.name} — ${row.worker.role} '
                          '${row.isNew ? '(novo)' : '(atualizar)'}',
                        ),
                      ),
                  if (preview.candidates.length > 15)
                    Text('... e mais ${preview.candidates.length - 15}.'),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.pop(
                dialogContext,
                deactivateMissing,
              ),
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Confirmar atualização'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editWorker([Worker? worker]) async {
    if (companies.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre uma empresa antes de adicionar trabalhadores.')),
      );
      return;
    }

    final nameController = TextEditingController(text: worker?.name ?? '');
    final cpfController = TextEditingController(text: worker?.cpf ?? '');
    final roleController = TextEditingController(text: worker?.role ?? '');
    String selectedCompanyId = widget.companyId ?? worker?.companyId ?? companies.first.id;
    String? selectedSectorId = worker?.sectorId;
    DateTime? admissionDate = worker?.admissionDate;
    DateTime? lastMedicalExamDate = worker?.lastMedicalExamDate;
    DateTime? nextMedicalExamDate = worker?.nextMedicalExamDate;
    bool active = worker?.active ?? true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            final sectors = allSectors
                .where((sector) => sector.companyId == selectedCompanyId)
                .toList();
            if (selectedSectorId != null &&
                !sectors.any((sector) => sector.id == selectedSectorId)) {
              selectedSectorId = null;
            }

            return AlertDialog(
              title: Text(worker == null ? 'Novo trabalhador' : 'Editar trabalhador'),
              content: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Nome *',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: selectedCompanyId,
                        decoration: const InputDecoration(
                          labelText: 'Empresa *',
                          prefixIcon: Icon(Icons.business_outlined),
                        ),
                        items: companies
                            .map(
                              (company) => DropdownMenuItem(
                                value: company.id,
                                child: Text(company.name),
                              ),
                            )
                            .toList(),
                        onChanged: widget.companyId != null
                            ? null
                            : (value) {
                                if (value == null) return;
                                setLocalState(() {
                                  selectedCompanyId = value;
                                  selectedSectorId = null;
                                });
                              },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String?>(
                        value: selectedSectorId,
                        decoration: const InputDecoration(
                          labelText: 'Setor',
                          prefixIcon: Icon(Icons.account_tree_outlined),
                        ),
                        items: [
                          const DropdownMenuItem<String?>(
                            value: null,
                            child: Text('Sem setor definido'),
                          ),
                          ...sectors.map(
                            (sector) => DropdownMenuItem<String?>(
                              value: sector.id,
                              child: Text(sector.name),
                            ),
                          ),
                        ],
                        onChanged: (value) => setLocalState(() => selectedSectorId = value),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: roleController,
                        decoration: const InputDecoration(
                          labelText: 'Cargo / Função',
                          prefixIcon: Icon(Icons.badge_outlined),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: cpfController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'CPF',
                          prefixIcon: Icon(Icons.credit_card_outlined),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.calendar_month_outlined),
                        title: const Text('Data de admissão'),
                        subtitle: Text(
                          admissionDate == null
                              ? 'Não informada'
                              : DateFormat('dd/MM/yyyy').format(admissionDate!),
                        ),
                        trailing: admissionDate == null
                            ? const Icon(Icons.chevron_right)
                            : IconButton(
                                tooltip: 'Limpar data',
                                onPressed: () => setLocalState(() => admissionDate = null),
                                icon: const Icon(Icons.close),
                              ),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: admissionDate ?? DateTime.now(),
                            firstDate: DateTime(1950),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) {
                            setLocalState(() => admissionDate = picked);
                          }
                        },
                      ),
                      const Divider(height: 22),
                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Saúde ocupacional',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.medical_information_outlined),
                        title: const Text('Data do último exame'),
                        subtitle: Text(
                          lastMedicalExamDate == null
                              ? 'Não informada'
                              : DateFormat('dd/MM/yyyy').format(lastMedicalExamDate!),
                        ),
                        trailing: lastMedicalExamDate == null
                            ? const Icon(Icons.chevron_right)
                            : IconButton(
                                tooltip: 'Limpar data',
                                onPressed: () => setLocalState(
                                  () => lastMedicalExamDate = null,
                                ),
                                icon: const Icon(Icons.close),
                              ),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: lastMedicalExamDate ?? DateTime.now(),
                            firstDate: DateTime(1950),
                            lastDate: DateTime.now().add(const Duration(days: 365)),
                          );
                          if (picked != null) {
                            setLocalState(() => lastMedicalExamDate = picked);
                          }
                        },
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.event_available_outlined),
                        title: const Text('Próximo exame periódico'),
                        subtitle: Text(
                          nextMedicalExamDate == null
                              ? 'Não informado'
                              : DateFormat('dd/MM/yyyy').format(nextMedicalExamDate!),
                        ),
                        trailing: nextMedicalExamDate == null
                            ? const Icon(Icons.chevron_right)
                            : IconButton(
                                tooltip: 'Limpar data',
                                onPressed: () => setLocalState(
                                  () => nextMedicalExamDate = null,
                                ),
                                icon: const Icon(Icons.close),
                              ),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: nextMedicalExamDate ??
                                DateTime.now().add(const Duration(days: 365)),
                            firstDate: DateTime(2000),
                            lastDate: DateTime.now().add(const Duration(days: 3650)),
                          );
                          if (picked != null) {
                            setLocalState(() => nextMedicalExamDate = picked);
                          }
                        },
                      ),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Trabalhador ativo'),
                        value: active,
                        onChanged: (value) => setLocalState(() => active = value),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () async {
                    final name = nameController.text.trim();
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Informe o nome do trabalhador.')),
                      );
                      return;
                    }
                    final record = Worker(
                      id: worker?.id ?? const Uuid().v4(),
                      companyId: selectedCompanyId,
                      sectorId: selectedSectorId,
                      name: name,
                      cpf: cpfController.text.trim(),
                      role: roleController.text.trim(),
                      admissionDate: admissionDate,
                      lastMedicalExamDate: lastMedicalExamDate,
                      nextMedicalExamDate: nextMedicalExamDate,
                      asoPath: worker?.asoPath ?? '',
                      active: active,
                    );
                    if (worker == null) {
                      await AppDatabase.instance.insertWorker(record);
                    } else {
                      await AppDatabase.instance.updateWorker(record);
                    }
                    if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    cpfController.dispose();
    roleController.dispose();
    if (saved == true) await _load();
  }

  Future<void> _deleteWorker(Worker worker) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir trabalhador?'),
        content: Text('Deseja excluir ${worker.name}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed != true) return;
    final deleted = await AppDatabase.instance.deleteWorkerIfUnused(worker.id);
    if (!mounted) return;
    if (!deleted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Esse trabalhador possui treinamentos cadastrados. Desative-o em vez de excluir.')),
      );
      return;
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final medicalDue = workers.where((worker) {
      final date = worker.nextMedicalExamDate;
      if (date == null) return false;
      final today = DateTime.now();
      final days = DateTime(date.year, date.month, date.day)
          .difference(DateTime(today.year, today.month, today.day))
          .inDays;
      return days <= 30;
    }).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trabalhadores'),
        actions: [
          if (widget.companyId != null)
            IconButton(
              tooltip: 'Importar lista do RH',
              onPressed: importing ? null : _importWorkers,
              icon: importing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.upload_file_outlined),
            ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                children: [
                  if (widget.companyId != null) ...[
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'Lista atualizada do RH',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Importe um PDF com Nome e Cargo para incluir, atualizar e retirar funcionários da lista ativa.',
                              style: TextStyle(fontSize: 12.5),
                            ),
                            const SizedBox(height: 9),
                            OutlinedButton.icon(
                              onPressed: importing ? null : _importWorkers,
                              icon: const Icon(Icons.picture_as_pdf_outlined),
                              label: Text(
                                importing
                                    ? 'LENDO PDF...'
                                    : 'IMPORTAR PDF DO RH',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: searchController,
                    onChanged: (value) => setState(() => query = value),
                    decoration: InputDecoration(
                      hintText: 'Buscar trabalhador, cargo ou setor',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchController.clear();
                                setState(() => query = '');
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _summaryCard('Trabalhadores', workers.length, Icons.groups_rounded, AuditarBrand.navy)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _summaryCard(
                          'Com setor',
                          workers.where((w) => w.sectorId != null).length,
                          Icons.account_tree_outlined,
                          AuditarBrand.greenDark,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _summaryCard(
                          'Periódicos ≤30d',
                          medicalDue,
                          Icons.medical_information_outlined,
                          medicalDue > 0
                              ? const Color(0xFFD93025)
                              : AuditarBrand.greenDark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (filteredWorkers.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(22),
                        child: Text('Nenhum trabalhador encontrado.'),
                      ),
                    )
                  else
                    ...filteredWorkers.map((worker) {
                      final company = _company(worker.companyId)?.name ?? 'Empresa';
                      final sector = _sector(worker.sectorId)?.name;
                      final periodic = worker.nextMedicalExamDate;
                      final now = DateTime.now();
                      final periodicDays = periodic == null
                          ? null
                          : DateTime(periodic.year, periodic.month, periodic.day)
                              .difference(DateTime(now.year, now.month, now.day))
                              .inDays;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        child: ListTile(
                          onTap: () => _editWorker(worker),
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFE7F5E9),
                            foregroundColor: AuditarBrand.greenDark,
                            child: const Icon(Icons.person_rounded),
                          ),
                          title: Text(
                            worker.name,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (worker.role.isNotEmpty) Text(worker.role),
                              Text(
                                [company, sector].whereType<String>().where((v) => v.isNotEmpty).join(' • '),
                                style: const TextStyle(fontSize: 12),
                              ),
                              if (periodicDays != null)
                                Text(
                                  periodicDays < 0
                                      ? 'Periódico vencido em ${DateFormat('dd/MM/yyyy').format(periodic!)}'
                                      : periodicDays <= 30
                                          ? 'Periódico vence em $periodicDays dia(s)'
                                          : 'Próximo periódico: ${DateFormat('dd/MM/yyyy').format(periodic!)}',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: periodicDays <= 30
                                        ? FontWeight.w700
                                        : FontWeight.normal,
                                    color: periodicDays < 0
                                        ? const Color(0xFFD93025)
                                        : periodicDays <= 30
                                            ? const Color(0xFFF29D18)
                                            : Colors.black54,
                                  ),
                                ),
                            ],
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') _editWorker(worker);
                              if (value == 'delete') _deleteWorker(worker);
                            },
                            itemBuilder: (context) => const [
                              PopupMenuItem(value: 'edit', child: Text('Editar')),
                              PopupMenuItem(value: 'delete', child: Text('Excluir')),
                            ],
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editWorker(),
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Adicionar'),
      ),
    );
  }

  Widget _summaryCard(String label, int value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$value', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color)),
                Text(label, style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
