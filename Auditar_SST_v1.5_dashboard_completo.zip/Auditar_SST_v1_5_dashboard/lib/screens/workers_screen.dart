import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';

class WorkersScreen extends StatefulWidget {
  final String? companyId;

  const WorkersScreen({super.key, this.companyId});

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  final searchController = TextEditingController();
  List<Worker> workers = [];
  List<Company> companies = [];
  List<Sector> allSectors = [];
  bool loading = true;
  String query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final companyRows = await AppDatabase.instance.getCompanies();
    final workerRows = await AppDatabase.instance.getWorkers(
      companyId: widget.companyId,
    );
    final sectorRows = <Sector>[];
    for (final company in companyRows) {
      sectorRows.addAll(await AppDatabase.instance.getSectors(company.id));
    }
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      allSectors = sectorRows;
      loading = false;
    });
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sector(String? id) {
    if (id == null) return null;
    for (final sector in allSectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  List<Worker> get filteredWorkers {
    final clean = query.trim().toLowerCase();
    if (clean.isEmpty) return workers;
    return workers.where((worker) {
      final company = _company(worker.companyId)?.name ?? '';
      final sector = _sector(worker.sectorId)?.name ?? '';
      return '${worker.name} ${worker.role} ${worker.cpf} $company $sector'
          .toLowerCase()
          .contains(clean);
    }).toList();
  }

  Future<void> _editWorker([Worker? worker]) async {
    if (companies.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre uma empresa antes de adicionar trabalhadores.')),
      );
      return;
    }

    final nameController = TextEditingController(text: worker?.name ?? '');
    final cpfController = TextEditingController(text: worker?.cpf ?? '');
    final roleController = TextEditingController(text: worker?.role ?? '');
    String selectedCompanyId = widget.companyId ?? worker?.companyId ?? companies.first.id;
    String? selectedSectorId = worker?.sectorId;
    DateTime? admissionDate = worker?.admissionDate;
    bool active = worker?.active ?? true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            final sectors = allSectors
                .where((sector) => sector.companyId == selectedCompanyId)
                .toList();
            if (selectedSectorId != null &&
                !sectors.any((sector) => sector.id == selectedSectorId)) {
              selectedSectorId = null;
            }

            return AlertDialog(
              title: Text(worker == null ? 'Novo trabalhador' : 'Editar trabalhador'),
              content: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Nome *',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: selectedCompanyId,
                        decoration: const InputDecoration(
                          labelText: 'Empresa *',
                          prefixIcon: Icon(Icons.business_outlined),
                        ),
                        items: companies
                            .map(
                              (company) => DropdownMenuItem(
                                value: company.id,
                                child: Text(company.name),
                              ),
                            )
                            .toList(),
                        onChanged: widget.companyId != null
                            ? null
                            : (value) {
                                if (value == null) return;
                                setLocalState(() {
                                  selectedCompanyId = value;
                                  selectedSectorId = null;
                                });
                              },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String?>(
                        value: selectedSectorId,
                        decoration: const InputDecoration(
                          labelText: 'Setor',
                          prefixIcon: Icon(Icons.account_tree_outlined),
                        ),
                        items: [
                          const DropdownMenuItem<String?>(
                            value: null,
                            child: Text('Sem setor definido'),
                          ),
                          ...sectors.map(
                            (sector) => DropdownMenuItem<String?>(
                              value: sector.id,
                              child: Text(sector.name),
                            ),
                          ),
                        ],
                        onChanged: (value) => setLocalState(() => selectedSectorId = value),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: roleController,
                        decoration: const InputDecoration(
                          labelText: 'Cargo / Função',
                          prefixIcon: Icon(Icons.badge_outlined),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: cpfController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'CPF',
                          prefixIcon: Icon(Icons.credit_card_outlined),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.calendar_month_outlined),
                        title: const Text('Data de admissão'),
                        subtitle: Text(
                          admissionDate == null
                              ? 'Não informada'
                              : DateFormat('dd/MM/yyyy').format(admissionDate!),
                        ),
                        trailing: admissionDate == null
                            ? const Icon(Icons.chevron_right)
                            : IconButton(
                                tooltip: 'Limpar data',
                                onPressed: () => setLocalState(() => admissionDate = null),
                                icon: const Icon(Icons.close),
                              ),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: dialogContext,
                            initialDate: admissionDate ?? DateTime.now(),
                            firstDate: DateTime(1950),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) {
                            setLocalState(() => admissionDate = picked);
                          }
                        },
                      ),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Trabalhador ativo'),
                        value: active,
                        onChanged: (value) => setLocalState(() => active = value),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () async {
                    final name = nameController.text.trim();
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Informe o nome do trabalhador.')),
                      );
                      return;
                    }
                    final record = Worker(
                      id: worker?.id ?? const Uuid().v4(),
                      companyId: selectedCompanyId,
                      sectorId: selectedSectorId,
                      name: name,
                      cpf: cpfController.text.trim(),
                      role: roleController.text.trim(),
                      admissionDate: admissionDate,
                      active: active,
                    );
                    if (worker == null) {
                      await AppDatabase.instance.insertWorker(record);
                    } else {
                      await AppDatabase.instance.updateWorker(record);
                    }
                    if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    cpfController.dispose();
    roleController.dispose();
    if (saved == true) await _load();
  }

  Future<void> _deleteWorker(Worker worker) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir trabalhador?'),
        content: Text('Deseja excluir ${worker.name}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed != true) return;
    final deleted = await AppDatabase.instance.deleteWorkerIfUnused(worker.id);
    if (!mounted) return;
    if (!deleted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Esse trabalhador possui treinamentos cadastrados. Desative-o em vez de excluir.')),
      );
      return;
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trabalhadores')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                children: [
                  TextField(
                    controller: searchController,
                    onChanged: (value) => setState(() => query = value),
                    decoration: InputDecoration(
                      hintText: 'Buscar trabalhador, cargo ou setor',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchController.clear();
                                setState(() => query = '');
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _summaryCard('Trabalhadores', workers.length, Icons.groups_rounded, AuditarBrand.navy)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _summaryCard(
                          'Com setor',
                          workers.where((w) => w.sectorId != null).length,
                          Icons.account_tree_outlined,
                          AuditarBrand.greenDark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (filteredWorkers.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(22),
                        child: Text('Nenhum trabalhador encontrado.'),
                      ),
                    )
                  else
                    ...filteredWorkers.map((worker) {
                      final company = _company(worker.companyId)?.name ?? 'Empresa';
                      final sector = _sector(worker.sectorId)?.name;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        child: ListTile(
                          onTap: () => _editWorker(worker),
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFE7F5E9),
                            foregroundColor: AuditarBrand.greenDark,
                            child: const Icon(Icons.person_rounded),
                          ),
                          title: Text(
                            worker.name,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (worker.role.isNotEmpty) Text(worker.role),
                              Text(
                                [company, sector].whereType<String>().where((v) => v.isNotEmpty).join(' • '),
                                style: const TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') _editWorker(worker);
                              if (value == 'delete') _deleteWorker(worker);
                            },
                            itemBuilder: (context) => const [
                              PopupMenuItem(value: 'edit', child: Text('Editar')),
                              PopupMenuItem(value: 'delete', child: Text('Excluir')),
                            ],
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editWorker(),
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Adicionar'),
      ),
    );
  }

  Widget _summaryCard(String label, int value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$value', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color)),
                Text(label, style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
