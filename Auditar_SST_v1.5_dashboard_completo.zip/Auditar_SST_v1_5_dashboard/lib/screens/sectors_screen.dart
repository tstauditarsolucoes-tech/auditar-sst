import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';

class SectorsScreen extends StatefulWidget {
  final Company company;

  const SectorsScreen({
    super.key,
    required this.company,
  });

  @override
  State<SectorsScreen> createState() => _SectorsScreenState();
}

class _SectorsScreenState extends State<SectorsScreen> {
  List<Sector> sectors = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getSectors(
      widget.company.id,
      onlyActive: false,
    );

    if (mounted) {
      setState(() => sectors = result);
    }
  }

  Future<void> _editSector([Sector? sector]) async {
    final name = TextEditingController(text: sector?.name ?? '');
    final description =
        TextEditingController(text: sector?.description ?? '');
    bool active = sector?.active ?? true;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(
            sector == null ? 'Novo setor' : 'Editar setor',
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText: 'Nome do setor *',
                    hintText: 'Ex.: Produção, Fornos, Manutenção',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Descrição / observação',
                    hintText: 'Opcional',
                  ),
                ),
                if (sector != null) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Setor ativo'),
                    subtitle: const Text(
                      'Setores desativados não aparecem em novas vistorias.',
                    ),
                    value: active,
                    onChanged: (value) {
                      setDialogState(() => active = value);
                    },
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (save != true || name.text.trim().isEmpty) return;

    final updated = Sector(
      id: sector?.id ?? const Uuid().v4(),
      companyId: widget.company.id,
      name: name.text.trim(),
      description: description.text.trim(),
      active: active,
    );

    if (sector == null) {
      await AppDatabase.instance.insertSector(updated);
    } else {
      await AppDatabase.instance.updateSector(updated);
    }

    await _load();
  }

  Future<void> _deleteSector(Sector sector) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir setor?'),
        content: Text(
          'Deseja excluir “${sector.name}”? Se já houver vistoria vinculada, '
          'o aplicativo preservará o setor no histórico e impedirá a exclusão.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final deleted =
        await AppDatabase.instance.deleteSectorIfUnused(sector.id);

    await _load();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          deleted
              ? 'Setor excluído.'
              : 'Este setor possui vistorias. Desative-o para preservar o histórico.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Setores • ${widget.company.name}', maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editSector(),
        icon: const Icon(Icons.add),
        label: const Text('Setor'),
      ),
      body: sectors.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Nenhum setor cadastrado.\n\nCadastre os setores da empresa para separar as vistorias e os indicadores.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 92),
              itemCount: sectors.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final sector = sectors[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Icon(
                        sector.active
                            ? Icons.account_tree_outlined
                            : Icons.pause_circle_outline,
                      ),
                    ),
                    title: Text(sector.name),
                    subtitle: Text(
                      [
                        if ((sector.description ?? '').trim().isNotEmpty)
                          sector.description!.trim(),
                        sector.active ? 'Ativo' : 'Desativado',
                      ].join(' • '),
                    ),
                    onTap: () => _editSector(sector),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') {
                          _editSector(sector);
                        } else if (value == 'delete') {
                          _deleteSector(sector);
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(
                          value: 'edit',
                          child: Text('Editar'),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text('Excluir'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
