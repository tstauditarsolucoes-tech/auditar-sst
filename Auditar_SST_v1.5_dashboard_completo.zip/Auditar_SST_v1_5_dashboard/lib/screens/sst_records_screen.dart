import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import 'sst_record_form_screen.dart';

class SstRecordsScreen extends StatefulWidget {
  final String type;
  final String? companyId;

  const SstRecordsScreen({
    super.key,
    required this.type,
    this.companyId,
  });

  @override
  State<SstRecordsScreen> createState() => _SstRecordsScreenState();
}

class _SstRecordsScreenState extends State<SstRecordsScreen> {
  bool loading = true;
  List<SstRecord> records = [];
  Map<String, String> companyNames = {};
  Map<String, String> sectorNames = {};

  String get title => _config(widget.type).$1;
  IconData get icon => _config(widget.type).$2;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final companies = await AppDatabase.instance.getCompanies(onlyActive: false);
    final rows = await AppDatabase.instance.getSstRecords(
      type: widget.type,
      companyId: widget.companyId,
    );
    final sectors = <Sector>[];
    for (final company in companies) {
      sectors.addAll(await AppDatabase.instance.getSectors(company.id, onlyActive: false));
    }
    if (!mounted) return;
    setState(() {
      companyNames = {for (final c in companies) c.id: c.name};
      sectorNames = {for (final s in sectors) s.id: s.name};
      records = rows;
      loading = false;
    });
  }

  Future<void> _edit([SstRecord? record]) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SstRecordFormScreen(
          type: widget.type,
          companyId: widget.companyId,
          record: record,
        ),
      ),
    );
    await _load();
  }

  Future<void> _delete(SstRecord record) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir registro?'),
        content: Text(record.title),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (ok != true) return;
    await AppDatabase.instance.deleteSstRecord(record.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: records.isEmpty
                  ? ListView(
                      padding: const EdgeInsets.all(24),
                      children: [
                        const SizedBox(height: 70),
                        Icon(icon, size: 58, color: AuditarBrand.navy.withValues(alpha: .28)),
                        const SizedBox(height: 16),
                        Text(
                          'Nenhum registro em $title.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Toque no botão + para começar.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.black54),
                        ),
                      ],
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                      itemCount: records.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, index) => _card(records[index]),
                    ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _edit(),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }

  Widget _card(SstRecord record) {
    final due = record.dueDate;
    final overdue = due != null &&
        due.isBefore(DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day)) &&
        !_isClosed(record.status);
    final color = overdue
        ? const Color(0xFFD93025)
        : _statusColor(record.status);
    final company = companyNames[record.companyId] ?? 'Empresa não informada';
    final sector = record.sectorId == null ? '' : (sectorNames[record.sectorId] ?? '');

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _edit(record),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            record.title,
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                          ),
                        ),
                        _chip(overdue ? 'Vencido' : record.status, color),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      sector.isEmpty ? company : '$company • $sector',
                      style: const TextStyle(color: Colors.black54, fontSize: 12),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 12,
                      runSpacing: 4,
                      children: [
                        _meta(Icons.calendar_today_outlined, DateFormat('dd/MM/yyyy').format(record.date)),
                        if (due != null)
                          _meta(Icons.event_outlined, '${_dueLabel(widget.type)} ${DateFormat('dd/MM/yyyy').format(due)}'),
                        if (record.priority.isNotEmpty)
                          _meta(Icons.flag_outlined, record.priority),
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'edit') _edit(record);
                  if (value == 'delete') _delete(record);
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Editar')),
                  PopupMenuItem(value: 'delete', child: Text('Excluir')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(text, style: TextStyle(color: color, fontSize: 10.5, fontWeight: FontWeight.w700)),
      );

  Widget _meta(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.black45),
          const SizedBox(width: 3),
          Text(text, style: const TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      );

  bool _isClosed(String status) => ['Concluído', 'Concluída', 'Encerrado', 'Inativo'].contains(status);

  Color _statusColor(String status) {
    if (status.contains('Conclu')) return AuditarBrand.greenDark;
    if (status == 'Em andamento' || status == 'Programado') return const Color(0xFFF29D18);
    if (status == 'Crítico' || status == 'Aberto') return const Color(0xFFD93025);
    return AuditarBrand.navy;
  }

  static (String, IconData) _config(String type) {
    switch (type) {
      case 'AGENDA':
        return ('Agenda SST', Icons.calendar_month_outlined);
      case 'DDS':
        return ('DDS', Icons.record_voice_over_outlined);
      case 'APR_PT':
        return ('APR / PT', Icons.assignment_outlined);
      case 'INCIDENTE':
        return ('Acidentes e incidentes', Icons.health_and_safety_outlined);
      case 'EQUIPAMENTO':
        return ('Equipamentos e máquinas', Icons.precision_manufacturing_outlined);
      default:
        return ('Rotina SST', Icons.work_outline_rounded);
    }
  }

  String _dueLabel(String type) {
    if (type == 'EQUIPAMENTO') return 'Próx. inspeção:';
    if (type == 'APR_PT') return 'Validade:';
    return 'Prazo:';
  }
}
