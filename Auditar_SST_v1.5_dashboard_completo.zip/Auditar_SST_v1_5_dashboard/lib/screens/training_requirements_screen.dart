import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';

class TrainingRequirementsScreen extends StatefulWidget {
  final String? companyId;

  const TrainingRequirementsScreen({super.key, this.companyId});

  @override
  State<TrainingRequirementsScreen> createState() =>
      _TrainingRequirementsScreenState();
}

class _TrainingRequirementsScreenState
    extends State<TrainingRequirementsScreen> {
  List<Company> companies = [];
  List<TrainingRequirement> requirements = [];
  List<String> workerRoles = [];
  String? selectedCompanyId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    selectedCompanyId = widget.companyId;
    _load();
  }

  Future<void> _load() async {
    final companyRows = await AppDatabase.instance.getCompanies();
    final companyId = selectedCompanyId ??
        (companyRows.isNotEmpty ? companyRows.first.id : null);
    final rows = companyId == null
        ? <TrainingRequirement>[]
        : await AppDatabase.instance.getTrainingRequirements(
            companyId: companyId,
            onlyActive: false,
          );
    final workers = companyId == null
        ? <Worker>[]
        : await AppDatabase.instance.getWorkers(companyId: companyId);
    final roles = workers
        .map((worker) => worker.role.trim())
        .where((role) => role.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      selectedCompanyId = companyId;
      requirements = rows;
      workerRoles = roles;
      loading = false;
    });
  }

  Future<void> _changeCompany(String? value) async {
    if (value == null) return;
    setState(() {
      selectedCompanyId = value;
      loading = true;
    });
    await _load();
  }

  Future<void> _edit([TrainingRequirement? requirement]) async {
    if (companies.isEmpty) return;
    String companyId = requirement?.companyId ??
        selectedCompanyId ??
        companies.first.id;
    final role = TextEditingController(text: requirement?.role ?? '');
    final code = TextEditingController(text: requirement?.code ?? '');
    final title = TextEditingController(text: requirement?.title ?? '');
    final validity = TextEditingController(
      text: requirement == null || requirement.validityMonths == 0
          ? ''
          : '${requirement.validityMonths}',
    );
    bool active = requirement?.active ?? true;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocalState) => AlertDialog(
          title: Text(requirement == null
              ? 'Novo treinamento obrigatório'
              : 'Editar treinamento obrigatório'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    value: companyId,
                    decoration: const InputDecoration(
                      labelText: 'Empresa *',
                      prefixIcon: Icon(Icons.business_outlined),
                      helperText: 'Altere a empresa no filtro da tela.',
                    ),
                    items: companies
                        .map((company) => DropdownMenuItem(
                              value: company.id,
                              child: Text(company.name),
                            ))
                        .toList(),
                    onChanged: null,
                  ),
                  const SizedBox(height: 10),
                  if (requirement == null && workerRoles.isNotEmpty)
                    DropdownButtonFormField<String>(
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Cargo / função *',
                        prefixIcon: Icon(Icons.badge_outlined),
                      ),
                      hint: const Text('Escolha um cargo da empresa'),
                      items: workerRoles
                          .map(
                            (item) => DropdownMenuItem(
                              value: item,
                              child: Text(item, overflow: TextOverflow.ellipsis),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) role.text = value;
                      },
                    )
                  else
                    TextField(
                      controller: role,
                      decoration: const InputDecoration(
                        labelText: 'Cargo / função *',
                        hintText: 'Ex.: Eletricista',
                        prefixIcon: Icon(Icons.badge_outlined),
                      ),
                    ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: code,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      labelText: 'NR / código',
                      hintText: 'Ex.: NR-10',
                      prefixIcon: Icon(Icons.menu_book_outlined),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: title,
                    decoration: const InputDecoration(
                      labelText: 'Nome do treinamento *',
                      prefixIcon: Icon(Icons.school_outlined),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: validity,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Validade em meses',
                      hintText: 'Deixe vazio se não houver validade definida',
                      prefixIcon: Icon(Icons.event_repeat_outlined),
                    ),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Regra ativa'),
                    value: active,
                    onChanged: (value) => setLocalState(() => active = value),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                if (role.text.trim().isEmpty || title.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Informe o cargo e o treinamento.'),
                    ),
                  );
                  return;
                }
                final trainingKey = AppDatabase.normalizeTrainingKey(
                  code.text.trim().isNotEmpty ? code.text : title.text,
                );
                final duplicate = requirements.any((item) {
                  if (item.id == requirement?.id) return false;
                  final itemKey = AppDatabase.normalizeTrainingKey(
                    item.code.isNotEmpty ? item.code : item.title,
                  );
                  return AppDatabase.normalizeRoleKey(item.role) ==
                          AppDatabase.normalizeRoleKey(role.text) &&
                      itemKey == trainingKey;
                });
                if (duplicate) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Esse treinamento já está na matriz do cargo.'),
                    ),
                  );
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      final record = TrainingRequirement(
        id: requirement?.id ?? const Uuid().v4(),
        companyId: companyId,
        role: role.text.trim(),
        code: code.text.trim().toUpperCase(),
        title: title.text.trim(),
        validityMonths: int.tryParse(validity.text.trim()) ?? 0,
        active: active,
      );
      if (requirement == null) {
        await AppDatabase.instance.insertTrainingRequirement(record);
      } else {
        await AppDatabase.instance.updateTrainingRequirement(record);
      }
      selectedCompanyId = companyId;
      await _load();
    }
    role.dispose();
    code.dispose();
    title.dispose();
    validity.dispose();
  }

  Future<void> _delete(TrainingRequirement requirement) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir regra?'),
        content: Text(
          'Remover ${requirement.code.isEmpty ? requirement.title : requirement.code} do cargo ${requirement.role}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteTrainingRequirement(requirement.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Matriz por cargo')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: companies.isEmpty ? null : () => _edit(),
        icon: const Icon(Icons.add),
        label: const Text('Adicionar regra'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
              children: [
                if (widget.companyId == null && companies.isNotEmpty)
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    value: selectedCompanyId,
                    decoration: const InputDecoration(
                      labelText: 'Empresa',
                      prefixIcon: Icon(Icons.business_outlined),
                    ),
                    items: companies
                        .map((company) => DropdownMenuItem(
                              value: company.id,
                              child: Text(company.name),
                            ))
                        .toList(),
                    onChanged: _changeCompany,
                  ),
                const SizedBox(height: 10),
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(14),
                    child: Text(
                      'Escolha os cargos importados do RH e informe os treinamentos obrigatórios. Diferenças de acento, espaço ou letra maiúscula não impedem mais a correspondência.',
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                if (requirements.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(22),
                      child: Text(
                        'Nenhuma regra cadastrada. Adicione o primeiro treinamento obrigatório por cargo.',
                      ),
                    ),
                  )
                else
                  ...requirements.map((requirement) => Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          onTap: () => _edit(requirement),
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFE7F5E9),
                            foregroundColor: AuditarBrand.greenDark,
                            child: const Icon(Icons.school_outlined),
                          ),
                          title: Text(
                            requirement.code.isEmpty
                                ? requirement.title
                                : '${requirement.code} • ${requirement.title}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${requirement.role}${requirement.validityMonths > 0 ? ' • ${requirement.validityMonths} meses' : ''}${requirement.active ? '' : ' • Desativado'}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') _edit(requirement);
                              if (value == 'delete') _delete(requirement);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('Editar')),
                              PopupMenuItem(value: 'delete', child: Text('Excluir')),
                            ],
                          ),
                        ),
                      )),
              ],
            ),
    );
  }
}
