import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() =>
      _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Company> companies = [];
  List<WorkSite> workSites = [];
  List<Sector> sectors = [];

  String? selectedCompanyId;
  String? selectedWorkSiteId;
  String? selectedSectorId;
  String selectedPeriod = 'Este mês';
  String selectedPriority = 'Todas';

  DateTime? customStart;
  DateTime? customEnd;

  Map<String, int> summary = {};
  List<Map<String, Object?>> sectorPerformance = [];
  bool loading = true;
  bool filtersExpanded = false;

  static const periods = <String>[
    'Todos',
    'Hoje',
    'Últimos 7 dias',
    'Este mês',
    'Últimos 30 dias',
    'Personalizado',
  ];

  static const priorities = <String>[
    'Todas',
    'Baixa',
    'Média',
    'Alta',
    'Crítica',
  ];

  @override
  void initState() {
    super.initState();
    _loadInitial();
  }

  Future<void> _loadInitial() async {
    final loadedCompanies =
        await AppDatabase.instance.getCompanies();

    if (!mounted) return;

    setState(() {
      companies = loadedCompanies;
    });

    await _refreshSummary();
  }

  DateTime? get _startDate {
    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    switch (selectedPeriod) {
      case 'Hoje':
        return today;
      case 'Últimos 7 dias':
        return today.subtract(
          const Duration(days: 6),
        );
      case 'Este mês':
        return DateTime(
          now.year,
          now.month,
          1,
        );
      case 'Últimos 30 dias':
        return today.subtract(
          const Duration(days: 29),
        );
      case 'Personalizado':
        return customStart;
      default:
        return null;
    }
  }

  DateTime? get _endDate {
    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    switch (selectedPeriod) {
      case 'Hoje':
      case 'Últimos 7 dias':
      case 'Este mês':
      case 'Últimos 30 dias':
        return today;
      case 'Personalizado':
        return customEnd;
      default:
        return null;
    }
  }

  Future<void> _refreshSummary() async {
    if (mounted) {
      setState(() => loading = true);
    }

    final result =
        await AppDatabase.instance.getDashboardSummary(
      companyId: selectedCompanyId,
      workSiteId: selectedWorkSiteId,
      sectorId: selectedSectorId,
      startDate: _startDate,
      endDate: _endDate,
      priority: selectedPriority,
    );

    final sectorsData = selectedCompanyId == null
        ? <Map<String, Object?>>[]
        : await AppDatabase.instance.getCompanySectorPerformance(selectedCompanyId!);

    if (!mounted) return;

    setState(() {
      summary = result;
      sectorPerformance = sectorsData;
      loading = false;
    });
  }

  Future<void> _changeCompany(
    String? companyId,
  ) async {
    setState(() {
      selectedCompanyId = companyId;
      selectedWorkSiteId = null;
      selectedSectorId = null;
      workSites = [];
      sectors = [];
    });

    if (companyId != null) {
      final loadedSites =
          await AppDatabase.instance.getWorkSites(
        companyId,
      );
      final loadedSectors =
          await AppDatabase.instance.getSectors(
        companyId,
      );

      if (!mounted) return;

      setState(() {
        workSites = loadedSites;
        sectors = loadedSectors;
      });
    }

    await _refreshSummary();
  }

  Future<void> _changePeriod(
    String? period,
  ) async {
    if (period == null) return;

    if (period == 'Personalizado') {
      final now = DateTime.now();

      final picked =
          await showDateRangePicker(
        context: context,
        firstDate: DateTime(now.year - 5),
        lastDate: DateTime(now.year + 2),
        initialDateRange:
            customStart != null &&
                    customEnd != null
                ? DateTimeRange(
                    start: customStart!,
                    end: customEnd!,
                  )
                : DateTimeRange(
                    start: DateTime(
                      now.year,
                      now.month,
                      1,
                    ),
                    end: now,
                  ),
        helpText: 'Escolha o período',
        saveText: 'Aplicar',
      );

      if (picked == null) return;

      setState(() {
        selectedPeriod = period;
        customStart = picked.start;
        customEnd = picked.end;
      });
    } else {
      setState(() {
        selectedPeriod = period;
      });
    }

    await _refreshSummary();
  }

  Future<void> _clearFilters() async {
    setState(() {
      selectedCompanyId = null;
      selectedWorkSiteId = null;
      selectedSectorId = null;
      workSites = [];
      sectors = [];
      selectedPeriod = 'Este mês';
      selectedPriority = 'Todas';
      customStart = null;
      customEnd = null;
    });

    await _refreshSummary();
  }

  String get _periodDetail {
    if (selectedPeriod == 'Personalizado' &&
        customStart != null &&
        customEnd != null) {
      return '${DateFormat('dd/MM/yyyy').format(customStart!)} '
          'a ${DateFormat('dd/MM/yyyy').format(customEnd!)}';
    }

    return selectedPeriod;
  }

  String get _companyLabel {
    if (selectedCompanyId == null) {
      return 'Todas as empresas';
    }

    for (final company in companies) {
      if (company.id == selectedCompanyId) {
        return company.name;
      }
    }

    return 'Empresa selecionada';
  }

  String get _workSiteLabel {
    if (selectedWorkSiteId == null) {
      return 'Todas as obras/unidades';
    }

    for (final site in workSites) {
      if (site.id == selectedWorkSiteId) {
        return site.name;
      }
    }

    return 'Local selecionado';
  }

  String get _sectorLabel {
    if (selectedSectorId == null) {
      return 'Todos os setores';
    }

    for (final sector in sectors) {
      if (sector.id == selectedSectorId) {
        return sector.name;
      }
    }

    return 'Setor selecionado';
  }

  @override
  Widget build(BuildContext context) {
    final conformity =
        summary['conformity'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Indicadores'),
        actions: [
          IconButton(
            tooltip: 'Limpar filtros',
            onPressed: _clearFilters,
            icon: const Icon(
              Icons.filter_alt_off_outlined,
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshSummary,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _filtersCard(),
            const SizedBox(height: 8),
            _activeFiltersCard(),
            const SizedBox(height: 10),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 50,
                ),
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            else ...[
              _conformityCard(conformity),
              const SizedBox(height: 8),
              ResponsiveWrap(
                minItemWidth: 145,
                maxColumns: 2,
                children: [
                  _metricCard(
                    'Vistorias',
                    summary['inspections'] ?? 0,
                    Icons.fact_check_outlined,
                  ),
                  _metricCard(
                    'Pendências',
                    summary['pending'] ?? 0,
                    Icons.assignment_late_outlined,
                  ),
                  _metricCard(
                    'Vencidas',
                    summary['overdue'] ?? 0,
                    Icons.warning_amber_rounded,
                  ),
                  _metricCard(
                    'Concluídas',
                    summary['completed'] ?? 0,
                    Icons.task_alt,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _ncStatusSection(),
              if (selectedCompanyId != null) ...[
                const SizedBox(height: 12),
                _sectorIndicatorsSection(),
              ],
              const SizedBox(height: 12),
              _prioritySection(),
              const SizedBox(height: 12),
              _detailsCard(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _filtersCard() {
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.filter_alt_outlined),
            title: const Text(
              'Filtros',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: Text(
              filtersExpanded ? 'Toque para recolher' : 'Empresa, local, setor, período e prioridade',
              style: const TextStyle(fontSize: 11),
            ),
            trailing: Icon(filtersExpanded ? Icons.expand_less_rounded : Icons.expand_more_rounded),
            onTap: () => setState(() => filtersExpanded = !filtersExpanded),
          ),
          if (filtersExpanded)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Column(
                children: [
            DropdownButtonFormField<String?>(
              value: selectedCompanyId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Empresa',
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text(
                    'Todas as empresas',
                  ),
                ),
                ...companies.map(
                  (company) =>
                      DropdownMenuItem<String?>(
                    value: company.id,
                    child: Text(company.name),
                  ),
                ),
              ],
              onChanged: _changeCompany,
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedWorkSiteId,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: 'Obra / Unidade',
                helperText:
                    selectedCompanyId == null
                        ? 'Selecione uma empresa para filtrar por obra.'
                        : null,
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text(
                    'Todas as obras/unidades',
                  ),
                ),
                ...workSites.map(
                  (site) =>
                      DropdownMenuItem<String?>(
                    value: site.id,
                    child: Text(site.name),
                  ),
                ),
              ],
              onChanged:
                  selectedCompanyId == null
                      ? null
                      : (value) async {
                          setState(() {
                            selectedWorkSiteId =
                                value;
                          });
                          await _refreshSummary();
                        },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedSectorId,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: 'Setor',
                helperText:
                    selectedCompanyId == null
                        ? 'Selecione uma empresa para filtrar por setor.'
                        : null,
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Todos os setores'),
                ),
                ...sectors.map(
                  (sector) => DropdownMenuItem<String?>(
                    value: sector.id,
                    child: Text(sector.name),
                  ),
                ),
              ],
              onChanged: selectedCompanyId == null
                  ? null
                  : (value) async {
                      setState(() {
                        selectedSectorId = value;
                      });
                      await _refreshSummary();
                    },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedPeriod,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Período',
              ),
              items: periods
                  .map(
                    (period) =>
                        DropdownMenuItem(
                      value: period,
                      child: Text(period),
                    ),
                  )
                  .toList(),
              onChanged: _changePeriod,
            ),
            if (selectedPeriod ==
                    'Personalizado' &&
                customStart != null &&
                customEnd != null) ...[
              const SizedBox(height: 6),
              TextButton.icon(
                onPressed: () =>
                    _changePeriod(
                      'Personalizado',
                    ),
                icon: const Icon(
                  Icons.date_range_outlined,
                ),
                label: Text(_periodDetail),
              ),
            ],
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedPriority,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText:
                    'Prioridade do plano de ação',
                helperText:
                    'A prioridade filtra pendências, vencidas e concluídas.',
              ),
              items: priorities
                  .map(
                    (priority) =>
                        DropdownMenuItem(
                      value: priority,
                      child: Text(priority),
                    ),
                  )
                  .toList(),
              onChanged: (value) async {
                if (value == null) return;

                setState(() {
                  selectedPriority = value;
                });

                await _refreshSummary();
              },
            ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _activeFiltersCard() {
    final parts = <String>[
      _companyLabel,
      if (selectedWorkSiteId != null) _workSiteLabel,
      if (selectedSectorId != null) _sectorLabel,
      _periodDetail,
      if (selectedPriority != 'Todas') 'Prioridade $selectedPriority',
    ];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFF4F6FA),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE4E8F0)),
      ),
      child: Row(
        children: [
          const Icon(Icons.visibility_outlined, size: 18, color: Color(0xFF667085)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              parts.join(' • '),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF475467)),
            ),
          ),
          if (!filtersExpanded)
            TextButton(
              onPressed: () => setState(() => filtersExpanded = true),
              child: const Text('Alterar'),
            ),
        ],
      ),
    );
  }

  Widget _conformityCard(
    int conformity,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'CONFORMIDADE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment:
                  CrossAxisAlignment.end,
              children: [
                Text(
                  '$conformity%',
                  style: Theme.of(context)
                      .textTheme
                      .displaySmall
                      ?.copyWith(
                        fontWeight:
                            FontWeight.bold,
                      ),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'dos itens avaliados',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: conformity / 100,
              minHeight: 10,
              borderRadius:
                  BorderRadius.circular(8),
            ),
            const SizedBox(height: 8),
            Text(
              '${summary['conformes'] ?? 0} conformes • '
              '${summary['naoConformes'] ?? 0} não conformes • '
              '${summary['parciais'] ?? 0} parciais • '
              '${summary['naoAplicaveis'] ?? 0} N/A',
            ),
          ],
        ),
      ),
    );
  }

  Widget _metricCard(
    String title,
    int value,
    IconData icon,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, size: 28),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  Text(
                    '$value',
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                  Text(
                    title,
                    maxLines: 2,
                    overflow:
                        TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _ncStatusSection() {
    final pending = summary['ncPending'] ?? 0;
    final inProgress = summary['ncInProgress'] ?? 0;
    final awaiting = summary['ncAwaiting'] ?? 0;
    final overdue = summary['ncOverdue'] ?? 0;
    final completed = summary['ncCompleted'] ?? 0;
    final rate = summary['ncResolutionRate'] ?? 0;

    Widget row(String label, int value, Color color, IconData icon) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Icon(icon, size: 19, color: color),
            const SizedBox(width: 8),
            Expanded(child: Text(label)),
            Text('$value', style: TextStyle(fontWeight: FontWeight.w800, color: color)),
          ],
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'SITUAÇÃO DAS NÃO CONFORMIDADES',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: .10),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('$rate% resolvidas', style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            row('Pendentes', pending, const Color(0xFFF29D18), Icons.pending_actions),
            row('Em andamento', inProgress, const Color(0xFF183365), Icons.autorenew_rounded),
            row('Aguardando verificação', awaiting, const Color(0xFF7B61A8), Icons.verified_outlined),
            row('Vencidas', overdue, const Color(0xFFD93025), Icons.event_busy_outlined),
            row('Concluídas', completed, Colors.green.shade700, Icons.task_alt),
            const Divider(),
            Text(
              '${summary['ncCompletedThisMonth'] ?? 0} NCs concluídas neste mês',
              style: const TextStyle(fontSize: 11, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  int _rowInt(Map<String, Object?> row, String key) {
    final value = row[key];
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  int _sectorConformity(Map<String, Object?> row) {
    final c = _rowInt(row, 'conformes');
    final p = _rowInt(row, 'parciais');
    final nc = _rowInt(row, 'nao_conformes');
    final total = c + p + nc;
    if (total == 0) return 0;
    return ((c / total) * 100).round();
  }

  Widget _sectorIndicatorsSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'INDICADORES POR SETOR',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            const Text(
              'Conformidade e NCs abertas por setor da empresa selecionada.',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
            const SizedBox(height: 10),
            if (sectorPerformance.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Nenhum setor cadastrado ou ainda sem dados.'),
              )
            else
              ...sectorPerformance.map((row) {
                final conformity = _sectorConformity(row);
                final openNcs = _rowInt(row, 'open_ncs');
                final overdueNcs = _rowInt(row, 'overdue_ncs');
                final color = conformity >= 80
                    ? Colors.green.shade700
                    : conformity >= 60
                        ? const Color(0xFFF29D18)
                        : const Color(0xFFD93025);
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 48,
                        height: 48,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CircularProgressIndicator(
                              value: conformity / 100,
                              strokeWidth: 5,
                              color: color,
                              backgroundColor: const Color(0xFFE9EDF3),
                            ),
                            Text('$conformity%', style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${row['name'] ?? 'Setor'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 3),
                            Text(
                              '$openNcs NCs abertas${overdueNcs > 0 ? ' • $overdueNcs vencida(s)' : ''}',
                              style: TextStyle(fontSize: 10.5, color: overdueNcs > 0 ? const Color(0xFFD93025) : Colors.black54),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _prioritySection() {
    final critical =
        summary['critical'] ?? 0;
    final high = summary['high'] ?? 0;
    final medium =
        summary['medium'] ?? 0;
    final low = summary['low'] ?? 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Text(
              'PLANOS DE AÇÃO POR PRIORIDADE',
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(
                    fontWeight:
                        FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Distribuição dos planos de ação no período selecionado.',
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _priorityBox(
                    'Crítica',
                    critical,
                    Icons.error_outline,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _priorityBox(
                    'Alta',
                    high,
                    Icons.priority_high,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Row(
              children: [
                Expanded(
                  child: _priorityBox(
                    'Média',
                    medium,
                    Icons.remove_circle_outline,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _priorityBox(
                    'Baixa',
                    low,
                    Icons.keyboard_arrow_down,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _priorityBox(
    String label,
    int value,
    IconData icon,
  ) {
    return Container(
      constraints:
          const BoxConstraints(minHeight: 66),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context)
              .colorScheme
              .outlineVariant,
        ),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 22),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  '$value',
                  style: const TextStyle(
                    fontWeight:
                        FontWeight.bold,
                    fontSize: 19,
                  ),
                ),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'ACOMPANHAMENTO',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            _detailRow(
              'Em andamento',
              summary['inProgress'] ?? 0,
              Icons.timelapse,
            ),
            const Divider(),
            _detailRow(
              'Pendentes',
              summary['pending'] ?? 0,
              Icons.pending_actions,
            ),
            const Divider(),
            _detailRow(
              'Vencidas',
              summary['overdue'] ?? 0,
              Icons.event_busy_outlined,
            ),
            const Divider(),
            _detailRow(
              'Concluídas',
              summary['completed'] ?? 0,
              Icons.task_alt,
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(
    String label,
    int value,
    IconData icon,
  ) {
    return Row(
      children: [
        Icon(icon, size: 21),
        const SizedBox(width: 9),
        Expanded(child: Text(label)),
        Text(
          '$value',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
