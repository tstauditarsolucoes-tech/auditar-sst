import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import 'checklist_screen.dart';

class NewInspectionScreen extends StatefulWidget {
  const NewInspectionScreen({super.key});

  @override
  State<NewInspectionScreen> createState() =>
      _NewInspectionScreenState();
}

class _NewInspectionScreenState extends State<NewInspectionScreen> {
  List<Company> companies = [];
  List<WorkSite> sites = [];
  List<ChecklistTemplate> templates = [];

  Company? selectedCompany;
  WorkSite? selectedSite;
  ChecklistTemplate? selectedTemplate;

  final technicianName = TextEditingController();
  final area = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    technicianName.dispose();
    area.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;

    final loadedCompanies = await db.getCompanies();
    final loadedTemplates = await db.getChecklistTemplates();
    final defaultTechnician = await db.getSetting(
      'default_technician',
      fallback: '',
    );

    if (!mounted) return;

    setState(() {
      companies = loadedCompanies;
      templates = loadedTemplates;
      technicianName.text = defaultTechnician;

      if (templates.isNotEmpty) {
        selectedTemplate = templates.first;
      }
    });
  }

  Future<void> _companyChanged(Company? company) async {
    setState(() {
      selectedCompany = company;
      selectedSite = null;
      sites = [];
    });

    if (company == null) return;

    final result =
        await AppDatabase.instance.getWorkSites(company.id);

    if (mounted) {
      setState(() => sites = result);
    }
  }

  Future<void> _start() async {
    if (selectedCompany == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione a empresa.')),
      );
      return;
    }

    if (selectedTemplate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione um checklist.')),
      );
      return;
    }

    final items = await AppDatabase.instance.getChecklistItems(
      selectedTemplate!.id,
    );

    if (items.isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Este checklist não possui perguntas ativas.',
          ),
        ),
      );
      return;
    }

    if (technicianName.text.trim().isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Informe o nome do técnico responsável.',
          ),
        ),
      );
      return;
    }

    if (area.text.trim().isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Informe o setor ou área.'),
        ),
      );
      return;
    }

    final now = DateTime.now();

    final inspection = Inspection(
      id: const Uuid().v4(),
      companyId: selectedCompany!.id,
      workSiteId: selectedSite?.id,
      area: area.text.trim(),
      checklistType: selectedTemplate!.name,
      checklistTemplateId: selectedTemplate!.id,
      date: now,
      status: 'Em andamento',
      technicianName: technicianName.text.trim(),
      reportNumber:
          'SST-${DateFormat('yyyyMMdd-HHmmss').format(now)}',
    );

    await AppDatabase.instance.insertInspection(inspection);

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ChecklistScreen(
          inspection: inspection,
          companyName: selectedCompany!.name,
          siteName: selectedSite?.name,
          checklistItems: items,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nova vistoria')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: technicianName,
            decoration: const InputDecoration(
              labelText: 'Técnico responsável *',
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<Company>(
            value: selectedCompany,
            decoration: const InputDecoration(
              labelText: 'Empresa *',
            ),
            items: companies
                .map(
                  (company) => DropdownMenuItem(
                    value: company,
                    child: Text(company.name),
                  ),
                )
                .toList(),
            onChanged: _companyChanged,
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<WorkSite>(
            value: selectedSite,
            decoration: const InputDecoration(
              labelText: 'Obra / Unidade',
              hintText: 'Opcional',
            ),
            items: sites
                .map(
                  (site) => DropdownMenuItem(
                    value: site,
                    child: Text(site.name),
                  ),
                )
                .toList(),
            onChanged: (value) {
              setState(() => selectedSite = value);
            },
          ),
          const SizedBox(height: 14),
          TextField(
            controller: area,
            decoration: const InputDecoration(
              labelText: 'Setor / Área *',
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<ChecklistTemplate>(
            value: selectedTemplate,
            decoration: const InputDecoration(
              labelText: 'Checklist *',
            ),
            items: templates
                .map(
                  (template) => DropdownMenuItem(
                    value: template,
                    child: Text(template.name),
                  ),
                )
                .toList(),
            onChanged: (value) {
              setState(() => selectedTemplate = value);
            },
          ),
          if (selectedTemplate != null) ...[
            const SizedBox(height: 8),
            Text(
              [
                if (selectedTemplate!.category.isNotEmpty)
                  selectedTemplate!.category,
                if (selectedTemplate!.reference.isNotEmpty)
                  selectedTemplate!.reference,
              ].join(' • '),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _start,
            icon: const Icon(Icons.play_arrow),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Text('INICIAR CHECKLIST'),
            ),
          ),
        ],
      ),
    );
  }
}
