import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import 'checklist_screen.dart';
import 'sectors_screen.dart';

class NewInspectionScreen extends StatefulWidget {
  const NewInspectionScreen({super.key});

  @override
  State<NewInspectionScreen> createState() =>
      _NewInspectionScreenState();
}

class _NewInspectionScreenState extends State<NewInspectionScreen> {
  List<Company> companies = [];
  List<WorkSite> sites = [];
  List<Sector> sectors = [];
  List<ChecklistTemplate> templates = [];

  Company? selectedCompany;
  WorkSite? selectedSite;
  Sector? selectedSector;
  ChecklistTemplate? selectedTemplate;

  final technicianName = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    technicianName.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;

    final loadedCompanies = await db.getCompanies();
    final loadedTemplates = await db.getChecklistTemplates();
    final defaultTechnician = await db.getSetting(
      'default_technician',
      fallback: '',
    );

    if (!mounted) return;

    setState(() {
      companies = loadedCompanies;
      templates = loadedTemplates;
      technicianName.text = defaultTechnician;
    });
  }

  Future<void> _companyChanged(Company? company) async {
    setState(() {
      selectedCompany = company;
      selectedSite = null;
      selectedSector = null;
      sites = [];
      sectors = [];
    });

    if (company == null) return;

    final results = await Future.wait([
      AppDatabase.instance.getWorkSites(company.id),
      AppDatabase.instance.getSectors(company.id),
    ]);

    if (!mounted) return;

    setState(() {
      sites = results[0] as List<WorkSite>;
      sectors = results[1] as List<Sector>;
    });
  }

  Future<void> _registerSector() async {
    final company = selectedCompany;
    if (company == null) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SectorsScreen(company: company),
      ),
    );

    final loaded = await AppDatabase.instance.getSectors(company.id);
    if (!mounted) return;

    setState(() {
      sectors = loaded;
      selectedSector = null;
    });
  }

  IconData _checklistIcon(String category) {
    switch (category) {
      case 'Construção Civil':
        return Icons.construction;
      case 'Panificação':
        return Icons.bakery_dining;
      case 'Cerâmica':
        return Icons.factory_outlined;
      case 'Máquinas e Equipamentos':
        return Icons.precision_manufacturing_outlined;
      case 'Incêndio e Emergência':
        return Icons.local_fire_department_outlined;
      case 'Elétrica':
        return Icons.electrical_services_outlined;
      case 'EPI':
        return Icons.health_and_safety_outlined;
      case 'Ergonomia':
        return Icons.accessibility_new;
      case 'Produtos Químicos':
        return Icons.science_outlined;
      case 'Espaço Confinado':
        return Icons.sensor_door_outlined;
      default:
        return Icons.fact_check_outlined;
    }
  }

  Future<void> _selectChecklist() async {
    final search = TextEditingController();
    String category = 'Todos';

    final categories = templates
        .map((template) => template.category.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    final selected = await showModalBottomSheet<ChecklistTemplate>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final query = search.text.trim().toLowerCase();
          final visible = templates.where((template) {
            if (category != 'Todos' && template.category != category) {
              return false;
            }
            if (query.isEmpty) return true;
            return template.name.toLowerCase().contains(query) ||
                template.category.toLowerCase().contains(query) ||
                template.reference.toLowerCase().contains(query);
          }).toList();

          return FractionallySizedBox(
            heightFactor: .88,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 10, 8),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Selecionar checklist',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(sheetContext),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: search,
                    autofocus: true,
                    onChanged: (_) => setSheetState(() {}),
                    decoration: const InputDecoration(
                      hintText: 'Buscar checklist...',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 42,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    itemCount: categories.length + 1,
                    separatorBuilder: (_, __) => const SizedBox(width: 7),
                    itemBuilder: (context, index) {
                      final value = index == 0 ? 'Todos' : categories[index - 1];
                      return FilterChip(
                        label: Text(value),
                        selected: category == value,
                        onSelected: (_) {
                          setSheetState(() => category = value);
                        },
                      );
                    },
                  ),
                ),
                const Divider(height: 18),
                Expanded(
                  child: visible.isEmpty
                      ? const Center(child: Text('Nenhum checklist encontrado.'))
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
                          itemCount: visible.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 5),
                          itemBuilder: (context, index) {
                            final template = visible[index];
                            return Card(
                              margin: EdgeInsets.zero,
                              child: ListTile(
                                leading: CircleAvatar(
                                  child: Icon(_checklistIcon(template.category)),
                                ),
                                title: Text(
                                  template.name,
                                  style: const TextStyle(fontWeight: FontWeight.w700),
                                ),
                                subtitle: Text(
                                  [
                                    if (template.category.isNotEmpty) template.category,
                                    if (template.reference.isNotEmpty) template.reference,
                                  ].join(' • '),
                                ),
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () => Navigator.pop(sheetContext, template),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );

    search.dispose();

    if (selected != null && mounted) {
      setState(() => selectedTemplate = selected);
    }
  }

  Future<void> _start() async {
    if (selectedCompany == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione a empresa.')),
      );
      return;
    }

    if (selectedSector == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Selecione o setor. Se ainda não existir, cadastre-o primeiro.',
          ),
        ),
      );
      return;
    }

    if (selectedTemplate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione um checklist.')),
      );
      return;
    }

    final items = await AppDatabase.instance.getChecklistItems(
      selectedTemplate!.id,
    );

    if (items.isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Este checklist não possui perguntas ativas.',
          ),
        ),
      );
      return;
    }

    if (technicianName.text.trim().isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Informe o nome do técnico responsável.',
          ),
        ),
      );
      return;
    }

    final now = DateTime.now();

    final inspection = Inspection(
      id: const Uuid().v4(),
      companyId: selectedCompany!.id,
      workSiteId: selectedSite?.id,
      sectorId: selectedSector!.id,
      area: selectedSector!.name,
      checklistType: selectedTemplate!.name,
      checklistTemplateId: selectedTemplate!.id,
      date: now,
      status: 'Em andamento',
      technicianName: technicianName.text.trim(),
      reportNumber:
          'SST-${DateFormat('yyyyMMdd-HHmmss').format(now)}',
    );

    await AppDatabase.instance.insertInspection(inspection);

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ChecklistScreen(
          inspection: inspection,
          companyName: selectedCompany!.name,
          siteName: selectedSite?.name,
          checklistItems: items,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nova vistoria')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: technicianName,
            decoration: const InputDecoration(
              labelText: 'Técnico responsável *',
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<Company>(
            value: selectedCompany,
            decoration: const InputDecoration(
              labelText: 'Empresa *',
            ),
            items: companies
                .map(
                  (company) => DropdownMenuItem(
                    value: company,
                    child: Text(company.name),
                  ),
                )
                .toList(),
            onChanged: _companyChanged,
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<WorkSite>(
            value: selectedSite,
            decoration: const InputDecoration(
              labelText: 'Obra / Unidade',
              hintText: 'Opcional',
            ),
            items: sites
                .map(
                  (site) => DropdownMenuItem(
                    value: site,
                    child: Text(site.name),
                  ),
                )
                .toList(),
            onChanged: (value) {
              setState(() => selectedSite = value);
            },
          ),
          const SizedBox(height: 14),
          if (selectedCompany == null)
            const InputDecorator(
              decoration: InputDecoration(
                labelText: 'Setor *',
              ),
              child: Text('Selecione primeiro uma empresa'),
            )
          else if (sectors.isEmpty)
            Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Setor *',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Esta empresa ainda não possui setores cadastrados.',
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _registerSector,
                      icon: const Icon(Icons.add),
                      label: const Text('Cadastrar setor agora'),
                    ),
                  ],
                ),
              ),
            )
          else
            DropdownButtonFormField<Sector>(
              value: selectedSector,
              decoration: const InputDecoration(
                labelText: 'Setor *',
              ),
              items: sectors
                  .map(
                    (sector) => DropdownMenuItem(
                      value: sector,
                      child: Text(sector.name),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                setState(() => selectedSector = value);
              },
            ),
          const SizedBox(height: 14),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: templates.isEmpty ? null : _selectChecklist,
            child: InputDecorator(
              decoration: const InputDecoration(
                labelText: 'Checklist *',
              ),
              child: Row(
                children: [
                  Icon(
                    selectedTemplate == null
                        ? Icons.fact_check_outlined
                        : _checklistIcon(selectedTemplate!.category),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: selectedTemplate == null
                        ? const Text(
                            'Toque para escolher na biblioteca',
                            style: TextStyle(color: Colors.black54),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                selectedTemplate!.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              if (selectedTemplate!.category.isNotEmpty)
                                Text(
                                  selectedTemplate!.category,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                            ],
                          ),
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
            ),
          ),
          if (selectedTemplate != null &&
              selectedTemplate!.reference.isNotEmpty) ...[
            const SizedBox(height: 7),
            Text(
              'Referência: ${selectedTemplate!.reference}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _start,
            icon: const Icon(Icons.play_arrow),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Text('INICIAR CHECKLIST'),
            ),
          ),
        ],
      ),
    );
  }
}
