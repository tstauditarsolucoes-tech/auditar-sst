import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import 'checklist_screen.dart';
import 'sectors_screen.dart';

class NewInspectionScreen extends StatefulWidget {
  const NewInspectionScreen({super.key});

  @override
  State<NewInspectionScreen> createState() =>
      _NewInspectionScreenState();
}

class _NewInspectionScreenState extends State<NewInspectionScreen> {
  List<Company> companies = [];
  List<WorkSite> sites = [];
  List<Sector> sectors = [];
  List<ChecklistTemplate> templates = [];

  Company? selectedCompany;
  WorkSite? selectedSite;
  Sector? selectedSector;
  ChecklistTemplate? pendingTemplate;
  final List<ChecklistTemplate> selectedTemplates = [];
  String? selectedChecklistCategory;

  final technicianName = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    technicianName.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;

    final loadedCompanies = await db.getCompanies();
    final loadedTemplates = await db.getChecklistTemplates();
    final defaultTechnician = await db.getSetting(
      'default_technician',
      fallback: '',
    );

    if (!mounted) return;

    setState(() {
      companies = loadedCompanies;
      templates = loadedTemplates;
      technicianName.text = defaultTechnician;
    });
  }

  Future<void> _companyChanged(Company? company) async {
    setState(() {
      selectedCompany = company;
      selectedSite = null;
      selectedSector = null;
      sites = [];
      sectors = [];
    });

    if (company == null) return;

    final results = await Future.wait([
      AppDatabase.instance.getWorkSites(company.id),
      AppDatabase.instance.getSectors(company.id),
    ]);

    if (!mounted) return;

    setState(() {
      sites = results[0] as List<WorkSite>;
      sectors = results[1] as List<Sector>;
    });
  }

  Future<void> _registerSector() async {
    final company = selectedCompany;
    if (company == null) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SectorsScreen(company: company),
      ),
    );

    final loaded = await AppDatabase.instance.getSectors(company.id);
    if (!mounted) return;

    setState(() {
      sectors = loaded;
      selectedSector = null;
    });
  }

  static const List<String> _preferredCategoryOrder = [
    'Normas Regulamentadoras',
    'Panificação',
    'Construção Civil',
    'Cerâmica',
    'Máquinas e Equipamentos',
    'Incêndio e Emergência',
    'Elétrica',
    'EPI',
    'Ergonomia',
    'Produtos Químicos',
    'Espaço Confinado',
    'Outros',
  ];

  List<String> get _checklistCategories {
    final available = templates
        .map((template) => template.category.trim())
        .where((category) => category.isNotEmpty)
        .toSet();

    final ordered = <String>[];
    for (final category in _preferredCategoryOrder) {
      if (available.remove(category)) ordered.add(category);
    }

    final remaining = available.toList()..sort();
    ordered.addAll(remaining);
    return ordered;
  }

  List<ChecklistTemplate> get _filteredTemplates {
    final category = selectedChecklistCategory;
    if (category == null) return const <ChecklistTemplate>[];

    final alreadySelected = selectedTemplates.map((item) => item.id).toSet();

    final filtered = templates
        .where(
          (template) =>
              template.category.trim() == category &&
              !alreadySelected.contains(template.id),
        )
        .toList();
    filtered.sort((a, b) => a.name.compareTo(b.name));
    return filtered;
  }

  void _addChecklist() {
    final template = pendingTemplate;
    if (template == null) return;

    if (selectedTemplates.any((item) => item.id == template.id)) return;

    setState(() {
      selectedTemplates.add(template);
      pendingTemplate = null;
    });
  }

  void _removeChecklist(ChecklistTemplate template) {
    setState(() {
      selectedTemplates.removeWhere((item) => item.id == template.id);
      if (pendingTemplate?.id == template.id) pendingTemplate = null;
    });
  }

  IconData _checklistIcon(String category) {
    switch (category) {
      case 'Normas Regulamentadoras':
        return Icons.menu_book_outlined;
      case 'Construção Civil':
        return Icons.construction;
      case 'Panificação':
        return Icons.bakery_dining;
      case 'Cerâmica':
        return Icons.factory_outlined;
      case 'Máquinas e Equipamentos':
        return Icons.precision_manufacturing_outlined;
      case 'Incêndio e Emergência':
        return Icons.local_fire_department_outlined;
      case 'Elétrica':
        return Icons.electrical_services_outlined;
      case 'EPI':
        return Icons.health_and_safety_outlined;
      case 'Ergonomia':
        return Icons.accessibility_new;
      case 'Produtos Químicos':
        return Icons.science_outlined;
      case 'Espaço Confinado':
        return Icons.sensor_door_outlined;
      default:
        return Icons.fact_check_outlined;
    }
  }

  Future<void> _start() async {
    if (selectedCompany == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione a empresa.')),
      );
      return;
    }

    if (selectedSector == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Selecione o setor. Se ainda não existir, cadastre-o primeiro.',
          ),
        ),
      );
      return;
    }

    if (selectedTemplates.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Selecione pelo menos um checklist.'),
        ),
      );
      return;
    }

    final items = <ChecklistItem>[];
    final templateNames = <String, String>{};

    for (final template in selectedTemplates) {
      final templateItems =
          await AppDatabase.instance.getChecklistItems(template.id);

      if (templateItems.isEmpty) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'O checklist “${template.name}” não possui perguntas ativas.',
            ),
          ),
        );
        return;
      }

      items.addAll(templateItems);
      templateNames[template.id] = template.name;
    }

    if (technicianName.text.trim().isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Informe o nome do técnico responsável.',
          ),
        ),
      );
      return;
    }

    final now = DateTime.now();
    final checklistNames =
        selectedTemplates.map((template) => template.name).join(' + ');
    final checklistIds =
        selectedTemplates.map((template) => template.id).join('|');

    final inspection = Inspection(
      id: const Uuid().v4(),
      companyId: selectedCompany!.id,
      workSiteId: selectedSite?.id,
      sectorId: selectedSector!.id,
      area: selectedSector!.name,
      checklistType: checklistNames,
      checklistTemplateId: checklistIds,
      date: now,
      status: 'Em andamento',
      technicianName: technicianName.text.trim(),
      reportNumber:
          'SST-${DateFormat('yyyyMMdd-HHmmss').format(now)}',
    );

    await AppDatabase.instance.insertInspection(inspection);

    if (!mounted) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChecklistScreen(
          inspection: inspection,
          companyName: selectedCompany!.name,
          siteName: selectedSite?.name,
          checklistItems: items,
          checklistTemplateNames: templateNames,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nova vistoria')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: technicianName,
            decoration: const InputDecoration(
              labelText: 'Técnico responsável *',
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<Company>(
            value: selectedCompany,
            decoration: const InputDecoration(
              labelText: 'Empresa *',
            ),
            items: companies
                .map(
                  (company) => DropdownMenuItem(
                    value: company,
                    child: Text(company.name),
                  ),
                )
                .toList(),
            onChanged: _companyChanged,
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<WorkSite>(
            value: selectedSite,
            decoration: const InputDecoration(
              labelText: 'Obra / Unidade',
              hintText: 'Opcional',
            ),
            items: sites
                .map(
                  (site) => DropdownMenuItem(
                    value: site,
                    child: Text(site.name),
                  ),
                )
                .toList(),
            onChanged: (value) {
              setState(() => selectedSite = value);
            },
          ),
          const SizedBox(height: 14),
          if (selectedCompany == null)
            const InputDecorator(
              decoration: InputDecoration(
                labelText: 'Setor *',
              ),
              child: Text('Selecione primeiro uma empresa'),
            )
          else if (sectors.isEmpty)
            Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Setor *',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Esta empresa ainda não possui setores cadastrados.',
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _registerSector,
                      icon: const Icon(Icons.add),
                      label: const Text('Cadastrar setor agora'),
                    ),
                  ],
                ),
              ),
            )
          else
            DropdownButtonFormField<Sector>(
              value: selectedSector,
              decoration: const InputDecoration(
                labelText: 'Setor *',
              ),
              items: sectors
                  .map(
                    (sector) => DropdownMenuItem(
                      value: sector,
                      child: Text(sector.name),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                setState(() => selectedSector = value);
              },
            ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: selectedChecklistCategory,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Tipo de checklist *',
            ),
            hint: const Text('Selecione o tipo'),
            items: _checklistCategories
                .map(
                  (category) => DropdownMenuItem<String>(
                    value: category,
                    child: Row(
                      children: [
                        Icon(_checklistIcon(category), size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            category,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (!mounted) return;
              setState(() {
                selectedChecklistCategory = value;
                pendingTemplate = null;
              });
            },
          ),
          const SizedBox(height: 14),
          if (selectedChecklistCategory == null)
            const InputDecorator(
              decoration: InputDecoration(
                labelText: 'Checklist *',
              ),
              child: Text('Selecione primeiro o tipo de checklist'),
            )
          else
            DropdownButtonFormField<ChecklistTemplate>(
              value: pendingTemplate,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Checklist para adicionar',
              ),
              hint: const Text('Selecione o checklist'),
              items: _filteredTemplates
                  .map(
                    (template) => DropdownMenuItem<ChecklistTemplate>(
                      value: template,
                      child: Text(
                        template.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (!mounted) return;
                setState(() => pendingTemplate = value);
              },
            ),
          if (pendingTemplate != null &&
              pendingTemplate!.reference.isNotEmpty) ...[
            const SizedBox(height: 7),
            Text(
              'Referência: ${pendingTemplate!.reference}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          if (pendingTemplate != null) ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _addChecklist,
                icon: const Icon(Icons.playlist_add_check_circle_outlined),
                label: const Text('ADICIONAR ESTE CHECKLIST'),
              ),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Checklists selecionados (${selectedTemplates.length})',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              if (selectedTemplates.isNotEmpty)
                TextButton(
                  onPressed: () => setState(selectedTemplates.clear),
                  child: const Text('Limpar'),
                ),
            ],
          ),
          if (selectedTemplates.isEmpty)
            const Card(
              margin: EdgeInsets.only(top: 4),
              child: Padding(
                padding: EdgeInsets.all(13),
                child: Text(
                  'Você pode adicionar um ou vários checklists na mesma vistoria.',
                ),
              ),
            )
          else
            ...selectedTemplates.asMap().entries.map((entry) {
              final index = entry.key + 1;
              final template = entry.value;
              return Card(
                margin: const EdgeInsets.only(top: 7),
                child: ListTile(
                  dense: true,
                  leading: CircleAvatar(
                    radius: 18,
                    child: Text('$index'),
                  ),
                  title: Text(
                    template.name,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    [
                      template.category,
                      if (template.reference.isNotEmpty) template.reference,
                    ].join(' • '),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: IconButton(
                    tooltip: 'Remover checklist',
                    onPressed: () => _removeChecklist(template),
                    icon: const Icon(Icons.close),
                  ),
                ),
              );
            }),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _start,
            icon: const Icon(Icons.play_arrow),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(
                selectedTemplates.length <= 1
                    ? 'INICIAR CHECKLIST'
                    : 'INICIAR ${selectedTemplates.length} CHECKLISTS',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

