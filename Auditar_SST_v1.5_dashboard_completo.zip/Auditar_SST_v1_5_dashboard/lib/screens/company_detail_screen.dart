import 'dart:io';

import 'package:flutter/material.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import 'action_plan_screen.dart';
import 'cipa_screen.dart';
import 'extinguishers_screen.dart';
import 'history_screen.dart';
import 'improvements_screen.dart';
import 'management_panel_screen.dart';
import 'non_conformities_screen.dart';
import 'routine_hub_screen.dart';
import 'safety_observations_screen.dart';
import 'sectors_screen.dart';
import 'worksites_screen.dart';
import 'workers_screen.dart';
import 'trainings_screen.dart';

class CompanyDetailScreen extends StatefulWidget {
  final Company company;

  const CompanyDetailScreen({
    super.key,
    required this.company,
  });

  @override
  State<CompanyDetailScreen> createState() => _CompanyDetailScreenState();
}

class _CompanyDetailScreenState extends State<CompanyDetailScreen> {
  Map<String, int> summary = {};
  List<Map<String, Object?>> sectorPerformance = [];
  int openNcs = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);

    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);
    final result = await AppDatabase.instance.getDashboardSummary(
      companyId: widget.company.id,
      startDate: monthStart,
      endDate: now,
    );
    final sectors = await AppDatabase.instance.getCompanySectorPerformance(
      widget.company.id,
    );
    final ncs = await AppDatabase.instance.getNonConformityRows(
      companyId: widget.company.id,
      includeClosed: false,
    );

    if (!mounted) return;
    setState(() {
      summary = result;
      sectorPerformance = sectors;
      openNcs = ncs.length;
      loading = false;
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _load();
  }

  Widget _companyLogo() {
    final path = widget.company.logoPath;
    if (path != null && path.isNotEmpty && File(path).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: 62,
          height: 62,
          padding: const EdgeInsets.all(5),
          color: Colors.white,
          child: Image.file(File(path), fit: BoxFit.contain),
        ),
      );
    }
    return Container(
      width: 62,
      height: 62,
      decoration: BoxDecoration(
        color: Colors.white12,
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Icon(Icons.business_rounded, color: Colors.white, size: 32),
    );
  }

  int _intValue(Map<String, Object?> row, String key) {
    final value = row[key];
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  int _sectorConformity(Map<String, Object?> row) {
    final c = _intValue(row, 'conformes');
    final p = _intValue(row, 'parciais');
    final nc = _intValue(row, 'nao_conformes');
    final total = c + p + nc;
    if (total == 0) return 0;
    return ((c / total) * 100).round();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.company.name),
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            indicatorColor: AuditarBrand.green,
            indicatorWeight: 3,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(text: 'Visão geral'),
              Tab(text: 'Vistorias'),
              Tab(text: 'NCs'),
              Tab(text: 'Ações'),
            ],
          ),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _overviewTab(),
                  _inspectionsTab(),
                  _ncsTab(),
                  _actionsTab(),
                ],
              ),
      ),
    );
  }

  Widget _overviewTab() {
    final conformity = summary['conformity'] ?? 0;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 26),
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AuditarBrand.navy, AuditarBrand.navyDark],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                _companyLogo(),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.company.name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        [widget.company.city, widget.company.uf]
                            .where((v) => v != null && v!.trim().isNotEmpty)
                            .join(' - '),
                        style: const TextStyle(color: Colors.white70, fontSize: 11.5),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 72,
                  height: 72,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(
                        value: conformity / 100,
                        strokeWidth: 7,
                        color: AuditarBrand.green,
                        backgroundColor: Colors.white24,
                      ),
                      Text(
                        '$conformity%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _metricCard('Vistorias', summary['inspections'] ?? 0, Icons.fact_check_outlined, AuditarBrand.navy)),
              const SizedBox(width: 8),
              Expanded(child: _metricCard('NC abertas', openNcs, Icons.warning_amber_rounded, const Color(0xFFD93025))),
              const SizedBox(width: 8),
              Expanded(child: _metricCard('NC vencidas', summary['ncOverdue'] ?? 0, Icons.schedule_rounded, const Color(0xFFD93025))),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            'Acesso gerencial',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          _shortcut(
            icon: Icons.monitor_heart_outlined,
            title: 'Painel Gerencial',
            subtitle: 'Link individual para a empresa acompanhar indicadores',
            onTap: () => _open(ManagementPanelScreen(company: widget.company)),
          ),
          const SizedBox(height: 14),
          const Text(
            'Organização',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _shortcut(
                  icon: Icons.account_tree_outlined,
                  title: 'Setores',
                  subtitle: 'Gerenciar setores',
                  onTap: () => _open(SectorsScreen(company: widget.company)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _shortcut(
                  icon: Icons.location_on_outlined,
                  title: 'Obras / Unidades',
                  subtitle: 'Locais da empresa',
                  onTap: () => _open(WorkSitesScreen(company: widget.company)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            'Gestão de pessoas',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _shortcut(
                  icon: Icons.groups_rounded,
                  title: 'Trabalhadores',
                  subtitle: 'Cadastro por setor',
                  onTap: () => _open(WorkersScreen(companyId: widget.company.id)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _shortcut(
                  icon: Icons.school_outlined,
                  title: 'Treinamentos',
                  subtitle: 'Novos, turmas, prazos e pendências',
                  onTap: () => _open(TrainingsScreen(companyId: widget.company.id)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _shortcut(
            icon: Icons.upload_file_outlined,
            title: 'Importar lista do RH',
            subtitle: 'Atualizar funcionários por PDF sem cadastrar um por um',
            onTap: () => _open(
              WorkersScreen(
                companyId: widget.company.id,
                startImport: true,
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Registros e melhorias',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          _shortcut(
            icon: Icons.report_problem_outlined,
            title: 'Atos e condições inseguras',
            subtitle: 'Registrar evidências, riscos, tratativas e gerar relatório',
            onTap: () => _open(SafetyObservationsScreen(company: widget.company)),
          ),
          const SizedBox(height: 14),
          _shortcut(
            icon: Icons.auto_awesome_outlined,
            title: 'Melhorias',
            subtitle: 'Sugestões e melhorias realizadas por setor, com fotos antes e depois',
            onTap: () => _open(ImprovementsScreen(company: widget.company)),
          ),
          const SizedBox(height: 14),
          const Text(
            'Equipamentos de emergência',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          _shortcut(
            icon: Icons.fire_extinguisher_rounded,
            title: 'Extintores',
            subtitle: 'Cadastro, validade, vistoria e responsabilidade',
            onTap: () => _open(ExtinguishersScreen(company: widget.company)),
          ),
          const SizedBox(height: 14),
          const Text(
            'Controles SST',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _shortcut(
                  icon: Icons.how_to_vote_outlined,
                  title: 'CIPA',
                  subtitle: 'Eleições e votação',
                  onTap: () => _open(CipaScreen(companyId: widget.company.id)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _shortcut(
                  icon: Icons.dashboard_customize_outlined,
                  title: 'Rotina SST',
                  subtitle: 'Agenda, DDS, APR/PT e incidentes',
                  onTap: () => _open(RoutineHubScreen(companyId: widget.company.id)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Desempenho por setor',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
                ),
              ),
              TextButton(
                onPressed: () => _open(SectorsScreen(company: widget.company)),
                child: const Text('Gerenciar'),
              ),
            ],
          ),
          const SizedBox(height: 4),
          if (sectorPerformance.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text('Nenhum setor cadastrado ou ainda sem dados.'),
              ),
            )
          else
            ...sectorPerformance.map(_sectorCard),
        ],
      ),
    );
  }

  Widget _inspectionsTab() {
    final total = summary['inspections'] ?? 0;
    return _simpleTab(
      icon: Icons.fact_check_rounded,
      color: AuditarBrand.navy,
      title: '$total vistorias neste mês',
      text: 'Consulte o histórico de vistorias, reabra registros e gere os relatórios da empresa.',
      button: 'Abrir histórico de vistorias',
      onPressed: () => _open(HistoryScreen(companyId: widget.company.id)),
    );
  }

  Widget _ncsTab() {
    return _simpleTab(
      icon: Icons.warning_amber_rounded,
      color: const Color(0xFFD93025),
      title: '$openNcs não conformidades abertas',
      text: 'Acompanhe as NCs da empresa, prioridade, setor, responsável e evidências.',
      button: 'Abrir não conformidades',
      onPressed: () => _open(NonConformitiesScreen(companyId: widget.company.id)),
    );
  }

  Widget _actionsTab() {
    final pending = summary['pending'] ?? 0;
    final inProgress = summary['inProgress'] ?? 0;
    final overdue = summary['overdue'] ?? 0;
    final completed = summary['completed'] ?? 0;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Row(
            children: [
              Expanded(child: _metricCard('Pendentes', pending, Icons.pending_actions_rounded, const Color(0xFFF29D18))),
              const SizedBox(width: 8),
              Expanded(child: _metricCard('Em andamento', inProgress, Icons.autorenew_rounded, AuditarBrand.navy)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _metricCard('Vencidas', overdue, Icons.schedule_rounded, const Color(0xFFD93025))),
              const SizedBox(width: 8),
              Expanded(child: _metricCard('Concluídas', completed, Icons.check_circle_outline, AuditarBrand.greenDark)),
            ],
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () => _open(ActionPlanScreen(companyId: widget.company.id)),
            icon: const Icon(Icons.assignment_turned_in_outlined),
            label: const Text('Abrir plano de ação da empresa'),
          ),
        ],
      ),
    );
  }

  Widget _simpleTab({
    required IconData icon,
    required Color color,
    required String title,
    required String text,
    required String button,
    required VoidCallback onPressed,
  }) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: color.withOpacity(.10),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Icon(icon, size: 34, color: color),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: AuditarBrand.navy),
                  ),
                  const SizedBox(height: 7),
                  Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: onPressed,
                      icon: Icon(icon),
                      label: Text(button),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _metricCard(String label, int value, IconData icon, Color color) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 21),
            const SizedBox(height: 5),
            Text('$value', style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5)),
          ],
        ),
      ),
    );
  }

  Widget _shortcut({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 108),
      child: Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF3FA),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(icon, color: AuditarBrand.navy),
              ),
              const SizedBox(height: 9),
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 2),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
            ],
          ),
        ),
      ),
      ),
    );
  }

  Widget _sectorCard(Map<String, Object?> row) {
    final name = '${row['name'] ?? 'Setor'}';
    final inspections = _intValue(row, 'inspections');
    final ncs = _intValue(row, 'open_ncs');
    final conformity = _sectorConformity(row);
    final progressColor = conformity >= 80
        ? AuditarBrand.greenDark
        : conformity >= 60
            ? const Color(0xFFF29D18)
            : const Color(0xFFD93025);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            SizedBox(
              width: 50,
              height: 50,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: conformity / 100,
                    strokeWidth: 5,
                    color: progressColor,
                    backgroundColor: const Color(0xFFE9EDF3),
                  ),
                  Text('$conformity%', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text('$inspections vistorias • $ncs NCs abertas', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: Colors.black38),
          ],
        ),
      ),
    );
  }
}
