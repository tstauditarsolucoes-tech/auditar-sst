import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../database.dart';
import 'action_detail_screen.dart';

class ActionPlanScreen extends StatefulWidget {
  const ActionPlanScreen({super.key});

  @override
  State<ActionPlanScreen> createState() =>
      _ActionPlanScreenState();
}

class _ActionPlanScreenState extends State<ActionPlanScreen> {
  List<Map<String, Object?>> rows = [];
  bool includeCompleted = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getPendingActions(
      includeCompleted: includeCompleted,
    );

    if (mounted) {
      setState(() => rows = result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Plano de ação'),
        actions: [
          IconButton(
            tooltip: includeCompleted
                ? 'Ocultar concluídas'
                : 'Mostrar concluídas',
            onPressed: () {
              setState(() {
                includeCompleted = !includeCompleted;
              });
              _load();
            },
            icon: Icon(
              includeCompleted
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: rows.isEmpty
            ? ListView(
                children: const [
                  SizedBox(height: 180),
                  Center(
                    child: Text(
                      'Nenhuma ação encontrada.',
                    ),
                  ),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final row = rows[i];

                  final dueDate = row['due_date'] == null
                      ? null
                      : DateTime.tryParse(
                          '${row['due_date']}',
                        );

                  final overdue = dueDate != null &&
                      row['status'] != 'Concluído' &&
                      dueDate.isBefore(today);

                  final dueText = dueDate == null
                      ? 'Sem prazo'
                      : DateFormat('dd/MM/yyyy')
                          .format(dueDate);

                  return Card(
                    child: ListTile(
                      contentPadding:
                          const EdgeInsets.all(14),
                      leading: CircleAvatar(
                        child: Icon(
                          row['status'] == 'Concluído'
                              ? Icons.task_alt
                              : overdue
                                  ? Icons.warning_amber_rounded
                                  : Icons.assignment_outlined,
                        ),
                      ),
                      title: Text(
                        '${row['company_name'] ?? '-'}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: Text(
                        [
                          if (row['worksite_name'] != null)
                            '${row['worksite_name']}',
                          '${row['area'] ?? '-'}',
                          'Prioridade: ${row['priority'] ?? '-'}',
                          'Prazo: $dueText${overdue ? ' • VENCIDO' : ''}',
                          'Status: ${row['status'] ?? '-'}',
                        ].join('\n'),
                      ),
                      isThreeLine: true,
                      trailing:
                          const Icon(Icons.chevron_right),
                      onTap: () => Navigator.of(context)
                          .push(
                            MaterialPageRoute(
                              builder: (_) =>
                                  ActionDetailScreen(
                                actionId:
                                    '${row['id']}',
                              ),
                            ),
                          )
                          .then((_) => _load()),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
