import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../brand.dart';
import '../database.dart';
import 'action_detail_screen.dart';

class ActionPlanScreen extends StatefulWidget {
  final String? companyId;

  const ActionPlanScreen({super.key, this.companyId});

  @override
  State<ActionPlanScreen> createState() => _ActionPlanScreenState();
}

class _ActionPlanScreenState extends State<ActionPlanScreen> {
  final searchController = TextEditingController();
  List<Map<String, Object?>> rows = [];
  String selectedFilter = 'Pendências';
  bool loading = true;

  static const filters = <String>[
    'Pendências',
    'Em andamento',
    'Vencidas',
    'Concluídas',
    'Todas',
  ];

  @override
  void initState() {
    super.initState();
    _load();
    searchController.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final result = await AppDatabase.instance.getPendingActions(
      companyId: widget.companyId,
      includeCompleted: true,
    );
    if (!mounted) return;
    setState(() {
      rows = result;
      loading = false;
    });
  }

  bool _isOverdue(Map<String, Object?> row) {
    if ('${row['status']}' == 'Concluído' || row['due_date'] == null) return false;
    final due = DateTime.tryParse('${row['due_date']}');
    if (due == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return DateTime(due.year, due.month, due.day).isBefore(today);
  }

  int _count(String filter) {
    return rows.where((row) {
      final status = '${row['status']}';
      switch (filter) {
        case 'Pendências':
          return status != 'Concluído';
        case 'Em andamento':
          return status == 'Em andamento';
        case 'Vencidas':
          return _isOverdue(row);
        case 'Concluídas':
          return status == 'Concluído';
        default:
          return true;
      }
    }).length;
  }

  List<Map<String, Object?>> get visibleRows {
    final q = searchController.text.trim().toLowerCase();
    return rows.where((row) {
      final status = '${row['status']}';
      final matchesFilter = switch (selectedFilter) {
        'Pendências' => status != 'Concluído',
        'Em andamento' => status == 'Em andamento',
        'Vencidas' => _isOverdue(row),
        'Concluídas' => status == 'Concluído',
        _ => true,
      };
      if (!matchesFilter) return false;
      if (q.isEmpty) return true;
      final haystack = [
        row['company_name'],
        row['nc_code'],
        row['sector_name'],
        row['area'],
        row['non_conformity'],
        row['corrective_action'],
        row['responsible'],
      ].map((e) => '${e ?? ''}'.toLowerCase()).join(' ');
      return haystack.contains(q);
    }).toList();
  }

  Color _priorityColor(String priority) {
    switch (priority) {
      case 'Crítica':
        return const Color(0xFF9B1C1C);
      case 'Alta':
        return const Color(0xFFD93025);
      case 'Média':
        return const Color(0xFFF29D18);
      default:
        return AuditarBrand.greenDark;
    }
  }

  Widget _metric(String label, int value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: .16)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 19),
            const SizedBox(height: 4),
            Text('$value', style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 20)),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleRows;
    return Scaffold(
      appBar: AppBar(title: const Text('Plano de ação')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
          children: [
            Row(
              children: [
                _metric('Pendentes', _count('Pendências'), const Color(0xFFF29D18), Icons.pending_actions),
                const SizedBox(width: 8),
                _metric('Atrasadas', _count('Vencidas'), const Color(0xFFD93025), Icons.event_busy_outlined),
                const SizedBox(width: 8),
                _metric('Concluídas', _count('Concluídas'), AuditarBrand.greenDark, Icons.task_alt),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Buscar ação, NC, responsável...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: searchController.text.isEmpty
                    ? null
                    : IconButton(onPressed: searchController.clear, icon: const Icon(Icons.close)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: filters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (_, index) {
                  final filter = filters[index];
                  return ChoiceChip(
                    selected: selectedFilter == filter,
                    label: Text('$filter ${_count(filter)}'),
                    onSelected: (_) => setState(() => selectedFilter = filter),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 70),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (visible.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 70),
                child: Center(child: Text('Nenhuma ação encontrada neste filtro.')),
              )
            else
              ...visible.map((row) {
                final dueDate = row['due_date'] == null ? null : DateTime.tryParse('${row['due_date']}');
                final overdue = _isOverdue(row);
                final dueText = dueDate == null ? 'Sem prazo' : DateFormat('dd/MM/yyyy').format(dueDate);
                final status = '${row['status'] ?? 'Pendente'}';
                final priority = '${row['priority'] ?? 'Média'}';
                final statusColor = status == 'Concluído'
                    ? AuditarBrand.greenDark
                    : overdue
                        ? const Color(0xFFD93025)
                        : status == 'Em andamento'
                            ? AuditarBrand.navy
                            : const Color(0xFFF29D18);

                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => ActionDetailScreen(actionId: '${row['id']}')))
                        .then((_) => _load()),
                    child: Padding(
                      padding: const EdgeInsets.all(13),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              if ('${row['nc_code'] ?? ''}'.trim().isNotEmpty)
                                Text(
                                  '${row['nc_code']}',
                                  style: const TextStyle(fontSize: 11, color: AuditarBrand.navy, fontWeight: FontWeight.w800),
                                ),
                              const Spacer(),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: statusColor.withValues(alpha: .09),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  overdue ? 'Atrasada' : status,
                                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: statusColor),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _priorityColor(priority).withValues(alpha: .08),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  priority,
                                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _priorityColor(priority)),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 7),
                          Text(
                            '${row['corrective_action'] ?? row['non_conformity'] ?? '-'}',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            [
                              '${row['company_name'] ?? '-'}',
                              if ('${row['sector_name'] ?? ''}'.trim().isNotEmpty) '${row['sector_name']}',
                            ].join(' • '),
                            style: const TextStyle(fontSize: 11, color: Colors.black54),
                          ),
                          const SizedBox(height: 7),
                          Row(
                            children: [
                              const Icon(Icons.person_outline, size: 16, color: Colors.black45),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  '${row['responsible'] ?? ''}'.trim().isEmpty ? 'Sem responsável' : '${row['responsible']}',
                                  style: const TextStyle(fontSize: 10.5, color: Colors.black54),
                                ),
                              ),
                              Icon(Icons.calendar_month_outlined, size: 15, color: overdue ? const Color(0xFFD93025) : Colors.black45),
                              const SizedBox(width: 4),
                              Text(
                                dueText,
                                style: TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  color: overdue ? const Color(0xFFD93025) : Colors.black54,
                                ),
                              ),
                              const SizedBox(width: 2),
                              const Icon(Icons.chevron_right, color: Colors.black38, size: 20),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
