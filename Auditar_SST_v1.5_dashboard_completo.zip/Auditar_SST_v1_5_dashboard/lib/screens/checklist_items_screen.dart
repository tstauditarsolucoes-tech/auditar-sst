import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import 'checklist_preview_screen.dart';

class ChecklistItemsScreen extends StatefulWidget {
  final ChecklistTemplate template;

  const ChecklistItemsScreen({
    super.key,
    required this.template,
  });

  @override
  State<ChecklistItemsScreen> createState() =>
      _ChecklistItemsScreenState();
}

class _ChecklistItemsScreenState
    extends State<ChecklistItemsScreen> {
  List<ChecklistItem> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result =
        await AppDatabase.instance.getChecklistItems(
      widget.template.id,
      onlyActive: false,
    );

    if (!mounted) return;

    setState(() {
      items = result;
      loading = false;
    });
  }

  Future<void> _editItem([
    ChecklistItem? item,
  ]) async {
    final category = TextEditingController(
      text: item?.category ?? '',
    );

    final question = TextEditingController(
      text: item?.text ?? '',
    );

    final reference = TextEditingController(
      text: item?.reference ?? '',
    );

    String priority = item?.priority ?? 'Média';
    bool active = item?.active ?? true;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) =>
            AlertDialog(
          title: Text(
            item == null
                ? 'Nova pergunta'
                : 'Editar pergunta',
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: question,
                  autofocus: item == null,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText:
                        'Pergunta do checklist *',
                    hintText:
                        'Ex.: A proteção da máquina está instalada e em boas condições?',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(
                    labelText: 'Categoria',
                    hintText:
                        'Ex.: Máquinas, EPI, Organização...',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: reference,
                  decoration: const InputDecoration(
                    labelText:
                        'NR / Referência',
                    hintText:
                        'Ex.: NR-12',
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: priority,
                  decoration: const InputDecoration(
                    labelText:
                        'Prioridade padrão',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'Baixa',
                      child: Text('Baixa'),
                    ),
                    DropdownMenuItem(
                      value: 'Média',
                      child: Text('Média'),
                    ),
                    DropdownMenuItem(
                      value: 'Alta',
                      child: Text('Alta'),
                    ),
                    DropdownMenuItem(
                      value: 'Crítica',
                      child: Text('Crítica'),
                    ),
                  ],
                  onChanged: (value) {
                    setDialogState(
                      () => priority =
                          value ?? 'Média',
                    );
                  },
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title:
                      const Text('Pergunta ativa'),
                  subtitle: const Text(
                    'Desative para esconder a pergunta sem excluí-la.',
                  ),
                  value: active,
                  onChanged: (value) {
                    setDialogState(
                      () => active = value,
                    );
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (save != true ||
        question.text.trim().isEmpty) {
      return;
    }

    if (item == null) {
      final order =
          await AppDatabase.instance
              .nextChecklistOrder(
        widget.template.id,
      );

      await AppDatabase.instance
          .insertChecklistItem(
        ChecklistItem(
          id: const Uuid().v4(),
          templateId: widget.template.id,
          sortOrder: order,
          category: category.text.trim(),
          text: question.text.trim(),
          reference:
              reference.text.trim(),
          priority: priority,
          active: active,
        ),
      );
    } else {
      await AppDatabase.instance
          .updateChecklistItem(
        ChecklistItem(
          id: item.id,
          templateId: item.templateId,
          sortOrder: item.sortOrder,
          category: category.text.trim(),
          text: question.text.trim(),
          reference:
              reference.text.trim(),
          priority: priority,
          active: active,
        ),
      );
    }

    await _load();
  }

  Future<void> _addSeveral() async {
    final questions = TextEditingController();
    final category = TextEditingController();
    final reference = TextEditingController(
      text: widget.template.reference,
    );

    String priority = 'Média';

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) =>
            AlertDialog(
          title:
              const Text('Adicionar várias perguntas'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: questions,
                  autofocus: true,
                  minLines: 6,
                  maxLines: 12,
                  decoration: const InputDecoration(
                    labelText:
                        'Uma pergunta por linha *',
                    hintText:
                        'A área está organizada?\nOs EPIs estão sendo utilizados?\nAs proteções das máquinas estão instaladas?',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(
                    labelText:
                        'Categoria para essas perguntas',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: reference,
                  decoration: const InputDecoration(
                    labelText:
                        'NR / Referência',
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: priority,
                  decoration: const InputDecoration(
                    labelText:
                        'Prioridade padrão',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'Baixa',
                      child: Text('Baixa'),
                    ),
                    DropdownMenuItem(
                      value: 'Média',
                      child: Text('Média'),
                    ),
                    DropdownMenuItem(
                      value: 'Alta',
                      child: Text('Alta'),
                    ),
                    DropdownMenuItem(
                      value: 'Crítica',
                      child: Text('Crítica'),
                    ),
                  ],
                  onChanged: (value) {
                    setDialogState(
                      () => priority =
                          value ?? 'Média',
                    );
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton.icon(
              onPressed: () =>
                  Navigator.pop(context, true),
              icon: const Icon(Icons.add),
              label:
                  const Text('Adicionar'),
            ),
          ],
        ),
      ),
    );

    if (save != true) return;

    final lines = questions.text
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .take(100)
        .toList();

    if (lines.isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Digite pelo menos uma pergunta.',
          ),
        ),
      );
      return;
    }

    var order =
        await AppDatabase.instance
            .nextChecklistOrder(
      widget.template.id,
    );

    for (final line in lines) {
      await AppDatabase.instance
          .insertChecklistItem(
        ChecklistItem(
          id: const Uuid().v4(),
          templateId: widget.template.id,
          sortOrder: order,
          category: category.text.trim(),
          text: line,
          reference:
              reference.text.trim(),
          priority: priority,
          active: true,
        ),
      );

      order++;
    }

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(
          '${lines.length} pergunta(s) adicionada(s).',
        ),
      ),
    );
  }

  Future<void> _duplicateItem(
    ChecklistItem item,
  ) async {
    final order =
        await AppDatabase.instance
            .nextChecklistOrder(
      widget.template.id,
    );

    await AppDatabase.instance
        .insertChecklistItem(
      ChecklistItem(
        id: const Uuid().v4(),
        templateId: item.templateId,
        sortOrder: order,
        category: item.category,
        text: '${item.text} - Cópia',
        reference: item.reference,
        priority: item.priority,
        active: item.active,
      ),
    );

    await _load();
  }

  Future<void> _toggleActive(
    ChecklistItem item,
    bool value,
  ) async {
    await AppDatabase.instance
        .updateChecklistItem(
      ChecklistItem(
        id: item.id,
        templateId: item.templateId,
        sortOrder: item.sortOrder,
        category: item.category,
        text: item.text,
        reference: item.reference,
        priority: item.priority,
        active: value,
      ),
    );

    await _load();
  }

  Future<void> _moveItem(
    int currentIndex,
    int targetIndex,
  ) async {
    if (targetIndex < 0 ||
        targetIndex >= items.length ||
        currentIndex == targetIndex) {
      return;
    }

    final reordered =
        List<ChecklistItem>.from(items);

    final moved =
        reordered.removeAt(currentIndex);

    reordered.insert(targetIndex, moved);

    for (var i = 0;
        i < reordered.length;
        i++) {
      final current = reordered[i];

      await AppDatabase.instance
          .updateChecklistItem(
        ChecklistItem(
          id: current.id,
          templateId: current.templateId,
          sortOrder: i + 1,
          category: current.category,
          text: current.text,
          reference: current.reference,
          priority: current.priority,
          active: current.active,
        ),
      );
    }

    await _load();
  }

  Future<void> _deleteItem(
    ChecklistItem item,
  ) async {
    final confirm =
        await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title:
            const Text('Excluir pergunta?'),
        content: Text(item.text),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await AppDatabase.instance
          .deleteChecklistItem(item.id);

      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeCount =
        items.where((item) => item.active).length;

    final inactiveCount =
        items.length - activeCount;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.template.name),
        actions: [
          IconButton(
            tooltip: 'Visualizar checklist',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) =>
                      ChecklistPreviewScreen(
                    template: widget.template,
                  ),
                ),
              );
            },
            icon:
                const Icon(Icons.visibility_outlined),
          ),
        ],
      ),
      floatingActionButton:
          FloatingActionButton.extended(
        onPressed: () => _editItem(),
        icon: const Icon(Icons.add),
        label: const Text('Pergunta'),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ReorderableListView.builder(
              buildDefaultDragHandles: false,
              padding:
                  const EdgeInsets.fromLTRB(
                12,
                12,
                12,
                92,
              ),
              header: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  Card(
                    child: Padding(
                      padding:
                          const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.template.name,
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(
                                  fontWeight:
                                      FontWeight.bold,
                                ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            [
                              if (widget.template
                                  .category.isNotEmpty)
                                widget.template
                                    .category,
                              if (widget.template
                                  .reference.isNotEmpty)
                                widget.template
                                    .reference,
                              '$activeCount ativa(s)',
                              if (inactiveCount > 0)
                                '$inactiveCount desativada(s)',
                            ].join(' • '),
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              FilledButton.icon(
                                onPressed:
                                    () => _editItem(),
                                icon: const Icon(
                                  Icons.add,
                                ),
                                label: const Text(
                                  'Uma pergunta',
                                ),
                              ),
                              OutlinedButton.icon(
                                onPressed:
                                    _addSeveral,
                                icon: const Icon(
                                  Icons.playlist_add,
                                ),
                                label: const Text(
                                  'Várias de uma vez',
                                ),
                              ),
                              OutlinedButton.icon(
                                onPressed: () {
                                  Navigator.of(
                                    context,
                                  ).push(
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          ChecklistPreviewScreen(
                                        template:
                                            widget
                                                .template,
                                      ),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons
                                      .visibility_outlined,
                                ),
                                label: const Text(
                                  'Visualizar',
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (items.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 38,
                      ),
                      child: Center(
                        child: Text(
                          'Nenhuma pergunta ainda.\n'
                          'Adicione uma pergunta ou várias de uma vez.',
                          textAlign:
                              TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
              itemCount: items.length,
              onReorder:
                  (oldIndex, newIndex) async {
                if (newIndex > oldIndex) {
                  newIndex -= 1;
                }

                await _moveItem(
                  oldIndex,
                  newIndex,
                );
              },
              itemBuilder: (_, i) {
                final item = items[i];

                return Card(
                  key: ValueKey(item.id),
                  margin:
                      const EdgeInsets.only(
                    bottom: 8,
                  ),
                  child: Padding(
                    padding:
                        const EdgeInsets.fromLTRB(
                      6,
                      4,
                      2,
                      4,
                    ),
                    child: Row(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding:
                              const EdgeInsets.only(
                            top: 12,
                            left: 4,
                          ),
                          child: CircleAvatar(
                            radius: 19,
                            child:
                                Text('${i + 1}'),
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                            children: [
                              const SizedBox(height: 8),
                              Text(
                                item.text,
                                style:
                                    const TextStyle(
                                  fontWeight:
                                      FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                [
                                  if (item.category
                                      .isNotEmpty)
                                    item.category,
                                  if (item.reference
                                      .isNotEmpty)
                                    item.reference,
                                  'Prioridade ${item.priority}',
                                ].join(' • '),
                                style: Theme.of(
                                  context,
                                )
                                    .textTheme
                                    .bodySmall,
                              ),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Switch(
                                    value:
                                        item.active,
                                    onChanged:
                                        (value) =>
                                            _toggleActive(
                                      item,
                                      value,
                                    ),
                                  ),
                                  Text(
                                    item.active
                                        ? 'Ativa'
                                        : 'Desativada',
                                    style:
                                        Theme.of(
                                      context,
                                    )
                                            .textTheme
                                            .bodySmall,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value ==
                                'edit') {
                              _editItem(item);
                            } else if (value ==
                                'duplicate') {
                              _duplicateItem(
                                item,
                              );
                            } else if (value ==
                                'up') {
                              _moveItem(
                                i,
                                i - 1,
                              );
                            } else if (value ==
                                'down') {
                              _moveItem(
                                i,
                                i + 1,
                              );
                            } else if (value ==
                                'delete') {
                              _deleteItem(
                                item,
                              );
                            }
                          },
                          itemBuilder: (_) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Text(
                                'Editar pergunta',
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'duplicate',
                              child: Text(
                                'Duplicar pergunta',
                              ),
                            ),
                            if (i > 0)
                              const PopupMenuItem(
                                value: 'up',
                                child: Text(
                                  'Mover para cima',
                                ),
                              ),
                            if (i <
                                items.length - 1)
                              const PopupMenuItem(
                                value: 'down',
                                child: Text(
                                  'Mover para baixo',
                                ),
                              ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Text(
                                'Excluir pergunta',
                              ),
                            ),
                          ],
                        ),
                        ReorderableDragStartListener(
                          index: i,
                          child: const Padding(
                            padding:
                                EdgeInsets.fromLTRB(
                              2,
                              13,
                              8,
                              13,
                            ),
                            child: Icon(
                              Icons.drag_handle,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
