import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../brand.dart';
import '../database.dart';
import '../widgets/responsive_wrap.dart';
import '../services/drive_service.dart';
import '../services/pdf_service.dart';
import '../services/report_file_service.dart';
import 'non_conformities_screen.dart';

class ReportScreen extends StatefulWidget {
  final String inspectionId;
  final String title;

  const ReportScreen({
    super.key,
    required this.inspectionId,
    required this.title,
  });

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  int conformes = 0;
  int naoConformes = 0;
  int parciais = 0;
  int na = 0;

  bool driveLinked = false;
  bool autoUpload = false;
  bool driveBusy = false;
  bool pdfBusy = false;
  String driveStatus = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final answers = await db.getAnswers(widget.inspectionId);

    final enabled = await db.getSetting(
      'drive_enabled',
      fallback: 'false',
    );

    final auto = await db.getSetting(
      'drive_auto_upload',
      fallback: 'true',
    );

    final existing =
        await db.getDriveUploadForInspection(widget.inspectionId);

    if (!mounted) return;

    setState(() {
      conformes = answers.where((e) => e.status == 'Conforme').length;
      naoConformes =
          answers.where((e) => e.status == 'Não Conforme').length;
      parciais = answers.where((e) => e.status == 'Parcial').length;
      na = answers.where((e) => e.status == 'Não se aplica').length;
      driveLinked = enabled == 'true';
      autoUpload = auto == 'true';

      if (existing != null) {
        final status = '${existing['status'] ?? ''}';

        if (status == 'Enviado') {
          driveStatus = 'Salvo no Google Drive';
        } else if (status == 'Pendente') {
          driveStatus = 'Aguardando sincronização com o Google Drive';
        }
      }
    });

    if (driveLinked &&
        autoUpload &&
        (existing == null || existing['status'] != 'Enviado')) {
      await _sendToDrive(silent: true);
    }
  }

  Future<void> _sharePdf({required bool executive}) async {
    if (pdfBusy) return;
    setState(() => pdfBusy = true);

    try {
      final bytes = await PdfService.generateInspectionPdf(
        widget.inspectionId,
        executive: executive,
      );

      await Printing.sharePdf(
        bytes: bytes,
        filename: executive
            ? 'Relatorio_Executivo_Auditar_SST.pdf'
            : 'Relatorio_Completo_Auditar_SST.pdf',
      );
    } finally {
      if (mounted) setState(() => pdfBusy = false);
    }
  }

  Future<void> _saveLocal({required bool executive}) async {
    try {
      final path = await ReportFileService.savePdfLocally(
        widget.inspectionId,
        executive: executive,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            executive
                ? 'Relatório executivo salvo: $path'
                : 'Relatório completo salvo: $path',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Não foi possível salvar: $e'),
        ),
      );
    }
  }

  Future<void> _sendToDrive({bool silent = false}) async {
    if (driveBusy) return;

    setState(() => driveBusy = true);

    try {
      final result = await DriveService.saveReportToDrive(
        widget.inspectionId,
        interactive: !silent,
      );

      if (!mounted) return;

      setState(() {
        driveStatus = result.uploaded
            ? 'Salvo no Google Drive'
            : result.queued
                ? 'Aguardando sincronização com o Google Drive'
                : result.message;
      });

      if (!silent) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.message)),
        );
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        driveStatus = 'Falha ao enviar ao Google Drive';
      });

      if (!silent) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Não foi possível enviar ao Drive: $e'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => driveBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final considered = conformes + parciais + naoConformes;
    final conformity =
        considered == 0 ? 0 : (conformes / considered * 100).round();

    return Scaffold(
      backgroundColor: AuditarBrand.background,
      appBar: AppBar(
        title: const Text('Relatórios'),
        backgroundColor: AuditarBrand.navyDark,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          _heroCard(conformity),
          const SizedBox(height: 14),
          ResponsiveWrap(
            minItemWidth: 112,
            maxColumns: 4,
            children: [
              _metric(
                'Conformes',
                '$conformes',
                Icons.check_circle_outline,
                Colors.green.shade700,
              ),
              _metric(
                'NCs',
                '$naoConformes',
                Icons.warning_amber_rounded,
                Colors.red.shade700,
              ),
              _metric(
                'Parciais',
                '$parciais',
                Icons.timelapse_rounded,
                Colors.orange.shade800,
              ),
              _metric(
                'N/A',
                '$na',
                Icons.remove_circle_outline,
                Colors.grey.shade700,
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'Escolha o formato',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AuditarBrand.navyDark,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Os dois formatos usam a identidade visual Auditar SST e podem ser compartilhados em PDF.',
            style: TextStyle(color: Colors.grey.shade700),
          ),
          const SizedBox(height: 12),
          _reportOption(
            title: 'Relatório Completo',
            subtitle:
                'Capa, resumo, NCs e parciais, fotos, plano de ação, checklist completo, antes/depois, conclusão e assinaturas.',
            icon: Icons.description_outlined,
            recommended: true,
            onShare: () => _sharePdf(executive: false),
            onSave: () => _saveLocal(executive: false),
          ),
          const SizedBox(height: 10),
          _reportOption(
            title: 'Relatório Executivo',
            subtitle:
                'Versão mais curta para gerência, com indicadores, pontos de atenção, ações e conclusão.',
            icon: Icons.assessment_outlined,
            onShare: () => _sharePdf(executive: true),
            onSave: () => _saveLocal(executive: true),
          ),
          const SizedBox(height: 14),
          if (naoConformes > 0)
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => NonConformitiesScreen(
                    inspectionId: widget.inspectionId,
                  ),
                ),
              ),
              icon: const Icon(Icons.warning_amber_rounded),
              label: Text('ABRIR NÃO CONFORMIDADES ($naoConformes)'),
            ),
          if (driveLinked) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: driveBusy ? null : () => _sendToDrive(),
              icon: const Icon(Icons.add_to_drive),
              label: Text(
                driveBusy ? 'Enviando...' : 'Salvar relatório no Google Drive',
              ),
            ),
            if (driveStatus.isNotEmpty) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    driveStatus.contains('Salvo')
                        ? Icons.cloud_done_outlined
                        : Icons.cloud_upload_outlined,
                    size: 19,
                    color: driveStatus.contains('Salvo')
                        ? Colors.green.shade700
                        : Colors.grey.shade700,
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      driveStatus,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ],
          ],
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            icon: const Icon(Icons.home_outlined),
            label: const Text('Voltar ao início'),
          ),
        ],
      ),
    );
  }

  Widget _heroCard(int conformity) {
    Color statusColor;
    String statusText;

    if (conformity >= 90) {
      statusColor = Colors.green.shade700;
      statusText = 'Excelente nível de conformidade';
    } else if (conformity >= 75) {
      statusColor = Colors.orange.shade800;
      statusText = 'Atenção a alguns pontos';
    } else {
      statusColor = Colors.red.shade700;
      statusText = 'Necessita acompanhamento prioritário';
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AuditarBrand.navyDark, AuditarBrand.navy],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 78,
            height: 78,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.10),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(.20)),
            ),
            child: Text(
              '$conformity%',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Relatório da vistoria',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white.withOpacity(.88)),
                ),
                const SizedBox(height: 9),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    statusText,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _reportOption({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onShare,
    required VoidCallback onSave,
    bool recommended = false,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey.shade300),
      ),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AuditarBrand.green.withOpacity(.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: AuditarBrand.greenDark),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              title,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: AuditarBrand.navyDark,
                              ),
                            ),
                          ),
                          if (recommended)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AuditarBrand.green.withOpacity(.12),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text(
                                'RECOMENDADO',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: AuditarBrand.greenDark,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        subtitle,
                        style: TextStyle(
                          height: 1.35,
                          color: Colors.grey.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: pdfBusy ? null : onShare,
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    label: Text(pdfBusy ? 'Gerando...' : 'Gerar / compartilhar'),
                    style: FilledButton.styleFrom(
                      backgroundColor: AuditarBrand.greenDark,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.outlined(
                  tooltip: 'Salvar no aparelho',
                  onPressed: onSave,
                  icon: const Icon(Icons.download_outlined),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _metric(
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        children: [
          Icon(icon, size: 19, color: color),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 10, height: 1.1, color: Colors.grey.shade700),
          ),
        ],
      ),
    );
  }
}
