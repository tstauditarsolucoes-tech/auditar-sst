import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../database.dart';
import '../services/drive_service.dart';
import '../services/pdf_service.dart';
import '../services/report_file_service.dart';

class ReportScreen extends StatefulWidget {
  final String inspectionId;
  final String title;

  const ReportScreen({
    super.key,
    required this.inspectionId,
    required this.title,
  });

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  int conformes = 0;
  int naoConformes = 0;
  int na = 0;

  bool driveLinked = false;
  bool autoUpload = false;
  bool driveBusy = false;
  String driveStatus = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final answers = await db.getAnswers(widget.inspectionId);

    final enabled = await db.getSetting(
      'drive_enabled',
      fallback: 'false',
    );

    final auto = await db.getSetting(
      'drive_auto_upload',
      fallback: 'true',
    );

    final existing =
        await db.getDriveUploadForInspection(widget.inspectionId);

    if (!mounted) return;

    setState(() {
      conformes = answers.where((e) => e.status == 'Conforme').length;
      naoConformes =
          answers.where((e) => e.status == 'Não Conforme').length;
      na = answers.where((e) => e.status == 'Não se aplica').length;
      driveLinked = enabled == 'true';
      autoUpload = auto == 'true';

      if (existing != null) {
        final status = '${existing['status'] ?? ''}';

        if (status == 'Enviado') {
          driveStatus = 'Salvo no Google Drive';
        } else if (status == 'Pendente') {
          driveStatus = 'Aguardando sincronização com o Google Drive';
        }
      }
    });

    if (driveLinked &&
        autoUpload &&
        (existing == null || existing['status'] != 'Enviado')) {
      await _sendToDrive(silent: true);
    }
  }

  Future<void> _sharePdf() async {
    final bytes =
        await PdfService.generateInspectionPdf(widget.inspectionId);

    await Printing.sharePdf(
      bytes: bytes,
      filename: 'Relatorio_Inspecao_SST.pdf',
    );
  }

  Future<void> _saveLocal() async {
    try {
      final path =
          await ReportFileService.savePdfLocally(widget.inspectionId);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Relatório salvo no aparelho: $path'),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Não foi possível salvar: $e'),
        ),
      );
    }
  }

  Future<void> _sendToDrive({bool silent = false}) async {
    if (driveBusy) return;

    setState(() => driveBusy = true);

    try {
      final result = await DriveService.saveReportToDrive(
        widget.inspectionId,
        interactive: !silent,
      );

      if (!mounted) return;

      setState(() {
        driveStatus = result.uploaded
            ? 'Salvo no Google Drive'
            : result.queued
                ? 'Aguardando sincronização com o Google Drive'
                : result.message;
      });

      if (!silent) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.message)),
        );
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        driveStatus = 'Falha ao enviar ao Google Drive';
      });

      if (!silent) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Não foi possível enviar ao Drive: $e'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => driveBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final considered = conformes + naoConformes;
    final conformity =
        considered == 0 ? 0 : (conformes / considered * 100).round();

    return Scaffold(
      appBar: AppBar(title: const Text('Relatório da vistoria')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'O relatório fica disponível no aparelho e pode ser compartilhado ou enviado ao Google Drive.',
                  ),
                  if (driveStatus.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          driveStatus.contains('Salvo')
                              ? Icons.cloud_done_outlined
                              : Icons.cloud_upload_outlined,
                          size: 20,
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: Text(
                            driveStatus,
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _metric('Conformes', '$conformes')),
              const SizedBox(width: 8),
              Expanded(
                child: _metric(
                  'Não conformes',
                  '$naoConformes',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _metric('N/A', '$na')),
              const SizedBox(width: 8),
              Expanded(
                child: _metric(
                  'Conformidade',
                  '$conformity%',
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _sharePdf,
            icon: const Icon(Icons.share),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Text(
                'GERAR / COMPARTILHAR PDF',
              ),
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _saveLocal,
            icon: const Icon(Icons.save_alt),
            label: const Text(
              'SALVAR PDF NO APARELHO',
            ),
          ),
          if (driveLinked) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed:
                  driveBusy ? null : () => _sendToDrive(),
              icon: const Icon(Icons.add_to_drive),
              label: Text(
                driveBusy
                    ? 'ENVIANDO...'
                    : 'SALVAR NO GOOGLE DRIVE',
              ),
            ),
          ],
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () {
              Navigator.of(context).popUntil(
                (route) => route.isFirst,
              );
            },
            icon: const Icon(Icons.home),
            label: const Text('VOLTAR AO INÍCIO'),
          ),
        ],
      ),
    );
  }

  Widget _metric(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text(
              label,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
