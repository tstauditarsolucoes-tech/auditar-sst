import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import '../services/ai_assistant_service.dart';
import '../services/storage_service.dart';
import 'signature_screen.dart';

class _QuickResponsePreset {
  final String title;
  final List<String> keywords;
  final String description;
  final String risk;
  final String recommendation;
  final String? priority;

  const _QuickResponsePreset({
    required this.title,
    required this.keywords,
    required this.description,
    required this.risk,
    required this.recommendation,
    this.priority,
  });
}

class ChecklistScreen extends StatefulWidget {
  final Inspection inspection;
  final String companyName;
  final String? siteName;
  final List<ChecklistItem> checklistItems;
  final Map<String, String> checklistTemplateNames;
  final bool editExisting;

  const ChecklistScreen({
    super.key,
    required this.inspection,
    required this.companyName,
    this.siteName,
    required this.checklistItems,
    this.checklistTemplateNames = const {},
    this.editExisting = false,
  });

  @override
  State<ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<ChecklistScreen> with WidgetsBindingObserver {
  final ImagePicker picker = ImagePicker();

  final Map<String, String> statuses = {};
  final Map<String, TextEditingController> observations = {};
  final Map<String, TextEditingController> risks = {};
  final Map<String, TextEditingController> recommendations = {};
  final Map<String, String> priorities = {};
  final Map<String, List<String>> photos = {};

  final Map<String, String> existingAnswerIds = {};
  final Map<String, NonConformity> existingNcs = {};

  bool loadingExisting = false;
  bool saving = false;
  bool draftSaving = false;
  Timer? draftSaveTimer;
  final Set<String> analyzingItems = {};

  static const List<_QuickResponsePreset> _quickResponsePresets = [
    _QuickResponsePreset(
      title: 'Extintor obstruído ou sem acesso livre',
      keywords: ['extintor', 'desobstruído', 'acesso imediato'],
      description:
          'O extintor encontra-se obstruído ou com o acesso dificultado.',
      risk:
          'Dificuldade de acesso ao equipamento e atraso no combate inicial a incêndio.',
      recommendation:
          'Desobstruir imediatamente o acesso ao extintor e manter a área sinalizada e permanentemente livre.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Proteção ausente ou inadequada',
      keywords: [
        'proteção',
        'protegida',
        'carenagem',
        'guarda-corpo',
        'rodapé',
        'intertravamento',
        'zona perigosa',
        'partes móveis',
      ],
      description:
          'Foi identificada ausência, inadequação ou dano na proteção de segurança.',
      risk:
          'Risco de contato com a zona perigosa, podendo causar corte, esmagamento, aprisionamento ou outro acidente grave.',
      recommendation:
          'Interromper o uso quando houver risco grave e instalar ou adequar a proteção antes da liberação da atividade.',
      priority: 'Crítica',
    ),
    _QuickResponsePreset(
      title: 'Trabalhador sem o EPI necessário',
      keywords: [
        'epi',
        'capacete',
        'óculos',
        'protetor',
        'cinturão',
        'calçado',
        'luva',
      ],
      description:
          'Foi observado trabalhador executando a atividade sem utilizar todos os EPIs necessários.',
      risk:
          'Exposição do trabalhador aos riscos da atividade, com possibilidade de lesão ou agravamento de acidente.',
      recommendation:
          'Fornecer o EPI adequado, orientar o trabalhador e fiscalizar o uso correto durante toda a atividade.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Área obstruída ou desorganizada',
      keywords: [
        'organização',
        'circulação',
        'obstruído',
        'acesso',
        'resíduos',
        'limpa',
        'obstáculos',
      ],
      description:
          'A área apresenta materiais, resíduos ou obstáculos prejudicando a organização e a circulação segura.',
      risk:
          'Risco de tropeço, queda, colisão e dificuldade de acesso ou evacuação.',
      recommendation:
          'Retirar os obstáculos e resíduos, organizar os materiais e manter as áreas de circulação permanentemente livres.',
      priority: 'Média',
    ),
    _QuickResponsePreset(
      title: 'Instalação elétrica inadequada',
      keywords: [
        'elétrica',
        'elétrico',
        'cabo',
        'plugue',
        'tomada',
        'aterramento',
        'quadro',
        'choque',
      ],
      description:
          'Foram identificados componentes elétricos danificados, expostos, sem proteção adequada ou com improvisações.',
      risk:
          'Risco de choque elétrico, curto-circuito, queimadura e incêndio.',
      recommendation:
          'Isolar a condição insegura e providenciar a correção por profissional autorizado antes da utilização.',
      priority: 'Crítica',
    ),
    _QuickResponsePreset(
      title: 'Sinalização ou isolamento insuficiente',
      keywords: [
        'sinalização',
        'isolamento',
        'sinalizada',
        'isolada',
        'placa',
        'cone',
        'barreira',
      ],
      description:
          'A área de risco não está devidamente sinalizada ou isolada.',
      risk:
          'Entrada ou aproximação indevida de pessoas, aumentando a possibilidade de acidente.',
      recommendation:
          'Instalar sinalização visível e realizar o isolamento adequado da área enquanto o risco permanecer.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Risco de queda ou trabalho em altura',
      keywords: [
        'queda',
        'altura',
        'andaime',
        'ancoragem',
        'abertura',
        'desnível',
        'plataforma',
      ],
      description:
          'A atividade ou o local apresenta proteção insuficiente contra queda de pessoas ou materiais.',
      risk:
          'Risco de queda com possibilidade de lesão grave ou fatal.',
      recommendation:
          'Suspender a exposição, isolar a área e instalar as medidas de proteção coletiva e individual aplicáveis antes de retomar a atividade.',
      priority: 'Crítica',
    ),
    _QuickResponsePreset(
      title: 'Componente danificado ou sem conservação',
      keywords: [
        'conservação',
        'condições',
        'danos',
        'trinca',
        'deformação',
        'vedação',
        'puxador',
        'porta',
        'estrutura',
      ],
      description:
          'O equipamento, estrutura ou componente apresenta desgaste, dano ou condição inadequada de conservação.',
      risk:
          'Risco de falha durante o uso, podendo ocasionar acidente ou agravar a exposição existente.',
      recommendation:
          'Realizar manutenção ou substituição do componente e liberar o uso somente após a verificação das condições de segurança.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Treinamento ou autorização não comprovados',
      keywords: [
        'treinamento',
        'capacitado',
        'capacitação',
        'orientado',
        'autorizado',
      ],
      description:
          'Não foi apresentado registro válido de treinamento, capacitação ou autorização para a atividade.',
      risk:
          'Execução da atividade sem comprovação de conhecimento dos riscos e procedimentos de segurança.',
      recommendation:
          'Regularizar o treinamento e o registro obrigatório antes de autorizar o trabalhador a executar a atividade.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Procedimento de trabalho inseguro',
      keywords: [
        'procedimento',
        'limpeza',
        'intervenção',
        'ajuste',
        'desobstrução',
        'operação',
        'manutenção',
      ],
      description:
          'A atividade está sendo realizada sem procedimento seguro ou com descumprimento das medidas previstas.',
      risk:
          'Risco de acidente durante a execução, limpeza, ajuste ou manutenção.',
      recommendation:
          'Interromper a prática insegura, orientar a equipe e implantar ou reforçar o procedimento correto antes de continuar.',
      priority: 'Alta',
    ),
    _QuickResponsePreset(
      title: 'Condição ergonômica inadequada',
      keywords: [
        'ergonomia',
        'postura',
        'esforço',
        'movimentação manual',
        'levantamento',
        'calor',
      ],
      description:
          'A atividade apresenta esforço excessivo, postura inadequada ou condição desfavorável ao trabalhador.',
      risk:
          'Risco de desconforto, fadiga e lesões musculoesqueléticas.',
      recommendation:
          'Adequar o posto e a forma de execução, orientar o trabalhador e adotar pausas ou meios auxiliares quando aplicáveis.',
      priority: 'Média',
    ),
    _QuickResponsePreset(
      title: 'Risco de incêndio, gás ou combustível',
      keywords: [
        'incêndio',
        'combustível',
        'gás',
        'vazamento',
        'forno',
        'ignição',
      ],
      description:
          'Foi identificada condição inadequada envolvendo combustível, gás, fonte de ignição ou material inflamável.',
      risk:
          'Risco de vazamento, incêndio, explosão ou queimadura.',
      recommendation:
          'Eliminar a fonte de risco, verificar as instalações e manter disponíveis as medidas de prevenção e resposta a emergências.',
      priority: 'Crítica',
    ),
    _QuickResponsePreset(
      title: 'Atendimento apenas parcial',
      keywords: const [],
      description:
          'O requisito está sendo atendido apenas parcialmente e necessita de adequação para alcançar a conformidade total.',
      risk:
          'A medida existente reduz o risco, mas ainda não garante proteção suficiente.',
      recommendation:
          'Complementar as medidas existentes e verificar novamente o item após a adequação.',
      priority: 'Média',
    ),
    _QuickResponsePreset(
      title: 'Outra condição inadequada',
      keywords: const [],
      description:
          'Foi identificada condição inadequada durante a inspeção.',
      risk:
          'Possibilidade de acidente ou exposição do trabalhador ao risco identificado.',
      recommendation:
          'Corrigir a condição identificada, orientar os envolvidos e verificar a eficácia da medida adotada.',
      priority: 'Média',
    ),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    for (final item in widget.checklistItems) {
      observations[item.id] = TextEditingController();
      risks[item.id] = TextEditingController();
      recommendations[item.id] = TextEditingController();
      priorities[item.id] = item.priority;
      photos[item.id] = [];

      observations[item.id]!.addListener(_scheduleDraftSave);
      risks[item.id]!.addListener(_scheduleDraftSave);
      recommendations[item.id]!.addListener(_scheduleDraftSave);
    }

    if (widget.editExisting) {
      loadingExisting = true;
      _loadExistingData();
    }
  }

  Future<void> _loadExistingData() async {
    final db = AppDatabase.instance;
    final answers = await db.getAnswers(widget.inspection.id);

    for (final answer in answers) {
      if (!observations.containsKey(answer.questionId)) continue;

      existingAnswerIds[answer.questionId] = answer.id;
      if (const ['Conforme', 'Não Conforme', 'Parcial', 'N/A'].contains(answer.status)) {
        statuses[answer.questionId] = answer.status;
      }
      observations[answer.questionId]!.text = answer.observation;
      risks[answer.questionId]!.text = answer.riskIdentified;
      recommendations[answer.questionId]!.text = answer.recommendation;

      final evidence = await db.getPhotosForAnswer(answer.id);
      photos[answer.questionId] =
          evidence.map((photo) => photo.path).toList();

      final nc = await db.getNonConformityForAnswer(answer.id);
      if (nc != null) {
        existingNcs[answer.questionId] = nc;
        priorities[answer.questionId] = nc.classification;
      }
    }

    if (!mounted) return;
    setState(() => loadingExisting = false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    draftSaveTimer?.cancel();
    if (!saving && !draftSaving && !loadingExisting) {
      unawaited(_saveDraft());
    }
    for (final controller in observations.values) {
      controller.dispose();
    }
    for (final controller in risks.values) {
      controller.dispose();
    }
    for (final controller in recommendations.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      draftSaveTimer?.cancel();
      unawaited(_saveDraft());
    }
  }

  void _scheduleDraftSave() {
    if (saving || draftSaving || loadingExisting) return;
    draftSaveTimer?.cancel();
    draftSaveTimer = Timer(const Duration(milliseconds: 700), () {
      unawaited(_saveDraft());
    });
  }

  Future<void> _saveDraft({bool showMessage = false}) async {
    if (saving || draftSaving || loadingExisting) return;

    draftSaveTimer?.cancel();
    draftSaving = true;

    const uuid = Uuid();
    final snapshot = <Map<String, Object?>>[];

    for (final item in widget.checklistItems) {
      final status = statuses[item.id] ?? '';
      final observation = observations[item.id]!.text.trim();
      final risk = risks[item.id]!.text.trim();
      final recommendation = recommendations[item.id]!.text.trim();
      final evidence = List<String>.from(photos[item.id] ?? const <String>[]);

      final hasDraft = status.isNotEmpty ||
          observation.isNotEmpty ||
          risk.isNotEmpty ||
          recommendation.isNotEmpty ||
          evidence.isNotEmpty;

      if (!hasDraft) continue;

      snapshot.add({
        'item': item,
        'status': status,
        'observation': observation,
        'risk': risk,
        'recommendation': recommendation,
        'evidence': evidence,
        'priority': priorities[item.id] ?? item.priority,
      });
    }

    try {
      final db = AppDatabase.instance;

      for (final entry in snapshot) {
        final item = entry['item'] as ChecklistItem;
        final existingAnswerId = existingAnswerIds[item.id];
        final answerId = existingAnswerId ?? uuid.v4();
        final status = entry['status'] as String;
        final observation = entry['observation'] as String;
        final risk = entry['risk'] as String;
        final recommendation = entry['recommendation'] as String;
        final evidence = entry['evidence'] as List<String>;
        final priority = entry['priority'] as String;

        final answer = InspectionAnswer(
          id: answerId,
          inspectionId: widget.inspection.id,
          questionId: item.id,
          questionText: item.text,
          questionCategory: item.category,
          questionReference: item.reference,
          status: status,
          observation: observation,
          riskIdentified: risk,
          recommendation: recommendation,
        );

        await db.upsertAnswer(answer);
        existingAnswerIds[item.id] = answerId;

        final photoRows = <EvidencePhoto>[];
        for (var i = 0; i < evidence.length; i++) {
          photoRows.add(
            EvidencePhoto(
              id: uuid.v4(),
              answerId: answerId,
              path: evidence[i],
              sortOrder: i,
            ),
          );
        }

        await db.replaceEvidencePhotos(
          answerId: answerId,
          photos: photoRows,
        );

        final oldNc = existingNcs[item.id] ??
            await db.getNonConformityForAnswer(answerId);

        if (status == 'Não Conforme') {
          final cleanId = answerId.replaceAll('-', '');
          final shortId = cleanId.length >= 6
              ? cleanId.substring(0, 6)
              : cleanId;
          final nc = NonConformity(
            id: oldNc?.id ?? uuid.v4(),
            inspectionId: widget.inspection.id,
            answerId: answerId,
            code: oldNc?.code ??
                'NC-${widget.inspection.reportNumber}-$shortId',
            description: observation,
            riskIdentified: risk,
            recommendation: recommendation,
            classification: priority,
            status: oldNc?.status ?? 'Pendente',
            createdAt: oldNc?.createdAt ?? DateTime.now(),
          );
          await db.upsertNonConformity(nc);
          existingNcs[item.id] = nc;
        } else if (oldNc != null) {
          await db.removeOrCloseNonConformityForAnswer(answerId);
          existingNcs.remove(item.id);
        }
      }

      await db.markInspectionInProgress(widget.inspection.id);
      if (showMessage && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Vistoria salva como rascunho. Você pode continuar depois pelo Histórico.',
            ),
          ),
        );
      }
    } finally {
      draftSaving = false;
    }
  }

  Future<void> _saveDraftAndExit() async {
    await _saveDraft(showMessage: true);
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _takePhoto(String itemId) async {
    final image = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
      maxWidth: 1800,
    );

    if (image == null) return;

    final storedPath = await StorageService.persistImage(
      image.path,
      folder: 'fotos_vistorias',
    );

    if (mounted) {
      setState(() => photos[itemId]!.add(storedPath));
      _scheduleDraftSave();
    }
  }

  Future<void> _choosePhotos(String itemId) async {
    final images = await picker.pickMultiImage(
      imageQuality: 75,
      maxWidth: 1800,
    );

    if (images.isEmpty) return;

    final current = photos[itemId] ?? [];
    final remaining = 10 - current.length;
    if (remaining <= 0) return;

    final added = <String>[];

    for (final image in images.take(remaining)) {
      final storedPath = await StorageService.persistImage(
        image.path,
        folder: 'fotos_vistorias',
      );
      added.add(storedPath);
    }

    if (mounted) {
      setState(() => photos[itemId]!.addAll(added));
      _scheduleDraftSave();
    }
  }

  void _removePhoto(String itemId, int index) {
    setState(() {
      photos[itemId]!.removeAt(index);
    });
    _scheduleDraftSave();
  }

  Future<void> _analyzeWithAi(ChecklistItem item) async {
    final evidence = photos[item.id] ?? [];
    if (evidence.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tire ou escolha pelo menos uma foto antes de analisar.'),
        ),
      );
      return;
    }

    setState(() => analyzingItems.add(item.id));
    final reply = await AiAssistantService.analyzeChecklistPhotos(
      inspection: widget.inspection,
      companyName: widget.companyName,
      item: item,
      photoPaths: evidence,
      technicianContext: observations[item.id]!.text,
    );
    if (mounted) setState(() => analyzingItems.remove(item.id));
    if (!mounted) return;

    if (!reply.success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(reply.message)),
      );
      return;
    }

    final result = reply.result;
    final description = '${result['description'] ?? ''}'.trim();
    final risk = '${result['risk'] ?? ''}'.trim();
    final recommendation = '${result['recommendation'] ?? ''}'.trim();
    final immediateAction = '${result['immediateAction'] ?? ''}'.trim();
    final correctiveAction = '${result['correctiveAction'] ?? ''}'.trim();
    final responsibleProfile = '${result['responsibleProfile'] ?? ''}'.trim();
    final suggestedDeadlineDays = result['suggestedDeadlineDays'];
    final priority = '${result['priority'] ?? 'Média'}'.trim();
    final confidence = '${result['confidence'] ?? 'Média'}'.trim();
    final references = (result['likelyReferences'] as List? ?? const [])
        .map((value) => '$value')
        .where((value) => value.trim().isNotEmpty)
        .toList();
    final checks = (result['checksRequired'] as List? ?? const [])
        .map((value) => '$value')
        .where((value) => value.trim().isNotEmpty)
        .toList();

    final useSuggestion = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sugestão da IA'),
        content: SizedBox(
          width: 620,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.amber.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Rascunho de apoio. Confirme a situação no local e edite o texto antes de usar no relatório.',
                    style: TextStyle(fontSize: 12.5),
                  ),
                ),
                const SizedBox(height: 12),
                _aiSuggestionField('Descrição sugerida', description),
                _aiSuggestionField('Risco identificado', risk),
                _aiSuggestionField('Ação imediata', immediateAction),
                _aiSuggestionField('Recomendação técnica', recommendation),
                _aiSuggestionField('Ação corretiva sugerida', correctiveAction),
                if (responsibleProfile.isNotEmpty ||
                    suggestedDeadlineDays != null)
                  _aiSuggestionField(
                    'Plano de ação inicial',
                    [
                      if (responsibleProfile.isNotEmpty)
                        'Responsável sugerido: $responsibleProfile',
                      if (suggestedDeadlineDays != null)
                        'Prazo inicial sugerido: $suggestedDeadlineDays dia(s)',
                    ].join('\n'),
                  ),
                _aiSuggestionField(
                  'Prioridade sugerida',
                  '$priority • confiança $confidence',
                ),
                if (references.isNotEmpty)
                  _aiSuggestionField(
                    'Referências prováveis para conferir',
                    references.join(' • '),
                  ),
                if (checks.isNotEmpty)
                  _aiSuggestionField(
                    'Confirmar presencialmente',
                    checks.map((value) => '• $value').join('\n'),
                  ),
                if (evidence.length > 4)
                  const Text(
                    'Nesta análise foram usadas as quatro primeiras fotos.',
                    style: TextStyle(fontSize: 11.5, color: Colors.black54),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('NÃO USAR'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('USAR E EDITAR'),
          ),
        ],
      ),
    );

    if (useSuggestion != true || !mounted) return;
    setState(() {
      if (description.isNotEmpty) observations[item.id]!.text = description;
      if (risk.isNotEmpty) risks[item.id]!.text = risk;
      if (recommendation.isNotEmpty ||
          immediateAction.isNotEmpty ||
          correctiveAction.isNotEmpty) {
        recommendations[item.id]!.text = [
          if (immediateAction.isNotEmpty) 'Ação imediata: $immediateAction',
          if (recommendation.isNotEmpty) recommendation,
          if (correctiveAction.isNotEmpty)
            'Ação corretiva sugerida: $correctiveAction',
          if (responsibleProfile.isNotEmpty)
            'Responsável sugerido: $responsibleProfile',
          if (suggestedDeadlineDays != null)
            'Prazo inicial sugerido: $suggestedDeadlineDays dia(s)',
        ].join('\n');
      }
      if (const ['Baixa', 'Média', 'Alta', 'Crítica'].contains(priority)) {
        priorities[item.id] = priority;
      }
    });
    _scheduleDraftSave();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Sugestão aplicada. Revise os campos antes de continuar.'),
      ),
    );
  }

  Widget _aiSuggestionField(String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
          ),
          const SizedBox(height: 3),
          SelectableText(value, style: const TextStyle(height: 1.35)),
        ],
      ),
    );
  }

  int _quickResponseScore(
    _QuickResponsePreset preset,
    ChecklistItem item,
  ) {
    final searchable = [
      item.category,
      item.text,
      item.reference,
    ].join(' ').toLowerCase();

    return preset.keywords
        .where((keyword) => searchable.contains(keyword.toLowerCase()))
        .length;
  }

  List<_QuickResponsePreset> _rankedQuickResponses(
    ChecklistItem item, {
    required bool isPartial,
  }) {
    final scored = _quickResponsePresets
        .where((preset) => preset.keywords.isNotEmpty)
        .map((preset) => MapEntry(preset, _quickResponseScore(preset, item)))
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final relevant = scored
        .where((entry) => entry.value > 0)
        .map((entry) => entry.key)
        .toList();
    final other = scored
        .where((entry) => entry.value == 0)
        .map((entry) => entry.key)
        .toList();
    final generic = _quickResponsePresets
        .where((preset) => preset.keywords.isEmpty)
        .toList();

    if (isPartial) {
      final partial = generic.firstWhere(
        (preset) => preset.title == 'Atendimento apenas parcial',
      );
      generic.remove(partial);
      return [partial, ...relevant, ...generic, ...other];
    }

    return [...relevant, ...generic.reversed, ...other];
  }

  Future<void> _showQuickResponses(
    ChecklistItem item, {
    required bool isPartial,
  }) async {
    final ranked = _rankedQuickResponses(item, isPartial: isPartial);
    final selected = await showModalBottomSheet<_QuickResponsePreset>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) => FractionallySizedBox(
        heightFactor: .88,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 10, 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Respostas prontas',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Toque na situação encontrada. Você poderá editar o texto depois.',
                          style: TextStyle(color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Fechar',
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 20),
                itemCount: ranked.length,
                separatorBuilder: (_, __) => const SizedBox(height: 6),
                itemBuilder: (context, index) {
                  final preset = ranked[index];
                  final isSuggested =
                      index < 4 && _quickResponseScore(preset, item) > 0;

                  return Card(
                    margin: EdgeInsets.zero,
                    color: isSuggested
                        ? Theme.of(context)
                            .colorScheme
                            .primaryContainer
                            .withValues(alpha: .42)
                        : null,
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 5,
                      ),
                      leading: CircleAvatar(
                        child: Icon(
                          isSuggested
                              ? Icons.bolt_outlined
                              : Icons.edit_note_outlined,
                        ),
                      ),
                      title: Text(
                        preset.title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          preset.description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.pop(context, preset),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );

    if (selected == null || !mounted) return;

    setState(() {
      observations[item.id]!.text = selected.description;
      risks[item.id]!.text = selected.risk;
      recommendations[item.id]!.text = selected.recommendation;
      if (selected.priority != null) {
        priorities[item.id] = selected.priority!;
      }
    });
    _scheduleDraftSave();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Resposta preenchida. Revise ou ajuste o texto se necessário.',
        ),
      ),
    );
  }

  Future<bool> _validate() async {
    if (statuses.length != widget.checklistItems.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Responda todos os itens do checklist.'),
        ),
      );
      return false;
    }

    for (final item in widget.checklistItems) {
      final status = statuses[item.id];
      if (status == 'Não Conforme' || status == 'Parcial') {
        if (observations[item.id]!.text.trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                status == 'Não Conforme'
                    ? 'Descreva a não conformidade em: ${item.category.isEmpty ? item.text : item.category}.'
                    : 'Descreva o que está parcialmente atendido em: ${item.category.isEmpty ? item.text : item.category}.',
              ),
            ),
          );
          return false;
        }
      }
    }

    return true;
  }

  Future<void> _save() async {
    if (saving || draftSaving) return;
    draftSaveTimer?.cancel();
    if (!await _validate()) return;

    setState(() => saving = true);

    const uuid = Uuid();
    final db = AppDatabase.instance;

    try {
      for (final item in widget.checklistItems) {
        final existingAnswerId = existingAnswerIds[item.id];
        final answerId = existingAnswerId ?? uuid.v4();
        final status = statuses[item.id]!;
        final observation = observations[item.id]!.text.trim();

        final answer = InspectionAnswer(
          id: answerId,
          inspectionId: widget.inspection.id,
          questionId: item.id,
          questionText: item.text,
          questionCategory: item.category,
          questionReference: item.reference,
          status: status,
          observation: observation,
          riskIdentified: risks[item.id]!.text.trim(),
          recommendation: recommendations[item.id]!.text.trim(),
        );

        if (widget.editExisting || existingAnswerId != null) {
          await db.upsertAnswer(answer);
        } else {
          await db.insertAnswer(answer);
        }

        final evidence = photos[item.id] ?? [];
        final photoRows = <EvidencePhoto>[];

        for (var i = 0; i < evidence.length; i++) {
          photoRows.add(
            EvidencePhoto(
              id: uuid.v4(),
              answerId: answerId,
              path: evidence[i],
              sortOrder: i,
            ),
          );
        }

        if (widget.editExisting || existingAnswerId != null) {
          await db.replaceEvidencePhotos(
            answerId: answerId,
            photos: photoRows,
          );
        } else {
          for (final photo in photoRows) {
            await db.insertEvidencePhoto(photo);
          }
        }

        final oldNc = existingNcs[item.id];

        if (status == 'Não Conforme') {
          final cleanId = answerId.replaceAll('-', '');
          final shortId = cleanId.length >= 6 ? cleanId.substring(0, 6) : cleanId;
          final nc = NonConformity(
            id: oldNc?.id ?? uuid.v4(),
            inspectionId: widget.inspection.id,
            answerId: answerId,
            code: oldNc?.code ?? 'NC-${widget.inspection.reportNumber}-$shortId',
            description: observation,
            riskIdentified: risks[item.id]!.text.trim(),
            recommendation: recommendations[item.id]!.text.trim(),
            classification: priorities[item.id] ?? item.priority,
            status: oldNc?.status ?? 'Pendente',
            createdAt: oldNc?.createdAt ?? DateTime.now(),
          );
          await db.upsertNonConformity(nc);
        } else if (oldNc != null) {
          await db.removeOrCloseNonConformityForAnswer(answerId);
        }
      }

      await db.markInspectionInProgress(widget.inspection.id);

      if (!mounted) return;

      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => SignatureScreen(
            inspectionId: widget.inspection.id,
            companyName: widget.companyName,
            technicianName: widget.inspection.technicianName,
            preserveExisting: widget.editExisting,
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => saving = false);
      }
    }
  }




  void _setStatus(String itemId, String value) {
    setState(() {
      statuses[itemId] = value;
    });
    _scheduleDraftSave();
  }

  void _markAllConforme() {
    setState(() {
      for (final item in widget.checklistItems) {
        statuses[item.id] = 'Conforme';
      }
    });

    _scheduleDraftSave();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Todos os itens foram marcados como Conforme. '
          'Agora altere somente os itens que apresentarem problema.',
        ),
      ),
    );
  }

  Widget _statusButton({
    required ChecklistItem item,
    required String value,
    required String label,
    required IconData icon,
  }) {
    final selected = statuses[item.id] == value;
    final scheme = Theme.of(context).colorScheme;

    Color foreground;
    Color background;
    Color border;

    if (value == 'Conforme') {
      foreground = selected ? Colors.white : Colors.green.shade800;
      background = selected ? Colors.green.shade700 : Colors.white;
      border = Colors.green.shade500;
    } else if (value == 'Não Conforme') {
      foreground = selected ? Colors.white : scheme.error;
      background = selected ? scheme.error : Colors.white;
      border = scheme.error;
    } else if (value == 'Parcial') {
      foreground = selected ? Colors.white : Colors.orange.shade900;
      background = selected ? Colors.orange.shade700 : Colors.white;
      border = Colors.orange.shade600;
    } else {
      foreground = selected ? Colors.white : Colors.grey.shade700;
      background = selected ? Colors.grey.shade700 : Colors.white;
      border = Colors.grey.shade500;
    }

    return Material(
      color: background,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _setStatus(item.id, value),
        child: Container(
          constraints: const BoxConstraints(minHeight: 64),
          padding: const EdgeInsets.symmetric(
            horizontal: 6,
            vertical: 10,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: border,
              width: selected ? 2.2 : 1.2,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: foreground,
                size: 24,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: foreground,
                  fontSize: 11.5,
                  fontWeight:
                      selected ? FontWeight.bold : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loadingExisting) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.companyName)),
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Carregando vistoria...'),
            ],
          ),
        ),
      );
    }

    final answered = statuses.length;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await _saveDraft();
        if (mounted) Navigator.of(context).pop(result);
      },
      child: Scaffold(
      appBar: AppBar(
        title: Text(widget.companyName),
        actions: [
          IconButton(
            tooltip: 'Salvar rascunho e sair',
            onPressed: saving || draftSaving ? null : _saveDraftAndExit,
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(12),
        child: FilledButton.icon(
          onPressed: saving || draftSaving ? null : _save,
          icon: const Icon(Icons.arrow_forward),
          label: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Text(
              saving
                  ? 'SALVANDO...'
                  : widget.editExisting
                      ? 'SALVAR ALTERAÇÕES E REVISAR'
                      : 'CONTINUAR PARA ASSINATURAS',
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.cloud_done_outlined),
              title: const Text(
                'Rascunho automático ativo',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: const Text(
                'Você pode fechar ou sair da vistoria. O que já foi preenchido fica salvo e poderá ser continuado depois pelo Histórico.',
              ),
              trailing: IconButton(
                tooltip: 'Salvar agora',
                onPressed: saving || draftSaving
                    ? null
                    : () => _saveDraft(showMessage: true),
                icon: const Icon(Icons.save_outlined),
              ),
            ),
          ),
          if (widget.editExisting)
            Card(
              child: ListTile(
                leading: const Icon(Icons.edit_note),
                title: const Text(
                  'Editando vistoria existente',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: const Text(
                  'As respostas, fotos e planos de ação anteriores foram mantidos. '
                  'Altere somente o que for necessário.',
                ),
              ),
            ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.inspection.checklistType.toUpperCase(),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text('Técnico: ${widget.inspection.technicianName}'),
                  if (widget.siteName != null)
                    Text('Obra / Unidade: ${widget.siteName}'),
                  Text('Setor / Área: ${widget.inspection.area}'),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: widget.checklistItems.isEmpty
                        ? 0
                        : answered / widget.checklistItems.length,
                    minHeight: 9,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '$answered de ${widget.checklistItems.length} itens respondidos',
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Text(
                        widget.checklistItems.isEmpty
                            ? '0%'
                            : '${((answered / widget.checklistItems.length) * 100).round()}%',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _markAllConforme,
                      icon: const Icon(Icons.done_all),
                      label: const Text(
                        'MARCAR TODOS COMO CONFORME',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ...widget.checklistItems.asMap().entries.map((entry) {
            final number = entry.key + 1;
            final item = entry.value;
            final previousTemplateId = entry.key == 0
                ? null
                : widget.checklistItems[entry.key - 1].templateId;
            final showTemplateHeader =
                widget.checklistTemplateNames.length > 1 &&
                    item.templateId != previousTemplateId;
            final templateName =
                widget.checklistTemplateNames[item.templateId];
            final isNc = statuses[item.id] == 'Não Conforme';
            final isPartial = statuses[item.id] == 'Parcial';
            final isIssue = isNc || isPartial;
            final evidence = photos[item.id] ?? [];

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (showTemplateHeader && templateName != null) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 9,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .colorScheme
                          .primary
                          .withValues(alpha: .08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.fact_check_outlined,
                          size: 18,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            templateName,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                Card(
                  margin: const EdgeInsets.only(top: 10),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(
                      [
                        '$number',
                        if (item.category.isNotEmpty) item.category,
                        if (item.reference.isNotEmpty) item.reference,
                      ].join(' • '),
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      item.text,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Situação',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Conforme',
                            label: 'CONFORME',
                            icon: Icons.check_circle_outline,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Parcial',
                            label: 'PARCIAL',
                            icon: Icons.adjust,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Não Conforme',
                            label: 'NÃO CONFORME',
                            icon: Icons.cancel_outlined,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Não se aplica',
                            label: 'N/A',
                            icon: Icons.remove_circle_outline,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: observations[item.id],
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: isNc
                            ? 'Descrição da não conformidade *'
                            : isPartial
                                ? 'Descrição do atendimento parcial *'
                                : 'Observação',
                      ),
                    ),
                    if (isIssue) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: Theme.of(context)
                              .colorScheme
                              .errorContainer
                              .withValues(alpha: 0.30),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonalIcon(
                                onPressed: () => _showQuickResponses(
                                  item,
                                  isPartial: isPartial,
                                ),
                                icon: const Icon(Icons.playlist_add_check),
                                label: const Text(
                                  'PREENCHER COM RESPOSTA PRONTA',
                                ),
                              ),
                            ),
                            const SizedBox(height: 5),
                            const Text(
                              'Preenche de uma vez a descrição, o risco e a recomendação. Depois você pode ajustar o texto.',
                              style: TextStyle(
                                fontSize: 11.5,
                                color: Colors.black54,
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'EVIDÊNCIAS FOTOGRÁFICAS',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${evidence.length} foto(s) • máximo 10',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            if (evidence.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 116,
                                child: ListView.separated(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: evidence.length,
                                  separatorBuilder: (_, __) =>
                                      const SizedBox(width: 8),
                                  itemBuilder: (_, index) {
                                    final path = evidence[index];
                                    final file = File(path);

                                    return Stack(
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: file.existsSync()
                                              ? Image.file(
                                                  file,
                                                  width: 116,
                                                  height: 116,
                                                  fit: BoxFit.cover,
                                                )
                                              : Container(
                                                  width: 116,
                                                  height: 116,
                                                  alignment: Alignment.center,
                                                  child: const Text(
                                                    'Foto indisponível',
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                        ),
                                        Positioned(
                                          right: 2,
                                          top: 2,
                                          child: IconButton.filled(
                                            visualDensity:
                                                VisualDensity.compact,
                                            iconSize: 18,
                                            onPressed: () =>
                                                _removePhoto(item.id, index),
                                            icon: const Icon(Icons.close),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ),
                            ],
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: evidence.length >= 10
                                      ? null
                                      : () => _takePhoto(item.id),
                                  icon: const Icon(Icons.camera_alt),
                                  label: const Text('TIRAR FOTO'),
                                ),
                                OutlinedButton.icon(
                                  onPressed: evidence.length >= 10
                                      ? null
                                      : () => _choosePhotos(item.id),
                                  icon:
                                      const Icon(Icons.photo_library_outlined),
                                  label: const Text('GALERIA'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonalIcon(
                                onPressed: evidence.isEmpty ||
                                        analyzingItems.contains(item.id)
                                    ? null
                                    : () => _analyzeWithAi(item),
                                icon: analyzingItems.contains(item.id)
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Icon(Icons.auto_awesome_outlined),
                                label: Text(
                                  analyzingItems.contains(item.id)
                                      ? 'ANALISANDO FOTOS...'
                                      : 'ANALISAR FOTOS COM IA',
                                ),
                              ),
                            ),
                            const SizedBox(height: 5),
                            const Text(
                              'Ao tocar, até 4 fotos reduzidas e sem metadados são enviadas ao Gemini. No plano gratuito, o conteúdo pode ser usado pelo Google para melhorar seus produtos. Evite rostos, crachás, documentos e outros dados pessoais.',
                              style: TextStyle(
                                fontSize: 11.5,
                                color: Colors.black54,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: risks[item.id],
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Risco identificado',
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: recommendations[item.id],
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Recomendação técnica',
                              ),
                            ),
                            if (isNc) ...[
                              const SizedBox(height: 12),
                              DropdownButtonFormField<String>(
                                value: priorities[item.id],
                                decoration: const InputDecoration(
                                  labelText: 'Classificação / prioridade da NC',
                                ),
                                items: const [
                                  DropdownMenuItem(value: 'Baixa', child: Text('Baixa')),
                                  DropdownMenuItem(value: 'Média', child: Text('Média')),
                                  DropdownMenuItem(value: 'Alta', child: Text('Alta')),
                                  DropdownMenuItem(value: 'Crítica', child: Text('Crítica')),
                                ],
                                onChanged: (value) {
                                  if (value != null) {
                                    setState(() => priorities[item.id] = value);
                                    _scheduleDraftSave();
                                  }
                                },
                              ),
                              const SizedBox(height: 12),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.blueGrey.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Text(
                                  'A Não Conformidade será registrada separadamente. '
                                  'Depois da vistoria você poderá criar um ou mais planos de ação vinculados a ela.',
                                  style: TextStyle(fontSize: 12.5),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                      ],
                    ),
                  ),
                ),
              ],
            );
          }),
        ],
      ),
      ),
    );
  }
}
