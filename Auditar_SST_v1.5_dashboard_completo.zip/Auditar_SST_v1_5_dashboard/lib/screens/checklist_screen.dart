import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import '../services/storage_service.dart';
import 'signature_screen.dart';

class ChecklistScreen extends StatefulWidget {
  final Inspection inspection;
  final String companyName;
  final String? siteName;
  final List<ChecklistItem> checklistItems;
  final bool editExisting;

  const ChecklistScreen({
    super.key,
    required this.inspection,
    required this.companyName,
    this.siteName,
    required this.checklistItems,
    this.editExisting = false,
  });

  @override
  State<ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<ChecklistScreen> {
  final ImagePicker picker = ImagePicker();

  final Map<String, String> statuses = {};
  final Map<String, TextEditingController> observations = {};
  final Map<String, TextEditingController> risks = {};
  final Map<String, TextEditingController> recommendations = {};
  final Map<String, TextEditingController> actions = {};
  final Map<String, TextEditingController> responsibles = {};
  final Map<String, String> priorities = {};
  final Map<String, DateTime?> dueDates = {};
  final Map<String, List<String>> photos = {};

  final Map<String, String> existingAnswerIds = {};
  final Map<String, ActionPlan> existingActions = {};

  bool loadingExisting = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();

    for (final item in widget.checklistItems) {
      observations[item.id] = TextEditingController();
      risks[item.id] = TextEditingController();
      recommendations[item.id] = TextEditingController();
      actions[item.id] = TextEditingController();
      responsibles[item.id] = TextEditingController();
      priorities[item.id] = item.priority;
      dueDates[item.id] = null;
      photos[item.id] = [];
    }

    if (widget.editExisting) {
      loadingExisting = true;
      _loadExistingData();
    }
  }

  Future<void> _loadExistingData() async {
    final db = AppDatabase.instance;
    final answers = await db.getAnswers(widget.inspection.id);

    for (final answer in answers) {
      if (!observations.containsKey(answer.questionId)) continue;

      existingAnswerIds[answer.questionId] = answer.id;
      statuses[answer.questionId] = answer.status;
      observations[answer.questionId]!.text = answer.observation;
      risks[answer.questionId]!.text = answer.riskIdentified;
      recommendations[answer.questionId]!.text = answer.recommendation;

      final evidence = await db.getPhotosForAnswer(answer.id);
      photos[answer.questionId] =
          evidence.map((photo) => photo.path).toList();

      final action = await db.getActionForAnswer(answer.id);
      if (action != null) {
        existingActions[answer.questionId] = action;
        actions[answer.questionId]!.text = action.correctiveAction;
        responsibles[answer.questionId]!.text = action.responsible;
        priorities[answer.questionId] = action.priority;
        dueDates[answer.questionId] = action.dueDate;
      }
    }

    if (!mounted) return;
    setState(() => loadingExisting = false);
  }

  @override
  void dispose() {
    for (final controller in observations.values) {
      controller.dispose();
    }
    for (final controller in risks.values) {
      controller.dispose();
    }
    for (final controller in recommendations.values) {
      controller.dispose();
    }
    for (final controller in actions.values) {
      controller.dispose();
    }
    for (final controller in responsibles.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _takePhoto(String itemId) async {
    final image = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
      maxWidth: 1800,
    );

    if (image == null) return;

    final storedPath = await StorageService.persistImage(
      image.path,
      folder: 'fotos_vistorias',
    );

    if (mounted) {
      setState(() => photos[itemId]!.add(storedPath));
    }
  }

  Future<void> _choosePhotos(String itemId) async {
    final images = await picker.pickMultiImage(
      imageQuality: 75,
      maxWidth: 1800,
    );

    if (images.isEmpty) return;

    final current = photos[itemId] ?? [];
    final remaining = 10 - current.length;
    if (remaining <= 0) return;

    final added = <String>[];

    for (final image in images.take(remaining)) {
      final storedPath = await StorageService.persistImage(
        image.path,
        folder: 'fotos_vistorias',
      );
      added.add(storedPath);
    }

    if (mounted) {
      setState(() => photos[itemId]!.addAll(added));
    }
  }

  void _removePhoto(String itemId, int index) {
    setState(() {
      photos[itemId]!.removeAt(index);
    });
  }

  Future<void> _pickDueDate(String itemId) async {
    final now = DateTime.now();
    final initial = dueDates[itemId] ?? now;

    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
      initialDate: initial,
    );

    if (selected != null && mounted) {
      setState(() => dueDates[itemId] = selected);
    }
  }

  Future<bool> _validate() async {
    if (statuses.length != widget.checklistItems.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Responda todos os itens do checklist.'),
        ),
      );
      return false;
    }

    for (final item in widget.checklistItems) {
      if (statuses[item.id] == 'Não Conforme') {
        if (observations[item.id]!.text.trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Descreva a não conformidade em: '
                '${item.category.isEmpty ? item.text : item.category}.',
              ),
            ),
          );
          return false;
        }

        if (actions[item.id]!.text.trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Informe a ação corretiva em: '
                '${item.category.isEmpty ? item.text : item.category}.',
              ),
            ),
          );
          return false;
        }
      }
    }

    return true;
  }

  Future<void> _save() async {
    if (saving) return;
    if (!await _validate()) return;

    setState(() => saving = true);

    const uuid = Uuid();
    final db = AppDatabase.instance;

    try {
      for (final item in widget.checklistItems) {
        final existingAnswerId = existingAnswerIds[item.id];
        final answerId = existingAnswerId ?? uuid.v4();
        final status = statuses[item.id]!;
        final observation = observations[item.id]!.text.trim();

        final answer = InspectionAnswer(
          id: answerId,
          inspectionId: widget.inspection.id,
          questionId: item.id,
          questionText: item.text,
          questionCategory: item.category,
          questionReference: item.reference,
          status: status,
          observation: observation,
          riskIdentified: risks[item.id]!.text.trim(),
          recommendation: recommendations[item.id]!.text.trim(),
        );

        if (widget.editExisting || existingAnswerId != null) {
          await db.upsertAnswer(answer);
        } else {
          await db.insertAnswer(answer);
        }

        final evidence = photos[item.id] ?? [];
        final photoRows = <EvidencePhoto>[];

        for (var i = 0; i < evidence.length; i++) {
          photoRows.add(
            EvidencePhoto(
              id: uuid.v4(),
              answerId: answerId,
              path: evidence[i],
              sortOrder: i,
            ),
          );
        }

        if (widget.editExisting || existingAnswerId != null) {
          await db.replaceEvidencePhotos(
            answerId: answerId,
            photos: photoRows,
          );
        } else {
          for (final photo in photoRows) {
            await db.insertEvidencePhoto(photo);
          }
        }

        final oldAction = existingActions[item.id];

        if (status == 'Não Conforme') {
          final updatedAction = ActionPlan(
            id: oldAction?.id ?? uuid.v4(),
            inspectionId: widget.inspection.id,
            answerId: answerId,
            nonConformity: observation,
            correctiveAction: actions[item.id]!.text.trim(),
            responsible: responsibles[item.id]!.text.trim(),
            priority: priorities[item.id] ?? item.priority,
            dueDate: dueDates[item.id],
            status: oldAction?.status ?? 'Pendente',
            completionDate: oldAction?.completionDate,
            completionNote: oldAction?.completionNote ?? '',
            completedBy: oldAction?.completedBy ?? '',
          );

          if (oldAction == null) {
            await db.insertAction(updatedAction);
          } else {
            await db.updateAction(updatedAction);
          }
        } else if (oldAction != null) {
          await db.deleteActionForAnswer(answerId);
        }
      }

      await db.markInspectionInProgress(widget.inspection.id);

      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => SignatureScreen(
            inspectionId: widget.inspection.id,
            companyName: widget.companyName,
            technicianName: widget.inspection.technicianName,
            preserveExisting: widget.editExisting,
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => saving = false);
      }
    }
  }

  String _dateLabel(DateTime? date) {
    if (date == null) return 'DEFINIR PRAZO';

    return 'Prazo: '
        '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year}';
  }


  void _setStatus(String itemId, String value) {
    setState(() {
      statuses[itemId] = value;
    });
  }

  void _markAllConforme() {
    setState(() {
      for (final item in widget.checklistItems) {
        statuses[item.id] = 'Conforme';
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Todos os itens foram marcados como Conforme. '
          'Agora altere somente os itens que apresentarem problema.',
        ),
      ),
    );
  }

  Widget _statusButton({
    required ChecklistItem item,
    required String value,
    required String label,
    required IconData icon,
  }) {
    final selected = statuses[item.id] == value;
    final scheme = Theme.of(context).colorScheme;

    Color foreground;
    Color background;
    Color border;

    if (value == 'Conforme') {
      foreground = selected ? Colors.white : Colors.green.shade800;
      background = selected ? Colors.green.shade700 : Colors.white;
      border = Colors.green.shade500;
    } else if (value == 'Não Conforme') {
      foreground = selected ? Colors.white : scheme.error;
      background = selected ? scheme.error : Colors.white;
      border = scheme.error;
    } else {
      foreground = selected ? Colors.white : Colors.grey.shade700;
      background = selected ? Colors.grey.shade700 : Colors.white;
      border = Colors.grey.shade500;
    }

    return Material(
      color: background,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _setStatus(item.id, value),
        child: Container(
          constraints: const BoxConstraints(minHeight: 64),
          padding: const EdgeInsets.symmetric(
            horizontal: 6,
            vertical: 10,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: border,
              width: selected ? 2.2 : 1.2,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: foreground,
                size: 24,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: foreground,
                  fontSize: 11.5,
                  fontWeight:
                      selected ? FontWeight.bold : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loadingExisting) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.companyName)),
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Carregando vistoria...'),
            ],
          ),
        ),
      );
    }

    final answered = statuses.length;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.companyName),
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(12),
        child: FilledButton.icon(
          onPressed: saving ? null : _save,
          icon: const Icon(Icons.arrow_forward),
          label: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Text(
              saving
                  ? 'SALVANDO...'
                  : widget.editExisting
                      ? 'SALVAR ALTERAÇÕES E REVISAR'
                      : 'CONTINUAR PARA ASSINATURAS',
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (widget.editExisting)
            Card(
              child: ListTile(
                leading: const Icon(Icons.edit_note),
                title: const Text(
                  'Editando vistoria existente',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: const Text(
                  'As respostas, fotos e planos de ação anteriores foram mantidos. '
                  'Altere somente o que for necessário.',
                ),
              ),
            ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.inspection.checklistType.toUpperCase(),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text('Técnico: ${widget.inspection.technicianName}'),
                  if (widget.siteName != null)
                    Text('Obra / Unidade: ${widget.siteName}'),
                  Text('Setor / Área: ${widget.inspection.area}'),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: widget.checklistItems.isEmpty
                        ? 0
                        : answered / widget.checklistItems.length,
                    minHeight: 9,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '$answered de ${widget.checklistItems.length} itens respondidos',
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Text(
                        widget.checklistItems.isEmpty
                            ? '0%'
                            : '${((answered / widget.checklistItems.length) * 100).round()}%',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _markAllConforme,
                      icon: const Icon(Icons.done_all),
                      label: const Text(
                        'MARCAR TODOS COMO CONFORME',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ...widget.checklistItems.asMap().entries.map((entry) {
            final number = entry.key + 1;
            final item = entry.value;
            final isNc = statuses[item.id] == 'Não Conforme';
            final evidence = photos[item.id] ?? [];

            return Card(
              margin: const EdgeInsets.only(top: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      [
                        '$number',
                        if (item.category.isNotEmpty) item.category,
                        if (item.reference.isNotEmpty) item.reference,
                      ].join(' • '),
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      item.text,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Situação',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Conforme',
                            label: 'CONFORME',
                            icon: Icons.check_circle_outline,
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Não Conforme',
                            label: 'NÃO CONFORME',
                            icon: Icons.cancel_outlined,
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _statusButton(
                            item: item,
                            value: 'Não se aplica',
                            label: 'N/A',
                            icon: Icons.remove_circle_outline,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: observations[item.id],
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: isNc
                            ? 'Descrição da não conformidade *'
                            : 'Observação',
                      ),
                    ),
                    if (isNc) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: Theme.of(context)
                              .colorScheme
                              .errorContainer
                              .withValues(alpha: 0.30),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'EVIDÊNCIAS FOTOGRÁFICAS',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${evidence.length} foto(s) • máximo 10',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            if (evidence.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 116,
                                child: ListView.separated(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: evidence.length,
                                  separatorBuilder: (_, __) =>
                                      const SizedBox(width: 8),
                                  itemBuilder: (_, index) {
                                    final path = evidence[index];
                                    final file = File(path);

                                    return Stack(
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: file.existsSync()
                                              ? Image.file(
                                                  file,
                                                  width: 116,
                                                  height: 116,
                                                  fit: BoxFit.cover,
                                                )
                                              : Container(
                                                  width: 116,
                                                  height: 116,
                                                  alignment: Alignment.center,
                                                  child: const Text(
                                                    'Foto indisponível',
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                        ),
                                        Positioned(
                                          right: 2,
                                          top: 2,
                                          child: IconButton.filled(
                                            visualDensity:
                                                VisualDensity.compact,
                                            iconSize: 18,
                                            onPressed: () =>
                                                _removePhoto(item.id, index),
                                            icon: const Icon(Icons.close),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ),
                            ],
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: evidence.length >= 10
                                      ? null
                                      : () => _takePhoto(item.id),
                                  icon: const Icon(Icons.camera_alt),
                                  label: const Text('TIRAR FOTO'),
                                ),
                                OutlinedButton.icon(
                                  onPressed: evidence.length >= 10
                                      ? null
                                      : () => _choosePhotos(item.id),
                                  icon:
                                      const Icon(Icons.photo_library_outlined),
                                  label: const Text('GALERIA'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: risks[item.id],
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Risco identificado',
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: recommendations[item.id],
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Recomendação técnica',
                              ),
                            ),
                            const SizedBox(height: 14),
                            const Divider(),
                            const Text(
                              'PLANO DE AÇÃO',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: actions[item.id],
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: 'Ação corretiva *',
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: responsibles[item.id],
                              decoration: const InputDecoration(
                                labelText: 'Responsável pela correção',
                              ),
                            ),
                            const SizedBox(height: 10),
                            DropdownButtonFormField<String>(
                              value: priorities[item.id],
                              decoration: const InputDecoration(
                                labelText: 'Prioridade',
                              ),
                              items: const [
                                DropdownMenuItem(
                                  value: 'Baixa',
                                  child: Text('Baixa'),
                                ),
                                DropdownMenuItem(
                                  value: 'Média',
                                  child: Text('Média'),
                                ),
                                DropdownMenuItem(
                                  value: 'Alta',
                                  child: Text('Alta'),
                                ),
                                DropdownMenuItem(
                                  value: 'Crítica',
                                  child: Text('Crítica'),
                                ),
                              ],
                              onChanged: (value) {
                                if (value != null) {
                                  setState(() => priorities[item.id] = value);
                                }
                              },
                            ),
                            const SizedBox(height: 10),
                            OutlinedButton.icon(
                              onPressed: () => _pickDueDate(item.id),
                              icon: const Icon(Icons.calendar_month),
                              label: Text(_dateLabel(dueDates[item.id])),
                            ),
                            if (existingActions[item.id]?.status ==
                                'Concluído') ...[
                              const SizedBox(height: 8),
                              const Text(
                                'Esta ação já está concluída. Ao editar, '
                                'as evidências de conclusão serão preservadas '
                                'enquanto o item continuar Não Conforme.',
                                style: TextStyle(fontSize: 12),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
