import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';
import '../services/cipa_voting_service.dart';
import 'settings_screen.dart';

class CipaElectionDetailScreen extends StatefulWidget {
  final Company company;
  final CipaElection election;

  const CipaElectionDetailScreen({
    super.key,
    required this.company,
    required this.election,
  });

  @override
  State<CipaElectionDetailScreen> createState() => _CipaElectionDetailScreenState();
}

class _CipaElectionDetailScreenState extends State<CipaElectionDetailScreen> {
  late CipaElection election;
  List<CipaCandidate> candidates = [];
  List<CipaVoter> voters = [];
  List<Worker> workers = [];
  List<Sector> sectors = [];
  bool loading = true;
  bool busy = false;
  String electionUrl = '';
  Map<String, dynamic> onlineStatus = {};
  List<Map<String, dynamic>> participationRows = [];
  String onlineMessage = '';
  Timer? timer;

  @override
  void initState() {
    super.initState();
    election = widget.election;
    _load();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final db = AppDatabase.instance;
    final loadedElections = await db.getCipaElections(companyId: widget.company.id);
    final latest = loadedElections.where((e) => e.id == election.id).firstOrNull;
    if (latest != null) election = latest;
    final loadedCandidates = await db.getCipaCandidates(election.id);
    final loadedVoters = await db.getCipaVoters(election.id);
    final loadedWorkers = await db.getWorkers(companyId: widget.company.id);
    final loadedSectors = await db.getSectors(widget.company.id);
    final url = await CipaVotingService.electionUrl(election);
    if (!mounted) return;
    setState(() {
      candidates = loadedCandidates;
      voters = loadedVoters;
      workers = loadedWorkers;
      sectors = loadedSectors;
      electionUrl = url;
      loading = false;
    });
    if (election.status == 'Aberta' || election.status == 'Encerrada') {
      await _refreshOnline();
      _startTimerIfNeeded();
    }
  }

  void _startTimerIfNeeded() {
    timer?.cancel();
    if (election.status != 'Aberta') return;
    timer = Timer.periodic(const Duration(seconds: 15), (_) => _refreshOnline(silent: true));
  }

  Sector? _sectorForWorker(Worker worker) {
    for (final sector in sectors) {
      if (sector.id == worker.sectorId) return sector;
    }
    return null;
  }

  Future<void> _addCandidate() async {
    if (election.status != 'Rascunho') {
      _message('Candidatos não podem ser alterados depois que a votação é publicada.');
      return;
    }
    if (workers.isEmpty) {
      _message('Cadastre os trabalhadores desta empresa primeiro.');
      return;
    }
    String? selectedWorkerId;
    final workerId = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocalState) => AlertDialog(
          title: const Text('Adicionar candidato'),
          content: DropdownButtonFormField<String>(
            value: selectedWorkerId,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Trabalhador',
              prefixIcon: Icon(Icons.person_outline),
            ),
            items: workers
                .where((worker) => !candidates.any((c) => c.workerId == worker.id))
                .map((worker) => DropdownMenuItem(value: worker.id, child: Text(worker.name)))
                .toList(),
            onChanged: (value) =>
                setLocalState(() => selectedWorkerId = value),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: selectedWorkerId == null
                  ? null
                  : () => Navigator.pop(dialogContext, selectedWorkerId),
              child: const Text('Adicionar'),
            ),
          ],
        ),
      ),
    );
    if (workerId == null || !mounted) return;
    final worker = workers.firstWhere((item) => item.id == workerId);
    final sector = _sectorForWorker(worker);
    await AppDatabase.instance.upsertCipaCandidate(
      CipaCandidate(
        id: const Uuid().v4(),
        electionId: election.id,
        workerId: worker.id,
        name: worker.name,
        role: worker.role,
        sector: sector?.name ?? '',
      ),
    );
    await _load();
  }

  Future<void> _removeCandidate(CipaCandidate candidate) async {
    if (election.status != 'Rascunho') return;
    await AppDatabase.instance.deleteCipaCandidate(candidate.id);
    await _load();
  }

  String _newAccessCode() {
    final raw = const Uuid().v4().replaceAll('-', '').toUpperCase();
    return '${raw.substring(0, 4)}-${raw.substring(4, 8)}';
  }

  String _digits(String value) => value.replaceAll(RegExp(r'\D'), '');

  Future<void> _prepareVoters() async {
    if (election.status != 'Rascunho') {
      _message('A lista de eleitores não pode ser alterada depois da publicação.');
      return;
    }
    final cnpj = _digits(widget.company.cnpj ?? '');
    if (cnpj.length != 14) {
      _message('Cadastre o CNPJ da empresa antes de preparar os eleitores.');
      return;
    }
    if (workers.isEmpty) {
      _message('Cadastre os trabalhadores ativos desta empresa primeiro.');
      return;
    }
    final eligibleWorkers = workers
        .where((worker) => worker.companyId == widget.company.id && worker.active && _digits(worker.cpf).length == 11)
        .toList();
    final excluded = workers.length - eligibleWorkers.length;
    if (eligibleWorkers.isEmpty) {
      _message('Nenhum trabalhador ativo desta empresa possui CPF válido cadastrado.');
      return;
    }
    final duplicateCpfs = <String>{};
    final seenCpfs = <String>{};
    for (final worker in eligibleWorkers) {
      final cpf = _digits(worker.cpf);
      if (!seenCpfs.add(cpf)) duplicateCpfs.add(cpf);
    }
    if (duplicateCpfs.isNotEmpty) {
      _message('Existem CPFs duplicados no cadastro de trabalhadores. Corrija antes de preparar a votação.');
      return;
    }
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Preparar eleitores'),
        content: Text(
          'Serão adicionados ${eligibleWorkers.length} trabalhadores ativos vinculados a ${widget.company.name} como eleitores. '
          'Na votação, cada trabalhador deverá informar o código individual e o próprio CPF.\n\n'
          '${excluded > 0 ? '$excluded trabalhador(es) ficaram fora por não terem CPF válido no cadastro.\n\n' : ''}'
          'Se já houver códigos preparados, eles serão substituídos.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Preparar')),
        ],
      ),
    );
    if (confirm != true) return;
    final prepared = eligibleWorkers
        .map(
          (worker) => CipaVoter(
            id: const Uuid().v4(),
            electionId: election.id,
            workerId: worker.id,
            name: worker.name,
            accessCode: _newAccessCode(),
          ),
        )
        .toList();
    await AppDatabase.instance.replaceCipaVoters(election.id, prepared);
    await _load();
    _message('Lista de eleitores preparada com vínculo ao CNPJ da empresa.');
  }

  Future<void> _showVoterCodes() async {
    if (voters.isEmpty) {
      _message('Prepare a lista de eleitores primeiro.');
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .78,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 12, 8),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text('Códigos individuais', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                    ),
                    IconButton(
                      tooltip: 'Copiar lista',
                      onPressed: () async {
                        final text = voters.map((v) => '${v.name}: ${v.accessCode}').join('\n');
                        await Clipboard.setData(ClipboardData(text: text));
                        if (sheetContext.mounted) {
                          ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Lista de códigos copiada.')));
                        }
                      },
                      icon: const Icon(Icons.copy_all_outlined),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'O QR Code é o mesmo para todos. Para votar, o trabalhador informa este código individual e o próprio CPF. O CPF é validado somente contra os trabalhadores ativos vinculados ao CNPJ desta empresa.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
                  itemCount: voters.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final voter = voters[index];
                    return ListTile(
                      title: Text(voter.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(voter.accessCode, style: const TextStyle(letterSpacing: 1.3)),
                      trailing: IconButton(
                        tooltip: 'Copiar código',
                        onPressed: () => Clipboard.setData(ClipboardData(text: voter.accessCode)),
                        icon: const Icon(Icons.copy_outlined),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _publish() async {
    if (busy) return;
    setState(() => busy = true);
    final result = await CipaVotingService.publishElection(
      company: widget.company,
      election: election,
    );
    if (mounted) setState(() => busy = false);
    _message(result.message);
    if (result.success) await _load();
  }

  Future<void> _refreshOnline({bool silent = false}) async {
    final results = await Future.wait([
      CipaVotingService.getStatus(election),
      CipaVotingService.getParticipation(election),
    ]);
    final statusResult = results[0];
    final participationResult = results[1];
    if (!mounted) return;
    setState(() {
      if (statusResult.success) onlineStatus = statusResult.data ?? {};
      if (participationResult.success) {
        participationRows = ((participationResult.data?['participants'] as List?) ?? const [])
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .toList();
      }
      onlineMessage = statusResult.success ? '' : statusResult.message;
    });
    if (!silent && !statusResult.success) _message(statusResult.message);
  }

  Future<void> _showParticipation() async {
    final result = await CipaVotingService.getParticipation(election);
    if (!mounted) return;
    if (!result.success) {
      _message(result.message);
      return;
    }
    final rows = ((result.data?['participants'] as List?) ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    setState(() => participationRows = rows);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .82,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 10, 8),
                child: Row(
                  children: [
                    const Expanded(child: Text('Lista de participação', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
                    IconButton(
                      tooltip: 'Gerar PDF',
                      onPressed: rows.isEmpty ? null : () => _generateParticipationPdf(rows),
                      icon: const Icon(Icons.picture_as_pdf_outlined),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'A lista mostra somente quem participou. O candidato escolhido permanece secreto.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: rows.isEmpty
                    ? const Center(child: Text('Nenhum eleitor sincronizado.'))
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
                        itemCount: rows.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final row = rows[index];
                          final voted = row['voted'] == true;
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: voted ? const Color(0xFFE7F5E9) : const Color(0xFFFFF3DC),
                              foregroundColor: voted ? AuditarBrand.greenDark : const Color(0xFFB76A00),
                              child: Icon(voted ? Icons.check : Icons.schedule, size: 19),
                            ),
                            title: Text('${row['name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                            subtitle: Text([row['role'], row['sector']].where((v) => '${v ?? ''}'.trim().isNotEmpty).join(' • ')),
                            trailing: Text(voted ? 'VOTOU' : 'NÃO VOTOU', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, color: voted ? AuditarBrand.greenDark : const Color(0xFFB76A00))),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _generateParticipationPdf([List<Map<String, dynamic>>? source]) async {
    final rows = source ?? participationRows;
    if (rows.isEmpty) {
      _message('Atualize a lista de participação antes de gerar o PDF.');
      return;
    }
    final voted = rows.where((row) => row['voted'] == true).length;
    final participation = rows.isEmpty ? 0.0 : voted * 100 / rows.length;
    final doc = pw.Document();
    final cnpj = widget.company.cnpj?.trim() ?? '';
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (_) => [
          pw.Text('AUDITAR SST', style: pw.TextStyle(fontSize: 17, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text('LISTA DE PARTICIPAÇÃO — ELEIÇÃO CIPA', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 12),
          pw.Text(widget.company.name, style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          if (cnpj.isNotEmpty) pw.Text('CNPJ: $cnpj', style: const pw.TextStyle(fontSize: 9)),
          pw.Text('${election.title}${election.managementPeriod.isNotEmpty ? ' • Gestão ${election.managementPeriod}' : ''}', style: const pw.TextStyle(fontSize: 9)),
          pw.Text('Emitido em ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}', style: const pw.TextStyle(fontSize: 9)),
          pw.SizedBox(height: 12),
          pw.Container(
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300), borderRadius: pw.BorderRadius.circular(6)),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Aptos: ${rows.length}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                pw.Text('Votaram: $voted', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                pw.Text('Participação: ${participation.toStringAsFixed(1)}%', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              ],
            ),
          ),
          pw.SizedBox(height: 12),
          pw.TableHelper.fromTextArray(
            headers: const ['Trabalhador', 'Cargo', 'Setor', 'Participação'],
            data: rows.map((row) => [
              '${row['name'] ?? '-'}',
              '${row['role'] ?? '-'}',
              '${row['sector'] ?? '-'}',
              row['voted'] == true ? 'VOTOU' : 'NÃO VOTOU',
            ]).toList(),
            headerStyle: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold),
            cellStyle: const pw.TextStyle(fontSize: 8),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey200),
            cellPadding: const pw.EdgeInsets.all(5),
          ),
          pw.SizedBox(height: 12),
          pw.Text(
            'Este relatório comprova somente a participação na votação. O sistema não relaciona o trabalhador ao candidato escolhido; a cédula permanece registrada separadamente.',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
          ),
        ],
      ),
    );
    final bytes = await doc.save();
    final safeName = widget.company.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
    await Printing.sharePdf(bytes: bytes, filename: 'Participacao_CIPA_$safeName.pdf');
  }

  Future<void> _closeElection() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Encerrar votação?'),
        content: const Text(
          'Depois de encerrar, novos votos serão bloqueados e a apuração ficará disponível.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Encerrar')),
        ],
      ),
    );
    if (confirm != true) return;
    setState(() => busy = true);
    final result = await CipaVotingService.closeElection(election);
    if (mounted) setState(() => busy = false);
    _message(result.message);
    if (result.success) await _load();
  }

  Future<void> _copyLink() async {
    if (electionUrl.isEmpty) {
      _message('Configure primeiro a publicação web gratuita em Configurações.');
      return;
    }
    await Clipboard.setData(ClipboardData(text: electionUrl));
    _message('Link da votação copiado.');
  }

  Future<void> _shareLink() async {
    if (electionUrl.isEmpty) {
      _message('Configure primeiro a publicação web gratuita em Configurações.');
      return;
    }
    await Share.share('Votação CIPA - ${widget.company.name}\n$electionUrl');
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()));
    await _load();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  int _int(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  double _double(dynamic value) {
    if (value is double) return value;
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final eligible = _int(onlineStatus['eligible']);
    final voted = _int(onlineStatus['voted']);
    final participation = _double(onlineStatus['participation']);
    final missing = eligible > voted ? eligible - voted : 0;
    final online = onlineStatus.isNotEmpty;
    final results = (onlineStatus['results'] as List?)?.cast<dynamic>() ?? const [];

    return Scaffold(
      appBar: AppBar(title: Text(election.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AuditarBrand.navy, AuditarBrand.navyDark]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.company.name, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(height: 3),
                  Text(election.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
                  if (election.managementPeriod.isNotEmpty) ...[
                    const SizedBox(height: 3),
                    Text('Gestão ${election.managementPeriod}', style: const TextStyle(color: Colors.white70)),
                  ],
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _statusChip(election.status),
                      _infoChip('${candidates.length} candidato(s)'),
                      _infoChip('${voters.length} eleitor(es)'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (election.status == 'Aberta' || election.status == 'Encerrada') ...[
              const Text('Participação da votação', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
              const SizedBox(height: 8),
              if (online)
                ResponsiveWrap(
                  minItemWidth: 112,
                  maxColumns: 3,
                  children: [
                    _metric('Aptos', eligible, AuditarBrand.navy),
                    _metric('Já votaram', voted, AuditarBrand.greenDark),
                    _metric('Faltam', missing, const Color(0xFFF29D18)),
                  ],
                )
              else
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(onlineMessage.isEmpty ? 'Carregando participação...' : onlineMessage),
                  ),
                ),
              if (online) ...[
                const SizedBox(height: 8),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(child: Text('Participação', style: TextStyle(fontWeight: FontWeight.w800))),
                            Text('${participation.toStringAsFixed(1)}%', style: const TextStyle(fontWeight: FontWeight.w900, color: AuditarBrand.greenDark)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(value: (participation / 100).clamp(0, 1).toDouble()),
                        const SizedBox(height: 8),
                        Text('${onlineStatus['quorumMessage'] ?? ''}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    onPressed: () => _refreshOnline(),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Atualizar agora'),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.fact_check_outlined, color: AuditarBrand.navy),
                    title: const Text('Lista de participação', style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${participationRows.where((row) => row['voted'] == true).length} de ${participationRows.length} trabalhador(es) identificados como participantes'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _showParticipation,
                  ),
                ),
              ],
              const SizedBox(height: 8),
            ],
            const Text('Preparação', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
            const SizedBox(height: 8),
            _actionCard(
              icon: Icons.groups_2_outlined,
              title: 'Eleitores',
              subtitle: voters.isEmpty ? 'Preparar trabalhadores aptos a votar' : '${voters.length} eleitores preparados',
              trailing: election.status == 'Rascunho' ? 'Preparar' : 'Ver códigos',
              onTap: election.status == 'Rascunho' ? _prepareVoters : _showVoterCodes,
              secondary: voters.isEmpty ? null : _showVoterCodes,
            ),
            const SizedBox(height: 8),
            _actionCard(
              icon: Icons.person_search_outlined,
              title: 'Candidatos',
              subtitle: candidates.isEmpty ? 'Nenhum candidato cadastrado' : candidates.map((c) => c.name).join(', '),
              trailing: election.status == 'Rascunho' ? 'Adicionar' : 'Definidos',
              onTap: election.status == 'Rascunho' ? _addCandidate : null,
            ),
            if (candidates.isNotEmpty) ...[
              const SizedBox(height: 8),
              Card(
                child: Column(
                  children: candidates
                      .map(
                        (candidate) => ListTile(
                          leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                          title: Text(candidate.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text([candidate.role, candidate.sector].where((v) => v.isNotEmpty).join(' • ')),
                          trailing: election.status == 'Rascunho'
                              ? IconButton(
                                  onPressed: () => _removeCandidate(candidate),
                                  icon: const Icon(Icons.close),
                                )
                              : null,
                        ),
                      )
                      .toList(),
                ),
              ),
            ],
            const SizedBox(height: 16),
            const Text('Votação online', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
            const SizedBox(height: 8),
            if (election.status == 'Rascunho')
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Quando publicar, será criado um link e um QR Code único para esta eleição. O restante do aplicativo continua funcionando offline.',
                        style: TextStyle(fontSize: 12.5),
                      ),
                      const SizedBox(height: 10),
                      FilledButton.icon(
                        onPressed: busy ? null : _publish,
                        icon: busy
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.cloud_upload_outlined),
                        label: const Text('Publicar eleição'),
                      ),
                      TextButton.icon(
                        onPressed: _openSettings,
                        icon: const Icon(Icons.settings_outlined),
                        label: const Text('Configuração gratuita do Google'),
                      ),
                    ],
                  ),
                ),
              )
            else ...[
              if (electionUrl.isNotEmpty)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (election.status == 'Aberta') ...[
                          QrImageView(data: electionUrl, size: 210),
                          const SizedBox(height: 8),
                          const Text('QR Code único da votação', style: TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 3),
                          const Text('O trabalhador abre pelo celular e informa o código individual + CPF.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
                          const SizedBox(height: 10),
                        ],
                        Row(
                          children: [
                            Expanded(child: OutlinedButton.icon(onPressed: _copyLink, icon: const Icon(Icons.copy), label: const Text('Copiar link'))),
                            const SizedBox(width: 8),
                            Expanded(child: FilledButton.icon(onPressed: _shareLink, icon: const Icon(Icons.share), label: const Text('Compartilhar'))),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              else
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.cloud_off_outlined),
                    title: const Text('Link online não configurado'),
                    subtitle: const Text('Abra Configurações e informe a URL do Google Apps Script e a chave de sincronização.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _openSettings,
                  ),
                ),
              if (election.status == 'Aberta') ...[
                const SizedBox(height: 8),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD93025)),
                  onPressed: busy ? null : _closeElection,
                  icon: const Icon(Icons.lock_outline),
                  label: const Text('Encerrar votação'),
                ),
              ],
            ],
            if (election.status == 'Encerrada') ...[
              const SizedBox(height: 16),
              const Text('Apuração', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy)),
              const SizedBox(height: 8),
              if (results.isEmpty)
                const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Atualize para consultar o resultado final.')))
              else
                ...results.map((row) {
                  final map = row is Map ? Map<String, dynamic>.from(row) : <String, dynamic>{};
                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFFE7F5E9),
                        foregroundColor: AuditarBrand.greenDark,
                        child: Text('${map['position'] ?? ''}º'),
                      ),
                      title: Text('${map['name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${map['role'] ?? ''}'),
                      trailing: Text('${map['votes'] ?? 0} voto(s)', style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  );
                }),
            ],
            const SizedBox(height: 16),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.security_outlined, color: AuditarBrand.greenDark),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Sigilo: código e CPF confirmam apenas que o trabalhador está apto e vinculado ao CNPJ da empresa. A participação e a cédula escolhida ficam separadas; o relatório de participação nunca mostra em quem a pessoa votou.',
                        style: TextStyle(fontSize: 12.2),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, int value, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(
          children: [
            Text('$value', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
            const SizedBox(height: 2),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String status) {
    Color color;
    if (status == 'Aberta') {
      color = AuditarBrand.green;
    } else if (status == 'Encerrada') {
      color = Colors.white70;
    } else {
      color = const Color(0xFFF6C453);
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(99)),
      child: Text(status, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 11.5)),
    );
  }

  Widget _infoChip(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(99)),
        child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
      );

  Widget _actionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required String trailing,
    VoidCallback? onTap,
    VoidCallback? secondary,
  }) {
    return Card(
      child: ListTile(
        onTap: onTap ?? secondary,
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFE9EEF9),
          foregroundColor: AuditarBrand.navy,
          child: Icon(icon),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: Text(trailing, style: const TextStyle(fontSize: 11, color: AuditarBrand.greenDark, fontWeight: FontWeight.w800)),
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
