import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../database.dart';
import '../models.dart';
import 'checklist_screen.dart';
import 'report_screen.dart';

class HistoryScreen extends StatefulWidget {
  final String? companyId;

  const HistoryScreen({super.key, this.companyId});

  @override
  State<HistoryScreen> createState() =>
      _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, Object?>> rows = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result =
        await AppDatabase.instance.getInspectionHistory(companyId: widget.companyId);

    if (mounted) {
      setState(() => rows = result);
    }
  }

  Future<void> _reopen(
    Map<String, Object?> row,
  ) async {
    final id = '${row['id']}';

    final header =
        await AppDatabase.instance.getInspectionHeader(id);

    if (header == null) return;

    final answers =
        await AppDatabase.instance.getAnswers(id);

    final templateId =
        '${header['checklist_template_id'] ?? ''}';

    final items = <ChecklistItem>[];

    if (answers.isNotEmpty) {
      for (var i = 0; i < answers.length; i++) {
        final answer = answers[i];
        final nc = await AppDatabase.instance
            .getNonConformityForAnswer(answer.id);

        items.add(
          ChecklistItem(
            id: answer.questionId,
            templateId: templateId,
            sortOrder: i + 1,
            category: answer.questionCategory,
            text: answer.questionText.isEmpty
                ? 'Item ${i + 1}'
                : answer.questionText,
            reference: answer.questionReference,
            priority: nc?.classification ?? 'Média',
          ),
        );
      }
    } else if (templateId.isNotEmpty) {
      final templateIds = templateId
          .split('|')
          .map((value) => value.trim())
          .where((value) => value.isNotEmpty);

      for (final id in templateIds) {
        items.addAll(
          await AppDatabase.instance.getChecklistItems(id),
        );
      }
    }

    if (items.isEmpty) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Não foi possível recuperar os itens desta vistoria.',
          ),
        ),
      );
      return;
    }

    final inspection = Inspection(
      id: id,
      companyId: '${header['company_id']}',
      workSiteId: header['worksite_id'] == null
          ? null
          : '${header['worksite_id']}',
      sectorId: header['sector_id'] == null
          ? null
          : '${header['sector_id']}',
      area: '${header['area'] ?? ''}',
      checklistType:
          '${header['checklist_type'] ?? ''}',
      checklistTemplateId: templateId,
      date: DateTime.tryParse('${header['date']}') ??
          DateTime.now(),
      status: '${header['status'] ?? 'Finalizada'}',
      technicianName:
          '${header['technician_name'] ?? ''}',
      responsibleName:
          '${header['responsible_name'] ?? ''}',
      technicianSignaturePath:
          header['technician_signature_path'] as String?,
      responsibleSignaturePath:
          header['responsible_signature_path'] as String?,
      reportNumber:
          '${header['report_number'] ?? ''}',
      generalNotes:
          '${header['general_notes'] ?? ''}',
      conclusion:
          '${header['conclusion'] ?? ''}',
    );

    if (!mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChecklistScreen(
          inspection: inspection,
          companyName:
              '${header['company_name'] ?? '-'}',
          siteName: header['worksite_name'] == null
              ? null
              : '${header['worksite_name']}',
          checklistItems: items,
          editExisting: true,
        ),
      ),
    );

    await _load();
  }

  Future<void> _delete(
    Map<String, Object?> row,
  ) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir vistoria?'),
        content: const Text(
          'A vistoria, respostas e planos de ação vinculados serão removidos do aplicativo. '
          'Use apenas para registros feitos por engano.',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    await AppDatabase.instance.deleteInspection(
      '${row['id']}',
    );

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Vistoria excluída.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Relatórios e histórico',
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: rows.isEmpty
            ? ListView(
                children: const [
                  SizedBox(height: 180),
                  Center(
                    child: Text(
                      'Nenhuma vistoria registrada.',
                    ),
                  ),
                ],
              )
            : ListView.builder(
                padding:
                    const EdgeInsets.all(12),
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final row = rows[i];

                  final date = DateTime.tryParse(
                    '${row['date']}',
                  );

                  final dateText = date == null
                      ? '-'
                      : DateFormat(
                          'dd/MM/yyyy HH:mm',
                        ).format(date);

                  final company =
                      '${row['company_name'] ?? '-'}';

                  final site =
                      row['worksite_name'] == null
                          ? ''
                          : ' • ${row['worksite_name']}';

                  final status =
                      '${row['status'] ?? '-'}';

                  return Card(
                    child: ListTile(
                      contentPadding:
                          const EdgeInsets.all(12),
                      leading: CircleAvatar(
                        child: Icon(
                          status == 'Finalizada'
                              ? Icons.description_outlined
                              : Icons.edit_note,
                        ),
                      ),
                      title: Text(company),
                      subtitle: Text(
                        [
                          '${row['area'] ?? '-'}$site',
                          dateText,
                          if (row['report_number'] != null)
                            '${row['report_number']}',
                          'Status: $status',
                        ].join('\n'),
                      ),
                      isThreeLine: true,
                      onTap: status == 'Finalizada'
                          ? () => Navigator.of(context)
                              .push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      ReportScreen(
                                    inspectionId:
                                        '${row['id']}',
                                    title: company,
                                  ),
                                ),
                              )
                              .then((_) => _load())
                          : () => _reopen(row),
                      trailing:
                          PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'report') {
                            Navigator.of(context)
                                .push(
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        ReportScreen(
                                      inspectionId:
                                          '${row['id']}',
                                      title: company,
                                    ),
                                  ),
                                )
                                .then((_) => _load());
                          } else if (value ==
                              'reopen') {
                            _reopen(row);
                          } else if (value ==
                              'delete') {
                            _delete(row);
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: 'report',
                            child: Text(
                              'Abrir relatório',
                            ),
                          ),
                          PopupMenuItem(
                            value: 'reopen',
                            child: Text(
                              'Refazer / corrigir',
                            ),
                          ),
                          PopupMenuItem(
                            value: 'delete',
                            child: Text('Excluir'),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
