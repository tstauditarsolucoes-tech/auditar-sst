import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/management_panel_service.dart';
import '../services/storage_service.dart';

class ExtinguishersScreen extends StatefulWidget {
  final Company company;

  const ExtinguishersScreen({
    super.key,
    required this.company,
  });

  @override
  State<ExtinguishersScreen> createState() => _ExtinguishersScreenState();
}

class _ExtinguishersScreenState extends State<ExtinguishersScreen> {
  List<SstRecord> records = [];
  List<Sector> sectors = [];
  bool loading = true;
  String filter = 'TODOS';
  String sectorFilter = 'TODOS';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final results = await Future.wait([
      AppDatabase.instance.getSstRecords(
        type: 'EXTINTOR',
        companyId: widget.company.id,
      ),
      AppDatabase.instance.getSectors(widget.company.id),
    ]);
    if (!mounted) return;
    setState(() {
      records = results[0] as List<SstRecord>;
      sectors = results[1] as List<Sector>;
      loading = false;
    });
  }

  String _statusOf(SstRecord record) {
    final p = record.payload;
    if (p['locationEmpty'] == true) return 'LOCAL SEM EXTINTOR';
    final operational = '${p['operationalStatus'] ?? ''}'.toUpperCase();
    if (operational == 'INATIVO') return 'INATIVO';
    if (operational == 'EM MANUTENÇÃO' || operational == 'EM MANUTENCAO') {
      return 'EM MANUTENÇÃO';
    }
    final checks = [
      p['sealOk'],
      p['gaugeOk'],
      p['signageOk'],
      p['accessOk'],
      p['hoseNozzleOk'],
    ];
    if (checks.any((value) => value == false)) return 'IRREGULAR';

    final today = DateTime.now();
    final base = DateTime(today.year, today.month, today.day);
    final expiry = _dateFrom(p['expiryDate']) ?? record.dueDate;
    final hydro = _dateFrom(p['hydrostaticExpiryDate']);
    if ((expiry != null && _day(expiry).isBefore(base)) ||
        (hydro != null && _day(hydro).isBefore(base))) {
      return 'VENCIDO';
    }
    final soon = [expiry, hydro].whereType<DateTime>().any((date) {
      final days = _day(date).difference(base).inDays;
      return days >= 0 && days <= 30;
    });
    if (soon) return 'VENCE EM BREVE';
    return 'EM DIA';
  }

  DateTime _day(DateTime date) => DateTime(date.year, date.month, date.day);

  DateTime? _dateFrom(Object? value) {
    final raw = '${value ?? ''}'.trim();
    return raw.isEmpty ? null : DateTime.tryParse(raw);
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'EM DIA':
        return AuditarBrand.green;
      case 'VENCE EM BREVE':
        return const Color(0xFFE08A00);
      case 'VENCIDO':
      case 'IRREGULAR':
      case 'LOCAL SEM EXTINTOR':
        return const Color(0xFFD93025);
      case 'EM MANUTENÇÃO':
        return const Color(0xFF6A4BBC);
      default:
        return Colors.blueGrey;
    }
  }

  List<SstRecord> get _visibleRecords {
    Iterable<SstRecord> result = records;
    if (filter == 'CRITICO') {
      result = result.where((record) {
        final status = _statusOf(record);
        return status == 'VENCIDO' ||
            status == 'IRREGULAR' ||
            status == 'LOCAL SEM EXTINTOR';
      });
    } else if (filter != 'TODOS') {
      result = result.where((record) => _statusOf(record) == filter);
    }
    if (sectorFilter != 'TODOS') {
      result = result.where((record) => record.sectorId == sectorFilter);
    }
    return result.toList();
  }

  int _count(String status) =>
      records.where((record) => _statusOf(record) == status).length;

  int _sectorTotal(String sectorId) =>
      records.where((record) => record.sectorId == sectorId).length;

  int _sectorMissing(String sectorId) => records
      .where((record) =>
          record.sectorId == sectorId &&
          _statusOf(record) == 'LOCAL SEM EXTINTOR')
      .length;

  int _sectorAttention(String sectorId) => records.where((record) {
        if (record.sectorId != sectorId) return false;
        final status = _statusOf(record);
        return status != 'EM DIA' && status != 'INATIVO';
      }).length;

  Widget _sectorControl() {
    if (sectors.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Controle por setor',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: AuditarBrand.navy,
                ),
              ),
            ),
            if (sectorFilter != 'TODOS')
              TextButton(
                onPressed: () => setState(() => sectorFilter = 'TODOS'),
                child: const Text('Todos os setores'),
              ),
          ],
        ),
        const SizedBox(height: 7),
        ...sectors.map((sector) {
          final total = _sectorTotal(sector.id);
          final missing = _sectorMissing(sector.id);
          final attention = _sectorAttention(sector.id);
          final selected = sectorFilter == sector.id;
          final statusText = missing > 0
              ? '$missing sem extintor'
              : '$attention requer(em) atenção';
          final color = missing > 0
              ? const Color(0xFFD93025)
              : attention > 0
                  ? const Color(0xFFE08A00)
                  : AuditarBrand.green;
          return Card(
            margin: const EdgeInsets.only(bottom: 7),
            color: selected ? color.withValues(alpha: .06) : Colors.white,
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(
                () => sectorFilter = selected ? 'TODOS' : sector.id,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: [
                    Container(
                      width: 9,
                      height: 34,
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            sector.name,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              color: AuditarBrand.navy,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '$total ponto(s) cadastrado(s) • $statusText',
                            style: TextStyle(
                              fontSize: 10.5,
                              color: missing > 0 ? color : Colors.black54,
                              fontWeight: missing > 0 ? FontWeight.w800 : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '$total',
                      style: TextStyle(
                        color: color,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Future<void> _edit([SstRecord? record]) async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ExtinguisherFormScreen(
          company: widget.company,
          sectors: sectors,
          existing: record,
        ),
      ),
    );
    if (changed == true) await _load();
  }

  Future<void> _delete(SstRecord record) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir extintor?'),
        content: Text(
          'O cadastro ${record.payload['code'] ?? record.title} será removido desta empresa.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteSstRecord(record.id);
    await _load();
    ManagementPanelService.syncCompany(widget.company);
  }

  Future<void> _toggleLocationEmpty(SstRecord record) async {
    final payload = Map<String, dynamic>.from(record.payload);
    final wasEmpty = payload['locationEmpty'] == true;
    final now = DateTime.now();
    payload['locationEmpty'] = !wasEmpty;
    payload['lastInspectionDate'] = now.toIso8601String();
    payload['actionStatus'] =
        wasEmpty ? 'Extintor reposto' : 'Aguardando reposição';

    final preview = SstRecord(
      id: record.id,
      companyId: record.companyId,
      sectorId: record.sectorId,
      type: record.type,
      title: record.title,
      date: now,
      dueDate: record.dueDate,
      status: record.status,
      priority: record.priority,
      payload: payload,
    );
    final updatedStatus = _statusOf(preview);
    final updated = SstRecord(
      id: record.id,
      companyId: record.companyId,
      sectorId: record.sectorId,
      type: record.type,
      title: record.title,
      date: now,
      dueDate: record.dueDate,
      status: updatedStatus,
      priority: updatedStatus == 'VENCIDO' ||
              updatedStatus == 'IRREGULAR' ||
              updatedStatus == 'LOCAL SEM EXTINTOR'
          ? 'Alta'
          : 'Média',
      payload: payload,
    );
    await AppDatabase.instance.upsertSstRecord(updated);
    await _load();
    ManagementPanelService.syncCompany(widget.company);
  }

  String _formatDate(DateTime? date) =>
      date == null ? '—' : DateFormat('dd/MM/yyyy').format(date);

  Widget _summaryCard(String label, int value, Color color, String status) {
    final selected = filter == status;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => setState(() => filter = selected ? 'TODOS' : status),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: selected ? color.withValues(alpha: .11) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? color : const Color(0xFFE5E8EF),
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$value',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: color,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                maxLines: 2,
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Extintores'),
        actions: [
          IconButton(
            tooltip: 'Atualizar',
            onPressed: _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        backgroundColor: AuditarBrand.green,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Novo ponto / extintor'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 100),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AuditarBrand.navy, AuditarBrand.navyDark],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: Colors.white12,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(
                            Icons.fire_extinguisher_rounded,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.company.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                '${records.length} ponto(s) de extintor cadastrado(s)',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 11.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _summaryCard(
                        'Em dia',
                        _count('EM DIA'),
                        AuditarBrand.green,
                        'EM DIA',
                      ),
                      const SizedBox(width: 7),
                      _summaryCard(
                        'Vence em breve',
                        _count('VENCE EM BREVE'),
                        const Color(0xFFE08A00),
                        'VENCE EM BREVE',
                      ),
                    ],
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      _summaryCard(
                        'Vencido / irregular',
                        _count('VENCIDO') + _count('IRREGULAR'),
                        const Color(0xFFD93025),
                        'CRITICO',
                      ),
                      const SizedBox(width: 7),
                      _summaryCard(
                        'Local sem extintor',
                        _count('LOCAL SEM EXTINTOR'),
                        const Color(0xFFD93025),
                        'LOCAL SEM EXTINTOR',
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _sectorControl(),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Pontos e extintores cadastrados',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: AuditarBrand.navy,
                          ),
                        ),
                      ),
                      if (filter != 'TODOS' || sectorFilter != 'TODOS')
                        TextButton(
                          onPressed: () => setState(() {
                            filter = 'TODOS';
                            sectorFilter = 'TODOS';
                          }),
                          child: const Text('Mostrar todos'),
                        ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  if (_visibleRecords.isEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          children: [
                            Icon(
                              Icons.fire_extinguisher_outlined,
                              size: 42,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              records.isEmpty
                                  ? 'Nenhum ponto de extintor cadastrado ainda.'
                                  : 'Nenhum ponto neste filtro.',
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                            if (records.isEmpty) ...[
                              const SizedBox(height: 5),
                              const Text(
                                'Cadastre os pontos e extintores da empresa para acompanhar localização, validade e situação.',
                                textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 12, color: Colors.black54),
                              ),
                            ],
                          ],
                        ),
                      ),
                    )
                  else
                    ..._visibleRecords.map((record) {
                      final p = record.payload;
                      final status = _statusOf(record);
                      final color = _statusColor(status);
                      final expiry = _dateFrom(p['expiryDate']) ?? record.dueDate;
                      final location = [
                        '${p['sectorName'] ?? ''}'.trim(),
                        '${p['location'] ?? ''}'.trim(),
                      ].where((value) => value.isNotEmpty).join(' • ');
                      return Card(
                        margin: const EdgeInsets.only(bottom: 9),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => _edit(record),
                          child: Padding(
                            padding: const EdgeInsets.all(13),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    color: color.withValues(alpha: .10),
                                    borderRadius: BorderRadius.circular(13),
                                  ),
                                  child: Icon(
                                    Icons.fire_extinguisher_rounded,
                                    color: color,
                                  ),
                                ),
                                const SizedBox(width: 11),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              '${p['code'] ?? record.title}',
                                              style: const TextStyle(
                                                fontSize: 14.5,
                                                fontWeight: FontWeight.w900,
                                                color: AuditarBrand.navy,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 5,
                                            ),
                                            decoration: BoxDecoration(
                                              color: color.withValues(alpha: .10),
                                              borderRadius: BorderRadius.circular(99),
                                            ),
                                            child: Text(
                                              status,
                                              style: TextStyle(
                                                color: color,
                                                fontSize: 9,
                                                fontWeight: FontWeight.w900,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        [
                                          '${p['extinguisherType'] ?? ''}',
                                          '${p['capacity'] ?? ''}',
                                        ].where((value) => value.trim().isNotEmpty).join(' • '),
                                        style: const TextStyle(
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      if (location.isNotEmpty) ...[
                                        const SizedBox(height: 3),
                                        Text(
                                          location,
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                      const SizedBox(height: 5),
                                      Text(
                                        'Validade da carga: ${_formatDate(expiry)}',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          color: status == 'VENCIDO'
                                              ? const Color(0xFFD93025)
                                              : Colors.black54,
                                        ),
                                      ),
                                      if (status == 'LOCAL SEM EXTINTOR') ...[
                                        const SizedBox(height: 6),
                                        const Text(
                                          'ATENÇÃO: ponto atualmente sem extintor instalado',
                                          style: TextStyle(
                                            fontSize: 10.5,
                                            color: Color(0xFFD93025),
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ],
                                      finalActionText(p),
                                      replacementText(p),
                                    ],
                                  ),
                                ),
                                PopupMenuButton<String>(
                                  onSelected: (value) {
                                    if (value == 'edit') _edit(record);
                                    if (value == 'toggle_empty') {
                                      _toggleLocationEmpty(record);
                                    }
                                    if (value == 'delete') _delete(record);
                                  },
                                  itemBuilder: (_) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Editar'),
                                    ),
                                    PopupMenuItem(
                                      value: 'toggle_empty',
                                      child: Text(
                                        p['locationEmpty'] == true
                                            ? 'Marcar extintor reposto'
                                            : 'Marcar local sem extintor',
                                      ),
                                    ),
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Text('Excluir'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }

  Widget replacementText(Map<String, dynamic> payload) {
    final reason = '${payload['lastReplacementReason'] ?? ''}'.trim();
    final date = _dateFrom(payload['lastReplacementDate']);
    if (reason.isEmpty || reason == 'Nenhuma' || date == null) {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Text(
        'Última substituição: ${_formatDate(date)} • $reason',
        style: const TextStyle(
          fontSize: 10.5,
          color: Colors.black54,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget finalActionText(Map<String, dynamic> payload) {
    final action = '${payload['actionStatus'] ?? ''}'.trim();
    if (action.isEmpty || action == 'Nenhuma') return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 5),
      child: Text(
        action,
        style: const TextStyle(
          fontSize: 10.5,
          color: Color(0xFF6A4BBC),
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class ExtinguisherFormScreen extends StatefulWidget {
  final Company company;
  final List<Sector> sectors;
  final SstRecord? existing;

  const ExtinguisherFormScreen({
    super.key,
    required this.company,
    required this.sectors,
    this.existing,
  });

  @override
  State<ExtinguisherFormScreen> createState() => _ExtinguisherFormScreenState();
}

class _ExtinguisherFormScreenState extends State<ExtinguisherFormScreen> {
  final formKey = GlobalKey<FormState>();
  final picker = ImagePicker();
  late final TextEditingController code;
  late final TextEditingController capacity;
  late final TextEditingController location;
  late final TextEditingController manufacturer;
  late final TextEditingController cylinderNumber;
  late final TextEditingController responsibleName;
  late final TextEditingController replacementDetails;
  late final TextEditingController notes;

  String extinguisherType = 'ABC';
  String? sectorId;
  String responsibility = 'Empresa';
  String actionStatus = 'Nenhuma';
  String operationalStatus = 'Ativo';
  String replacementReason = 'Nenhuma';
  DateTime? lastReplacementDate;
  bool locationEmpty = false;
  DateTime? rechargeDate;
  DateTime? expiryDate;
  DateTime? hydrostaticExpiryDate;
  bool sealOk = true;
  bool gaugeOk = true;
  bool signageOk = true;
  bool accessOk = true;
  bool hoseNozzleOk = true;
  String photoPath = '';
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.existing?.payload ?? const <String, dynamic>{};
    code = TextEditingController(text: '${p['code'] ?? ''}');
    capacity = TextEditingController(text: '${p['capacity'] ?? ''}');
    location = TextEditingController(text: '${p['location'] ?? ''}');
    manufacturer = TextEditingController(text: '${p['manufacturer'] ?? ''}');
    cylinderNumber = TextEditingController(text: '${p['cylinderNumber'] ?? ''}');
    responsibleName = TextEditingController(text: '${p['responsibleName'] ?? ''}');
    replacementDetails = TextEditingController(text: '${p['replacementDetails'] ?? ''}');
    notes = TextEditingController(text: '${p['notes'] ?? ''}');
    extinguisherType = '${p['extinguisherType'] ?? 'ABC'}';
    sectorId = '${p['sectorId'] ?? ''}'.trim().isEmpty ? null : '${p['sectorId']}';
    responsibility = '${p['responsibility'] ?? 'Empresa'}';
    actionStatus = '${p['actionStatus'] ?? 'Nenhuma'}';
    operationalStatus = '${p['operationalStatus'] ?? 'Ativo'}';
    replacementReason = '${p['lastReplacementReason'] ?? 'Nenhuma'}';
    lastReplacementDate = _dateFrom(p['lastReplacementDate']);
    locationEmpty = p['locationEmpty'] == true;
    rechargeDate = _dateFrom(p['rechargeDate']);
    expiryDate = _dateFrom(p['expiryDate']) ?? widget.existing?.dueDate;
    hydrostaticExpiryDate = _dateFrom(p['hydrostaticExpiryDate']);
    sealOk = p['sealOk'] != false;
    gaugeOk = p['gaugeOk'] != false;
    signageOk = p['signageOk'] != false;
    accessOk = p['accessOk'] != false;
    hoseNozzleOk = p['hoseNozzleOk'] != false;
    photoPath = '${p['photoPath'] ?? ''}';
  }

  DateTime? _dateFrom(Object? value) {
    final raw = '${value ?? ''}'.trim();
    return raw.isEmpty ? null : DateTime.tryParse(raw);
  }

  @override
  void dispose() {
    code.dispose();
    capacity.dispose();
    location.dispose();
    manufacturer.dispose();
    cylinderNumber.dispose();
    responsibleName.dispose();
    replacementDetails.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDate(DateTime? current) async {
    return showDatePicker(
      context: context,
      initialDate: current ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(DateTime.now().year + 15),
    );
  }

  String _formatDate(DateTime? date) =>
      date == null ? 'Não informada' : DateFormat('dd/MM/yyyy').format(date);

  DateTime _dayOnly(DateTime date) => DateTime(date.year, date.month, date.day);

  Future<void> _pickPhoto(ImageSource source) async {
    final image = await picker.pickImage(
      source: source,
      imageQuality: 82,
      maxWidth: 1800,
    );
    if (image == null) return;
    final persisted = await StorageService.persistImage(
      image.path,
      folder: 'extintores',
    );
    if (!mounted) return;
    setState(() => photoPath = persisted);
  }

  String _sectorName() {
    for (final sector in widget.sectors) {
      if (sector.id == sectorId) return sector.name;
    }
    return '';
  }

  String _calculatedStatus(Map<String, dynamic> payload) {
    if (locationEmpty) return 'LOCAL SEM EXTINTOR';
    final operational = operationalStatus.toUpperCase();
    if (operational == 'INATIVO') return 'INATIVO';
    if (operational == 'EM MANUTENÇÃO') return 'EM MANUTENÇÃO';
    if ([sealOk, gaugeOk, signageOk, accessOk, hoseNozzleOk].contains(false)) {
      return 'IRREGULAR';
    }
    final today = DateTime.now();
    final base = DateTime(today.year, today.month, today.day);
    final dates = [expiryDate, hydrostaticExpiryDate].whereType<DateTime>().toList();
    if (dates.any((date) => DateTime(date.year, date.month, date.day).isBefore(base))) {
      return 'VENCIDO';
    }
    if (dates.any((date) {
      final day = DateTime(date.year, date.month, date.day);
      final days = day.difference(base).inDays;
      return days >= 0 && days <= 30;
    })) {
      return 'VENCE EM BREVE';
    }
    return 'EM DIA';
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    if (sectorId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vincule este ponto a um setor.')),
      );
      return;
    }
    if (expiryDate == null && !locationEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe a validade da carga do extintor.')),
      );
      return;
    }
    setState(() => saving = true);
    final now = DateTime.now();

    final existingPayload = widget.existing?.payload ?? const <String, dynamic>{};
    final history = <Map<String, dynamic>>[];
    final rawHistory = existingPayload['replacementHistory'];
    if (rawHistory is List) {
      for (final item in rawHistory) {
        if (item is Map) {
          history.add(Map<String, dynamic>.from(item));
        }
      }
    }
    final oldReason = '${existingPayload['lastReplacementReason'] ?? 'Nenhuma'}';
    final oldReplacementDate = _dateFrom(existingPayload['lastReplacementDate']);
    final replacementChanged = replacementReason != 'Nenhuma' &&
        lastReplacementDate != null &&
        (replacementReason != oldReason ||
            oldReplacementDate == null ||
            _dayOnly(lastReplacementDate!) != _dayOnly(oldReplacementDate));
    if (replacementChanged) {
      history.add({
        'date': lastReplacementDate!.toIso8601String(),
        'reason': replacementReason,
        'details': replacementDetails.text.trim(),
        'previousCode': '${existingPayload['code'] ?? widget.existing?.title ?? ''}',
        'previousCylinderNumber': '${existingPayload['cylinderNumber'] ?? ''}',
        'previousType': '${existingPayload['extinguisherType'] ?? ''}',
        'previousCapacity': '${existingPayload['capacity'] ?? ''}',
        'previousExpiryDate': '${existingPayload['expiryDate'] ?? ''}',
      });
    }

    final payload = <String, dynamic>{
      'code': code.text.trim(),
      'extinguisherType': extinguisherType,
      'capacity': capacity.text.trim(),
      'sectorId': sectorId ?? '',
      'sectorName': _sectorName(),
      'location': location.text.trim(),
      'manufacturer': manufacturer.text.trim(),
      'cylinderNumber': cylinderNumber.text.trim(),
      'rechargeDate': rechargeDate?.toIso8601String() ?? '',
      'expiryDate': expiryDate?.toIso8601String() ?? '',
      'hydrostaticExpiryDate': hydrostaticExpiryDate?.toIso8601String() ?? '',
      'sealOk': sealOk,
      'gaugeOk': gaugeOk,
      'signageOk': signageOk,
      'accessOk': accessOk,
      'hoseNozzleOk': hoseNozzleOk,
      'responsibility': responsibility,
      'responsibleName': responsibleName.text.trim(),
      'actionStatus': actionStatus,
      'operationalStatus': operationalStatus,
      'locationEmpty': locationEmpty,
      'lastReplacementReason': replacementReason,
      'lastReplacementDate': lastReplacementDate?.toIso8601String() ?? '',
      'replacementDetails': replacementDetails.text.trim(),
      'replacementHistory': history,
      'photoPath': photoPath,
      'notes': notes.text.trim(),
      'lastInspectionDate': now.toIso8601String(),
    };
    final status = _calculatedStatus(payload);
    final record = SstRecord(
      id: widget.existing?.id ?? const Uuid().v4(),
      companyId: widget.company.id,
      sectorId: sectorId,
      type: 'EXTINTOR',
      title: code.text.trim(),
      date: now,
      dueDate: expiryDate,
      status: status,
      priority: status == 'VENCIDO' ||
              status == 'IRREGULAR' ||
              status == 'LOCAL SEM EXTINTOR'
          ? 'Alta'
          : 'Média',
      payload: payload,
    );
    await AppDatabase.instance.upsertSstRecord(record);
    await ManagementPanelService.syncCompany(widget.company);
    if (!mounted) return;
    setState(() => saving = false);
    Navigator.pop(context, true);
  }

  Widget _dateField(String label, DateTime? value, ValueChanged<DateTime?> onChanged) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () async {
        final picked = await _pickDate(value);
        if (picked != null) onChanged(picked);
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: const Icon(Icons.calendar_month_outlined),
        ),
        child: Text(_formatDate(value)),
      ),
    );
  }

  Widget _checkTile(String title, bool value, ValueChanged<bool> onChanged) {
    return SwitchListTile.adaptive(
      contentPadding: EdgeInsets.zero,
      title: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
      subtitle: Text(value ? 'Conforme' : 'Irregular'),
      value: value,
      activeTrackColor: AuditarBrand.green.withValues(alpha: .55),
      activeThumbColor: AuditarBrand.green,
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {
    final replacementHistory = <Map<String, dynamic>>[];
    final rawHistory = widget.existing?.payload['replacementHistory'];
    if (rawHistory is List) {
      for (final item in rawHistory) {
        if (item is Map) {
          replacementHistory.add(Map<String, dynamic>.from(item));
        }
      }
    }
    replacementHistory.sort((a, b) {
      final aDate = DateTime.tryParse('${a['date'] ?? ''}') ?? DateTime(1900);
      final bDate = DateTime.tryParse('${b['date'] ?? ''}') ?? DateTime(1900);
      return bDate.compareTo(aDate);
    });

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'Novo ponto / extintor' : 'Editar ponto / extintor'),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 110),
          children: [
            const Text(
              'Identificação',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: code,
              decoration: const InputDecoration(
                labelText: 'Código / identificação *',
                hintText: 'Ex.: EXT-001',
              ),
              validator: (value) => value == null || value.trim().isEmpty ? 'Informe o código.' : null,
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final typeField = DropdownButtonFormField<String>(
                  value: ['ABC', 'BC', 'CO₂', 'AP', 'PQS', 'Espuma'].contains(extinguisherType) ? extinguisherType : 'ABC',
                  decoration: const InputDecoration(labelText: 'Tipo'),
                  items: const ['ABC', 'BC', 'CO₂', 'AP', 'PQS', 'Espuma']
                      .map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(),
                  onChanged: (value) => setState(() => extinguisherType = value ?? 'ABC'),
                );
                final capacityField = TextFormField(
                  controller: capacity,
                  decoration: const InputDecoration(labelText: 'Capacidade', hintText: 'Ex.: 6 kg'),
                );
                if (constraints.maxWidth < 430) {
                  return Column(children: [typeField, const SizedBox(height: 10), capacityField]);
                }
                return Row(children: [Expanded(child: typeField), const SizedBox(width: 10), Expanded(child: capacityField)]);
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: widget.sectors.any((sector) => sector.id == sectorId)
                  ? sectorId
                  : null,
              decoration: const InputDecoration(labelText: 'Setor *'),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Sem setor definido')),
                ...widget.sectors.map(
                  (sector) => DropdownMenuItem<String?>(
                    value: sector.id,
                    child: Text(sector.name),
                  ),
                ),
              ],
              onChanged: (value) => setState(() => sectorId = value),
              validator: (value) => value == null ? 'Selecione o setor.' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: location,
              decoration: const InputDecoration(
                labelText: 'Ponto / local exato *',
                hintText: 'Ex.: ao lado da entrada do forno',
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Informe o ponto onde o extintor deve ficar.'
                  : null,
            ),
            const SizedBox(height: 6),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'Este ponto está sem extintor',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'Marque quando o equipamento foi retirado e ainda não houve reposição.',
              ),
              value: locationEmpty,
              activeTrackColor: const Color(0xFFD93025).withValues(alpha: .45),
              activeThumbColor: const Color(0xFFD93025),
              onChanged: (value) => setState(() => locationEmpty = value),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final manufacturerField = TextFormField(
                  controller: manufacturer,
                  decoration: const InputDecoration(labelText: 'Fabricante'),
                );
                final cylinderField = TextFormField(
                  controller: cylinderNumber,
                  decoration: const InputDecoration(labelText: 'Nº cilindro / patrimônio'),
                );
                if (constraints.maxWidth < 430) {
                  return Column(children: [manufacturerField, const SizedBox(height: 10), cylinderField]);
                }
                return Row(children: [Expanded(child: manufacturerField), const SizedBox(width: 10), Expanded(child: cylinderField)]);
              },
            ),
            const SizedBox(height: 20),
            const Text(
              'Validades',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            const SizedBox(height: 10),
            _dateField('Última recarga', rechargeDate, (value) => setState(() => rechargeDate = value)),
            const SizedBox(height: 10),
            _dateField(
              locationEmpty ? 'Validade da carga' : 'Validade da carga *',
              expiryDate,
              (value) => setState(() => expiryDate = value),
            ),
            const SizedBox(height: 10),
            _dateField(
              'Validade do teste hidrostático',
              hydrostaticExpiryDate,
              (value) => setState(() => hydrostaticExpiryDate = value),
            ),
            const SizedBox(height: 20),
            const Text(
              'Conferência na vistoria',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            _checkTile('Lacre e pino de segurança', sealOk, (value) => setState(() => sealOk = value)),
            _checkTile('Manômetro / indicador de pressão', gaugeOk, (value) => setState(() => gaugeOk = value)),
            _checkTile('Sinalização e identificação', signageOk, (value) => setState(() => signageOk = value)),
            _checkTile('Acesso livre e desobstruído', accessOk, (value) => setState(() => accessOk = value)),
            _checkTile('Mangueira / bico em condição adequada', hoseNozzleOk, (value) => setState(() => hoseNozzleOk = value)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: operationalStatus,
              decoration: const InputDecoration(labelText: 'Situação operacional'),
              items: const ['Ativo', 'Em manutenção', 'Inativo']
                  .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
              onChanged: (value) => setState(() => operationalStatus = value ?? 'Ativo'),
            ),
            const SizedBox(height: 20),
            const Text(
              'Substituição do extintor',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: AuditarBrand.navy,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Use esta parte quando houver troca por uso, lacre rompido, vencimento, avaria ou manutenção.',
              style: TextStyle(fontSize: 11.5, color: Colors.black54),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: const [
                'Nenhuma',
                'Uso / acionamento',
                'Lacre rompido',
                'Vencimento',
                'Recarga / manutenção',
                'Avaria',
                'Outro',
              ].contains(replacementReason)
                  ? replacementReason
                  : 'Outro',
              decoration: const InputDecoration(labelText: 'Motivo da substituição'),
              items: const [
                'Nenhuma',
                'Uso / acionamento',
                'Lacre rompido',
                'Vencimento',
                'Recarga / manutenção',
                'Avaria',
                'Outro',
              ].map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(),
              onChanged: (value) => setState(() {
                replacementReason = value ?? 'Nenhuma';
                if (replacementReason != 'Nenhuma' && lastReplacementDate == null) {
                  lastReplacementDate = DateTime.now();
                }
              }),
            ),
            if (replacementReason != 'Nenhuma') ...[
              const SizedBox(height: 10),
              _dateField(
                'Data da substituição',
                lastReplacementDate,
                (value) => setState(() => lastReplacementDate = value),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: replacementDetails,
                decoration: const InputDecoration(
                  labelText: 'Observação da substituição',
                  hintText: 'Ex.: extintor utilizado em princípio de incêndio',
                ),
              ),
            ],
            if (replacementHistory.isNotEmpty) ...[
              const SizedBox(height: 14),
              const Text(
                'Histórico de substituições',
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              ...replacementHistory.take(4).map((item) {
                final date = _dateFrom(item['date']);
                final reason = '${item['reason'] ?? 'Substituição'}';
                final details = '${item['details'] ?? ''}'.trim();
                return Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F8FA),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE5E8EF)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${_formatDate(date)} • $reason',
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w900,
                          color: AuditarBrand.navy,
                        ),
                      ),
                      if (details.isNotEmpty) ...[
                        const SizedBox(height: 3),
                        Text(
                          details,
                          style: const TextStyle(
                            fontSize: 10.5,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ],
                  ),
                );
              }),
            ],
            const SizedBox(height: 20),
            const Text(
              'Tratativa / responsabilidade',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: responsibility,
              decoration: const InputDecoration(labelText: 'Responsável pela providência'),
              items: const ['Empresa', 'Auditar', 'Terceirizada', 'Não definido']
                  .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
              onChanged: (value) => setState(() => responsibility = value ?? 'Empresa'),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: responsibleName,
              decoration: const InputDecoration(
                labelText: 'Nome do responsável',
                hintText: 'Opcional',
              ),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: actionStatus,
              decoration: const InputDecoration(labelText: 'Andamento'),
              items: const [
                'Nenhuma',
                'Informado ao responsável',
                'Aguardando troca',
                'Aguardando reposição',
                'Enviado para recarga',
                'Substituído pela Auditar',
                'Extintor reposto',
                'Regularizado pela empresa',
              ].map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(),
              onChanged: (value) => setState(() => actionStatus = value ?? 'Nenhuma'),
            ),
            const SizedBox(height: 20),
            const Text(
              'Foto e observações',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
            ),
            const SizedBox(height: 10),
            if (photoPath.isNotEmpty && File(photoPath).existsSync())
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(
                  File(photoPath),
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.camera),
                    icon: const Icon(Icons.photo_camera_outlined),
                    label: const Text('Tirar foto'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Galeria'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: notes,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Observações',
                hintText: 'Condições encontradas, orientação dada, troca realizada etc.',
                alignLabelWithHint: true,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(14, 8, 14, 12),
        child: FilledButton.icon(
          onPressed: saving ? null : _save,
          style: FilledButton.styleFrom(
            backgroundColor: AuditarBrand.green,
            minimumSize: const Size.fromHeight(52),
          ),
          icon: saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              : const Icon(Icons.save_outlined),
          label: Text(saving ? 'Salvando...' : 'Salvar ponto / extintor'),
        ),
      ),
    );
  }
}
