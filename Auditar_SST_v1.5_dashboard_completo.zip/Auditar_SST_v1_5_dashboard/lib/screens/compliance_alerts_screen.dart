import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';
import 'training_requirements_screen.dart';

class ComplianceAlertsScreen extends StatefulWidget {
  final String? companyId;

  const ComplianceAlertsScreen({super.key, this.companyId});

  @override
  State<ComplianceAlertsScreen> createState() =>
      _ComplianceAlertsScreenState();
}

class _ComplianceAlertsScreenState extends State<ComplianceAlertsScreen> {
  List<Company> companies = [];
  List<Worker> workers = [];
  List<TrainingControl> trainings = [];
  List<Map<String, Object?>> missing = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final companyRows = await AppDatabase.instance.getCompanies();
    final workerRows = await AppDatabase.instance.getWorkers(
      companyId: widget.companyId,
    );
    final trainingRows = await AppDatabase.instance.getTrainingControls(
      companyId: widget.companyId,
    );
    final missingRows = await AppDatabase.instance.getMissingRequiredTrainings(
      companyId: widget.companyId,
    );
    if (!mounted) return;
    setState(() {
      companies = companyRows;
      workers = workerRows;
      trainings = trainingRows;
      missing = missingRows;
      loading = false;
    });
  }

  Company? _company(String id) {
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Worker? _worker(String id) {
    for (final worker in workers) {
      if (worker.id == id) return worker;
    }
    return null;
  }

  int _daysUntil(DateTime date) {
    final now = DateTime.now();
    return DateTime(date.year, date.month, date.day)
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;
  }

  List<TrainingControl> get _trainingAlerts {
    return trainings.where((training) {
      if (training.trainingDate == null) return true;
      final expiry = training.expiryDate;
      return expiry != null && _daysUntil(expiry) <= 30;
    }).toList()
      ..sort((a, b) {
        final ad = a.expiryDate ?? DateTime(1900);
        final bd = b.expiryDate ?? DateTime(1900);
        return ad.compareTo(bd);
      });
  }

  List<Worker> get _medicalAlerts {
    return workers.where((worker) {
      final date = worker.nextMedicalExamDate;
      return date == null || _daysUntil(date) <= 30;
    }).toList()
      ..sort((a, b) {
        final ad = a.nextMedicalExamDate ?? DateTime(1900);
        final bd = b.nextMedicalExamDate ?? DateTime(1900);
        return ad.compareTo(bd);
      });
  }

  Future<void> _openMatrix() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrainingRequirementsScreen(companyId: widget.companyId),
      ),
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final trainingAlerts = _trainingAlerts;
    final medicalAlerts = _medicalAlerts;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Avisos SST'),
        actions: [
          IconButton(
            tooltip: 'Matriz por cargo',
            onPressed: _openMatrix,
            icon: const Icon(Icons.rule_folder_outlined),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
                children: [
                  ResponsiveWrap(
                    minItemWidth: 112,
                    maxColumns: 3,
                    children: [
                      _metric('Sem registro', missing.length, const Color(0xFFD93025)),
                      _metric('Treinamentos', trainingAlerts.length, const Color(0xFFF29D18)),
                      _metric('Periódicos', medicalAlerts.length, const Color(0xFF6A4BBC)),
                    ],
                  ),
                  _sectionTitle('Sem treinamento obrigatório', missing.length),
                  if (missing.isEmpty)
                    _empty('Nenhuma falta encontrada na matriz por cargo.')
                  else
                    ...missing.map((row) {
                      final worker = row['worker'] as Worker;
                      final requirement = row['requirement'] as TrainingRequirement;
                      return _alertCard(
                        icon: Icons.report_gmailerrorred_outlined,
                        color: const Color(0xFFD93025),
                        title: worker.name,
                        subtitle:
                            '${requirement.code.isEmpty ? requirement.title : '${requirement.code} • ${requirement.title}'}\n${worker.role} • ${_company(worker.companyId)?.name ?? 'Empresa'}',
                        status: 'SEM REGISTRO',
                      );
                    }),
                  _sectionTitle('Treinamentos próximos ou vencidos', trainingAlerts.length),
                  if (trainingAlerts.isEmpty)
                    _empty('Nenhum treinamento vence nos próximos 30 dias.')
                  else
                    ...trainingAlerts.map((training) {
                      final worker = _worker(training.workerId);
                      final expiry = training.expiryDate;
                      final days = expiry == null ? null : _daysUntil(expiry);
                      final status = training.trainingDate == null
                          ? 'PENDENTE'
                          : days! < 0
                              ? 'VENCIDO'
                              : days == 0
                                  ? 'VENCE HOJE'
                                  : 'VENCE EM $days DIAS';
                      final color = days != null && days < 0
                          ? const Color(0xFFD93025)
                          : const Color(0xFFF29D18);
                      return _alertCard(
                        icon: Icons.school_outlined,
                        color: color,
                        title: worker?.name ?? 'Trabalhador',
                        subtitle:
                            '${training.code.isEmpty ? training.title : '${training.code} • ${training.title}'}${expiry == null ? '' : '\nValidade: ${DateFormat('dd/MM/yyyy').format(expiry)}'}',
                        status: status,
                      );
                    }),
                  _sectionTitle('Exames periódicos', medicalAlerts.length),
                  if (medicalAlerts.isEmpty)
                    _empty('Nenhum periódico vence nos próximos 30 dias.')
                  else
                    ...medicalAlerts.map((worker) {
                      final date = worker.nextMedicalExamDate;
                      final days = date == null ? null : _daysUntil(date);
                      final status = date == null
                          ? 'SEM DATA'
                          : days! < 0
                              ? 'VENCIDO'
                              : days == 0
                                  ? 'VENCE HOJE'
                                  : 'VENCE EM $days DIAS';
                      final color = days == null
                          ? Colors.black54
                          : days < 0
                              ? const Color(0xFFD93025)
                              : const Color(0xFF6A4BBC);
                      return _alertCard(
                        icon: Icons.medical_information_outlined,
                        color: color,
                        title: worker.name,
                        subtitle:
                            '${worker.role.isEmpty ? 'Cargo não informado' : worker.role} • ${_company(worker.companyId)?.name ?? 'Empresa'}${date == null ? '\nPróximo periódico não cadastrado' : '\nPróximo exame: ${DateFormat('dd/MM/yyyy').format(date)}'}',
                        status: status,
                      );
                    }),
                ],
              ),
            ),
    );
  }

  Widget _metric(String label, int value, Color color) => Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
          child: Column(
            children: [
              Text('$value', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5)),
            ],
          ),
        ),
      );

  Widget _sectionTitle(String title, int count) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(
          '$title ($count)',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AuditarBrand.navy),
        ),
      );

  Widget _empty(String text) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(text),
        ),
      );

  Widget _alertCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required String status,
  }) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: color.withValues(alpha: .10),
            foregroundColor: color,
            child: Icon(icon),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
            decoration: BoxDecoration(
              color: color.withValues(alpha: .10),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              status,
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: color),
            ),
          ),
        ),
      );
}
