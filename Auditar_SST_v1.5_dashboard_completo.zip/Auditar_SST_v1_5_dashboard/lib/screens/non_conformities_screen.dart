import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../brand.dart';
import '../database.dart';
import 'non_conformity_detail_screen.dart';
import '../widgets/responsive_wrap.dart';

class NonConformitiesScreen extends StatefulWidget {
  final String? companyId;
  final String? inspectionId;

  const NonConformitiesScreen({
    super.key,
    this.companyId,
    this.inspectionId,
  });

  @override
  State<NonConformitiesScreen> createState() => _NonConformitiesScreenState();
}

class _NonConformitiesScreenState extends State<NonConformitiesScreen> {
  final searchController = TextEditingController();
  List<Map<String, Object?>> rows = [];
  Map<String, int> counts = {};
  String selectedStatus = 'Todas';
  bool loading = true;

  static const statuses = <String>[
    'Todas',
    'Pendente',
    'Em andamento',
    'Aguardando verificação',
    'Vencida',
    'Concluída',
  ];

  @override
  void initState() {
    super.initState();
    _load();
    searchController.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final result = await AppDatabase.instance.getNonConformityRows(
      companyId: widget.companyId,
      inspectionId: widget.inspectionId,
      includeClosed: true,
      status: selectedStatus,
    );
    final statusCounts = await AppDatabase.instance.getNonConformityStatusCounts(
      companyId: widget.companyId,
    );
    if (!mounted) return;
    setState(() {
      rows = result;
      counts = statusCounts;
      loading = false;
    });
  }

  List<Map<String, Object?>> get filteredRows {
    final q = searchController.text.trim().toLowerCase();
    if (q.isEmpty) return rows;
    return rows.where((row) {
      final haystack = [
        row['code'],
        row['company_name'],
        row['sector_name'],
        row['worksite_name'],
        row['description'],
        row['classification'],
        row['status'],
      ].map((e) => '${e ?? ''}'.toLowerCase()).join(' ');
      return haystack.contains(q);
    }).toList();
  }

  Color _priorityColor(String priority) {
    switch (priority) {
      case 'Crítica':
        return const Color(0xFF9B1C1C);
      case 'Alta':
        return const Color(0xFFD93025);
      case 'Média':
        return const Color(0xFFF29D18);
      default:
        return AuditarBrand.greenDark;
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Vencida':
        return const Color(0xFFD93025);
      case 'Pendente':
        return const Color(0xFFF29D18);
      case 'Em andamento':
        return AuditarBrand.navy;
      case 'Aguardando verificação':
        return const Color(0xFF7B61A8);
      case 'Concluída':
        return AuditarBrand.greenDark;
      default:
        return Colors.blueGrey;
    }
  }

  String _shortStatus(String status) {
    if (status == 'Aguardando verificação') return 'Aguardando';
    return status;
  }

  int get openCount =>
      (counts['Pendente'] ?? 0) +
      (counts['Em andamento'] ?? 0) +
      (counts['Aguardando verificação'] ?? 0) +
      (counts['Vencida'] ?? 0);

  Widget _summaryCard(String label, int value, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: .18)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(
            '$value',
            style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 20),
          ),
          Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 10.5, height: 1.15),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = filteredRows;
    return Scaffold(
      appBar: AppBar(title: const Text('Não conformidades')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
          children: [
            ResponsiveWrap(
              minItemWidth: 112,
              maxColumns: 3,
              children: [
                _summaryCard('Abertas', openCount, const Color(0xFFD93025), Icons.warning_amber_rounded),
                _summaryCard('Vencidas', counts['Vencida'] ?? 0, const Color(0xFFD93025), Icons.event_busy_outlined),
                _summaryCard('Concluídas', counts['Concluída'] ?? 0, AuditarBrand.greenDark, Icons.task_alt),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Buscar NC, empresa, setor...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: searchController.clear,
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: statuses.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (_, index) {
                  final status = statuses[index];
                  final selected = selectedStatus == status;
                  final count = status == 'Todas'
                      ? counts.values.fold<int>(0, (a, b) => a + b)
                      : counts[status] ?? 0;
                  return ChoiceChip(
                    selected: selected,
                    label: Text('${_shortStatus(status)} $count'),
                    onSelected: (_) async {
                      setState(() => selectedStatus = status);
                      await _load();
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 70),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (visible.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 70),
                child: Center(child: Text('Nenhuma não conformidade encontrada.')),
              )
            else
              ...visible.map((row) {
                final priority = '${row['classification'] ?? 'Média'}';
                final status = '${row['status'] ?? 'Pendente'}';
                final sector = '${row['sector_name'] ?? ''}'.trim();
                final site = '${row['worksite_name'] ?? ''}'.trim();
                final openActions = int.tryParse('${row['open_action_count'] ?? 0}') ?? 0;
                final actionCount = int.tryParse('${row['action_count'] ?? 0}') ?? 0;
                final due = row['next_due_date'] == null
                    ? null
                    : DateTime.tryParse('${row['next_due_date']}');

                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.of(context)
                        .push(
                          MaterialPageRoute(
                            builder: (_) => NonConformityDetailScreen(ncId: '${row['id']}'),
                          ),
                        )
                        .then((_) => _load()),
                    child: Padding(
                      padding: const EdgeInsets.all(13),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '${row['code'] ?? 'NC'}',
                                  style: const TextStyle(fontWeight: FontWeight.w800, color: AuditarBrand.navy),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _statusColor(status).withValues(alpha: .10),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  _shortStatus(status),
                                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _statusColor(status)),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _priorityColor(priority).withValues(alpha: .09),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  priority,
                                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _priorityColor(priority)),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 7),
                          Text(
                            '${row['description'] ?? ''}'.trim().isEmpty
                                ? '${row['question_text'] ?? 'Não conformidade registrada'}'
                                : '${row['description']}',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 7),
                          Text(
                            [
                              '${row['company_name'] ?? '-'}',
                              if (sector.isNotEmpty) sector,
                              if (site.isNotEmpty) site,
                            ].join(' • '),
                            style: const TextStyle(fontSize: 11, color: Colors.black54),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.assignment_outlined, size: 16, color: openActions > 0 ? AuditarBrand.navy : Colors.black38),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  actionCount == 0
                                      ? 'Sem plano de ação'
                                      : '$actionCount ação(ões) • $openActions aberta(s)',
                                  style: const TextStyle(fontSize: 10.5, color: Colors.black54),
                                ),
                              ),
                              if (due != null)
                                Text(
                                  'Prazo ${DateFormat('dd/MM').format(due)}',
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w700,
                                    color: status == 'Vencida' ? const Color(0xFFD93025) : Colors.black54,
                                  ),
                                ),
                              const SizedBox(width: 2),
                              const Icon(Icons.chevron_right, size: 20, color: Colors.black38),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
