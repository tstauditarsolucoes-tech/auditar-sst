import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';

class WorkSitesScreen extends StatefulWidget {
  final Company company;

  const WorkSitesScreen({
    super.key,
    required this.company,
  });

  @override
  State<WorkSitesScreen> createState() =>
      _WorkSitesScreenState();
}

class _WorkSitesScreenState extends State<WorkSitesScreen> {
  List<WorkSite> sites = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getWorkSites(
      widget.company.id,
      onlyActive: false,
    );

    if (mounted) {
      setState(() => sites = result);
    }
  }

  Future<void> _editSite([WorkSite? site]) async {
    final name = TextEditingController(text: site?.name ?? '');
    final address =
        TextEditingController(text: site?.address ?? '');

    String type = site?.type ?? 'Obra';
    bool active = site?.active ?? true;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(
            site == null
                ? 'Nova obra / unidade'
                : 'Editar obra / unidade',
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText: 'Nome *',
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  value: type,
                  decoration: const InputDecoration(
                    labelText: 'Tipo',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'Obra',
                      child: Text('Obra'),
                    ),
                    DropdownMenuItem(
                      value: 'Fábrica',
                      child: Text('Fábrica'),
                    ),
                    DropdownMenuItem(
                      value: 'Unidade',
                      child: Text('Unidade'),
                    ),
                    DropdownMenuItem(
                      value: 'Fazenda',
                      child: Text('Fazenda'),
                    ),
                    DropdownMenuItem(
                      value: 'Loja',
                      child: Text('Loja'),
                    ),
                    DropdownMenuItem(
                      value: 'Depósito',
                      child: Text('Depósito'),
                    ),
                    DropdownMenuItem(
                      value: 'Outro',
                      child: Text('Outro'),
                    ),
                  ],
                  onChanged: (value) {
                    setDialogState(
                      () => type = value ?? 'Obra',
                    );
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: address,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Endereço / referência',
                  ),
                ),
                if (site != null) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Local ativo'),
                    value: active,
                    onChanged: (value) {
                      setDialogState(() => active = value);
                    },
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (save != true || name.text.trim().isEmpty) return;

    final updated = WorkSite(
      id: site?.id ?? const Uuid().v4(),
      companyId: widget.company.id,
      name: name.text.trim(),
      type: type,
      address: address.text.trim(),
      active: active,
    );

    if (site == null) {
      await AppDatabase.instance.insertWorkSite(updated);
    } else {
      await AppDatabase.instance.updateWorkSite(updated);
    }

    await _load();
  }

  Future<void> _deleteSite(WorkSite site) async {
    final deleted =
        await AppDatabase.instance.deleteWorkSiteIfUnused(
      site.id,
    );

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          deleted
              ? 'Local excluído.'
              : 'Este local possui vistorias. Desative-o para preservar o histórico.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.company.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editSite(),
        icon: const Icon(Icons.add_location_alt),
        label: const Text('Obra / Unidade'),
      ),
      body: sites.isEmpty
          ? const Center(
              child: Text(
                'Nenhuma obra ou unidade cadastrada.',
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 92),
              itemCount: sites.length,
              itemBuilder: (_, i) {
                final site = sites[i];

                return Card(
                  child: ListTile(
                    leading: const Icon(
                      Icons.location_on_outlined,
                    ),
                    title: Text(site.name),
                    subtitle: Text(
                      [
                        site.type,
                        if (site.address != null &&
                            site.address!.isNotEmpty)
                          site.address!,
                        site.active ? 'Ativo' : 'Desativado',
                      ].join(' • '),
                    ),
                    onTap: () => _editSite(site),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') {
                          _editSite(site);
                        } else if (value == 'delete') {
                          _deleteSite(site);
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(
                          value: 'edit',
                          child: Text('Editar'),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text('Excluir'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
