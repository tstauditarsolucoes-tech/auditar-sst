import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import 'cipa_election_detail_screen.dart';

class CipaScreen extends StatefulWidget {
  final String? companyId;

  const CipaScreen({super.key, this.companyId});

  @override
  State<CipaScreen> createState() => _CipaScreenState();
}

class _CipaScreenState extends State<CipaScreen> {
  List<Company> companies = [];
  List<CipaElection> elections = [];
  String? selectedCompanyId;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    selectedCompanyId = widget.companyId;
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final loadedCompanies = await AppDatabase.instance.getCompanies();
    var companyId = selectedCompanyId;
    if (companyId == null && loadedCompanies.isNotEmpty) {
      companyId = loadedCompanies.first.id;
    }
    final loadedElections = companyId == null
        ? <CipaElection>[]
        : await AppDatabase.instance.getCipaElections(companyId: companyId);
    if (!mounted) return;
    setState(() {
      companies = loadedCompanies;
      selectedCompanyId = companyId;
      elections = loadedElections;
      loading = false;
    });
  }

  Company? get selectedCompany {
    for (final company in companies) {
      if (company.id == selectedCompanyId) return company;
    }
    return null;
  }

  Future<void> _changeCompany(String? value) async {
    if (value == null) return;
    setState(() => selectedCompanyId = value);
    await _load();
  }

  Future<void> _createElection() async {
    final company = selectedCompany;
    if (company == null) {
      _message('Cadastre uma empresa antes de criar uma eleição.');
      return;
    }
    final draft = await showDialog<_CipaElectionDraft>(
      context: context,
      builder: (_) => const _CreateCipaElectionDialog(),
    );
    if (draft == null || !mounted) return;

    final now = DateTime.now();
    final election = CipaElection(
      id: const Uuid().v4(),
      companyId: company.id,
      title: draft.title,
      managementPeriod: draft.managementPeriod,
      status: 'Rascunho',
      startDate: draft.startDate,
      endDate: draft.endDate,
      accessToken: const Uuid().v4().replaceAll('-', ''),
      createdAt: now,
    );
    await AppDatabase.instance.insertCipaElection(election);
    await _load();
  }

  Future<void> _openElection(CipaElection election) async {
    final company = selectedCompany;
    if (company == null) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CipaElectionDetailScreen(
          company: company,
          election: election,
        ),
      ),
    );
    await _load();
  }

  Future<void> _delete(CipaElection election) async {
    if (election.status != 'Rascunho') {
      _message('Uma eleição publicada não deve ser excluída. Mantenha o histórico.');
      return;
    }
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir eleição?'),
        content: Text('Excluir o rascunho “${election.title}”?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirm != true) return;
    await AppDatabase.instance.deleteCipaElection(election.id);
    await _load();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CIPA')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 92),
              children: [
                if (widget.companyId == null && companies.isNotEmpty) ...[
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    value: selectedCompanyId,
                    decoration: const InputDecoration(
                      labelText: 'Empresa',
                      prefixIcon: Icon(Icons.business_outlined),
                    ),
                    items: companies
                        .map((company) => DropdownMenuItem(value: company.id, child: Text(company.name)))
                        .toList(),
                    onChanged: _changeCompany,
                  ),
                  const SizedBox(height: 14),
                ],
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AuditarBrand.navy, AuditarBrand.navyDark],
                    ),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.white12,
                        child: Icon(Icons.how_to_vote_rounded, color: Colors.white),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Processo eleitoral da CIPA', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
                            SizedBox(height: 3),
                            Text('Prepare candidatos, eleitores, QR Code e acompanhe a participação.', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                if (companies.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('Cadastre uma empresa para iniciar a gestão da CIPA.'),
                    ),
                  )
                else if (elections.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('Nenhuma eleição cadastrada para esta empresa.'),
                    ),
                  )
                else
                  ...elections.map((election) {
                    final isOpen = election.status == 'Aberta';
                    final isClosed = election.status == 'Encerrada';
                    final color = isOpen
                        ? AuditarBrand.greenDark
                        : isClosed
                            ? AuditarBrand.navy
                            : const Color(0xFFF29D18);
                    return Card(
                      margin: const EdgeInsets.only(bottom: 9),
                      child: ListTile(
                        onTap: () => _openElection(election),
                        leading: CircleAvatar(
                          backgroundColor: color.withValues(alpha: .12),
                          foregroundColor: color,
                          child: const Icon(Icons.how_to_vote_outlined),
                        ),
                        title: Text(election.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text([
                          if (election.managementPeriod.isNotEmpty) election.managementPeriod,
                          election.status,
                        ].join(' • ')),
                        trailing: election.status == 'Rascunho'
                            ? IconButton(
                                tooltip: 'Excluir rascunho',
                                onPressed: () => _delete(election),
                                icon: const Icon(Icons.delete_outline),
                              )
                            : const Icon(Icons.chevron_right),
                      ),
                    );
                  }),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createElection,
        icon: const Icon(Icons.add),
        label: const Text('Nova eleição'),
      ),
    );
  }
}

class _CipaElectionDraft {
  final String title;
  final String managementPeriod;
  final DateTime? startDate;
  final DateTime? endDate;

  const _CipaElectionDraft({
    required this.title,
    required this.managementPeriod,
    required this.startDate,
    required this.endDate,
  });
}

class _CreateCipaElectionDialog extends StatefulWidget {
  const _CreateCipaElectionDialog();

  @override
  State<_CreateCipaElectionDialog> createState() =>
      _CreateCipaElectionDialogState();
}

class _CreateCipaElectionDialogState
    extends State<_CreateCipaElectionDialog> {
  final titleController = TextEditingController(text: 'Eleição CIPA');
  final termController = TextEditingController();
  DateTime? startDate = DateTime.now();
  DateTime? endDate;

  @override
  void dispose() {
    titleController.dispose();
    termController.dispose();
    super.dispose();
  }

  Future<void> _pickStartDate() async {
    FocusScope.of(context).unfocus();
    final picked = await showDatePicker(
      context: context,
      initialDate: startDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) {
      setState(() {
        startDate = picked;
        if (endDate != null && endDate!.isBefore(picked)) endDate = null;
      });
    }
  }

  Future<void> _pickEndDate() async {
    FocusScope.of(context).unfocus();
    final minimumDate = startDate ?? DateTime(2020);
    final initialDate = endDate == null || endDate!.isBefore(minimumDate)
        ? minimumDate
        : endDate!;
    final picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: minimumDate,
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) setState(() => endDate = picked);
  }

  void _submit() {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe o nome da eleição.')),
      );
      return;
    }
    if (startDate != null &&
        endDate != null &&
        endDate!.isBefore(startDate!)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('O encerramento não pode ser anterior ao início.'),
        ),
      );
      return;
    }
    FocusScope.of(context).unfocus();
    Navigator.of(context).pop(
      _CipaElectionDraft(
        title: title,
        managementPeriod: termController.text.trim(),
        startDate: startDate,
        endDate: endDate,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Nova eleição da CIPA'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Nome da eleição *',
                  prefixIcon: Icon(Icons.how_to_vote_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: termController,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submit(),
                decoration: const InputDecoration(
                  labelText: 'Gestão / mandato',
                  hintText: 'Ex.: 2026/2027',
                  prefixIcon: Icon(Icons.calendar_month_outlined),
                ),
              ),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.play_circle_outline),
                title: const Text('Início previsto'),
                subtitle: Text(
                  startDate == null
                      ? 'Não definido'
                      : DateFormat('dd/MM/yyyy').format(startDate!),
                ),
                onTap: _pickStartDate,
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.stop_circle_outlined),
                title: const Text('Encerramento previsto'),
                subtitle: Text(
                  endDate == null
                      ? 'Não definido'
                      : DateFormat('dd/MM/yyyy').format(endDate!),
                ),
                onTap: _pickEndDate,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Criar'),
        ),
      ],
    );
  }
}
