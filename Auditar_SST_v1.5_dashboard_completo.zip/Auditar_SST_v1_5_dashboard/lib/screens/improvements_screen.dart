import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/improvement_pdf_service.dart';
import '../services/management_panel_service.dart';
import '../services/storage_service.dart';

class ImprovementsScreen extends StatefulWidget {
  final Company? company;

  const ImprovementsScreen({
    super.key,
    this.company,
  });

  @override
  State<ImprovementsScreen> createState() => _ImprovementsScreenState();
}

class _ImprovementsScreenState extends State<ImprovementsScreen> {
  bool loading = true;
  bool generatingReport = false;
  List<Company> companies = [];
  List<Sector> sectors = [];
  List<SstRecord> records = [];
  String? companyFilterId;
  String? sectorFilterId;
  String statusFilter = 'Todos';

  @override
  void initState() {
    super.initState();
    companyFilterId = widget.company?.id;
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final allCompanies = await AppDatabase.instance.getCompanies(onlyActive: false);
    final allRecords = await AppDatabase.instance.getSstRecords(type: 'MELHORIA');
    final allSectors = <Sector>[];
    for (final company in allCompanies) {
      allSectors.addAll(
        await AppDatabase.instance.getSectors(company.id, onlyActive: false),
      );
    }
    if (!mounted) return;
    setState(() {
      companies = allCompanies;
      records = allRecords;
      sectors = allSectors;
      if (widget.company != null) companyFilterId = widget.company!.id;
      loading = false;
    });
  }

  Company? _companyById(String? id) {
    if (id == null) return null;
    for (final company in companies) {
      if (company.id == id) return company;
    }
    return null;
  }

  Sector? _sectorById(String? id) {
    if (id == null) return null;
    for (final sector in sectors) {
      if (sector.id == id) return sector;
    }
    return null;
  }

  String _companyName(SstRecord record) {
    final stored = '${record.payload['companyName'] ?? ''}'.trim();
    if (stored.isNotEmpty) return stored;
    return _companyById(record.companyId)?.name ?? 'Empresa não informada';
  }

  String _sectorName(SstRecord record) {
    final stored = '${record.payload['sectorName'] ?? ''}'.trim();
    if (stored.isNotEmpty) return stored;
    return _sectorById(record.sectorId)?.name ?? 'Setor não informado';
  }

  bool _realized(SstRecord record) =>
      record.status.toLowerCase().contains('realiz') ||
      record.status.toLowerCase().contains('conclu');

  bool _inProgress(SstRecord record) =>
      record.status == 'Planejada' || record.status == 'Em execução';

  bool _overdue(SstRecord record) {
    if (_realized(record) || record.dueDate == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final due = record.dueDate!;
    return DateTime(due.year, due.month, due.day).isBefore(today);
  }

  List<SstRecord> get _visibleRecords => records.where((record) {
        if (widget.company != null && record.companyId != widget.company!.id) {
          return false;
        }
        if (companyFilterId != null && record.companyId != companyFilterId) {
          return false;
        }
        if (sectorFilterId != null && record.sectorId != sectorFilterId) {
          return false;
        }
        if (statusFilter == 'Sugestões' && record.status != 'Sugerida') {
          return false;
        }
        if (statusFilter == 'Em andamento' && !_inProgress(record)) {
          return false;
        }
        if (statusFilter == 'Realizadas' && !_realized(record)) {
          return false;
        }
        return true;
      }).toList()
        ..sort((a, b) => b.date.compareTo(a.date));

  List<Sector> get _filterSectors {
    final companyId = companyFilterId ?? widget.company?.id;
    if (companyId == null) return [];
    return sectors.where((sector) => sector.companyId == companyId).toList();
  }

  Future<void> _edit([SstRecord? existing]) async {
    final fixedCompany = widget.company ??
        (companyFilterId == null ? null : _companyById(companyFilterId));
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ImprovementFormScreen(
          fixedCompany: fixedCompany,
          companies: companies.where((company) => company.active).toList(),
          existing: existing,
        ),
      ),
    );
    if (saved == true) await _load();
  }

  Future<void> _delete(SstRecord record) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir melhoria?'),
        content: Text('O registro “${record.title}” será removido.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppDatabase.instance.deleteSstRecord(record.id);
    final company = _companyById(record.companyId);
    if (company != null) {
      await ManagementPanelService.syncCompany(company);
    }
    await _load();
  }

  Future<void> _shareReport() async {
    if (generatingReport) return;
    final company = widget.company ?? _companyById(companyFilterId);
    if (company == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Escolha uma empresa para gerar o relatório de melhorias.'),
        ),
      );
      return;
    }
    final companyRecords = records
        .where((record) => record.companyId == company.id)
        .toList();
    if (companyRecords.isEmpty) return;
    setState(() => generatingReport = true);
    try {
      final companySectors = sectors
          .where((sector) => sector.companyId == company.id)
          .toList();
      final bytes = await ImprovementPdfService.generate(
        company: company,
        records: companyRecords,
        sectors: companySectors,
      );
      final safeCompany = company.name
          .replaceAll(RegExp(r'[^A-Za-z0-9À-ÿ _-]'), '')
          .trim()
          .replaceAll(RegExp(r'\s+'), '_');
      await Printing.sharePdf(
        bytes: bytes,
        filename:
            'Relatorio_Melhorias_${safeCompany.isEmpty ? 'Empresa' : safeCompany}.pdf',
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível gerar o relatório: $error')),
      );
    } finally {
      if (mounted) setState(() => generatingReport = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visibleRecords;
    final scoped = records.where((record) {
      if (widget.company != null) return record.companyId == widget.company!.id;
      if (companyFilterId != null) return record.companyId == companyFilterId;
      return true;
    }).toList();
    final realized = scoped.where(_realized).length;
    final suggestions = scoped.where((r) => r.status == 'Sugerida').length;
    final running = scoped.where(_inProgress).length;
    final evidenceComplete = scoped.where((record) {
      final before = '${record.payload['beforePhotoPath'] ?? ''}'.trim();
      final after = '${record.payload['afterPhotoPath'] ?? ''}'.trim();
      return before.isNotEmpty && after.isNotEmpty;
    }).length;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.company == null ? 'Melhorias' : 'Melhorias • ${widget.company!.name}', maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Gerar relatório de melhorias',
            onPressed: generatingReport ? null : _shareReport,
            icon: generatingReport
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.picture_as_pdf_outlined),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 100),
                children: [
                  _summaryCard(
                    total: scoped.length,
                    suggestions: suggestions,
                    running: running,
                    realized: realized,
                    evidenceComplete: evidenceComplete,
                  ),
                  const SizedBox(height: 12),
                  _filters(),
                  const SizedBox(height: 12),
                  if (visible.isEmpty)
                    _empty()
                  else
                    ...visible.map(_card),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Nova melhoria'),
      ),
    );
  }

  Widget _summaryCard({
    required int total,
    required int suggestions,
    required int running,
    required int realized,
    required int evidenceComplete,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Controle de melhorias',
              style: TextStyle(
                color: AuditarBrand.navy,
                fontWeight: FontWeight.w900,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 3),
            const Text(
              'Sugestões e melhorias realizadas, sempre vinculadas à empresa e ao setor.',
              style: TextStyle(color: Colors.black54, fontSize: 11),
            ),
            const SizedBox(height: 11),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 520;
                final first = [
                  Expanded(child: _metric('Total', total, AuditarBrand.navy)),
                  const SizedBox(width: 6),
                  Expanded(child: _metric('Sugeridas', suggestions, const Color(0xFFF29D18))),
                ];
                final second = [
                  Expanded(child: _metric('Em andamento', running, const Color(0xFF6A4BBC))),
                  const SizedBox(width: 6),
                  Expanded(child: _metric('Realizadas', realized, AuditarBrand.greenDark)),
                ];
                if (compact) {
                  return Column(
                    children: [
                      Row(children: first),
                      const SizedBox(height: 6),
                      Row(children: second),
                    ],
                  );
                }
                return Row(
                  children: [
                    ...first,
                    const SizedBox(width: 6),
                    ...second,
                  ],
                );
              },
            ),
            if (evidenceComplete > 0) ...[
              const SizedBox(height: 8),
              Text(
                '$evidenceComplete melhoria(s) com fotos de antes e depois.',
                style: const TextStyle(
                  color: AuditarBrand.greenDark,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, int value, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .07),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Column(
          children: [
            Text(
              '$value',
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 2,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 9.2),
            ),
          ],
        ),
      );

  Widget _filters() {
    final activeCompanies = companies.where((company) => company.active).toList();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            if (widget.company == null) ...[
              DropdownButtonFormField<String>(
                isExpanded: true,
                value: companyFilterId ?? '',
                decoration: const InputDecoration(
                  labelText: 'Empresa',
                  isDense: true,
                ),
                items: [
                  const DropdownMenuItem(value: '', child: Text('Todas as empresas')),
                  ...activeCompanies.map(
                    (company) => DropdownMenuItem(
                      value: company.id,
                      child: Text(company.name),
                    ),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    companyFilterId = value == null || value.isEmpty ? null : value;
                    sectorFilterId = null;
                  });
                },
              ),
              const SizedBox(height: 8),
            ],
            if ((companyFilterId ?? widget.company?.id) != null) ...[
              DropdownButtonFormField<String>(
                isExpanded: true,
                value: sectorFilterId ?? '',
                decoration: const InputDecoration(
                  labelText: 'Setor',
                  isDense: true,
                ),
                items: [
                  const DropdownMenuItem(value: '', child: Text('Todos os setores')),
                  ..._filterSectors.map(
                    (sector) => DropdownMenuItem(
                      value: sector.id,
                      child: Text(sector.name),
                    ),
                  ),
                ],
                onChanged: (value) => setState(
                  () => sectorFilterId = value == null || value.isEmpty ? null : value,
                ),
              ),
              const SizedBox(height: 8),
            ],
            DropdownButtonFormField<String>(
              isExpanded: true,
              value: statusFilter,
              decoration: const InputDecoration(
                labelText: 'Situação',
                isDense: true,
              ),
              items: const ['Todos', 'Sugestões', 'Em andamento', 'Realizadas']
                  .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
              onChanged: (value) => setState(() => statusFilter = value ?? 'Todos'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _empty() => Card(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              Icon(
                Icons.auto_awesome_outlined,
                size: 50,
                color: AuditarBrand.navy.withValues(alpha: .24),
              ),
              const SizedBox(height: 10),
              const Text(
                'Nenhuma melhoria encontrada.',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              const Text(
                'Registre uma sugestão ou uma melhoria já realizada e vincule ao setor.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
            ],
          ),
        ),
      );

  Widget _card(SstRecord record) {
    final payload = record.payload;
    final before = '${payload['beforePhotoPath'] ?? ''}'.trim();
    final after = '${payload['afterPhotoPath'] ?? ''}'.trim();
    final location = '${payload['location'] ?? ''}'.trim();
    final overdue = _overdue(record);
    final color = _statusColor(record, overdue: overdue);

    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Card(
        margin: EdgeInsets.zero,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _edit(record),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        record.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14.5,
                        ),
                      ),
                    ),
                    _chip(overdue ? 'Vencida' : record.status, color),
                    PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') _edit(record);
                        if (value == 'delete') _delete(record);
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Editar')),
                        PopupMenuItem(value: 'delete', child: Text('Excluir')),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  '${_companyName(record)} • ${_sectorName(record)}${location.isEmpty ? '' : ' • $location'}',
                  style: const TextStyle(color: Colors.black54, fontSize: 11.5),
                ),
                const SizedBox(height: 9),
                Row(
                  children: [
                    Expanded(child: _evidenceThumb('ANTES', before, Icons.photo_camera_back_outlined)),
                    const SizedBox(width: 8),
                    Expanded(child: _evidenceThumb('DEPOIS', after, Icons.done_all_rounded)),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 4,
                  children: [
                    _meta(Icons.calendar_today_outlined, DateFormat('dd/MM/yyyy').format(record.date)),
                    _meta(Icons.flag_outlined, record.priority),
                    if (record.dueDate != null)
                      _meta(Icons.event_outlined, 'Prazo ${DateFormat('dd/MM/yyyy').format(record.dueDate!)}'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _evidenceThumb(String label, String path, IconData icon) {
    final exists = path.isNotEmpty && File(path).existsSync();
    return Container(
      height: 94,
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8FA),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE6E9EF)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (exists)
            Image.file(File(path), fit: BoxFit.cover)
          else
            Center(child: Icon(icon, color: Colors.black26, size: 28)),
          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              margin: const EdgeInsets.all(6),
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: .64),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 9.5,
            fontWeight: FontWeight.w800,
            color: color,
          ),
        ),
      );

  Widget _meta(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12.5, color: Colors.black45),
          const SizedBox(width: 3),
          Text(text, style: const TextStyle(fontSize: 10.5, color: Colors.black54)),
        ],
      );

  Color _statusColor(SstRecord record, {bool overdue = false}) {
    if (overdue) return const Color(0xFFD93025);
    if (_realized(record)) return AuditarBrand.greenDark;
    if (record.status == 'Em execução') return const Color(0xFF6A4BBC);
    if (record.status == 'Planejada') return const Color(0xFF1976D2);
    return const Color(0xFFF29D18);
  }
}

class ImprovementFormScreen extends StatefulWidget {
  final Company? fixedCompany;
  final List<Company> companies;
  final SstRecord? existing;

  const ImprovementFormScreen({
    super.key,
    this.fixedCompany,
    required this.companies,
    this.existing,
  });

  @override
  State<ImprovementFormScreen> createState() => _ImprovementFormScreenState();
}

class _ImprovementFormScreenState extends State<ImprovementFormScreen> {
  final formKey = GlobalKey<FormState>();
  final picker = ImagePicker();

  late final TextEditingController title;
  late final TextEditingController location;
  late final TextEditingController beforeSituation;
  late final TextEditingController suggestion;
  late final TextEditingController expectedBenefit;
  late final TextEditingController workPerformed;
  late final TextEditingController result;
  late final TextEditingController responsible;
  late final TextEditingController notes;

  String? companyId;
  String? sectorId;
  List<Sector> companySectors = [];
  String status = 'Sugerida';
  String priority = 'Média';
  DateTime date = DateTime.now();
  DateTime? dueDate;
  DateTime? completedDate;
  String beforePhotoPath = '';
  String afterPhotoPath = '';
  bool loadingSectors = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final record = widget.existing;
    final payload = record?.payload ?? const <String, dynamic>{};
    companyId = widget.fixedCompany?.id ?? record?.companyId;
    sectorId = record?.sectorId;
    title = TextEditingController(text: record?.title ?? '');
    location = TextEditingController(text: '${payload['location'] ?? ''}');
    beforeSituation = TextEditingController(text: '${payload['beforeSituation'] ?? ''}');
    suggestion = TextEditingController(text: '${payload['suggestion'] ?? ''}');
    expectedBenefit = TextEditingController(text: '${payload['expectedBenefit'] ?? ''}');
    workPerformed = TextEditingController(text: '${payload['workPerformed'] ?? ''}');
    result = TextEditingController(text: '${payload['result'] ?? ''}');
    responsible = TextEditingController(text: '${payload['responsible'] ?? ''}');
    notes = TextEditingController(text: '${payload['notes'] ?? ''}');
    status = record?.status ?? 'Sugerida';
    priority = record?.priority ?? 'Média';
    date = record?.date ?? DateTime.now();
    dueDate = record?.dueDate;
    completedDate = DateTime.tryParse('${payload['completedDate'] ?? ''}');
    beforePhotoPath = '${payload['beforePhotoPath'] ?? ''}';
    afterPhotoPath = '${payload['afterPhotoPath'] ?? ''}';
    _loadSectors();
  }

  @override
  void dispose() {
    title.dispose();
    location.dispose();
    beforeSituation.dispose();
    suggestion.dispose();
    expectedBenefit.dispose();
    workPerformed.dispose();
    result.dispose();
    responsible.dispose();
    notes.dispose();
    super.dispose();
  }

  Company? _company() {
    if (widget.fixedCompany != null) return widget.fixedCompany;
    for (final company in widget.companies) {
      if (company.id == companyId) return company;
    }
    return null;
  }

  Sector? _sector() {
    for (final sector in companySectors) {
      if (sector.id == sectorId) return sector;
    }
    return null;
  }

  Future<void> _loadSectors() async {
    if (companyId == null || companyId!.isEmpty) {
      if (mounted) setState(() => companySectors = []);
      return;
    }
    if (mounted) setState(() => loadingSectors = true);
    final loaded = await AppDatabase.instance.getSectors(companyId!);
    if (!mounted) return;
    setState(() {
      companySectors = loaded;
      if (sectorId != null && !loaded.any((sector) => sector.id == sectorId)) {
        sectorId = null;
      }
      loadingSectors = false;
    });
  }

  Future<DateTime?> _pickDate(DateTime? current) => showDatePicker(
        context: context,
        initialDate: current ?? DateTime.now(),
        firstDate: DateTime(2020),
        lastDate: DateTime(DateTime.now().year + 10),
      );

  Future<void> _pickPhoto({
    required bool before,
    required ImageSource source,
  }) async {
    final image = await picker.pickImage(
      source: source,
      imageQuality: 82,
      maxWidth: 1800,
    );
    if (image == null) return;
    final persisted = await StorageService.persistImage(
      image.path,
      folder: before ? 'melhorias/antes' : 'melhorias/depois',
    );
    if (!mounted) return;
    setState(() {
      if (before) {
        beforePhotoPath = persisted;
      } else {
        afterPhotoPath = persisted;
      }
    });
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false) || saving) return;
    final company = _company();
    final sector = _sector();
    if (company == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escolha a empresa.')),
      );
      return;
    }
    if (sector == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escolha o setor onde a melhoria foi identificada ou realizada.')),
      );
      return;
    }

    setState(() => saving = true);
    final now = DateTime.now();
    DateTime? finalCompletedDate = completedDate;
    if (status == 'Realizada' && finalCompletedDate == null) {
      finalCompletedDate = now;
    }
    if (status != 'Realizada') finalCompletedDate = null;

    final payload = <String, dynamic>{
      'companyName': company.name,
      'sectorName': sector.name,
      'location': location.text.trim(),
      'beforeSituation': beforeSituation.text.trim(),
      'suggestion': suggestion.text.trim(),
      'expectedBenefit': expectedBenefit.text.trim(),
      'workPerformed': workPerformed.text.trim(),
      'result': result.text.trim(),
      'responsible': responsible.text.trim(),
      'beforePhotoPath': beforePhotoPath,
      'afterPhotoPath': afterPhotoPath,
      'completedDate': finalCompletedDate?.toIso8601String() ?? '',
      'notes': notes.text.trim(),
      'updatedAt': now.toIso8601String(),
    };

    final record = SstRecord(
      id: widget.existing?.id ?? const Uuid().v4(),
      companyId: company.id,
      sectorId: sector.id,
      type: 'MELHORIA',
      title: title.text.trim(),
      date: date,
      dueDate: dueDate,
      status: status,
      priority: priority,
      payload: payload,
    );

    await AppDatabase.instance.upsertSstRecord(record);
    await ManagementPanelService.syncCompany(company);
    if (!mounted) return;
    setState(() => saving = false);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final company = _company();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'Nova melhoria' : 'Editar melhoria', maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 120),
          children: [
            _section('Empresa e setor'),
            if (widget.fixedCompany != null)
              InputDecorator(
                decoration: const InputDecoration(labelText: 'Empresa'),
                child: Text(
                  widget.fixedCompany!.name,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              )
            else
              DropdownButtonFormField<String>(
                isExpanded: true,
                value: companyId ?? '',
                decoration: const InputDecoration(labelText: 'Empresa *'),
                items: [
                  const DropdownMenuItem(value: '', child: Text('Selecione a empresa')),
                  ...widget.companies.map(
                    (item) => DropdownMenuItem(value: item.id, child: Text(item.name)),
                  ),
                ],
                onChanged: (value) async {
                  setState(() {
                    companyId = value == null || value.isEmpty ? null : value;
                    sectorId = null;
                  });
                  await _loadSectors();
                },
                validator: (value) => value == null || value.isEmpty ? 'Escolha a empresa.' : null,
              ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              isExpanded: true,
              value: sectorId ?? '',
              decoration: InputDecoration(
                labelText: 'Setor *',
                helperText: company == null
                    ? 'Escolha primeiro a empresa.'
                    : companySectors.isEmpty
                        ? 'Cadastre um setor nesta empresa antes de registrar a melhoria.'
                        : 'A melhoria ficará vinculada a este setor.',
              ),
              items: [
                const DropdownMenuItem(value: '', child: Text('Selecione o setor')),
                ...companySectors.map(
                  (sector) => DropdownMenuItem(value: sector.id, child: Text(sector.name)),
                ),
              ],
              onChanged: loadingSectors || company == null
                  ? null
                  : (value) => setState(
                        () => sectorId = value == null || value.isEmpty ? null : value,
                      ),
              validator: (value) => value == null || value.isEmpty ? 'Escolha o setor.' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: location,
              decoration: const InputDecoration(
                labelText: 'Local exato',
                hintText: 'Ex.: ao lado do forno 2, corredor de expedição',
              ),
            ),
            const SizedBox(height: 14),
            _section('Sugestão / melhoria'),
            TextFormField(
              controller: title,
              decoration: const InputDecoration(
                labelText: 'Título da melhoria *',
                hintText: 'Ex.: Melhorar isolamento da área quente',
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Informe um título.'
                  : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: beforeSituation,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Situação antes *',
                hintText: 'Descreva como estava o local antes da melhoria.',
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Descreva a situação antes.'
                  : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: suggestion,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Sugestão / melhoria proposta *',
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Informe a melhoria sugerida.'
                  : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: expectedBenefit,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Benefício esperado',
                hintText: 'Ex.: reduzir exposição, melhorar organização, evitar acesso indevido',
              ),
            ),
            const SizedBox(height: 14),
            _section('Antes e depois'),
            const Text(
              'Registre a foto do local antes. Quando a melhoria for concluída, adicione a foto depois para comprovar a evolução.',
              style: TextStyle(color: Colors.black54, fontSize: 11.5),
            ),
            const SizedBox(height: 9),
            LayoutBuilder(
              builder: (context, constraints) {
                final beforeCard = _photoCard(
                  title: 'ANTES',
                  path: beforePhotoPath,
                  before: true,
                );
                final afterCard = _photoCard(
                  title: 'DEPOIS',
                  path: afterPhotoPath,
                  before: false,
                );
                if (constraints.maxWidth < 560) {
                  return Column(
                    children: [
                      beforeCard,
                      const SizedBox(height: 10),
                      afterCard,
                    ],
                  );
                }
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: beforeCard),
                    const SizedBox(width: 10),
                    Expanded(child: afterCard),
                  ],
                );
              },
            ),
            const SizedBox(height: 14),
            _section('Acompanhamento'),
            LayoutBuilder(
              builder: (context, constraints) {
                final priorityField = DropdownButtonFormField<String>(
                  isExpanded: true,
                  value: priority,
                  decoration: const InputDecoration(labelText: 'Prioridade'),
                  items: const ['Baixa', 'Média', 'Alta']
                      .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                      .toList(),
                  onChanged: (value) => setState(() => priority = value ?? priority),
                );
                final statusField = DropdownButtonFormField<String>(
                  isExpanded: true,
                  value: status,
                  decoration: const InputDecoration(labelText: 'Situação'),
                  items: const ['Sugerida', 'Planejada', 'Em execução', 'Realizada']
                      .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                      .toList(),
                  onChanged: (value) => setState(() {
                    status = value ?? status;
                    if (status == 'Realizada' && completedDate == null) {
                      completedDate = DateTime.now();
                    }
                  }),
                );
                if (constraints.maxWidth < 430) {
                  return Column(
                    children: [priorityField, const SizedBox(height: 10), statusField],
                  );
                }
                return Row(
                  children: [
                    Expanded(child: priorityField),
                    const SizedBox(width: 8),
                    Expanded(child: statusField),
                  ],
                );
              },
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: responsible,
              decoration: const InputDecoration(labelText: 'Responsável / responsável informado'),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final registered = _dateField('Data do registro', date, () async {
                  final picked = await _pickDate(date);
                  if (picked != null) setState(() => date = picked);
                });
                final due = _dateField('Prazo', dueDate, () async {
                  final picked = await _pickDate(dueDate ?? date);
                  if (picked != null) setState(() => dueDate = picked);
                }, optional: true);
                if (constraints.maxWidth < 430) {
                  return Column(children: [registered, const SizedBox(height: 10), due]);
                }
                return Row(
                  children: [
                    Expanded(child: registered),
                    const SizedBox(width: 8),
                    Expanded(child: due),
                  ],
                );
              },
            ),
            if (status == 'Realizada') ...[
              const SizedBox(height: 10),
              _dateField('Data da realização', completedDate, () async {
                final picked = await _pickDate(completedDate ?? DateTime.now());
                if (picked != null) setState(() => completedDate = picked);
              }),
              const SizedBox(height: 10),
              TextFormField(
                controller: workPerformed,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'O que foi feito'),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: result,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Resultado / melhoria observada'),
              ),
            ],
            const SizedBox(height: 10),
            TextFormField(
              controller: notes,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Observações'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(
            onPressed: saving ? null : _save,
            icon: saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(saving ? 'Salvando...' : 'Salvar melhoria'),
            ),
          ),
        ),
      ),
    );
  }

  Widget _photoCard({
    required String title,
    required String path,
    required bool before,
  }) {
    final exists = path.isNotEmpty && File(path).existsSync();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: TextStyle(
                color: before ? AuditarBrand.navy : AuditarBrand.greenDark,
                fontWeight: FontWeight.w900,
                fontSize: 11,
              ),
            ),
            const SizedBox(height: 7),
            Container(
              height: 170,
              decoration: BoxDecoration(
                color: const Color(0xFFF7F8FA),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE6E9EF)),
              ),
              clipBehavior: Clip.antiAlias,
              child: exists
                  ? Image.file(File(path), fit: BoxFit.cover)
                  : const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add_a_photo_outlined, color: Colors.black26, size: 30),
                          SizedBox(height: 5),
                          Text('Sem foto', style: TextStyle(color: Colors.black38, fontSize: 11)),
                        ],
                      ),
                    ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(before: before, source: ImageSource.camera),
                    icon: const Icon(Icons.photo_camera_outlined, size: 17),
                    label: const Text('Câmera'),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(before: before, source: ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_outlined, size: 17),
                    label: const Text('Galeria'),
                  ),
                ),
              ],
            ),
            if (path.isNotEmpty)
              TextButton.icon(
                onPressed: () => setState(() {
                  if (before) {
                    beforePhotoPath = '';
                  } else {
                    afterPhotoPath = '';
                  }
                }),
                icon: const Icon(Icons.delete_outline, size: 17),
                label: const Text('Remover foto'),
              ),
          ],
        ),
      ),
    );
  }

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: const TextStyle(
            color: AuditarBrand.navy,
            fontSize: 15,
            fontWeight: FontWeight.w900,
          ),
        ),
      );

  Widget _dateField(
    String label,
    DateTime? value,
    VoidCallback onTap, {
    bool optional = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: const Icon(Icons.calendar_today_outlined, size: 18),
        ),
        child: Text(
          value == null
              ? (optional ? 'Sem prazo' : '-')
              : DateFormat('dd/MM/yyyy').format(value),
        ),
      ),
    );
  }
}
