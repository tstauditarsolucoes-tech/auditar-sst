import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/ai_assistant_service.dart';
import '../services/management_panel_service.dart';
import 'settings_screen.dart';

class ManagementPanelScreen extends StatefulWidget {
  final Company company;

  const ManagementPanelScreen({
    super.key,
    required this.company,
  });

  @override
  State<ManagementPanelScreen> createState() => _ManagementPanelScreenState();
}

class _ManagementPanelScreenState extends State<ManagementPanelScreen> {
  bool loading = true;
  bool syncing = false;
  bool testingEmail = false;
  bool analyzingPriorities = false;
  bool enabled = true;
  String accessToken = '';
  String panelUrl = '';
  String lastSyncStatus = 'Nunca sincronizado';
  String lastSyncAt = '';
  String lastError = '';
  Map<String, int> summary = {};
  Map<String, int> trainingSummary = {};
  List<Map<String, Object?>> sectors = [];
  int missingRequiredCount = 0;
  int medicalCriticalCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);

    final db = AppDatabase.instance;
    final panel = await db.ensureManagementPanel(widget.company.id);
    final loadedSummary =
        await db.getDashboardSummary(companyId: widget.company.id);
    final loadedTrainings =
        await db.getTrainingSummary(companyId: widget.company.id);
    final loadedSectors =
        await db.getCompanySectorPerformance(widget.company.id);
    final missingRequired =
        await db.getMissingRequiredTrainings(companyId: widget.company.id);
    final workers = await db.getWorkers(companyId: widget.company.id);
    final url =
        await ManagementPanelService.panelUrlForCompany(widget.company.id);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final medicalLimit = today.add(const Duration(days: 30));
    final criticalMedicalExams = workers.where((worker) {
      final nextExam = worker.nextMedicalExamDate;
      if (nextExam == null) return true;
      final examDay = DateTime(nextExam.year, nextExam.month, nextExam.day);
      return !examDay.isAfter(medicalLimit);
    }).length;

    if (!mounted) return;
    setState(() {
      enabled = (panel['enabled'] as int? ?? 1) == 1;
      accessToken = '${panel['access_token'] ?? ''}';
      lastSyncStatus = '${panel['last_sync_status'] ?? 'Nunca sincronizado'}';
      lastSyncAt = '${panel['last_sync_at'] ?? ''}';
      lastError = '${panel['last_error'] ?? ''}';
      summary = loadedSummary;
      trainingSummary = loadedTrainings;
      sectors = loadedSectors;
      missingRequiredCount = missingRequired.length;
      medicalCriticalCount = criticalMedicalExams;
      panelUrl = url;
      loading = false;
    });
  }

  int _intValue(Map<String, Object?> row, String key) {
    final value = row[key];
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  int _sectorConformity(Map<String, Object?> row) {
    final c = _intValue(row, 'conformes');
    final p = _intValue(row, 'parciais');
    final nc = _intValue(row, 'nao_conformes');
    final total = c + p + nc;
    if (total == 0) return 0;
    return ((c / total) * 100).round();
  }

  String get _shortCode {
    if (accessToken.length <= 10) return accessToken.toUpperCase();
    return accessToken.substring(0, 10).toUpperCase();
  }

  String _formatSyncDate() {
    if (lastSyncAt.trim().isEmpty) return 'Nunca';
    final parsed = DateTime.tryParse(lastSyncAt)?.toLocal();
    if (parsed == null) return 'Nunca';
    return DateFormat('dd/MM/yyyy HH:mm').format(parsed);
  }

  Future<void> _copyLink() async {
    if (panelUrl.isEmpty) {
      _showMessage(
        'O link externo ainda precisa da configuração única de publicação web.',
      );
      return;
    }
    await Clipboard.setData(ClipboardData(text: panelUrl));
    _showMessage('Link do painel copiado.');
  }

  Future<void> _shareLink() async {
    if (panelUrl.isEmpty) {
      _showMessage(
        'O link externo ainda precisa da configuração única de publicação web.',
      );
      return;
    }
    await Share.share(
      'Acompanhe os indicadores de SST da ${widget.company.name}:\n$panelUrl',
    );
  }

  Future<void> _sync() async {
    setState(() => syncing = true);
    final result = await ManagementPanelService.syncCompany(widget.company);
    if (!mounted) return;
    setState(() => syncing = false);
    _showMessage(result.message);
    await _load();
  }

  Future<void> _testEmail() async {
    if (widget.company.reportEmail.trim().isEmpty) {
      _showMessage('Cadastre o e-mail principal da empresa antes do teste.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Enviar e-mail de teste?'),
        content: Text(
          'Será enviado um e-mail real para ${widget.company.reportEmail}'
          '${widget.company.secondaryReportEmail.trim().isEmpty ? '' : ' e cópia para ${widget.company.secondaryReportEmail}'}.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Enviar teste'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => testingEmail = true);
    final result = await ManagementPanelService.sendTestEmail(widget.company);
    if (!mounted) return;
    setState(() => testingEmail = false);
    _showMessage(result.message);
  }

  Future<void> _analyzePriorities() async {
    setState(() => analyzingPriorities = true);
    final reply = await AiAssistantService.analyzeCompanyPriorities(
      widget.company,
    );
    if (!mounted) return;
    setState(() => analyzingPriorities = false);
    if (!reply.success) {
      _showMessage(reply.message);
      return;
    }

    final result = reply.result;
    final situation = '${result['situation'] ?? ''}'.trim();
    final priorities = (result['priorities'] as List? ?? const [])
        .map((value) => '$value'.trim())
        .where((value) => value.isNotEmpty)
        .toList();
    final nextActions = (result['nextActions'] as List? ?? const [])
        .map((value) => '$value'.trim())
        .where((value) => value.isNotEmpty)
        .toList();
    final dataGaps = (result['dataGaps'] as List? ?? const [])
        .map((value) => '$value'.trim())
        .where((value) => value.isNotEmpty)
        .toList();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Prioridades sugeridas pela IA'),
        content: SizedBox(
          width: 620,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.amber.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Leitura de apoio baseada nos registros do aplicativo. Confirme as prioridades antes de tomar decisões.',
                    style: TextStyle(fontSize: 12.5),
                  ),
                ),
                if (situation.isNotEmpty)
                  _aiResultSection('Situação geral', situation),
                if (priorities.isNotEmpty)
                  _aiResultSection(
                    'Prioridades',
                    priorities.map((value) => '• $value').join('\n'),
                  ),
                if (nextActions.isNotEmpty)
                  _aiResultSection(
                    'Próximos passos',
                    nextActions.map((value) => '• $value').join('\n'),
                  ),
                if (dataGaps.isNotEmpty)
                  _aiResultSection(
                    'Informações que ainda faltam',
                    dataGaps.map((value) => '• $value').join('\n'),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleAccess() async {
    final target = !enabled;

    if (!target && panelUrl.isNotEmpty) {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Desativar acesso?'),
          content: const Text(
            'O painel deixará de ficar disponível para a empresa depois da sincronização.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Desativar'),
            ),
          ],
        ),
      );
      if (confirm != true) return;
    }

    final db = AppDatabase.instance;
    await db.setManagementPanelEnabled(widget.company.id, target);

    if (panelUrl.isNotEmpty) {
      setState(() => syncing = true);
      final result = await ManagementPanelService.syncCompany(
        widget.company,
        enabledOverride: target,
      );
      if (!mounted) return;
      setState(() => syncing = false);

      if (!result.success) {
        await db.setManagementPanelEnabled(widget.company.id, !target);
        _showMessage(
          'Não alterei o acesso porque a atualização web falhou. ${result.message}',
        );
        await _load();
        return;
      }
    }

    _showMessage(target ? 'Painel reativado.' : 'Acesso ao painel desativado.');
    await _load();
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SettingsScreen()),
    );
    await _load();
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Painel Gerencial')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
                children: [
                  _header(),
                  const SizedBox(height: 12),
                  _linkCard(),
                  const SizedBox(height: 16),
                  const Text(
                    'O que a gerência acompanha',
                    style: TextStyle(
                      color: AuditarBrand.navy,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _metric(
                          'Conformidade',
                          '${summary['conformity'] ?? 0}%',
                          Icons.donut_large_rounded,
                          AuditarBrand.greenDark,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _metric(
                          'NC abertas',
                          '${(summary['ncPending'] ?? 0) + (summary['ncInProgress'] ?? 0) + (summary['ncAwaiting'] ?? 0) + (summary['ncOverdue'] ?? 0)}',
                          Icons.warning_amber_rounded,
                          const Color(0xFFD93025),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _metric(
                          'Obrigatórios sem registro',
                          '$missingRequiredCount',
                          Icons.assignment_late_outlined,
                          missingRequiredCount > 0
                              ? const Color(0xFFD93025)
                              : AuditarBrand.greenDark,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _metric(
                          'Periódicos críticos',
                          '$medicalCriticalCount',
                          Icons.health_and_safety_outlined,
                          medicalCriticalCount > 0
                              ? const Color(0xFFF29D18)
                              : AuditarBrand.greenDark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _metric(
                          'Ações vencidas',
                          '${summary['overdue'] ?? 0}',
                          Icons.schedule_rounded,
                          const Color(0xFFD93025),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _metric(
                          'Treinamentos vencidos',
                          '${trainingSummary['expired'] ?? 0}',
                          Icons.school_outlined,
                          const Color(0xFFF29D18),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Card(
                    color: AuditarBrand.navy.withValues(alpha: .05),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(
                                Icons.auto_awesome_rounded,
                                color: AuditarBrand.navy,
                              ),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Leitura técnica da empresa',
                                  style: TextStyle(
                                    color: AuditarBrand.navy,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 7),
                          const Text(
                            'A IA analisa indicadores agregados, treinamentos, periódicos, NCs, ações e setores para sugerir o que deve ser tratado primeiro.',
                            style: TextStyle(
                              fontSize: 12.5,
                              color: Colors.black54,
                              height: 1.35,
                            ),
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: analyzingPriorities
                                  ? null
                                  : _analyzePriorities,
                              icon: analyzingPriorities
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Icon(Icons.auto_awesome_rounded),
                              label: Text(
                                analyzingPriorities
                                    ? 'Analisando...'
                                    : 'Analisar prioridades com IA',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Desempenho por setor',
                          style: TextStyle(
                            color: AuditarBrand.navy,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Text(
                        '${sectors.length} setor${sectors.length == 1 ? '' : 'es'}',
                        style: const TextStyle(color: Colors.black45),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (sectors.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('Ainda não há dados por setor.'),
                      ),
                    )
                  else
                    ...sectors.map(_sectorCard),
                  const SizedBox(height: 12),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.privacy_tip_outlined, color: AuditarBrand.navy),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'O painel publica nome, cargo, treinamentos e vencimentos necessários à gestão. CPF, arquivos de ASO, certificados e outros documentos pessoais não são publicados.',
                              style: TextStyle(fontSize: 12.5, height: 1.35),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _header() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AuditarBrand.navy, AuditarBrand.navyDark],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Colors.white12,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.monitor_heart_outlined,
                  color: AuditarBrand.green,
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.company.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    const Text(
                      'Acompanhamento gerencial SST',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                decoration: BoxDecoration(
                  color: enabled ? AuditarBrand.green : Colors.white24,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  enabled ? 'ATIVO' : 'DESATIVADO',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'Código individual: $_shortCode',
            style: const TextStyle(color: Colors.white70, fontSize: 11.5),
          ),
        ],
      ),
    );
  }

  Widget _linkCard() {
    final configured = panelUrl.isNotEmpty;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  configured ? Icons.link_rounded : Icons.cloud_off_outlined,
                  color: configured ? AuditarBrand.greenDark : const Color(0xFFF29D18),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    configured ? 'Painel executivo individual preparado' : 'Publicação web ainda não configurada',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (configured)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'A empresa verá uma leitura rápida da situação geral, prioridades, treinamentos, periódicos, NCs, ações e vistorias.',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Colors.black54,
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SelectableText(
                    panelUrl,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AuditarBrand.navy,
                    ),
                  ),
                ],
              )
            else
              const Text(
                'O aplicativo já criou o acesso individual desta empresa. Falta somente uma configuração única do serviço web para transformar esse acesso em um link externo.',
                style: TextStyle(fontSize: 12.5, color: Colors.black54, height: 1.35),
              ),
            const SizedBox(height: 10),
            Text(
              'Última atualização: ${_formatSyncDate()} • $lastSyncStatus',
              style: const TextStyle(fontSize: 11.5, color: Colors.black54),
            ),
            if (lastError.trim().isNotEmpty && lastSyncStatus == 'Falha') ...[
              const SizedBox(height: 5),
              Text(
                lastError,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, color: Color(0xFFD93025)),
              ),
            ],
            const SizedBox(height: 12),
            if (configured) ...[
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: enabled ? _copyLink : null,
                      icon: const Icon(Icons.copy_rounded, size: 18),
                      label: const Text('Copiar'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: enabled ? _shareLink : null,
                      icon: const Icon(Icons.share_outlined, size: 18),
                      label: const Text('Compartilhar'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: syncing || !enabled ? null : _sync,
                  icon: const Icon(Icons.sync_rounded),
                  label: Text(syncing ? 'Atualizando...' : 'Atualizar painel'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: syncing || testingEmail ? null : _testEmail,
                  icon: const Icon(Icons.mark_email_read_outlined),
                  label: Text(
                    testingEmail
                        ? 'Enviando teste...'
                        : 'Enviar e-mail de teste',
                  ),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: syncing ? null : _toggleAccess,
                  icon: Icon(enabled ? Icons.link_off_rounded : Icons.link_rounded),
                  label: Text(enabled ? 'Desativar acesso' : 'Reativar acesso'),
                ),
              ),
            ] else
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _openSettings,
                  icon: const Icon(Icons.settings_outlined),
                  label: const Text('Configurar publicação'),
                ),
              ),
            if (syncing) ...[
              const SizedBox(height: 10),
              const LinearProgressIndicator(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, String value, IconData icon, Color color) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 5),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 21,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 10.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _aiResultSection(String title, String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AuditarBrand.navy,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 5),
          SelectableText(
            text,
            style: const TextStyle(fontSize: 13, height: 1.35),
          ),
        ],
      ),
    );
  }

  Widget _sectorCard(Map<String, Object?> row) {
    final conformity = _sectorConformity(row);
    final openNcs = _intValue(row, 'open_ncs');
    final overdue = _intValue(row, 'overdue_ncs');
    final color = conformity >= 80
        ? AuditarBrand.greenDark
        : conformity >= 60
            ? const Color(0xFFF29D18)
            : const Color(0xFFD93025);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            SizedBox(
              width: 48,
              height: 48,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: conformity / 100,
                    strokeWidth: 5,
                    color: color,
                    backgroundColor: const Color(0xFFE9EDF3),
                  ),
                  Text(
                    '$conformity%',
                    style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${row['name'] ?? 'Setor'}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$openNcs NC aberta${openNcs == 1 ? '' : 's'}${overdue > 0 ? ' • $overdue vencida${overdue == 1 ? '' : 's'}' : ''}',
                    style: const TextStyle(fontSize: 11, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
