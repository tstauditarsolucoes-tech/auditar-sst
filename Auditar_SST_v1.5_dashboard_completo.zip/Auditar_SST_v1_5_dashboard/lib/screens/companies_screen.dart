import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../brand.dart';
import '../database.dart';
import '../models.dart';
import '../services/storage_service.dart';
import 'company_detail_screen.dart';
import 'sectors_screen.dart';
import 'worksites_screen.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  final ImagePicker picker = ImagePicker();
  final TextEditingController searchController = TextEditingController();
  List<Company> companies = [];
  Map<String, Map<String, int>> stats = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    searchController.addListener(() => setState(() {}));
    _load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getCompanies(onlyActive: false);
    final loadedStats = <String, Map<String, int>>{};
    for (final company in result) {
      final summary = await AppDatabase.instance.getDashboardSummary(
        companyId: company.id,
      );
      final ncs = await AppDatabase.instance.getNonConformityRows(
        companyId: company.id,
        includeClosed: false,
      );
      loadedStats[company.id] = {
        ...summary,
        'openNcs': ncs.length,
      };
    }

    if (!mounted) return;
    setState(() {
      companies = result;
      stats = loadedStats;
      loading = false;
    });
  }

  Future<void> _editCompany([Company? company]) async {
    final name = TextEditingController(text: company?.name ?? '');
    final cnpj = TextEditingController(text: company?.cnpj ?? '');
    final city = TextEditingController(text: company?.city ?? '');
    final uf = TextEditingController(text: company?.uf ?? 'PI');
    final contact = TextEditingController(text: company?.contact ?? '');
    final phone = TextEditingController(text: company?.phone ?? '');
    bool active = company?.active ?? true;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(company == null ? 'Nova empresa' : 'Editar empresa'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome da empresa *')),
                const SizedBox(height: 10),
                TextField(controller: cnpj, decoration: const InputDecoration(labelText: 'CNPJ')),
                const SizedBox(height: 10),
                TextField(controller: city, decoration: const InputDecoration(labelText: 'Cidade')),
                const SizedBox(height: 10),
                TextField(controller: uf, decoration: const InputDecoration(labelText: 'UF')),
                const SizedBox(height: 10),
                TextField(controller: contact, decoration: const InputDecoration(labelText: 'Contato / responsável')),
                const SizedBox(height: 10),
                TextField(controller: phone, decoration: const InputDecoration(labelText: 'Telefone')),
                if (company != null) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Empresa ativa'),
                    subtitle: const Text('Empresas desativadas não aparecem em novas vistorias.'),
                    value: active,
                    onChanged: (value) => setDialogState(() => active = value),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
          ],
        ),
      ),
    );

    if (save != true || name.text.trim().isEmpty) return;
    final updated = Company(
      id: company?.id ?? const Uuid().v4(),
      name: name.text.trim(),
      cnpj: cnpj.text.trim(),
      city: city.text.trim(),
      uf: uf.text.trim().toUpperCase(),
      contact: contact.text.trim(),
      phone: phone.text.trim(),
      logoPath: company?.logoPath,
      active: active,
    );

    if (company == null) {
      await AppDatabase.instance.insertCompany(updated);
    } else {
      await AppDatabase.instance.updateCompany(updated);
    }
    await _load();
  }

  Future<void> _chooseLogo(Company company) async {
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90, maxWidth: 1600);
    if (image == null) return;
    final storedPath = await StorageService.persistImage(image.path, folder: 'logos_empresas');
    await AppDatabase.instance.updateCompanyLogo(company.id, storedPath);
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logo salva. Ela será usada automaticamente nos relatórios desta empresa.')),
    );
  }

  Future<void> _removeLogo(Company company) async {
    await AppDatabase.instance.updateCompanyLogo(company.id, null);
    await _load();
  }

  Future<void> _deleteCompany(Company company) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir empresa?'),
        content: Text('Deseja excluir “${company.name}”? Se ela já tiver vistorias registradas, o aplicativo impedirá a exclusão para preservar o histórico.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirm != true) return;
    final deleted = await AppDatabase.instance.deleteCompanyIfUnused(company.id);
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(deleted ? 'Empresa excluída.' : 'A empresa possui vistorias. Desative-a em vez de excluir.')),
    );
  }

  Widget _logo(Company company) {
    final path = company.logoPath;
    if (path != null && path.isNotEmpty && File(path).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 52,
          height: 52,
          padding: const EdgeInsets.all(4),
          color: Colors.white,
          child: Image.file(File(path), fit: BoxFit.contain),
        ),
      );
    }
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        color: const Color(0xFFEFF3FA),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Icon(Icons.business_rounded, color: AuditarBrand.navy),
    );
  }

  List<Company> get _filtered {
    final q = searchController.text.trim().toLowerCase();
    if (q.isEmpty) return companies;
    return companies.where((c) {
      return c.name.toLowerCase().contains(q) ||
          (c.city ?? '').toLowerCase().contains(q) ||
          (c.cnpj ?? '').toLowerCase().contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final visible = _filtered;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Empresas'),
        actions: [
          IconButton(
            tooltip: 'Nova empresa',
            onPressed: () => _editCompany(),
            icon: const Icon(Icons.add_business_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editCompany(),
        icon: const Icon(Icons.add),
        label: const Text('Nova empresa'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 90),
                children: [
                  TextField(
                    controller: searchController,
                    decoration: const InputDecoration(
                      hintText: 'Buscar empresa, cidade ou CNPJ',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Text(
                        '${visible.length} empresa${visible.length == 1 ? '' : 's'}',
                        style: const TextStyle(fontWeight: FontWeight.w800, color: AuditarBrand.navy),
                      ),
                      const Spacer(),
                      const Text('Conformidade', style: TextStyle(fontSize: 11, color: Colors.black45)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (visible.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 80),
                      child: Center(child: Text('Nenhuma empresa encontrada.')),
                    )
                  else
                    ...visible.map(_companyCard),
                ],
              ),
      ),
    );
  }

  Widget _companyCard(Company company) {
    final s = stats[company.id] ?? const <String, int>{};
    final conformity = s['conformity'] ?? 0;
    final openNcs = s['openNcs'] ?? 0;
    final inspections = s['inspections'] ?? 0;
    final location = [company.city, company.uf]
        .where((v) => v != null && v!.trim().isNotEmpty)
        .join(' - ');

    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => CompanyDetailScreen(company: company)))
            .then((_) => _load()),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 6, 12),
          child: Row(
            children: [
              _logo(company),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      company.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      location.isEmpty ? (company.active ? 'Empresa ativa' : 'Empresa desativada') : location,
                      style: const TextStyle(fontSize: 11.5, color: Colors.black54),
                    ),
                    const SizedBox(height: 7),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _miniChip(Icons.fact_check_outlined, '$inspections vistorias', AuditarBrand.navy),
                        _miniChip(Icons.warning_amber_rounded, '$openNcs NC abertas', openNcs > 0 ? const Color(0xFFD93025) : AuditarBrand.greenDark),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 58,
                child: Column(
                  children: [
                    SizedBox(
                      width: 45,
                      height: 45,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CircularProgressIndicator(
                            value: conformity / 100,
                            strokeWidth: 5,
                            color: conformity >= 80 ? AuditarBrand.greenDark : const Color(0xFFF29D18),
                            backgroundColor: const Color(0xFFE9EDF3),
                          ),
                          Text('$conformity%', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                    PopupMenuButton<String>(
                      padding: EdgeInsets.zero,
                      iconSize: 19,
                      onSelected: (value) {
                        if (value == 'edit') _editCompany(company);
                        if (value == 'logo') _chooseLogo(company);
                        if (value == 'remove_logo') _removeLogo(company);
                        if (value == 'sectors') {
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => SectorsScreen(company: company))).then((_) => _load());
                        }
                        if (value == 'locations') {
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => WorkSitesScreen(company: company))).then((_) => _load());
                        }
                        if (value == 'delete') _deleteCompany(company);
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'edit', child: Text('Editar empresa')),
                        const PopupMenuItem(value: 'logo', child: Text('Cadastrar / trocar logo')),
                        if (company.logoPath != null)
                          const PopupMenuItem(value: 'remove_logo', child: Text('Remover logo')),
                        const PopupMenuItem(value: 'sectors', child: Text('Setores')),
                        const PopupMenuItem(value: 'locations', child: Text('Obras / unidades')),
                        const PopupMenuItem(value: 'delete', child: Text('Excluir')),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniChip(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(text, style: TextStyle(fontSize: 9.5, color: color, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
