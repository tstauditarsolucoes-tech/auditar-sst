import 'package:flutter/material.dart';

import '../database.dart';
import '../models.dart';
import '../widgets/responsive_wrap.dart';

class ChecklistPreviewScreen extends StatefulWidget {
  final ChecklistTemplate template;

  const ChecklistPreviewScreen({
    super.key,
    required this.template,
  });

  @override
  State<ChecklistPreviewScreen> createState() =>
      _ChecklistPreviewScreenState();
}

class _ChecklistPreviewScreenState
    extends State<ChecklistPreviewScreen> {
  List<ChecklistItem> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getChecklistItems(
      widget.template.id,
      onlyActive: true,
    );

    if (!mounted) return;

    setState(() {
      items = result;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Visualizar checklist'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.template.name,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          [
                            if (widget.template.category.isNotEmpty)
                              widget.template.category,
                            if (widget.template.reference.isNotEmpty)
                              widget.template.reference,
                            '${items.length} pergunta(s) ativa(s)',
                          ].join(' • '),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Prévia de como os itens aparecerão durante a vistoria.',
                        ),
                      ],
                    ),
                  ),
                ),
                if (items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(
                      child: Text(
                        'Este checklist não possui perguntas ativas.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                else
                  ...items.asMap().entries.map((entry) {
                    final index = entry.key + 1;
                    final item = entry.value;

                    return Card(
                      margin: const EdgeInsets.only(top: 9),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              [
                                '$index',
                                if (item.category.isNotEmpty)
                                  item.category,
                                if (item.reference.isNotEmpty)
                                  item.reference,
                              ].join(' • '),
                              style: Theme.of(context)
                                  .textTheme
                                  .labelMedium,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item.text,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 10),
                            const ResponsiveWrap(
                              minItemWidth: 92,
                              spacing: 6,
                              runSpacing: 6,
                              maxColumns: 3,
                              children: [
                                _PreviewStatus(
                                  icon: Icons.check_circle_outline,
                                  label: 'Conforme',
                                ),
                                _PreviewStatus(
                                  icon: Icons.cancel_outlined,
                                  label: 'Não Conforme',
                                ),
                                _PreviewStatus(
                                  icon: Icons.remove_circle_outline,
                                  label: 'N/A',
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }
}

class _PreviewStatus extends StatelessWidget {
  final IconData icon;
  final String label;

  const _PreviewStatus({
    required this.icon,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 48),
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Icon(icon, size: 20),
          const SizedBox(height: 3),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11),
          ),
        ],
      ),
    );
  }
}
