import 'package:flutter/material.dart';

class AuditarBrand {
  // Identidade visual oficial Auditar SST.
  static const navy = Color(0xFF1D2E6C);
  static const navyDark = Color(0xFF0E1A43);
  static const navySoft = Color(0xFFEFF2FA);
  static const green = Color(0xFF33C64A);
  static const greenDark = Color(0xFF178D2C);
  static const greenSoft = Color(0xFFEAF8ED);
  static const background = Color(0xFFF7F9FC);
  static const surface = Colors.white;
  static const line = Color(0xFFE4E8F0);

  static const danger = Color(0xFFD93025);
  static const warning = Color(0xFFF29D18);
  static const info = Color(0xFF2563B8);
  static const neutral = Color(0xFF667085);

  static const iconAsset = 'assets/branding/auditar_icon.png';
  static const transparentIconAsset =
      'assets/branding/auditar_icon_transparent.png';
  static const logoAsset = 'assets/branding/auditar_logo.jpg';

  static const slogan = 'Segurança do Trabalho na prática';
  static const subtitle = 'MEDICINA OCUPACIONAL E SEGURANÇA DO TRABALHO';
}
