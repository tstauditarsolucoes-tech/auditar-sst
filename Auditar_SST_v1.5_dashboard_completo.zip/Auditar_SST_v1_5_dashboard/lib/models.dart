import 'dart:convert';

class Company {
  final String id;
  final String name;
  final String? cnpj;
  final String? city;
  final String? uf;
  final String? contact;
  final String? phone;
  final String? logoPath;
  final String reportEmail;
  final String secondaryReportEmail;
  final String reportRecipient;
  final bool monthlyReportEnabled;
  final bool trainingAlertsEnabled;
  final bool medicalAlertsEnabled;
  final int monthlyReportDay;
  final bool active;

  Company({
    required this.id,
    required this.name,
    this.cnpj,
    this.city,
    this.uf,
    this.contact,
    this.phone,
    this.logoPath,
    this.reportEmail = '',
    this.secondaryReportEmail = '',
    this.reportRecipient = '',
    this.monthlyReportEnabled = false,
    this.trainingAlertsEnabled = false,
    this.medicalAlertsEnabled = false,
    this.monthlyReportDay = 5,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'cnpj': cnpj,
        'city': city,
        'uf': uf,
        'contact': contact,
        'phone': phone,
        'logo_path': logoPath,
        'report_email': reportEmail,
        'secondary_report_email': secondaryReportEmail,
        'report_recipient': reportRecipient,
        'monthly_report_enabled': monthlyReportEnabled ? 1 : 0,
        'training_alerts_enabled': trainingAlertsEnabled ? 1 : 0,
        'medical_alerts_enabled': medicalAlertsEnabled ? 1 : 0,
        'monthly_report_day': monthlyReportDay,
        'active': active ? 1 : 0,
      };

  factory Company.fromMap(Map<String, Object?> map) => Company(
        id: map['id'] as String,
        name: map['name'] as String,
        cnpj: map['cnpj'] as String?,
        city: map['city'] as String?,
        uf: map['uf'] as String?,
        contact: map['contact'] as String?,
        phone: map['phone'] as String?,
        logoPath: map['logo_path'] as String?,
        reportEmail: (map['report_email'] as String?) ?? '',
        secondaryReportEmail:
            (map['secondary_report_email'] as String?) ?? '',
        reportRecipient: (map['report_recipient'] as String?) ?? '',
        monthlyReportEnabled:
            (map['monthly_report_enabled'] as int? ?? 0) == 1,
        trainingAlertsEnabled:
            (map['training_alerts_enabled'] as int? ?? 0) == 1,
        medicalAlertsEnabled:
            (map['medical_alerts_enabled'] as int? ?? 0) == 1,
        monthlyReportDay: (map['monthly_report_day'] as int?) ?? 5,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class WorkSite {
  final String id;
  final String companyId;
  final String name;
  final String type;
  final String? address;
  final bool active;

  WorkSite({
    required this.id,
    required this.companyId,
    required this.name,
    required this.type,
    this.address,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'name': name,
        'type': type,
        'address': address,
        'active': active ? 1 : 0,
      };

  factory WorkSite.fromMap(Map<String, Object?> map) => WorkSite(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        name: map['name'] as String,
        type: map['type'] as String,
        address: map['address'] as String?,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class Sector {
  final String id;
  final String companyId;
  final String name;
  final String? description;
  final bool active;

  Sector({
    required this.id,
    required this.companyId,
    required this.name,
    this.description,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'name': name,
        'description': description,
        'active': active ? 1 : 0,
      };

  factory Sector.fromMap(Map<String, Object?> map) => Sector(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        name: map['name'] as String,
        description: map['description'] as String?,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class ChecklistTemplate {
  final String id;
  final String name;
  final String category;
  final String reference;
  final bool active;

  ChecklistTemplate({
    required this.id,
    required this.name,
    required this.category,
    required this.reference,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'category': category,
        'reference': reference,
        'active': active ? 1 : 0,
      };

  factory ChecklistTemplate.fromMap(Map<String, Object?> map) =>
      ChecklistTemplate(
        id: map['id'] as String,
        name: map['name'] as String,
        category: (map['category'] as String?) ?? '',
        reference: (map['reference'] as String?) ?? '',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class ChecklistItem {
  final String id;
  final String templateId;
  final int sortOrder;
  final String category;
  final String text;
  final String reference;
  final String priority;
  final bool active;

  ChecklistItem({
    required this.id,
    required this.templateId,
    required this.sortOrder,
    required this.category,
    required this.text,
    required this.reference,
    required this.priority,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'template_id': templateId,
        'sort_order': sortOrder,
        'category': category,
        'text': text,
        'reference': reference,
        'priority': priority,
        'active': active ? 1 : 0,
      };

  factory ChecklistItem.fromMap(Map<String, Object?> map) => ChecklistItem(
        id: map['id'] as String,
        templateId: map['template_id'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
        category: (map['category'] as String?) ?? '',
        text: map['text'] as String,
        reference: (map['reference'] as String?) ?? '',
        priority: (map['priority'] as String?) ?? 'Média',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class Inspection {
  final String id;
  final String companyId;
  final String? workSiteId;
  final String? sectorId;
  final String area;
  final String checklistType;
  final String checklistTemplateId;
  final DateTime date;
  final String status;
  final String technicianName;
  final String responsibleName;
  final String? technicianSignaturePath;
  final String? responsibleSignaturePath;
  final String generalNotes;
  final String conclusion;
  final String reportNumber;

  Inspection({
    required this.id,
    required this.companyId,
    this.workSiteId,
    this.sectorId,
    required this.area,
    required this.checklistType,
    required this.checklistTemplateId,
    required this.date,
    this.status = 'Em andamento',
    this.technicianName = '',
    this.responsibleName = '',
    this.technicianSignaturePath,
    this.responsibleSignaturePath,
    this.generalNotes = '',
    this.conclusion = '',
    required this.reportNumber,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'worksite_id': workSiteId,
        'sector_id': sectorId,
        'area': area,
        'checklist_type': checklistType,
        'checklist_template_id': checklistTemplateId,
        'date': date.toIso8601String(),
        'status': status,
        'technician_name': technicianName,
        'responsible_name': responsibleName,
        'technician_signature_path': technicianSignaturePath,
        'responsible_signature_path': responsibleSignaturePath,
        'general_notes': generalNotes,
        'conclusion': conclusion,
        'report_number': reportNumber,
      };
}

class InspectionAnswer {
  final String id;
  final String inspectionId;
  final String questionId;
  final String questionText;
  final String questionCategory;
  final String questionReference;
  final String status;
  final String observation;
  final String riskIdentified;
  final String recommendation;

  InspectionAnswer({
    required this.id,
    required this.inspectionId,
    required this.questionId,
    required this.questionText,
    required this.questionCategory,
    required this.questionReference,
    required this.status,
    required this.observation,
    required this.riskIdentified,
    required this.recommendation,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'question_id': questionId,
        'question_text': questionText,
        'question_category': questionCategory,
        'question_reference': questionReference,
        'status': status,
        'observation': observation,
        'risk_identified': riskIdentified,
        'recommendation': recommendation,
      };

  factory InspectionAnswer.fromMap(Map<String, Object?> map) => InspectionAnswer(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        questionId: map['question_id'] as String,
        questionText: (map['question_text'] as String?) ?? '',
        questionCategory: (map['question_category'] as String?) ?? '',
        questionReference: (map['question_reference'] as String?) ?? '',
        status: map['status'] as String,
        observation: (map['observation'] as String?) ?? '',
        riskIdentified: (map['risk_identified'] as String?) ?? '',
        recommendation: (map['recommendation'] as String?) ?? '',
      );
}

class EvidencePhoto {
  final String id;
  final String answerId;
  final String path;
  final int sortOrder;

  EvidencePhoto({
    required this.id,
    required this.answerId,
    required this.path,
    required this.sortOrder,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'answer_id': answerId,
        'path': path,
        'sort_order': sortOrder,
      };

  factory EvidencePhoto.fromMap(Map<String, Object?> map) => EvidencePhoto(
        id: map['id'] as String,
        answerId: map['answer_id'] as String,
        path: map['path'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
      );
}


class NonConformity {
  final String id;
  final String inspectionId;
  final String answerId;
  final String code;
  final String description;
  final String riskIdentified;
  final String recommendation;
  final String classification;
  final String status;
  final DateTime createdAt;
  final DateTime? verifiedAt;
  final String verifiedBy;

  NonConformity({
    required this.id,
    required this.inspectionId,
    required this.answerId,
    required this.code,
    required this.description,
    required this.riskIdentified,
    required this.recommendation,
    this.classification = 'Média',
    this.status = 'Pendente',
    required this.createdAt,
    this.verifiedAt,
    this.verifiedBy = '',
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'answer_id': answerId,
        'code': code,
        'description': description,
        'risk_identified': riskIdentified,
        'recommendation': recommendation,
        'classification': classification,
        'status': status,
        'created_at': createdAt.toIso8601String(),
        'verified_at': verifiedAt?.toIso8601String(),
        'verified_by': verifiedBy,
      };

  factory NonConformity.fromMap(Map<String, Object?> map) => NonConformity(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        answerId: map['answer_id'] as String,
        code: (map['code'] as String?) ?? '',
        description: (map['description'] as String?) ?? '',
        riskIdentified: (map['risk_identified'] as String?) ?? '',
        recommendation: (map['recommendation'] as String?) ?? '',
        classification: (map['classification'] as String?) ?? 'Média',
        status: (map['status'] as String?) ?? 'Pendente',
        createdAt: DateTime.tryParse('${map['created_at'] ?? ''}') ?? DateTime.now(),
        verifiedAt: map['verified_at'] == null
            ? null
            : DateTime.tryParse('${map['verified_at']}'),
        verifiedBy: (map['verified_by'] as String?) ?? '',
      );
}

class ActionPlan {
  final String id;
  final String inspectionId;
  final String answerId;
  final String? ncId;
  final String nonConformity;
  final String correctiveAction;
  final String responsible;
  final String priority;
  final DateTime? dueDate;
  final String status;
  final DateTime? completionDate;
  final String completionNote;
  final String completedBy;

  ActionPlan({
    required this.id,
    required this.inspectionId,
    required this.answerId,
    this.ncId,
    required this.nonConformity,
    required this.correctiveAction,
    required this.responsible,
    required this.priority,
    this.dueDate,
    this.status = 'Pendente',
    this.completionDate,
    this.completionNote = '',
    this.completedBy = '',
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'answer_id': answerId,
        'nc_id': ncId,
        'non_conformity': nonConformity,
        'corrective_action': correctiveAction,
        'responsible': responsible,
        'priority': priority,
        'due_date': dueDate?.toIso8601String(),
        'status': status,
        'completion_date': completionDate?.toIso8601String(),
        'completion_note': completionNote,
        'completed_by': completedBy,
      };

  factory ActionPlan.fromMap(Map<String, Object?> map) => ActionPlan(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        answerId: map['answer_id'] as String,
        ncId: map['nc_id'] as String?,
        nonConformity: map['non_conformity'] as String,
        correctiveAction: map['corrective_action'] as String,
        responsible: (map['responsible'] as String?) ?? '',
        priority: map['priority'] as String,
        dueDate: map['due_date'] == null
            ? null
            : DateTime.tryParse(map['due_date'] as String),
        status: map['status'] as String,
        completionDate: map['completion_date'] == null
            ? null
            : DateTime.tryParse(map['completion_date'] as String),
        completionNote: (map['completion_note'] as String?) ?? '',
        completedBy: (map['completed_by'] as String?) ?? '',
      );
}

class CompletionPhoto {
  final String id;
  final String actionId;
  final String path;
  final int sortOrder;

  CompletionPhoto({
    required this.id,
    required this.actionId,
    required this.path,
    required this.sortOrder,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'action_id': actionId,
        'path': path,
        'sort_order': sortOrder,
      };

  factory CompletionPhoto.fromMap(Map<String, Object?> map) => CompletionPhoto(
        id: map['id'] as String,
        actionId: map['action_id'] as String,
        path: map['path'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
      );
}

class Worker {
  final String id;
  final String companyId;
  final String? sectorId;
  final String name;
  final String cpf;
  final String role;
  final DateTime? admissionDate;
  final DateTime? lastMedicalExamDate;
  final DateTime? nextMedicalExamDate;
  final String asoPath;
  final bool active;

  Worker({
    required this.id,
    required this.companyId,
    this.sectorId,
    required this.name,
    this.cpf = '',
    this.role = '',
    this.admissionDate,
    this.lastMedicalExamDate,
    this.nextMedicalExamDate,
    this.asoPath = '',
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'sector_id': sectorId,
        'name': name,
        'cpf': cpf,
        'role': role,
        'admission_date': admissionDate?.toIso8601String(),
        'last_medical_exam_date': lastMedicalExamDate?.toIso8601String(),
        'next_medical_exam_date': nextMedicalExamDate?.toIso8601String(),
        'aso_path': asoPath,
        'active': active ? 1 : 0,
      };

  factory Worker.fromMap(Map<String, Object?> map) => Worker(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        sectorId: map['sector_id'] as String?,
        name: map['name'] as String,
        cpf: (map['cpf'] as String?) ?? '',
        role: (map['role'] as String?) ?? '',
        admissionDate: map['admission_date'] == null
            ? null
            : DateTime.tryParse('${map['admission_date']}'),
        lastMedicalExamDate: map['last_medical_exam_date'] == null
            ? null
            : DateTime.tryParse('${map['last_medical_exam_date']}'),
        nextMedicalExamDate: map['next_medical_exam_date'] == null
            ? null
            : DateTime.tryParse('${map['next_medical_exam_date']}'),
        asoPath: (map['aso_path'] as String?) ?? '',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class TrainingRequirement {
  final String id;
  final String companyId;
  final String role;
  final String code;
  final String title;
  final int validityMonths;
  final bool active;

  TrainingRequirement({
    required this.id,
    required this.companyId,
    required this.role,
    required this.code,
    required this.title,
    this.validityMonths = 0,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'role': role,
        'code': code,
        'title': title,
        'validity_months': validityMonths,
        'active': active ? 1 : 0,
      };

  factory TrainingRequirement.fromMap(Map<String, Object?> map) =>
      TrainingRequirement(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        role: (map['role'] as String?) ?? '',
        code: (map['code'] as String?) ?? '',
        title: (map['title'] as String?) ?? '',
        validityMonths: (map['validity_months'] as int?) ?? 0,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class TrainingControl {
  final String id;
  final String workerId;
  final String code;
  final String title;
  final DateTime? trainingDate;
  final DateTime? expiryDate;
  final String certificatePath;
  final String notes;

  TrainingControl({
    required this.id,
    required this.workerId,
    required this.code,
    required this.title,
    this.trainingDate,
    this.expiryDate,
    this.certificatePath = '',
    this.notes = '',
  });

  String statusAt(DateTime now) {
    if (trainingDate == null) return 'PENDENTE';
    if (expiryDate != null) {
      final today = DateTime(now.year, now.month, now.day);
      final expiry = DateTime(
        expiryDate!.year,
        expiryDate!.month,
        expiryDate!.day,
      );
      if (expiry.isBefore(today)) return 'VENCIDO';
    }
    return 'EM DIA';
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'worker_id': workerId,
        'code': code,
        'title': title,
        'training_date': trainingDate?.toIso8601String(),
        'expiry_date': expiryDate?.toIso8601String(),
        'certificate_path': certificatePath,
        'notes': notes,
      };

  factory TrainingControl.fromMap(Map<String, Object?> map) => TrainingControl(
        id: map['id'] as String,
        workerId: map['worker_id'] as String,
        code: (map['code'] as String?) ?? '',
        title: (map['title'] as String?) ?? '',
        trainingDate: map['training_date'] == null
            ? null
            : DateTime.tryParse('${map['training_date']}'),
        expiryDate: map['expiry_date'] == null
            ? null
            : DateTime.tryParse('${map['expiry_date']}'),
        certificatePath: (map['certificate_path'] as String?) ?? '',
        notes: (map['notes'] as String?) ?? '',
      );
}


class CipaElection {
  final String id;
  final String companyId;
  final String title;
  final String managementPeriod;
  final String status;
  final DateTime? startDate;
  final DateTime? endDate;
  final String accessToken;
  final DateTime createdAt;
  final DateTime? publishedAt;
  final DateTime? lastSyncAt;
  final String lastSyncStatus;
  final String lastError;

  CipaElection({
    required this.id,
    required this.companyId,
    required this.title,
    this.managementPeriod = '',
    this.status = 'Rascunho',
    this.startDate,
    this.endDate,
    required this.accessToken,
    required this.createdAt,
    this.publishedAt,
    this.lastSyncAt,
    this.lastSyncStatus = 'Nunca sincronizado',
    this.lastError = '',
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'title': title,
        'management_period': managementPeriod,
        'status': status,
        'start_date': startDate?.toIso8601String(),
        'end_date': endDate?.toIso8601String(),
        'access_token': accessToken,
        'created_at': createdAt.toIso8601String(),
        'published_at': publishedAt?.toIso8601String(),
        'last_sync_at': lastSyncAt?.toIso8601String(),
        'last_sync_status': lastSyncStatus,
        'last_error': lastError,
      };

  factory CipaElection.fromMap(Map<String, Object?> map) => CipaElection(
        id: '${map['id']}',
        companyId: '${map['company_id']}',
        title: '${map['title'] ?? ''}',
        managementPeriod: '${map['management_period'] ?? ''}',
        status: '${map['status'] ?? 'Rascunho'}',
        startDate: map['start_date'] == null
            ? null
            : DateTime.tryParse('${map['start_date']}'),
        endDate: map['end_date'] == null
            ? null
            : DateTime.tryParse('${map['end_date']}'),
        accessToken: '${map['access_token'] ?? ''}',
        createdAt: DateTime.tryParse('${map['created_at']}') ?? DateTime.now(),
        publishedAt: map['published_at'] == null
            ? null
            : DateTime.tryParse('${map['published_at']}'),
        lastSyncAt: map['last_sync_at'] == null
            ? null
            : DateTime.tryParse('${map['last_sync_at']}'),
        lastSyncStatus: '${map['last_sync_status'] ?? 'Nunca sincronizado'}',
        lastError: '${map['last_error'] ?? ''}',
      );
}

class CipaCandidate {
  final String id;
  final String electionId;
  final String? workerId;
  final String name;
  final String role;
  final String sector;
  final bool active;

  CipaCandidate({
    required this.id,
    required this.electionId,
    this.workerId,
    required this.name,
    this.role = '',
    this.sector = '',
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'election_id': electionId,
        'worker_id': workerId,
        'name': name,
        'role': role,
        'sector': sector,
        'active': active ? 1 : 0,
      };

  factory CipaCandidate.fromMap(Map<String, Object?> map) => CipaCandidate(
        id: '${map['id']}',
        electionId: '${map['election_id']}',
        workerId: map['worker_id'] as String?,
        name: '${map['name'] ?? ''}',
        role: '${map['role'] ?? ''}',
        sector: '${map['sector'] ?? ''}',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class CipaVoter {
  final String id;
  final String electionId;
  final String? workerId;
  final String name;
  final String accessCode;
  final bool active;

  CipaVoter({
    required this.id,
    required this.electionId,
    this.workerId,
    required this.name,
    required this.accessCode,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'election_id': electionId,
        'worker_id': workerId,
        'name': name,
        'access_code': accessCode,
        'active': active ? 1 : 0,
      };

  factory CipaVoter.fromMap(Map<String, Object?> map) => CipaVoter(
        id: '${map['id']}',
        electionId: '${map['election_id']}',
        workerId: map['worker_id'] as String?,
        name: '${map['name'] ?? ''}',
        accessCode: '${map['access_code'] ?? ''}',
        active: (map['active'] as int? ?? 1) == 1,
      );
}


class SstRecord {
  final String id;
  final String? companyId;
  final String? sectorId;
  final String type;
  final String title;
  final DateTime date;
  final DateTime? dueDate;
  final String status;
  final String priority;
  final Map<String, dynamic> payload;

  const SstRecord({
    required this.id,
    this.companyId,
    this.sectorId,
    required this.type,
    required this.title,
    required this.date,
    this.dueDate,
    this.status = 'Pendente',
    this.priority = 'Média',
    this.payload = const {},
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'sector_id': sectorId,
        'type': type,
        'title': title,
        'date': date.toIso8601String(),
        'due_date': dueDate?.toIso8601String(),
        'status': status,
        'priority': priority,
        'payload': jsonEncode(payload),
      };

  factory SstRecord.fromMap(Map<String, Object?> map) {
    Map<String, dynamic> decoded = const {};
    final raw = map['payload'] as String?;
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final value = jsonDecode(raw);
        if (value is Map<String, dynamic>) decoded = value;
      } catch (_) {}
    }
    return SstRecord(
      id: map['id'] as String,
      companyId: map['company_id'] as String?,
      sectorId: map['sector_id'] as String?,
      type: (map['type'] as String?) ?? '',
      title: (map['title'] as String?) ?? '',
      date: DateTime.tryParse((map['date'] as String?) ?? '') ?? DateTime.now(),
      dueDate: DateTime.tryParse((map['due_date'] as String?) ?? ''),
      status: (map['status'] as String?) ?? 'Pendente',
      priority: (map['priority'] as String?) ?? 'Média',
      payload: decoded,
    );
  }
}
