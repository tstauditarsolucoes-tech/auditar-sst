import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import 'models.dart';
import 'ready_checklists.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<String> get databaseFilePath async {
    final dbPath = await getDatabasesPath();
    return join(dbPath, 'auditar_sst.db');
  }

  Future<Database> get database async {
    if (_db != null) return _db!;

    final path = await databaseFilePath;

    _db = await openDatabase(
      path,
      version: 14,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await _createSchema(db);
        await _seedDefaultChecklist(db);
        await _seedReadyChecklistLibrary(db);
        await _seedDefaultSettings(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await _upgradeSchema(db, oldVersion);
        await _seedDefaultChecklist(db);
        await _seedReadyChecklistLibrary(db);
        await _seedDefaultSettings(db);
      },
      onOpen: (db) async {
        await _seedDefaultChecklist(db);
        await _seedReadyChecklistLibrary(db);
        await _seedDefaultSettings(db);
      },
    );

    return _db!;
  }

  static Future<void> _createSchema(Database db) async {
    await db.execute(
      'CREATE TABLE companies('
      'id TEXT PRIMARY KEY, '
      'name TEXT NOT NULL, '
      'cnpj TEXT, '
      'city TEXT, '
      'uf TEXT, '
      'contact TEXT, '
      'phone TEXT, '
      'logo_path TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE worksites('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'name TEXT NOT NULL, '
      'type TEXT NOT NULL, '
      'address TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE sectors('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'name TEXT NOT NULL, '
      'description TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE checklist_templates('
      'id TEXT PRIMARY KEY, '
      'name TEXT NOT NULL, '
      'category TEXT, '
      'reference TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE checklist_items('
      'id TEXT PRIMARY KEY, '
      'template_id TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0, '
      'category TEXT, '
      'text TEXT NOT NULL, '
      'reference TEXT, '
      'priority TEXT NOT NULL DEFAULT "Média", '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE inspections('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'worksite_id TEXT, '
      'sector_id TEXT, '
      'area TEXT NOT NULL, '
      'checklist_type TEXT NOT NULL, '
      'checklist_template_id TEXT, '
      'date TEXT NOT NULL, '
      'status TEXT NOT NULL, '
      'technician_name TEXT, '
      'responsible_name TEXT, '
      'technician_signature_path TEXT, '
      'responsible_signature_path TEXT, '
      'general_notes TEXT, '
      'conclusion TEXT, '
      'report_number TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE answers('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT NOT NULL, '
      'question_id TEXT NOT NULL, '
      'question_text TEXT, '
      'question_category TEXT, '
      'question_reference TEXT, '
      'status TEXT NOT NULL, '
      'observation TEXT, '
      'risk_identified TEXT, '
      'recommendation TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE evidence_photos('
      'id TEXT PRIMARY KEY, '
      'answer_id TEXT NOT NULL, '
      'path TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0'
      ')',
    );

    await db.execute(
      'CREATE TABLE non_conformities('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT NOT NULL, '
      'answer_id TEXT NOT NULL, '
      'code TEXT NOT NULL, '
      'description TEXT NOT NULL, '
      'risk_identified TEXT, '
      'recommendation TEXT, '
      'classification TEXT NOT NULL DEFAULT "Média", '
      'status TEXT NOT NULL DEFAULT "Pendente", '
      'created_at TEXT NOT NULL, '
      'verified_at TEXT, '
      'verified_by TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE action_plans('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT NOT NULL, '
      'answer_id TEXT NOT NULL, '
      'nc_id TEXT, '
      'non_conformity TEXT NOT NULL, '
      'corrective_action TEXT NOT NULL, '
      'responsible TEXT, '
      'priority TEXT NOT NULL, '
      'due_date TEXT, '
      'status TEXT NOT NULL, '
      'completion_date TEXT, '
      'completion_note TEXT, '
      'completed_by TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE completion_photos('
      'id TEXT PRIMARY KEY, '
      'action_id TEXT NOT NULL, '
      'path TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0'
      ')',
    );

    await db.execute(
      'CREATE TABLE workers('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'sector_id TEXT, '
      'name TEXT NOT NULL, '
      'cpf TEXT, '
      'role TEXT, '
      'admission_date TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE training_controls('
      'id TEXT PRIMARY KEY, '
      'worker_id TEXT NOT NULL, '
      'code TEXT, '
      'title TEXT NOT NULL, '
      'training_date TEXT, '
      'expiry_date TEXT, '
      'certificate_path TEXT, '
      'notes TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE app_settings('
      'key TEXT PRIMARY KEY, '
      'value TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE drive_upload_queue('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT, '
      'local_path TEXT NOT NULL, '
      'file_name TEXT NOT NULL, '
      'company_name TEXT, '
      'created_at TEXT NOT NULL, '
      'status TEXT NOT NULL DEFAULT "Pendente", '
      'last_error TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE management_panels('
      'company_id TEXT PRIMARY KEY, '
      'access_token TEXT NOT NULL UNIQUE, '
      'enabled INTEGER NOT NULL DEFAULT 1, '
      'last_sync_at TEXT, '
      'last_sync_status TEXT, '
      'last_error TEXT'
      ')',
    );


    await db.execute(
      'CREATE TABLE cipa_elections('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'title TEXT NOT NULL, '
      'management_period TEXT, '
      'status TEXT NOT NULL DEFAULT "Rascunho", '
      'start_date TEXT, '
      'end_date TEXT, '
      'access_token TEXT NOT NULL UNIQUE, '
      'created_at TEXT NOT NULL, '
      'published_at TEXT, '
      'last_sync_at TEXT, '
      'last_sync_status TEXT, '
      'last_error TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE cipa_candidates('
      'id TEXT PRIMARY KEY, '
      'election_id TEXT NOT NULL, '
      'worker_id TEXT, '
      'name TEXT NOT NULL, '
      'role TEXT, '
      'sector TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE cipa_voters('
      'id TEXT PRIMARY KEY, '
      'election_id TEXT NOT NULL, '
      'worker_id TEXT, '
      'name TEXT NOT NULL, '
      'access_code TEXT NOT NULL, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE sst_records('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT, '
      'sector_id TEXT, '
      'type TEXT NOT NULL, '
      'title TEXT NOT NULL, '
      'date TEXT NOT NULL, '
      'due_date TEXT, '
      'status TEXT NOT NULL DEFAULT "Pendente", '
      'priority TEXT NOT NULL DEFAULT "Média", '
      'payload TEXT'
      ')',
    );
  }

  static Future<void> _upgradeSchema(Database db, int oldVersion) async {
    if (oldVersion < 2) {
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN logo_path TEXT',
      );
    }

    if (oldVersion < 3) {
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN technician_name TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN responsible_name TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN technician_signature_path TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN responsible_signature_path TEXT',
      );
      await db.execute(
        'CREATE TABLE IF NOT EXISTS evidence_photos('
        'id TEXT PRIMARY KEY, '
        'answer_id TEXT NOT NULL, '
        'path TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0'
        ')',
      );
    }

    if (oldVersion < 4) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS checklist_templates('
        'id TEXT PRIMARY KEY, '
        'name TEXT NOT NULL, '
        'category TEXT, '
        'reference TEXT, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS checklist_items('
        'id TEXT PRIMARY KEY, '
        'template_id TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0, '
        'category TEXT, '
        'text TEXT NOT NULL, '
        'reference TEXT, '
        'priority TEXT NOT NULL DEFAULT "Média", '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );

      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN checklist_template_id TEXT',
      );
    }

    if (oldVersion < 5) {
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_text TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_category TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_reference TEXT',
      );
    }

    if (oldVersion < 6) {
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN cnpj TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN contact TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN phone TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN active INTEGER NOT NULL DEFAULT 1',
      );

      await _trySql(
        db,
        'ALTER TABLE worksites ADD COLUMN address TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE worksites ADD COLUMN active INTEGER NOT NULL DEFAULT 1',
      );

      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN general_notes TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN conclusion TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN report_number TEXT',
      );

      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completion_date TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completion_note TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completed_by TEXT',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS completion_photos('
        'id TEXT PRIMARY KEY, '
        'action_id TEXT NOT NULL, '
        'path TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0'
        ')',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS app_settings('
        'key TEXT PRIMARY KEY, '
        'value TEXT'
        ')',
      );
    }

    if (oldVersion < 7) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS drive_upload_queue('
        'id TEXT PRIMARY KEY, '
        'inspection_id TEXT, '
        'local_path TEXT NOT NULL, '
        'file_name TEXT NOT NULL, '
        'company_name TEXT, '
        'created_at TEXT NOT NULL, '
        'status TEXT NOT NULL DEFAULT "Pendente", '
        'last_error TEXT'
        ')',
      );
    }
    if (oldVersion < 8) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS sectors('
        'id TEXT PRIMARY KEY, '
        'company_id TEXT NOT NULL, '
        'name TEXT NOT NULL, '
        'description TEXT, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN sector_id TEXT',
      );
    }
    if (oldVersion < 9) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS non_conformities('
        'id TEXT PRIMARY KEY, '
        'inspection_id TEXT NOT NULL, '
        'answer_id TEXT NOT NULL, '
        'code TEXT NOT NULL, '
        'description TEXT NOT NULL, '
        'risk_identified TEXT, '
        'recommendation TEXT, '
        'classification TEXT NOT NULL DEFAULT "Média", '
        'status TEXT NOT NULL DEFAULT "Pendente", '
        'created_at TEXT NOT NULL, '
        'verified_at TEXT, '
        'verified_by TEXT'
        ')',
      );
      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN nc_id TEXT',
      );

      final ncAnswers = await db.rawQuery(
        "SELECT r.*, i.date AS inspection_date FROM answers r "
        "JOIN inspections i ON i.id = r.inspection_id "
        "WHERE r.status = 'Não Conforme' OR r.status = 'Parcial'",
      );
      for (final row in ncAnswers) {
        final answerId = '${row['id']}';
        final existing = await db.query(
          'non_conformities',
          columns: ['id'],
          where: 'answer_id = ?',
          whereArgs: [answerId],
          limit: 1,
        );
        if (existing.isNotEmpty) continue;

        final cleanAnswerId = answerId.replaceAll('-', '');
        final codePart = cleanAnswerId.length > 8
            ? cleanAnswerId.substring(0, 8)
            : cleanAnswerId;
        final code = 'NC-${codePart.toUpperCase()}';
        await db.insert('non_conformities', {
          'id': 'nc-$answerId',
          'inspection_id': '${row['inspection_id']}',
          'answer_id': answerId,
          'code': code,
          'description': '${row['observation'] ?? ''}',
          'risk_identified': '${row['risk_identified'] ?? ''}',
          'recommendation': '${row['recommendation'] ?? ''}',
          'classification': 'Média',
          'status': 'Pendente',
          'created_at': '${row['inspection_date'] ?? DateTime.now().toIso8601String()}',
        });
      }

      final migratedNcs = await db.query('non_conformities');
      for (final nc in migratedNcs) {
        final oldActions = await db.query(
          'action_plans',
          columns: ['priority'],
          where: 'answer_id = ?',
          whereArgs: [nc['answer_id']],
          limit: 1,
        );
        if (oldActions.isNotEmpty) {
          await db.update(
            'non_conformities',
            {'classification': oldActions.first['priority'] ?? 'Média'},
            where: 'id = ?',
            whereArgs: [nc['id']],
          );
        }
        await db.update(
          'action_plans',
          {'nc_id': nc['id']},
          where: 'answer_id = ? AND (nc_id IS NULL OR nc_id = "")',
          whereArgs: [nc['answer_id']],
        );
      }
    }
    if (oldVersion < 10) {
      await _trySql(db, 'ALTER TABLE non_conformities ADD COLUMN verified_at TEXT');
      await _trySql(db, 'ALTER TABLE non_conformities ADD COLUMN verified_by TEXT');
      await db.execute(
        "UPDATE non_conformities SET status = CASE "
        "WHEN status = 'Encerrada' THEN 'Concluída' "
        "WHEN status = 'Em tratamento' THEN 'Em andamento' "
        "WHEN status = 'Aberta' THEN 'Pendente' "
        "ELSE status END",
      );
    }
    if (oldVersion < 11) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS workers('
        'id TEXT PRIMARY KEY, '
        'company_id TEXT NOT NULL, '
        'sector_id TEXT, '
        'name TEXT NOT NULL, '
        'cpf TEXT, '
        'role TEXT, '
        'admission_date TEXT, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );
      await db.execute(
        'CREATE TABLE IF NOT EXISTS training_controls('
        'id TEXT PRIMARY KEY, '
        'worker_id TEXT NOT NULL, '
        'code TEXT, '
        'title TEXT NOT NULL, '
        'training_date TEXT, '
        'expiry_date TEXT, '
        'certificate_path TEXT, '
        'notes TEXT'
        ')',
      );
    }
    if (oldVersion < 12) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS management_panels('
        'company_id TEXT PRIMARY KEY, '
        'access_token TEXT NOT NULL UNIQUE, '
        'enabled INTEGER NOT NULL DEFAULT 1, '
        'last_sync_at TEXT, '
        'last_sync_status TEXT, '
        'last_error TEXT'
        ')',
      );

      final companies = await db.query('companies', columns: ['id']);
      for (final company in companies) {
        final companyId = '${company['id']}';
        final existing = await db.query(
          'management_panels',
          columns: ['company_id'],
          where: 'company_id = ?',
          whereArgs: [companyId],
          limit: 1,
        );
        if (existing.isEmpty) {
          await db.insert('management_panels', {
            'company_id': companyId,
            'access_token': const Uuid().v4().replaceAll('-', ''),
            'enabled': 1,
            'last_sync_status': 'Nunca sincronizado',
            'last_error': '',
          });
        }
      }
    }
    if (oldVersion < 13) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS cipa_elections('
        'id TEXT PRIMARY KEY, '
        'company_id TEXT NOT NULL, '
        'title TEXT NOT NULL, '
        'management_period TEXT, '
        'status TEXT NOT NULL DEFAULT "Rascunho", '
        'start_date TEXT, '
        'end_date TEXT, '
        'access_token TEXT NOT NULL UNIQUE, '
        'created_at TEXT NOT NULL, '
        'published_at TEXT, '
        'last_sync_at TEXT, '
        'last_sync_status TEXT, '
        'last_error TEXT'
        ')',
      );
      await db.execute(
        'CREATE TABLE IF NOT EXISTS cipa_candidates('
        'id TEXT PRIMARY KEY, '
        'election_id TEXT NOT NULL, '
        'worker_id TEXT, '
        'name TEXT NOT NULL, '
        'role TEXT, '
        'sector TEXT, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );
      await db.execute(
        'CREATE TABLE IF NOT EXISTS cipa_voters('
        'id TEXT PRIMARY KEY, '
        'election_id TEXT NOT NULL, '
        'worker_id TEXT, '
        'name TEXT NOT NULL, '
        'access_code TEXT NOT NULL, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );
    }

    if (oldVersion < 14) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS sst_records('
        'id TEXT PRIMARY KEY, '
        'company_id TEXT, '
        'sector_id TEXT, '
        'type TEXT NOT NULL, '
        'title TEXT NOT NULL, '
        'date TEXT NOT NULL, '
        'due_date TEXT, '
        'status TEXT NOT NULL DEFAULT "Pendente", '
        'priority TEXT NOT NULL DEFAULT "Média", '
        'payload TEXT'
        ')',
      );
    }

  }

  static Future<void> _trySql(Database db, String sql) async {
    try {
      await db.execute(sql);
    } catch (_) {}
  }

  static Future<void> _seedDefaultSettings(Database db) async {
    const defaults = {
      'app_name': 'Auditar SST',
      'default_technician': '',
      'report_footer': 'Relatório de Inspeção de Segurança do Trabalho',
      'drive_enabled': 'false',
      'drive_account_email': '',
      'drive_root_folder_id': '',
      'drive_auto_upload': 'true',
      'management_panel_endpoint': '',
      'management_panel_sync_key': '',
    };

    for (final entry in defaults.entries) {
      await db.insert(
        'app_settings',
        {'key': entry.key, 'value': entry.value},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  static Future<void> _seedDefaultChecklist(Database db) async {
    const templateId = 'template-geral-sst';

    final existing = await db.query(
      'checklist_templates',
      where: 'id = ?',
      whereArgs: [templateId],
      limit: 1,
    );

    if (existing.isEmpty) {
      await db.insert('checklist_templates', {
        'id': templateId,
        'name': 'Inspeção Geral SST',
        'category': 'Geral',
        'reference': 'NRs aplicáveis',
        'active': 1,
      });
    }

    final countResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );

    final count = Sqflite.firstIntValue(countResult) ?? 0;
    if (count > 0) return;

    final items = [
      [
        'Organização e limpeza',
        'A área está limpa, organizada e com circulação desobstruída?',
        'NR-01',
        'Média'
      ],
      [
        'EPI',
        'Os trabalhadores utilizam os EPIs necessários para a atividade?',
        'NR-06',
        'Alta'
      ],
      [
        'Máquinas',
        'As máquinas possuem proteções e dispositivos de segurança adequados?',
        'NR-12',
        'Crítica'
      ],
      [
        'Elétrica',
        'As instalações elétricas estão protegidas e sem improvisações aparentes?',
        'NR-10',
        'Alta'
      ],
      [
        'Prevenção contra incêndio',
        'Extintores, acessos e rotas de saída estão livres e sinalizados?',
        'NR-23',
        'Alta'
      ],
      [
        'Ergonomia',
        'As condições de trabalho evitam postura inadequada e esforço excessivo?',
        'NR-17',
        'Média'
      ],
      [
        'Sinalização',
        'Os riscos e áreas restritas estão devidamente sinalizados?',
        'NR-26',
        'Média'
      ],
      [
        'Trabalho em altura',
        'Quando aplicável, existem medidas de prevenção e proteção contra quedas?',
        'NR-35',
        'Crítica'
      ],
    ];

    for (var i = 0; i < items.length; i++) {
      await db.insert('checklist_items', {
        'id': 'geral-${i + 1}',
        'template_id': templateId,
        'sort_order': i + 1,
        'category': items[i][0],
        'text': items[i][1],
        'reference': items[i][2],
        'priority': items[i][3],
        'active': 1,
      });
    }
  }

  static Future<void> _seedReadyChecklistLibrary(Database db) async {
    for (final definition in readyChecklistLibrary) {
      await db.insert(
        'checklist_templates',
        {
          'id': definition.id,
          'name': definition.name,
          'category': definition.category,
          'reference': definition.reference,
          'active': 1,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );

      final countResult = await db.rawQuery(
        'SELECT COUNT(*) FROM checklist_items WHERE template_id = ?',
        [definition.id],
      );

      final count = Sqflite.firstIntValue(countResult) ?? 0;
      if (count > 0) continue;

      for (var i = 0; i < definition.items.length; i++) {
        final item = definition.items[i];
        await db.insert(
          'checklist_items',
          {
            'id': '${definition.id}-${i + 1}',
            'template_id': definition.id,
            'sort_order': i + 1,
            'category': item.category,
            'text': item.text,
            'reference': item.reference,
            'priority': item.priority,
            'active': 1,
          },
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );
      }
    }
  }

  Future<void> closeForFileOperation() async {
    final db = _db;
    if (db != null) {
      try {
        await db.rawQuery('PRAGMA wal_checkpoint(FULL)');
      } catch (_) {}
      await db.close();
      _db = null;
    }
  }

  Future<void> reopen() async {
    await closeForFileOperation();
    await database;
  }

  // SETTINGS
  Future<String> getSetting(String key, {String fallback = ''}) async {
    final db = await database;
    final rows = await db.query(
      'app_settings',
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    if (rows.isEmpty) return fallback;
    return (rows.first['value'] as String?) ?? fallback;
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      'app_settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // COMPANIES
  Future<void> insertCompany(Company company) async {
    final db = await database;
    await db.insert(
      'companies',
      company.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    await _ensureManagementPanelRow(db, company.id);
  }

  Future<void> _ensureManagementPanelRow(
    Database db,
    String companyId,
  ) async {
    final existing = await db.query(
      'management_panels',
      where: 'company_id = ?',
      whereArgs: [companyId],
      limit: 1,
    );
    if (existing.isNotEmpty) return;

    await db.insert(
      'management_panels',
      {
        'company_id': companyId,
        'access_token': const Uuid().v4().replaceAll('-', ''),
        'enabled': 1,
        'last_sync_status': 'Nunca sincronizado',
        'last_error': '',
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<Map<String, Object?>> ensureManagementPanel(
    String companyId,
  ) async {
    final db = await database;
    await _ensureManagementPanelRow(db, companyId);
    final rows = await db.query(
      'management_panels',
      where: 'company_id = ?',
      whereArgs: [companyId],
      limit: 1,
    );
    return rows.first;
  }

  Future<void> setManagementPanelEnabled(
    String companyId,
    bool enabled,
  ) async {
    final db = await database;
    await _ensureManagementPanelRow(db, companyId);
    await db.update(
      'management_panels',
      {'enabled': enabled ? 1 : 0},
      where: 'company_id = ?',
      whereArgs: [companyId],
    );
  }

  Future<void> updateManagementPanelSync({
    required String companyId,
    required String status,
    String error = '',
  }) async {
    final db = await database;
    await _ensureManagementPanelRow(db, companyId);
    await db.update(
      'management_panels',
      {
        'last_sync_at': DateTime.now().toIso8601String(),
        'last_sync_status': status,
        'last_error': error,
      },
      where: 'company_id = ?',
      whereArgs: [companyId],
    );
  }

  Future<void> updateCompany(Company company) async {
    final db = await database;
    await db.update(
      'companies',
      company.toMap(),
      where: 'id = ?',
      whereArgs: [company.id],
    );
  }

  Future<void> updateCompanyLogo(String companyId, String? logoPath) async {
    final db = await database;
    await db.update(
      'companies',
      {'logo_path': logoPath},
      where: 'id = ?',
      whereArgs: [companyId],
    );
  }

  Future<List<Company>> getCompanies({bool onlyActive = true}) async {
    final db = await database;
    final rows = await db.query(
      'companies',
      where: onlyActive ? 'active = 1' : null,
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Company.fromMap).toList();
  }

  Future<bool> deleteCompanyIfUnused(String companyId) async {
    final db = await database;
    final inspectionCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM inspections WHERE company_id = ?',
            [companyId],
          ),
        ) ??
        0;
    final workerCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM workers WHERE company_id = ?',
            [companyId],
          ),
        ) ??
        0;
    final cipaCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM cipa_elections WHERE company_id = ?',
            [companyId],
          ),
        ) ??
        0;
    final routineCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM sst_records WHERE company_id = ?',
            [companyId],
          ),
        ) ??
        0;

    if (inspectionCount > 0 || workerCount > 0 || cipaCount > 0 || routineCount > 0) return false;

    await db.transaction((txn) async {
      await txn.delete(
        'worksites',
        where: 'company_id = ?',
        whereArgs: [companyId],
      );
      await txn.delete(
        'sectors',
        where: 'company_id = ?',
        whereArgs: [companyId],
      );
      await txn.delete(
        'management_panels',
        where: 'company_id = ?',
        whereArgs: [companyId],
      );
      await txn.delete(
        'companies',
        where: 'id = ?',
        whereArgs: [companyId],
      );
    });
    return true;
  }

  // WORKSITES
  Future<void> insertWorkSite(WorkSite site) async {
    final db = await database;
    await db.insert(
      'worksites',
      site.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateWorkSite(WorkSite site) async {
    final db = await database;
    await db.update(
      'worksites',
      site.toMap(),
      where: 'id = ?',
      whereArgs: [site.id],
    );
  }

  Future<List<WorkSite>> getWorkSites(
    String companyId, {
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'worksites',
      where: onlyActive
          ? 'company_id = ? AND active = 1'
          : 'company_id = ?',
      whereArgs: [companyId],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(WorkSite.fromMap).toList();
  }

  Future<bool> deleteWorkSiteIfUnused(String siteId) async {
    final db = await database;
    final count = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM inspections WHERE worksite_id = ?',
            [siteId],
          ),
        ) ??
        0;

    if (count > 0) return false;

    await db.delete(
      'worksites',
      where: 'id = ?',
      whereArgs: [siteId],
    );
    return true;
  }

  // SECTORS
  Future<void> insertSector(Sector sector) async {
    final db = await database;
    await db.insert(
      'sectors',
      sector.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateSector(Sector sector) async {
    final db = await database;
    await db.update(
      'sectors',
      sector.toMap(),
      where: 'id = ?',
      whereArgs: [sector.id],
    );
  }

  Future<List<Sector>> getSectors(
    String companyId, {
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'sectors',
      where: onlyActive
          ? 'company_id = ? AND active = 1'
          : 'company_id = ?',
      whereArgs: [companyId],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Sector.fromMap).toList();
  }

  Future<bool> deleteSectorIfUnused(String sectorId) async {
    final db = await database;
    final inspectionCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM inspections WHERE sector_id = ?',
            [sectorId],
          ),
        ) ??
        0;
    final workerCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM workers WHERE sector_id = ?',
            [sectorId],
          ),
        ) ??
        0;
    final routineCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM sst_records WHERE sector_id = ?',
            [sectorId],
          ),
        ) ??
        0;

    if (inspectionCount > 0 || workerCount > 0 || routineCount > 0) return false;

    await db.delete(
      'sectors',
      where: 'id = ?',
      whereArgs: [sectorId],
    );
    return true;
  }

  Future<List<Map<String, Object?>>> getCompanySectorPerformance(
    String companyId,
  ) async {
    await refreshNonConformityStatuses(companyId: companyId);
    final db = await database;
    return db.rawQuery(
      "SELECT s.id, s.name, "
      "COUNT(DISTINCT i.id) AS inspections, "
      "MAX(i.date) AS latest_inspection, "
      "SUM(CASE WHEN r.status = 'Conforme' THEN 1 ELSE 0 END) AS conformes, "
      "SUM(CASE WHEN r.status = 'Não Conforme' THEN 1 ELSE 0 END) AS nao_conformes, "
      "SUM(CASE WHEN r.status = 'Parcial' THEN 1 ELSE 0 END) AS parciais, "
      "SUM(CASE WHEN r.status = 'Não se aplica' THEN 1 ELSE 0 END) AS nao_aplicaveis, "
      "(SELECT COUNT(*) FROM non_conformities nc "
      " JOIN inspections ix ON ix.id = nc.inspection_id "
      " WHERE ix.sector_id = s.id AND nc.status <> 'Concluída') AS open_ncs, "
      "(SELECT COUNT(*) FROM non_conformities nc "
      " JOIN inspections ix ON ix.id = nc.inspection_id "
      " WHERE ix.sector_id = s.id AND nc.status = 'Vencida') AS overdue_ncs "
      "FROM sectors s "
      "LEFT JOIN inspections i ON i.sector_id = s.id "
      "LEFT JOIN answers r ON r.inspection_id = i.id "
      "WHERE s.company_id = ? AND s.active = 1 "
      "GROUP BY s.id, s.name "
      "ORDER BY s.name COLLATE NOCASE",
      [companyId],
    );
  }

  // WORKERS
  Future<void> insertWorker(Worker worker) async {
    final db = await database;
    await db.insert(
      'workers',
      worker.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateWorker(Worker worker) async {
    final db = await database;
    await db.update(
      'workers',
      worker.toMap(),
      where: 'id = ?',
      whereArgs: [worker.id],
    );
  }

  Future<List<Worker>> getWorkers({
    String? companyId,
    String? sectorId,
    bool onlyActive = true,
  }) async {
    final db = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (companyId != null && companyId.isNotEmpty) {
      where.add('company_id = ?');
      args.add(companyId);
    }
    if (sectorId != null && sectorId.isNotEmpty) {
      where.add('sector_id = ?');
      args.add(sectorId);
    }
    if (onlyActive) where.add('active = 1');
    final rows = await db.query(
      'workers',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Worker.fromMap).toList();
  }

  Future<bool> deleteWorkerIfUnused(String workerId) async {
    final db = await database;
    final count = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM training_controls WHERE worker_id = ?',
            [workerId],
          ),
        ) ??
        0;
    if (count > 0) return false;
    await db.delete('workers', where: 'id = ?', whereArgs: [workerId]);
    return true;
  }

  // TRAININGS
  Future<void> insertTrainingControl(TrainingControl training) async {
    final db = await database;
    await db.insert(
      'training_controls',
      training.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateTrainingControl(TrainingControl training) async {
    final db = await database;
    await db.update(
      'training_controls',
      training.toMap(),
      where: 'id = ?',
      whereArgs: [training.id],
    );
  }

  Future<void> deleteTrainingControl(String trainingId) async {
    final db = await database;
    await db.delete(
      'training_controls',
      where: 'id = ?',
      whereArgs: [trainingId],
    );
  }

  Future<List<TrainingControl>> getTrainingControls({
    String? workerId,
    String? companyId,
  }) async {
    final db = await database;
    if (companyId != null && companyId.isNotEmpty) {
      final rows = await db.rawQuery(
        'SELECT t.* FROM training_controls t '
        'JOIN workers w ON w.id = t.worker_id '
        'WHERE w.company_id = ? '
        'ORDER BY t.title COLLATE NOCASE, t.expiry_date',
        [companyId],
      );
      return rows.map(TrainingControl.fromMap).toList();
    }
    final rows = await db.query(
      'training_controls',
      where: workerId == null ? null : 'worker_id = ?',
      whereArgs: workerId == null ? null : [workerId],
      orderBy: 'title COLLATE NOCASE, expiry_date',
    );
    return rows.map(TrainingControl.fromMap).toList();
  }

  Future<Map<String, int>> getTrainingSummary({String? companyId}) async {
    final trainings = await getTrainingControls(companyId: companyId);
    final now = DateTime.now();
    var current = 0;
    var pending = 0;
    var expired = 0;
    var expiringSoon = 0;
    for (final training in trainings) {
      final status = training.statusAt(now);
      if (status == 'PENDENTE') {
        pending++;
      } else if (status == 'VENCIDO') {
        expired++;
      } else {
        current++;
        if (training.expiryDate != null) {
          final days = training.expiryDate!.difference(now).inDays;
          if (days >= 0 && days <= 30) expiringSoon++;
        }
      }
    }
    return {
      'total': trainings.length,
      'current': current,
      'pending': pending,
      'expired': expired,
      'expiringSoon': expiringSoon,
    };
  }

  // CHECKLIST TEMPLATES
  Future<List<ChecklistTemplate>> getChecklistTemplates({
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'checklist_templates',
      where: onlyActive ? 'active = 1' : null,
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(ChecklistTemplate.fromMap).toList();
  }


  Future<Map<String, int>> getChecklistTemplateStats(
    String templateId,
  ) async {
    final db = await database;

    final totalResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );

    final activeResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items '
      'WHERE template_id = ? AND active = 1',
      [templateId],
    );

    final total = Sqflite.firstIntValue(totalResult) ?? 0;
    final active = Sqflite.firstIntValue(activeResult) ?? 0;

    return {
      'total': total,
      'active': active,
      'inactive': total - active,
    };
  }

  Future<void> insertChecklistTemplate(ChecklistTemplate template) async {
    final db = await database;
    await db.insert(
      'checklist_templates',
      template.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateChecklistTemplate(ChecklistTemplate template) async {
    final db = await database;
    await db.update(
      'checklist_templates',
      template.toMap(),
      where: 'id = ?',
      whereArgs: [template.id],
    );
  }

  Future<void> deleteChecklistTemplate(String templateId) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'checklist_items',
        where: 'template_id = ?',
        whereArgs: [templateId],
      );
      await txn.delete(
        'checklist_templates',
        where: 'id = ?',
        whereArgs: [templateId],
      );
    });
  }

  Future<void> duplicateChecklistTemplate(String templateId) async {
    final db = await database;

    final templates = await db.query(
      'checklist_templates',
      where: 'id = ?',
      whereArgs: [templateId],
      limit: 1,
    );
    if (templates.isEmpty) return;

    final original = ChecklistTemplate.fromMap(templates.first);
    final newTemplateId = const Uuid().v4();

    await db.insert(
      'checklist_templates',
      ChecklistTemplate(
        id: newTemplateId,
        name: '${original.name} - Cópia',
        category: original.category,
        reference: original.reference,
      ).toMap(),
    );

    final items = await getChecklistItems(
      templateId,
      onlyActive: false,
    );

    for (final item in items) {
      await db.insert(
        'checklist_items',
        ChecklistItem(
          id: const Uuid().v4(),
          templateId: newTemplateId,
          sortOrder: item.sortOrder,
          category: item.category,
          text: item.text,
          reference: item.reference,
          priority: item.priority,
          active: item.active,
        ).toMap(),
      );
    }
  }

  // CHECKLIST ITEMS
  Future<List<ChecklistItem>> getChecklistItems(
    String templateId, {
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'checklist_items',
      where: onlyActive
          ? 'template_id = ? AND active = 1'
          : 'template_id = ?',
      whereArgs: [templateId],
      orderBy: 'sort_order ASC, category COLLATE NOCASE',
    );
    return rows.map(ChecklistItem.fromMap).toList();
  }

  Future<void> insertChecklistItem(ChecklistItem item) async {
    final db = await database;
    await db.insert(
      'checklist_items',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateChecklistItem(ChecklistItem item) async {
    final db = await database;
    await db.update(
      'checklist_items',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<void> deleteChecklistItem(String itemId) async {
    final db = await database;
    await db.delete(
      'checklist_items',
      where: 'id = ?',
      whereArgs: [itemId],
    );
  }

  Future<int> nextChecklistOrder(String templateId) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT MAX(sort_order) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );
    return (Sqflite.firstIntValue(result) ?? 0) + 1;
  }

  // INSPECTIONS
  Future<void> insertInspection(Inspection inspection) async {
    final db = await database;
    await db.insert(
      'inspections',
      inspection.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateInspectionFinalData({
    required String inspectionId,
    required String technicianName,
    required String responsibleName,
    required String? technicianSignaturePath,
    required String? responsibleSignaturePath,
    required String generalNotes,
    required String conclusion,
  }) async {
    final db = await database;
    await db.update(
      'inspections',
      {
        'technician_name': technicianName,
        'responsible_name': responsibleName,
        'technician_signature_path': technicianSignaturePath,
        'responsible_signature_path': responsibleSignaturePath,
        'general_notes': generalNotes,
        'conclusion': conclusion,
        'status': 'Finalizada',
      },
      where: 'id = ?',
      whereArgs: [inspectionId],
    );
  }

  Future<void> markInspectionInProgress(String inspectionId) async {
    final db = await database;
    await db.update(
      'inspections',
      {'status': 'Em andamento'},
      where: 'id = ?',
      whereArgs: [inspectionId],
    );
  }

  Future<void> clearInspectionResults(String inspectionId) async {
    final db = await database;

    await db.transaction((txn) async {
      final answerRows = await txn.query(
        'answers',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final answerIds = answerRows
          .map((row) => row['id'] as String)
          .toList();

      final actionRows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final actionIds = actionRows
          .map((row) => row['id'] as String)
          .toList();

      for (final actionId in actionIds) {
        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [actionId],
        );
      }

      await txn.delete(
        'action_plans',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'non_conformities',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final answerId in answerIds) {
        await txn.delete(
          'evidence_photos',
          where: 'answer_id = ?',
          whereArgs: [answerId],
        );
      }

      await txn.delete(
        'answers',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.update(
        'inspections',
        {
          'status': 'Em andamento',
          'technician_signature_path': null,
          'responsible_signature_path': null,
          'responsible_name': null,
        },
        where: 'id = ?',
        whereArgs: [inspectionId],
      );
    });
  }

  Future<List<Map<String, Object?>>> getInspectionHistory({
    String? companyId,
  }) async {
    final db = await database;
    final where = companyId == null || companyId.isEmpty
        ? ''
        : 'WHERE i.company_id = ? ';
    final args = companyId == null || companyId.isEmpty
        ? <Object?>[]
        : <Object?>[companyId];
    return db.rawQuery(
      'SELECT i.id, i.area, i.checklist_type, i.date, i.status, '
      'i.report_number, c.name AS company_name, w.name AS worksite_name, '
      's.name AS sector_name '
      'FROM inspections i '
      'JOIN companies c ON c.id = i.company_id '
      'LEFT JOIN worksites w ON w.id = i.worksite_id '
      'LEFT JOIN sectors s ON s.id = i.sector_id '
      '$where'
      'ORDER BY i.date DESC',
      args,
    );
  }

  Future<Map<String, Object?>?> getInspectionHeader(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT i.*, '
      'c.name AS company_name, '
      'c.cnpj AS company_cnpj, '
      'c.logo_path AS company_logo_path, '
      'w.name AS worksite_name, '
      'w.address AS worksite_address, '
      's.name AS sector_name '
      'FROM inspections i '
      'JOIN companies c ON c.id = i.company_id '
      'LEFT JOIN worksites w ON w.id = i.worksite_id '
      'LEFT JOIN sectors s ON s.id = i.sector_id '
      'WHERE i.id = ? LIMIT 1',
      [inspectionId],
    );

    if (rows.isEmpty) return null;
    return rows.first;
  }

  // ANSWERS / EVIDENCE
  Future<void> insertAnswer(InspectionAnswer answer) async {
    final db = await database;
    await db.insert('answers', answer.toMap());
  }

  Future<List<InspectionAnswer>> getAnswers(String inspectionId) async {
    final db = await database;
    final rows = await db.query(
      'answers',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'rowid ASC',
    );
    return rows.map(InspectionAnswer.fromMap).toList();
  }

  Future<void> insertEvidencePhoto(EvidencePhoto photo) async {
    final db = await database;
    await db.insert('evidence_photos', photo.toMap());
  }

  Future<List<EvidencePhoto>> getPhotosForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'evidence_photos',
      where: 'answer_id = ?',
      whereArgs: [answerId],
      orderBy: 'sort_order ASC',
    );
    return rows.map(EvidencePhoto.fromMap).toList();
  }

  // NON CONFORMITIES
  Future<void> upsertNonConformity(NonConformity nc) async {
    final db = await database;
    await db.insert(
      'non_conformities',
      nc.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<NonConformity?> getNonConformity(String ncId) async {
    await syncNonConformityStatus(ncId);
    final db = await database;
    final rows = await db.query(
      'non_conformities',
      where: 'id = ?',
      whereArgs: [ncId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return NonConformity.fromMap(rows.first);
  }

  Future<NonConformity?> getNonConformityForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'non_conformities',
      columns: ['id'],
      where: 'answer_id = ?',
      whereArgs: [answerId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return getNonConformity('${rows.first['id']}');
  }

  Future<List<NonConformity>> getNonConformitiesForInspection(
    String inspectionId,
  ) async {
    await refreshNonConformityStatuses(inspectionId: inspectionId);
    final db = await database;
    final rows = await db.query(
      'non_conformities',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'created_at DESC',
    );
    return rows.map(NonConformity.fromMap).toList();
  }

  Future<void> refreshNonConformityStatuses({
    String? companyId,
    String? inspectionId,
  }) async {
    final db = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (companyId != null && companyId.isNotEmpty) {
      where.add('i.company_id = ?');
      args.add(companyId);
    }
    if (inspectionId != null && inspectionId.isNotEmpty) {
      where.add('nc.inspection_id = ?');
      args.add(inspectionId);
    }
    final whereSql = where.isEmpty ? '' : 'WHERE ${where.join(' AND ')}';
    final rows = await db.rawQuery(
      'SELECT nc.id FROM non_conformities nc '
      'JOIN inspections i ON i.id = nc.inspection_id '
      '$whereSql',
      args,
    );
    for (final row in rows) {
      await syncNonConformityStatus('${row['id']}');
    }
  }

  Future<List<Map<String, Object?>>> getNonConformityRows({
    String? companyId,
    String? inspectionId,
    bool includeClosed = true,
    String? status,
  }) async {
    await refreshNonConformityStatuses(
      companyId: companyId,
      inspectionId: inspectionId,
    );

    final db = await database;
    final where = <String>[];
    final args = <Object?>[];

    if (companyId != null && companyId.isNotEmpty) {
      where.add('i.company_id = ?');
      args.add(companyId);
    }
    if (inspectionId != null && inspectionId.isNotEmpty) {
      where.add('nc.inspection_id = ?');
      args.add(inspectionId);
    }
    if (!includeClosed) {
      where.add("nc.status <> 'Concluída'");
    }
    if (status != null && status.isNotEmpty && status != 'Todas') {
      where.add('nc.status = ?');
      args.add(status);
    }

    final whereSql = where.isEmpty ? '' : 'WHERE ${where.join(' AND ')} ';

    return db.rawQuery(
      "SELECT nc.*, c.name AS company_name, c.cnpj AS company_cnpj, "
      "w.name AS worksite_name, s.name AS sector_name, i.area AS area, "
      "i.date AS inspection_date, i.report_number AS inspection_report_number, "
      "i.technician_name AS technician_name, i.responsible_name AS responsible_name, "
      "r.question_text AS question_text, r.question_category AS question_category, "
      "r.question_reference AS question_reference, r.status AS answer_status, "
      "(SELECT COUNT(*) FROM action_plans a WHERE a.nc_id = nc.id) AS action_count, "
      "(SELECT COUNT(*) FROM action_plans a WHERE a.nc_id = nc.id AND a.status <> 'Concluído') AS open_action_count, "
      "(SELECT MIN(a.due_date) FROM action_plans a WHERE a.nc_id = nc.id AND a.status <> 'Concluído' AND a.due_date IS NOT NULL) AS next_due_date "
      "FROM non_conformities nc "
      "JOIN inspections i ON i.id = nc.inspection_id "
      "JOIN companies c ON c.id = i.company_id "
      "LEFT JOIN worksites w ON w.id = i.worksite_id "
      "LEFT JOIN sectors s ON s.id = i.sector_id "
      "JOIN answers r ON r.id = nc.answer_id "
      "$whereSql"
      "ORDER BY CASE nc.status "
      "WHEN 'Vencida' THEN 1 WHEN 'Pendente' THEN 2 WHEN 'Em andamento' THEN 3 "
      "WHEN 'Aguardando verificação' THEN 4 ELSE 5 END, nc.created_at DESC",
      args,
    );
  }

  Future<Map<String, Object?>?> getNonConformityDetailRow(String ncId) async {
    await syncNonConformityStatus(ncId);
    final db = await database;
    final rows = await db.rawQuery(
      "SELECT nc.*, c.name AS company_name, c.cnpj AS company_cnpj, "
      "w.name AS worksite_name, s.name AS sector_name, i.area AS area, "
      "i.date AS inspection_date, i.report_number AS inspection_report_number, "
      "i.technician_name AS technician_name, i.responsible_name AS responsible_name, "
      "r.question_text AS question_text, r.question_category AS question_category, "
      "r.question_reference AS question_reference, r.status AS answer_status "
      "FROM non_conformities nc "
      "JOIN inspections i ON i.id = nc.inspection_id "
      "JOIN companies c ON c.id = i.company_id "
      "LEFT JOIN worksites w ON w.id = i.worksite_id "
      "LEFT JOIN sectors s ON s.id = i.sector_id "
      "JOIN answers r ON r.id = nc.answer_id "
      "WHERE nc.id = ? LIMIT 1",
      [ncId],
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> setNonConformityStatus(String ncId, String status) async {
    final db = await database;
    await db.update(
      'non_conformities',
      {'status': status},
      where: 'id = ?',
      whereArgs: [ncId],
    );
  }

  Future<void> verifyNonConformity({
    required String ncId,
    required String verifiedBy,
  }) async {
    final db = await database;
    await db.update(
      'non_conformities',
      {
        'status': 'Concluída',
        'verified_at': DateTime.now().toIso8601String(),
        'verified_by': verifiedBy.trim(),
      },
      where: 'id = ?',
      whereArgs: [ncId],
    );
  }

  Future<void> reopenNonConformity(String ncId) async {
    final db = await database;
    await db.update(
      'non_conformities',
      {
        'status': 'Pendente',
        'verified_at': null,
        'verified_by': null,
      },
      where: 'id = ?',
      whereArgs: [ncId],
    );
    await syncNonConformityStatus(ncId, allowReopen: true);
  }

  Future<void> removeOrCloseNonConformityForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'non_conformities',
      where: 'answer_id = ?',
      whereArgs: [answerId],
      limit: 1,
    );
    if (rows.isEmpty) return;

    final ncId = '${rows.first['id']}';
    final actionCount = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM action_plans WHERE nc_id = ?',
            [ncId],
          ),
        ) ??
        0;

    if (actionCount == 0) {
      await db.delete(
        'non_conformities',
        where: 'id = ?',
        whereArgs: [ncId],
      );
    } else {
      await db.update(
        'non_conformities',
        {
          'status': 'Concluída',
          'verified_at': DateTime.now().toIso8601String(),
          'verified_by': 'Reclassificada na vistoria',
        },
        where: 'id = ?',
        whereArgs: [ncId],
      );
    }
  }

  Future<List<ActionPlan>> getActionsForNonConformity(String ncId) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'nc_id = ?',
      whereArgs: [ncId],
      orderBy: 'due_date',
    );
    return rows.map(ActionPlan.fromMap).toList();
  }

  Future<void> syncNonConformityStatus(
    String ncId, {
    bool allowReopen = false,
  }) async {
    final db = await database;
    final ncRows = await db.query(
      'non_conformities',
      columns: ['status'],
      where: 'id = ?',
      whereArgs: [ncId],
      limit: 1,
    );
    if (ncRows.isEmpty) return;

    final currentStatus = '${ncRows.first['status'] ?? 'Pendente'}';
    if (currentStatus == 'Concluída' && !allowReopen) return;

    final actions = await db.query(
      'action_plans',
      columns: ['status', 'due_date'],
      where: 'nc_id = ?',
      whereArgs: [ncId],
    );

    String status;
    if (actions.isEmpty) {
      status = 'Pendente';
    } else if (actions.every((row) => row['status'] == 'Concluído')) {
      status = 'Aguardando verificação';
    } else {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final hasOverdue = actions.any((row) {
        if (row['status'] == 'Concluído' || row['due_date'] == null) return false;
        final due = DateTime.tryParse('${row['due_date']}');
        if (due == null) return false;
        return DateTime(due.year, due.month, due.day).isBefore(today);
      });
      if (hasOverdue) {
        status = 'Vencida';
      } else if (actions.any((row) => row['status'] == 'Em andamento')) {
        status = 'Em andamento';
      } else {
        status = 'Pendente';
      }
    }

    await db.update(
      'non_conformities',
      {'status': status},
      where: 'id = ?',
      whereArgs: [ncId],
    );
  }

  Future<Map<String, int>> getNonConformityStatusCounts({
    String? companyId,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    await refreshNonConformityStatuses(companyId: companyId);
    final db = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (companyId != null && companyId.isNotEmpty) {
      where.add('i.company_id = ?');
      args.add(companyId);
    }
    if (startDate != null) {
      where.add('nc.created_at >= ?');
      args.add(DateTime(startDate.year, startDate.month, startDate.day).toIso8601String());
    }
    if (endDate != null) {
      where.add('nc.created_at < ?');
      args.add(DateTime(endDate.year, endDate.month, endDate.day).add(const Duration(days: 1)).toIso8601String());
    }
    final whereSql = where.isEmpty ? '' : 'WHERE ${where.join(' AND ')}';
    final rows = await db.rawQuery(
      "SELECT nc.status, COUNT(*) AS total FROM non_conformities nc "
      "JOIN inspections i ON i.id = nc.inspection_id $whereSql GROUP BY nc.status",
      args,
    );
    final result = <String, int>{
      'Pendente': 0,
      'Em andamento': 0,
      'Aguardando verificação': 0,
      'Vencida': 0,
      'Concluída': 0,
    };
    for (final row in rows) {
      result['${row['status']}'] = (row['total'] as num?)?.toInt() ?? 0;
    }
    return result;
  }

  // ACTION PLAN
  Future<void> insertAction(ActionPlan action) async {
    final db = await database;
    await db.insert('action_plans', action.toMap());
  }

  Future<void> updateAction(ActionPlan action) async {
    final db = await database;
    await db.update(
      'action_plans',
      action.toMap(),
      where: 'id = ?',
      whereArgs: [action.id],
    );
  }

  Future<List<ActionPlan>> getActionsForInspection(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'due_date',
    );
    return rows.map(ActionPlan.fromMap).toList();
  }

  Future<ActionPlan?> getAction(String actionId) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'id = ?',
      whereArgs: [actionId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ActionPlan.fromMap(rows.first);
  }

  Future<List<Map<String, Object?>>> getPendingActions({
    String? companyId,
    bool includeCompleted = false,
  }) async {
    final db = await database;

    final where = <String>[];
    final args = <Object?>[];

    if (!includeCompleted) {
      where.add("a.status <> 'Concluído'");
    }
    if (companyId != null) {
      where.add('i.company_id = ?');
      args.add(companyId);
    }

    final whereSql =
        where.isEmpty ? '' : 'WHERE ${where.join(' AND ')} ';

    return db.rawQuery(
      "SELECT a.*, c.name AS company_name, "
      "w.name AS worksite_name, s.name AS sector_name, i.area AS area, "
      "nc.code AS nc_code "
      "FROM action_plans a "
      "JOIN inspections i ON i.id = a.inspection_id "
      "JOIN companies c ON c.id = i.company_id "
      "LEFT JOIN worksites w ON w.id = i.worksite_id "
      "LEFT JOIN sectors s ON s.id = i.sector_id "
      "LEFT JOIN non_conformities nc ON nc.id = a.nc_id "
      "$whereSql"
      "ORDER BY CASE a.status "
      "WHEN 'Pendente' THEN 1 "
      "WHEN 'Em andamento' THEN 2 "
      "ELSE 3 END, "
      "CASE a.priority "
      "WHEN 'Crítica' THEN 1 "
      "WHEN 'Alta' THEN 2 "
      "WHEN 'Média' THEN 3 "
      "ELSE 4 END, "
      "a.due_date",
      args,
    );
  }

  Future<void> setActionStatus(String actionId, String status) async {
    final db = await database;
    await db.update(
      'action_plans',
      {'status': status},
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> concludeAction({
    required String actionId,
    required String completedBy,
    required String completionNote,
  }) async {
    final db = await database;
    await db.update(
      'action_plans',
      {
        'status': 'Concluído',
        'completion_date': DateTime.now().toIso8601String(),
        'completion_note': completionNote,
        'completed_by': completedBy,
      },
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> reopenAction(String actionId) async {
    final db = await database;
    await db.update(
      'action_plans',
      {
        'status': 'Pendente',
        'completion_date': null,
        'completion_note': null,
        'completed_by': null,
      },
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> insertCompletionPhoto(CompletionPhoto photo) async {
    final db = await database;
    await db.insert('completion_photos', photo.toMap());
  }

  Future<List<CompletionPhoto>> getCompletionPhotos(String actionId) async {
    final db = await database;
    final rows = await db.query(
      'completion_photos',
      where: 'action_id = ?',
      whereArgs: [actionId],
      orderBy: 'sort_order ASC',
    );
    return rows.map(CompletionPhoto.fromMap).toList();
  }

  Future<List<EvidencePhoto>> getOriginalPhotosForAction(
    String actionId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT p.* FROM evidence_photos p '
      'JOIN action_plans a ON a.answer_id = p.answer_id '
      'WHERE a.id = ? '
      'ORDER BY p.sort_order ASC',
      [actionId],
    );
    return rows.map(EvidencePhoto.fromMap).toList();
  }

  // DASHBOARD

  Future<Map<String, int>> getDashboardSummary({
    String? companyId,
    String? workSiteId,
    String? sectorId,
    DateTime? startDate,
    DateTime? endDate,
    String? priority,
  }) async {
    final db = await database;

    // Filtros base da vistoria: empresa, obra/unidade e período.
    final inspectionWhere = <String>[];
    final inspectionArgs = <Object?>[];

    if (companyId != null && companyId.isNotEmpty) {
      inspectionWhere.add('i.company_id = ?');
      inspectionArgs.add(companyId);
    }

    if (workSiteId != null && workSiteId.isNotEmpty) {
      inspectionWhere.add('i.worksite_id = ?');
      inspectionArgs.add(workSiteId);
    }

    if (sectorId != null && sectorId.isNotEmpty) {
      inspectionWhere.add('i.sector_id = ?');
      inspectionArgs.add(sectorId);
    }

    if (startDate != null) {
      final start = DateTime(
        startDate.year,
        startDate.month,
        startDate.day,
      );
      inspectionWhere.add('i.date >= ?');
      inspectionArgs.add(start.toIso8601String());
    }

    if (endDate != null) {
      final endExclusive = DateTime(
        endDate.year,
        endDate.month,
        endDate.day,
      ).add(const Duration(days: 1));

      inspectionWhere.add('i.date < ?');
      inspectionArgs.add(endExclusive.toIso8601String());
    }

    final inspectionClause = inspectionWhere.isEmpty
        ? ''
        : 'WHERE ${inspectionWhere.join(' AND ')}';

    // Vistorias e conformidade seguem empresa/obra/período.
    // O filtro de prioridade é aplicado aos indicadores do Plano de Ação.
    final totalInspections = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) '
            'FROM inspections i '
            '$inspectionClause',
            inspectionArgs,
          ),
        ) ??
        0;

    final answerWhere = <String>[
      ...inspectionWhere,
    ];
    final answerArgs = <Object?>[
      ...inspectionArgs,
    ];

    final answerClause = answerWhere.isEmpty
        ? ''
        : 'AND ${answerWhere.join(' AND ')}';

    final conformes = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Conforme' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final naoConformes = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Não Conforme' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final parciais = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Parcial' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final naoAplicaveis = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Não se aplica' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final considered = conformes + parciais + naoConformes;
    final conformity = considered == 0
        ? 0
        : ((conformes / considered) * 100).round();

    // Filtros do Plano de Ação.
    final actionWhere = <String>[
      ...inspectionWhere,
    ];
    final actionArgs = <Object?>[
      ...inspectionArgs,
    ];

    if (priority != null &&
        priority.isNotEmpty &&
        priority != 'Todas') {
      actionWhere.add('a.priority = ?');
      actionArgs.add(priority);
    }

    final actionClause = actionWhere.isEmpty
        ? ''
        : 'AND ${actionWhere.join(' AND ')}';

    final pending = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status <> 'Concluído' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    final completed = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status = 'Concluído' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    final overdueArgs = <Object?>[
      today.toIso8601String(),
      ...actionArgs,
    ];

    final overdue = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status <> 'Concluído' "
            "AND a.due_date IS NOT NULL "
            "AND a.due_date < ? "
            "$actionClause",
            overdueArgs,
          ),
        ) ??
        0;

    final inProgress = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status = 'Em andamento' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    // Distribuição por prioridade usa empresa/obra/período, mas ignora
    // o filtro de prioridade escolhido para permitir comparar as faixas.
    final baseActionWhere = <String>[
      ...inspectionWhere,
    ];
    final baseActionArgs = <Object?>[
      ...inspectionArgs,
    ];

    final baseActionClause = baseActionWhere.isEmpty
        ? ''
        : 'AND ${baseActionWhere.join(' AND ')}';

    Future<int> priorityCount(String value) async {
      return Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) "
              "FROM action_plans a "
              "JOIN inspections i ON i.id = a.inspection_id "
              "WHERE a.priority = ? "
              "$baseActionClause",
              [value, ...baseActionArgs],
            ),
          ) ??
          0;
    }

    final critical = await priorityCount('Crítica');
    final high = await priorityCount('Alta');
    final medium = await priorityCount('Média');
    final low = await priorityCount('Baixa');

    await refreshNonConformityStatuses(companyId: companyId);

    final ncWhere = <String>[...inspectionWhere];
    final ncArgs = <Object?>[...inspectionArgs];
    final ncBaseClause = ncWhere.isEmpty
        ? ''
        : 'AND ${ncWhere.join(' AND ')}';

    Future<int> ncStatusCount(String value) async {
      return Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) FROM non_conformities nc "
              "JOIN inspections i ON i.id = nc.inspection_id "
              "WHERE nc.status = ? $ncBaseClause",
              [value, ...ncArgs],
            ),
          ) ??
          0;
    }

    final ncPending = await ncStatusCount('Pendente');
    final ncInProgress = await ncStatusCount('Em andamento');
    final ncAwaiting = await ncStatusCount('Aguardando verificação');
    final ncOverdue = await ncStatusCount('Vencida');
    final ncCompleted = await ncStatusCount('Concluída');
    final ncTotal = ncPending + ncInProgress + ncAwaiting + ncOverdue + ncCompleted;
    final ncResolutionRate = ncTotal == 0 ? 0 : ((ncCompleted / ncTotal) * 100).round();

    final monthStart = DateTime(now.year, now.month, 1).toIso8601String();
    final nextMonth = DateTime(now.year, now.month + 1, 1).toIso8601String();
    final completedThisMonth = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) FROM non_conformities nc "
            "JOIN inspections i ON i.id = nc.inspection_id "
            "WHERE nc.status = 'Concluída' AND nc.verified_at >= ? AND nc.verified_at < ? $ncBaseClause",
            [monthStart, nextMonth, ...ncArgs],
          ),
        ) ??
        0;

    return {
      'inspections': totalInspections,
      'pending': pending,
      'overdue': overdue,
      'completed': completed,
      'inProgress': inProgress,
      'conformes': conformes,
      'naoConformes': naoConformes,
      'parciais': parciais,
      'naoAplicaveis': naoAplicaveis,
      'conformity': conformity,
      'critical': critical,
      'high': high,
      'medium': medium,
      'low': low,
      'ncPending': ncPending,
      'ncInProgress': ncInProgress,
      'ncAwaiting': ncAwaiting,
      'ncOverdue': ncOverdue,
      'ncCompleted': ncCompleted,
      'ncResolutionRate': ncResolutionRate,
      'ncCompletedThisMonth': completedThisMonth,
    };
  }

  Future<int> pendingActionsCount() async {
    final summary = await getDashboardSummary();
    return summary['pending'] ?? 0;
  }

  // GOOGLE DRIVE QUEUE
  Future<void> enqueueDriveUpload({
    required String id,
    required String inspectionId,
    required String localPath,
    required String fileName,
    required String companyName,
    String status = 'Pendente',
    String lastError = '',
  }) async {
    final db = await database;
    await db.insert(
      'drive_upload_queue',
      {
        'id': id,
        'inspection_id': inspectionId,
        'local_path': localPath,
        'file_name': fileName,
        'company_name': companyName,
        'created_at': DateTime.now().toIso8601String(),
        'status': status,
        'last_error': lastError,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, Object?>>> getPendingDriveUploads() async {
    final db = await database;
    return db.query(
      'drive_upload_queue',
      where: "status <> 'Enviado'",
      orderBy: 'created_at ASC',
    );
  }

  Future<int> pendingDriveUploadsCount() async {
    final db = await database;
    final result = await db.rawQuery(
      "SELECT COUNT(*) FROM drive_upload_queue WHERE status <> 'Enviado'",
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> markDriveUploadSent(String id) async {
    final db = await database;
    await db.update(
      'drive_upload_queue',
      {
        'status': 'Enviado',
        'last_error': '',
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> markDriveUploadFailed(String id, String error) async {
    final db = await database;
    await db.update(
      'drive_upload_queue',
      {
        'status': 'Pendente',
        'last_error': error,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }


  Future<Map<String, Object?>?> getDriveUploadForInspection(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.query(
      'drive_upload_queue',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }


  Future<void> deleteInspection(String inspectionId) async {
    final db = await database;

    await db.transaction((txn) async {
      final answerRows = await txn.query(
        'answers',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final actionRows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final row in actionRows) {
        final actionId = row['id'] as String;

        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [actionId],
        );
      }

      await txn.delete(
        'action_plans',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'non_conformities',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final row in answerRows) {
        final answerId = row['id'] as String;

        await txn.delete(
          'evidence_photos',
          where: 'answer_id = ?',
          whereArgs: [answerId],
        );
      }

      await txn.delete(
        'answers',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'drive_upload_queue',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'inspections',
        where: 'id = ?',
        whereArgs: [inspectionId],
      );
    });
  }


  // EDIT EXISTING INSPECTIONS
  Future<ActionPlan?> getActionForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'answer_id = ?',
      whereArgs: [answerId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ActionPlan.fromMap(rows.first);
  }

  Future<void> upsertAnswer(InspectionAnswer answer) async {
    final db = await database;
    await db.insert(
      'answers',
      answer.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> replaceEvidencePhotos({
    required String answerId,
    required List<EvidencePhoto> photos,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'evidence_photos',
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
      for (final photo in photos) {
        await txn.insert('evidence_photos', photo.toMap());
      }
    });
  }

  Future<void> deleteActionForAnswer(String answerId) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
      for (final row in rows) {
        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [row['id']],
        );
      }
      await txn.delete(
        'action_plans',
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
    });
  }

  Future<void> remapStoredPaths({
    required String oldDocumentsPath,
    required String newDocumentsPath,
  }) async {
    if (oldDocumentsPath.isEmpty ||
        oldDocumentsPath == newDocumentsPath) {
      return;
    }

    final db = await database;
    final likePattern = '$oldDocumentsPath%';

    await db.transaction((txn) async {
      await txn.rawUpdate(
        'UPDATE companies SET logo_path = REPLACE(logo_path, ?, ?) '
        'WHERE logo_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE evidence_photos SET path = REPLACE(path, ?, ?) '
        'WHERE path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE completion_photos SET path = REPLACE(path, ?, ?) '
        'WHERE path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE inspections SET technician_signature_path = '
        'REPLACE(technician_signature_path, ?, ?) '
        'WHERE technician_signature_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE inspections SET responsible_signature_path = '
        'REPLACE(responsible_signature_path, ?, ?) '
        'WHERE responsible_signature_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE drive_upload_queue SET local_path = REPLACE(local_path, ?, ?) '
        'WHERE local_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );
    });
  }


  // CIPA - PROCESSO ELEITORAL
  Future<void> insertCipaElection(CipaElection election) async {
    final db = await database;
    await db.insert(
      'cipa_elections',
      election.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateCipaElection(CipaElection election) async {
    final db = await database;
    await db.update(
      'cipa_elections',
      election.toMap(),
      where: 'id = ?',
      whereArgs: [election.id],
    );
  }

  Future<List<CipaElection>> getCipaElections({String? companyId}) async {
    final db = await database;
    final rows = await db.query(
      'cipa_elections',
      where: companyId == null ? null : 'company_id = ?',
      whereArgs: companyId == null ? null : [companyId],
      orderBy: 'created_at DESC',
    );
    return rows.map(CipaElection.fromMap).toList();
  }

  Future<void> deleteCipaElection(String electionId) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('cipa_candidates', where: 'election_id = ?', whereArgs: [electionId]);
      await txn.delete('cipa_voters', where: 'election_id = ?', whereArgs: [electionId]);
      await txn.delete('cipa_elections', where: 'id = ?', whereArgs: [electionId]);
    });
  }

  Future<void> setCipaElectionSync({
    required String electionId,
    required String status,
    String? electionStatus,
    String error = '',
  }) async {
    final db = await database;
    final values = <String, Object?>{
      'last_sync_at': DateTime.now().toIso8601String(),
      'last_sync_status': status,
      'last_error': error,
    };
    if (electionStatus != null) {
      values['status'] = electionStatus;
      if (electionStatus == 'Aberta') {
        values['published_at'] = DateTime.now().toIso8601String();
      }
    }
    await db.update(
      'cipa_elections',
      values,
      where: 'id = ?',
      whereArgs: [electionId],
    );
  }

  Future<void> upsertCipaCandidate(CipaCandidate candidate) async {
    final db = await database;
    await db.insert(
      'cipa_candidates',
      candidate.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteCipaCandidate(String id) async {
    final db = await database;
    await db.delete('cipa_candidates', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<CipaCandidate>> getCipaCandidates(String electionId) async {
    final db = await database;
    final rows = await db.query(
      'cipa_candidates',
      where: 'election_id = ? AND active = 1',
      whereArgs: [electionId],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(CipaCandidate.fromMap).toList();
  }

  Future<void> replaceCipaVoters(String electionId, List<CipaVoter> voters) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('cipa_voters', where: 'election_id = ?', whereArgs: [electionId]);
      for (final voter in voters) {
        await txn.insert(
          'cipa_voters',
          voter.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  Future<List<CipaVoter>> getCipaVoters(String electionId) async {
    final db = await database;
    final rows = await db.query(
      'cipa_voters',
      where: 'election_id = ? AND active = 1',
      whereArgs: [electionId],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(CipaVoter.fromMap).toList();
  }


  // ROTINA SST - AGENDA, DDS, APR/PT, INCIDENTES E EQUIPAMENTOS
  Future<void> upsertSstRecord(SstRecord record) async {
    final db = await database;
    await db.insert(
      'sst_records',
      record.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteSstRecord(String id) async {
    final db = await database;
    await db.delete('sst_records', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<SstRecord>> getSstRecords({
    required String type,
    String? companyId,
  }) async {
    final db = await database;
    final where = companyId == null ? 'type = ?' : 'type = ? AND company_id = ?';
    final args = companyId == null ? <Object?>[type] : <Object?>[type, companyId];
    final rows = await db.query(
      'sst_records',
      where: where,
      whereArgs: args,
      orderBy: 'COALESCE(due_date, date) ASC, date DESC',
    );
    return rows.map(SstRecord.fromMap).toList();
  }

  Future<Map<String, int>> getRoutineTodaySummary({String? companyId}) async {
    final db = await database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    final soon = start.add(const Duration(days: 8));
    final monthAhead = start.add(const Duration(days: 31));
    final companyClause = companyId == null ? '' : ' AND company_id = ?';
    final companyArgs = companyId == null ? <Object?>[] : <Object?>[companyId];


    final agendaToday = Sqflite.firstIntValue(await db.rawQuery(
          "SELECT COUNT(*) FROM sst_records WHERE type = 'AGENDA' "
          "AND date >= ? AND date < ? AND status != 'Concluído'$companyClause",
          [start.toIso8601String(), end.toIso8601String(), ...companyArgs],
        )) ?? 0;

    final equipmentDue = Sqflite.firstIntValue(await db.rawQuery(
          "SELECT COUNT(*) FROM sst_records WHERE type = 'EQUIPAMENTO' "
          "AND due_date IS NOT NULL AND due_date < ? "
          "AND status != 'Inativo'$companyClause",
          [soon.toIso8601String(), ...companyArgs],
        )) ?? 0;

    String actionCompanyJoin = '';
    String actionCompanyWhere = '';
    List<Object?> actionCompanyArgs = [];
    if (companyId != null) {
      actionCompanyJoin = ' JOIN inspections i ON i.id = a.inspection_id ';
      actionCompanyWhere = ' AND i.company_id = ?';
      actionCompanyArgs = [companyId];
    }
    final actionsOverdue = Sqflite.firstIntValue(await db.rawQuery(
          "SELECT COUNT(*) FROM action_plans a$actionCompanyJoin WHERE a.due_date IS NOT NULL "
          "AND a.due_date < ? AND a.status != 'Concluído'$actionCompanyWhere",
          [start.toIso8601String(), ...actionCompanyArgs],
        )) ?? 0;

    String trainingJoin = ' JOIN workers w ON w.id = t.worker_id ';
    String trainingWhere = " WHERE w.active = 1 AND t.expiry_date IS NOT NULL AND t.expiry_date < ?";
    final trainingArgs = <Object?>[monthAhead.toIso8601String()];
    if (companyId != null) {
      trainingWhere += ' AND w.company_id = ?';
      trainingArgs.add(companyId);
    }
    final trainingsDue = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM training_controls t$trainingJoin$trainingWhere',
          trainingArgs,
        )) ?? 0;

    String ncJoin = ' JOIN inspections i ON i.id = n.inspection_id ';
    String ncWhere = " WHERE n.status = 'Aguardando verificação'";
    final ncArgs = <Object?>[];
    if (companyId != null) {
      ncWhere += ' AND i.company_id = ?';
      ncArgs.add(companyId);
    }
    final ncVerification = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM non_conformities n$ncJoin$ncWhere',
          ncArgs,
        )) ?? 0;

    return {
      'agendaToday': agendaToday,
      'actionsOverdue': actionsOverdue,
      'trainingsDue': trainingsDue,
      'equipmentDue': equipmentDue,
      'ncVerification': ncVerification,
    };
  }

}
