import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import 'models.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<String> get databaseFilePath async {
    final dbPath = await getDatabasesPath();
    return join(dbPath, 'auditar_sst.db');
  }

  Future<Database> get database async {
    if (_db != null) return _db!;

    final path = await databaseFilePath;

    _db = await openDatabase(
      path,
      version: 7,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await _createSchema(db);
        await _seedDefaultChecklist(db);
        await _seedDefaultSettings(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await _upgradeSchema(db, oldVersion);
        await _seedDefaultChecklist(db);
        await _seedDefaultSettings(db);
      },
      onOpen: (db) async {
        await _seedDefaultChecklist(db);
        await _seedDefaultSettings(db);
      },
    );

    return _db!;
  }

  static Future<void> _createSchema(Database db) async {
    await db.execute(
      'CREATE TABLE companies('
      'id TEXT PRIMARY KEY, '
      'name TEXT NOT NULL, '
      'cnpj TEXT, '
      'city TEXT, '
      'uf TEXT, '
      'contact TEXT, '
      'phone TEXT, '
      'logo_path TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE worksites('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'name TEXT NOT NULL, '
      'type TEXT NOT NULL, '
      'address TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE checklist_templates('
      'id TEXT PRIMARY KEY, '
      'name TEXT NOT NULL, '
      'category TEXT, '
      'reference TEXT, '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE checklist_items('
      'id TEXT PRIMARY KEY, '
      'template_id TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0, '
      'category TEXT, '
      'text TEXT NOT NULL, '
      'reference TEXT, '
      'priority TEXT NOT NULL DEFAULT "Média", '
      'active INTEGER NOT NULL DEFAULT 1'
      ')',
    );

    await db.execute(
      'CREATE TABLE inspections('
      'id TEXT PRIMARY KEY, '
      'company_id TEXT NOT NULL, '
      'worksite_id TEXT, '
      'area TEXT NOT NULL, '
      'checklist_type TEXT NOT NULL, '
      'checklist_template_id TEXT, '
      'date TEXT NOT NULL, '
      'status TEXT NOT NULL, '
      'technician_name TEXT, '
      'responsible_name TEXT, '
      'technician_signature_path TEXT, '
      'responsible_signature_path TEXT, '
      'general_notes TEXT, '
      'conclusion TEXT, '
      'report_number TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE answers('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT NOT NULL, '
      'question_id TEXT NOT NULL, '
      'question_text TEXT, '
      'question_category TEXT, '
      'question_reference TEXT, '
      'status TEXT NOT NULL, '
      'observation TEXT, '
      'risk_identified TEXT, '
      'recommendation TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE evidence_photos('
      'id TEXT PRIMARY KEY, '
      'answer_id TEXT NOT NULL, '
      'path TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0'
      ')',
    );

    await db.execute(
      'CREATE TABLE action_plans('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT NOT NULL, '
      'answer_id TEXT NOT NULL, '
      'non_conformity TEXT NOT NULL, '
      'corrective_action TEXT NOT NULL, '
      'responsible TEXT, '
      'priority TEXT NOT NULL, '
      'due_date TEXT, '
      'status TEXT NOT NULL, '
      'completion_date TEXT, '
      'completion_note TEXT, '
      'completed_by TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE completion_photos('
      'id TEXT PRIMARY KEY, '
      'action_id TEXT NOT NULL, '
      'path TEXT NOT NULL, '
      'sort_order INTEGER NOT NULL DEFAULT 0'
      ')',
    );

    await db.execute(
      'CREATE TABLE app_settings('
      'key TEXT PRIMARY KEY, '
      'value TEXT'
      ')',
    );

    await db.execute(
      'CREATE TABLE drive_upload_queue('
      'id TEXT PRIMARY KEY, '
      'inspection_id TEXT, '
      'local_path TEXT NOT NULL, '
      'file_name TEXT NOT NULL, '
      'company_name TEXT, '
      'created_at TEXT NOT NULL, '
      'status TEXT NOT NULL DEFAULT "Pendente", '
      'last_error TEXT'
      ')',
    );
  }

  static Future<void> _upgradeSchema(Database db, int oldVersion) async {
    if (oldVersion < 2) {
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN logo_path TEXT',
      );
    }

    if (oldVersion < 3) {
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN technician_name TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN responsible_name TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN technician_signature_path TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN responsible_signature_path TEXT',
      );
      await db.execute(
        'CREATE TABLE IF NOT EXISTS evidence_photos('
        'id TEXT PRIMARY KEY, '
        'answer_id TEXT NOT NULL, '
        'path TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0'
        ')',
      );
    }

    if (oldVersion < 4) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS checklist_templates('
        'id TEXT PRIMARY KEY, '
        'name TEXT NOT NULL, '
        'category TEXT, '
        'reference TEXT, '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS checklist_items('
        'id TEXT PRIMARY KEY, '
        'template_id TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0, '
        'category TEXT, '
        'text TEXT NOT NULL, '
        'reference TEXT, '
        'priority TEXT NOT NULL DEFAULT "Média", '
        'active INTEGER NOT NULL DEFAULT 1'
        ')',
      );

      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN checklist_template_id TEXT',
      );
    }

    if (oldVersion < 5) {
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_text TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_category TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE answers ADD COLUMN question_reference TEXT',
      );
    }

    if (oldVersion < 6) {
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN cnpj TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN contact TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN phone TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE companies ADD COLUMN active INTEGER NOT NULL DEFAULT 1',
      );

      await _trySql(
        db,
        'ALTER TABLE worksites ADD COLUMN address TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE worksites ADD COLUMN active INTEGER NOT NULL DEFAULT 1',
      );

      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN general_notes TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN conclusion TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE inspections ADD COLUMN report_number TEXT',
      );

      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completion_date TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completion_note TEXT',
      );
      await _trySql(
        db,
        'ALTER TABLE action_plans ADD COLUMN completed_by TEXT',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS completion_photos('
        'id TEXT PRIMARY KEY, '
        'action_id TEXT NOT NULL, '
        'path TEXT NOT NULL, '
        'sort_order INTEGER NOT NULL DEFAULT 0'
        ')',
      );

      await db.execute(
        'CREATE TABLE IF NOT EXISTS app_settings('
        'key TEXT PRIMARY KEY, '
        'value TEXT'
        ')',
      );
    }

    if (oldVersion < 7) {
      await db.execute(
        'CREATE TABLE IF NOT EXISTS drive_upload_queue('
        'id TEXT PRIMARY KEY, '
        'inspection_id TEXT, '
        'local_path TEXT NOT NULL, '
        'file_name TEXT NOT NULL, '
        'company_name TEXT, '
        'created_at TEXT NOT NULL, '
        'status TEXT NOT NULL DEFAULT "Pendente", '
        'last_error TEXT'
        ')',
      );
    }
  }

  static Future<void> _trySql(Database db, String sql) async {
    try {
      await db.execute(sql);
    } catch (_) {}
  }

  static Future<void> _seedDefaultSettings(Database db) async {
    const defaults = {
      'app_name': 'Auditar SST',
      'default_technician': '',
      'report_footer': 'Relatório de Inspeção de Segurança do Trabalho',
      'drive_enabled': 'false',
      'drive_account_email': '',
      'drive_root_folder_id': '',
      'drive_auto_upload': 'true',
    };

    for (final entry in defaults.entries) {
      await db.insert(
        'app_settings',
        {'key': entry.key, 'value': entry.value},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  static Future<void> _seedDefaultChecklist(Database db) async {
    const templateId = 'template-geral-sst';

    final existing = await db.query(
      'checklist_templates',
      where: 'id = ?',
      whereArgs: [templateId],
      limit: 1,
    );

    if (existing.isEmpty) {
      await db.insert('checklist_templates', {
        'id': templateId,
        'name': 'Inspeção Geral SST',
        'category': 'Geral',
        'reference': 'NRs aplicáveis',
        'active': 1,
      });
    }

    final countResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );

    final count = Sqflite.firstIntValue(countResult) ?? 0;
    if (count > 0) return;

    final items = [
      [
        'Organização e limpeza',
        'A área está limpa, organizada e com circulação desobstruída?',
        'NR-01',
        'Média'
      ],
      [
        'EPI',
        'Os trabalhadores utilizam os EPIs necessários para a atividade?',
        'NR-06',
        'Alta'
      ],
      [
        'Máquinas',
        'As máquinas possuem proteções e dispositivos de segurança adequados?',
        'NR-12',
        'Crítica'
      ],
      [
        'Elétrica',
        'As instalações elétricas estão protegidas e sem improvisações aparentes?',
        'NR-10',
        'Alta'
      ],
      [
        'Prevenção contra incêndio',
        'Extintores, acessos e rotas de saída estão livres e sinalizados?',
        'NR-23',
        'Alta'
      ],
      [
        'Ergonomia',
        'As condições de trabalho evitam postura inadequada e esforço excessivo?',
        'NR-17',
        'Média'
      ],
      [
        'Sinalização',
        'Os riscos e áreas restritas estão devidamente sinalizados?',
        'NR-26',
        'Média'
      ],
      [
        'Trabalho em altura',
        'Quando aplicável, existem medidas de prevenção e proteção contra quedas?',
        'NR-35',
        'Crítica'
      ],
    ];

    for (var i = 0; i < items.length; i++) {
      await db.insert('checklist_items', {
        'id': 'geral-${i + 1}',
        'template_id': templateId,
        'sort_order': i + 1,
        'category': items[i][0],
        'text': items[i][1],
        'reference': items[i][2],
        'priority': items[i][3],
        'active': 1,
      });
    }
  }

  Future<void> closeForFileOperation() async {
    final db = _db;
    if (db != null) {
      try {
        await db.rawQuery('PRAGMA wal_checkpoint(FULL)');
      } catch (_) {}
      await db.close();
      _db = null;
    }
  }

  Future<void> reopen() async {
    await closeForFileOperation();
    await database;
  }

  // SETTINGS
  Future<String> getSetting(String key, {String fallback = ''}) async {
    final db = await database;
    final rows = await db.query(
      'app_settings',
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    if (rows.isEmpty) return fallback;
    return (rows.first['value'] as String?) ?? fallback;
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      'app_settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // COMPANIES
  Future<void> insertCompany(Company company) async {
    final db = await database;
    await db.insert(
      'companies',
      company.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateCompany(Company company) async {
    final db = await database;
    await db.update(
      'companies',
      company.toMap(),
      where: 'id = ?',
      whereArgs: [company.id],
    );
  }

  Future<void> updateCompanyLogo(String companyId, String? logoPath) async {
    final db = await database;
    await db.update(
      'companies',
      {'logo_path': logoPath},
      where: 'id = ?',
      whereArgs: [companyId],
    );
  }

  Future<List<Company>> getCompanies({bool onlyActive = true}) async {
    final db = await database;
    final rows = await db.query(
      'companies',
      where: onlyActive ? 'active = 1' : null,
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(Company.fromMap).toList();
  }

  Future<bool> deleteCompanyIfUnused(String companyId) async {
    final db = await database;
    final count = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM inspections WHERE company_id = ?',
            [companyId],
          ),
        ) ??
        0;

    if (count > 0) return false;

    await db.transaction((txn) async {
      await txn.delete(
        'worksites',
        where: 'company_id = ?',
        whereArgs: [companyId],
      );
      await txn.delete(
        'companies',
        where: 'id = ?',
        whereArgs: [companyId],
      );
    });
    return true;
  }

  // WORKSITES
  Future<void> insertWorkSite(WorkSite site) async {
    final db = await database;
    await db.insert(
      'worksites',
      site.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateWorkSite(WorkSite site) async {
    final db = await database;
    await db.update(
      'worksites',
      site.toMap(),
      where: 'id = ?',
      whereArgs: [site.id],
    );
  }

  Future<List<WorkSite>> getWorkSites(
    String companyId, {
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'worksites',
      where: onlyActive
          ? 'company_id = ? AND active = 1'
          : 'company_id = ?',
      whereArgs: [companyId],
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(WorkSite.fromMap).toList();
  }

  Future<bool> deleteWorkSiteIfUnused(String siteId) async {
    final db = await database;
    final count = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM inspections WHERE worksite_id = ?',
            [siteId],
          ),
        ) ??
        0;

    if (count > 0) return false;

    await db.delete(
      'worksites',
      where: 'id = ?',
      whereArgs: [siteId],
    );
    return true;
  }

  // CHECKLIST TEMPLATES
  Future<List<ChecklistTemplate>> getChecklistTemplates({
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'checklist_templates',
      where: onlyActive ? 'active = 1' : null,
      orderBy: 'name COLLATE NOCASE',
    );
    return rows.map(ChecklistTemplate.fromMap).toList();
  }


  Future<Map<String, int>> getChecklistTemplateStats(
    String templateId,
  ) async {
    final db = await database;

    final totalResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );

    final activeResult = await db.rawQuery(
      'SELECT COUNT(*) FROM checklist_items '
      'WHERE template_id = ? AND active = 1',
      [templateId],
    );

    final total = Sqflite.firstIntValue(totalResult) ?? 0;
    final active = Sqflite.firstIntValue(activeResult) ?? 0;

    return {
      'total': total,
      'active': active,
      'inactive': total - active,
    };
  }

  Future<void> insertChecklistTemplate(ChecklistTemplate template) async {
    final db = await database;
    await db.insert(
      'checklist_templates',
      template.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateChecklistTemplate(ChecklistTemplate template) async {
    final db = await database;
    await db.update(
      'checklist_templates',
      template.toMap(),
      where: 'id = ?',
      whereArgs: [template.id],
    );
  }

  Future<void> deleteChecklistTemplate(String templateId) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'checklist_items',
        where: 'template_id = ?',
        whereArgs: [templateId],
      );
      await txn.delete(
        'checklist_templates',
        where: 'id = ?',
        whereArgs: [templateId],
      );
    });
  }

  Future<void> duplicateChecklistTemplate(String templateId) async {
    final db = await database;

    final templates = await db.query(
      'checklist_templates',
      where: 'id = ?',
      whereArgs: [templateId],
      limit: 1,
    );
    if (templates.isEmpty) return;

    final original = ChecklistTemplate.fromMap(templates.first);
    final newTemplateId = const Uuid().v4();

    await db.insert(
      'checklist_templates',
      ChecklistTemplate(
        id: newTemplateId,
        name: '${original.name} - Cópia',
        category: original.category,
        reference: original.reference,
      ).toMap(),
    );

    final items = await getChecklistItems(
      templateId,
      onlyActive: false,
    );

    for (final item in items) {
      await db.insert(
        'checklist_items',
        ChecklistItem(
          id: const Uuid().v4(),
          templateId: newTemplateId,
          sortOrder: item.sortOrder,
          category: item.category,
          text: item.text,
          reference: item.reference,
          priority: item.priority,
          active: item.active,
        ).toMap(),
      );
    }
  }

  // CHECKLIST ITEMS
  Future<List<ChecklistItem>> getChecklistItems(
    String templateId, {
    bool onlyActive = true,
  }) async {
    final db = await database;
    final rows = await db.query(
      'checklist_items',
      where: onlyActive
          ? 'template_id = ? AND active = 1'
          : 'template_id = ?',
      whereArgs: [templateId],
      orderBy: 'sort_order ASC, category COLLATE NOCASE',
    );
    return rows.map(ChecklistItem.fromMap).toList();
  }

  Future<void> insertChecklistItem(ChecklistItem item) async {
    final db = await database;
    await db.insert(
      'checklist_items',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateChecklistItem(ChecklistItem item) async {
    final db = await database;
    await db.update(
      'checklist_items',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<void> deleteChecklistItem(String itemId) async {
    final db = await database;
    await db.delete(
      'checklist_items',
      where: 'id = ?',
      whereArgs: [itemId],
    );
  }

  Future<int> nextChecklistOrder(String templateId) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT MAX(sort_order) FROM checklist_items WHERE template_id = ?',
      [templateId],
    );
    return (Sqflite.firstIntValue(result) ?? 0) + 1;
  }

  // INSPECTIONS
  Future<void> insertInspection(Inspection inspection) async {
    final db = await database;
    await db.insert(
      'inspections',
      inspection.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateInspectionFinalData({
    required String inspectionId,
    required String technicianName,
    required String responsibleName,
    required String? technicianSignaturePath,
    required String? responsibleSignaturePath,
    required String generalNotes,
    required String conclusion,
  }) async {
    final db = await database;
    await db.update(
      'inspections',
      {
        'technician_name': technicianName,
        'responsible_name': responsibleName,
        'technician_signature_path': technicianSignaturePath,
        'responsible_signature_path': responsibleSignaturePath,
        'general_notes': generalNotes,
        'conclusion': conclusion,
        'status': 'Finalizada',
      },
      where: 'id = ?',
      whereArgs: [inspectionId],
    );
  }

  Future<void> markInspectionInProgress(String inspectionId) async {
    final db = await database;
    await db.update(
      'inspections',
      {'status': 'Em andamento'},
      where: 'id = ?',
      whereArgs: [inspectionId],
    );
  }

  Future<void> clearInspectionResults(String inspectionId) async {
    final db = await database;

    await db.transaction((txn) async {
      final answerRows = await txn.query(
        'answers',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final answerIds = answerRows
          .map((row) => row['id'] as String)
          .toList();

      final actionRows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final actionIds = actionRows
          .map((row) => row['id'] as String)
          .toList();

      for (final actionId in actionIds) {
        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [actionId],
        );
      }

      await txn.delete(
        'action_plans',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final answerId in answerIds) {
        await txn.delete(
          'evidence_photos',
          where: 'answer_id = ?',
          whereArgs: [answerId],
        );
      }

      await txn.delete(
        'answers',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.update(
        'inspections',
        {
          'status': 'Em andamento',
          'technician_signature_path': null,
          'responsible_signature_path': null,
          'responsible_name': null,
        },
        where: 'id = ?',
        whereArgs: [inspectionId],
      );
    });
  }

  Future<List<Map<String, Object?>>> getInspectionHistory() async {
    final db = await database;
    return db.rawQuery(
      'SELECT i.id, i.area, i.checklist_type, i.date, i.status, '
      'i.report_number, c.name AS company_name, w.name AS worksite_name '
      'FROM inspections i '
      'JOIN companies c ON c.id = i.company_id '
      'LEFT JOIN worksites w ON w.id = i.worksite_id '
      'ORDER BY i.date DESC',
    );
  }

  Future<Map<String, Object?>?> getInspectionHeader(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT i.*, '
      'c.name AS company_name, '
      'c.cnpj AS company_cnpj, '
      'c.logo_path AS company_logo_path, '
      'w.name AS worksite_name, '
      'w.address AS worksite_address '
      'FROM inspections i '
      'JOIN companies c ON c.id = i.company_id '
      'LEFT JOIN worksites w ON w.id = i.worksite_id '
      'WHERE i.id = ? LIMIT 1',
      [inspectionId],
    );

    if (rows.isEmpty) return null;
    return rows.first;
  }

  // ANSWERS / EVIDENCE
  Future<void> insertAnswer(InspectionAnswer answer) async {
    final db = await database;
    await db.insert('answers', answer.toMap());
  }

  Future<List<InspectionAnswer>> getAnswers(String inspectionId) async {
    final db = await database;
    final rows = await db.query(
      'answers',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'rowid ASC',
    );
    return rows.map(InspectionAnswer.fromMap).toList();
  }

  Future<void> insertEvidencePhoto(EvidencePhoto photo) async {
    final db = await database;
    await db.insert('evidence_photos', photo.toMap());
  }

  Future<List<EvidencePhoto>> getPhotosForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'evidence_photos',
      where: 'answer_id = ?',
      whereArgs: [answerId],
      orderBy: 'sort_order ASC',
    );
    return rows.map(EvidencePhoto.fromMap).toList();
  }

  // ACTION PLAN
  Future<void> insertAction(ActionPlan action) async {
    final db = await database;
    await db.insert('action_plans', action.toMap());
  }

  Future<void> updateAction(ActionPlan action) async {
    final db = await database;
    await db.update(
      'action_plans',
      action.toMap(),
      where: 'id = ?',
      whereArgs: [action.id],
    );
  }

  Future<List<ActionPlan>> getActionsForInspection(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'due_date',
    );
    return rows.map(ActionPlan.fromMap).toList();
  }

  Future<ActionPlan?> getAction(String actionId) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'id = ?',
      whereArgs: [actionId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ActionPlan.fromMap(rows.first);
  }

  Future<List<Map<String, Object?>>> getPendingActions({
    String? companyId,
    bool includeCompleted = false,
  }) async {
    final db = await database;

    final where = <String>[];
    final args = <Object?>[];

    if (!includeCompleted) {
      where.add("a.status <> 'Concluído'");
    }
    if (companyId != null) {
      where.add('i.company_id = ?');
      args.add(companyId);
    }

    final whereSql =
        where.isEmpty ? '' : 'WHERE ${where.join(' AND ')} ';

    return db.rawQuery(
      "SELECT a.*, c.name AS company_name, "
      "w.name AS worksite_name, i.area AS area "
      "FROM action_plans a "
      "JOIN inspections i ON i.id = a.inspection_id "
      "JOIN companies c ON c.id = i.company_id "
      "LEFT JOIN worksites w ON w.id = i.worksite_id "
      "$whereSql"
      "ORDER BY CASE a.status "
      "WHEN 'Pendente' THEN 1 "
      "WHEN 'Em andamento' THEN 2 "
      "ELSE 3 END, "
      "CASE a.priority "
      "WHEN 'Crítica' THEN 1 "
      "WHEN 'Alta' THEN 2 "
      "WHEN 'Média' THEN 3 "
      "ELSE 4 END, "
      "a.due_date",
      args,
    );
  }

  Future<void> setActionStatus(String actionId, String status) async {
    final db = await database;
    await db.update(
      'action_plans',
      {'status': status},
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> concludeAction({
    required String actionId,
    required String completedBy,
    required String completionNote,
  }) async {
    final db = await database;
    await db.update(
      'action_plans',
      {
        'status': 'Concluído',
        'completion_date': DateTime.now().toIso8601String(),
        'completion_note': completionNote,
        'completed_by': completedBy,
      },
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> reopenAction(String actionId) async {
    final db = await database;
    await db.update(
      'action_plans',
      {
        'status': 'Pendente',
        'completion_date': null,
        'completion_note': null,
        'completed_by': null,
      },
      where: 'id = ?',
      whereArgs: [actionId],
    );
  }

  Future<void> insertCompletionPhoto(CompletionPhoto photo) async {
    final db = await database;
    await db.insert('completion_photos', photo.toMap());
  }

  Future<List<CompletionPhoto>> getCompletionPhotos(String actionId) async {
    final db = await database;
    final rows = await db.query(
      'completion_photos',
      where: 'action_id = ?',
      whereArgs: [actionId],
      orderBy: 'sort_order ASC',
    );
    return rows.map(CompletionPhoto.fromMap).toList();
  }

  Future<List<EvidencePhoto>> getOriginalPhotosForAction(
    String actionId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT p.* FROM evidence_photos p '
      'JOIN action_plans a ON a.answer_id = p.answer_id '
      'WHERE a.id = ? '
      'ORDER BY p.sort_order ASC',
      [actionId],
    );
    return rows.map(EvidencePhoto.fromMap).toList();
  }

  // DASHBOARD

  Future<Map<String, int>> getDashboardSummary({
    String? companyId,
    String? workSiteId,
    DateTime? startDate,
    DateTime? endDate,
    String? priority,
  }) async {
    final db = await database;

    // Filtros base da vistoria: empresa, obra/unidade e período.
    final inspectionWhere = <String>[];
    final inspectionArgs = <Object?>[];

    if (companyId != null && companyId.isNotEmpty) {
      inspectionWhere.add('i.company_id = ?');
      inspectionArgs.add(companyId);
    }

    if (workSiteId != null && workSiteId.isNotEmpty) {
      inspectionWhere.add('i.worksite_id = ?');
      inspectionArgs.add(workSiteId);
    }

    if (startDate != null) {
      final start = DateTime(
        startDate.year,
        startDate.month,
        startDate.day,
      );
      inspectionWhere.add('i.date >= ?');
      inspectionArgs.add(start.toIso8601String());
    }

    if (endDate != null) {
      final endExclusive = DateTime(
        endDate.year,
        endDate.month,
        endDate.day,
      ).add(const Duration(days: 1));

      inspectionWhere.add('i.date < ?');
      inspectionArgs.add(endExclusive.toIso8601String());
    }

    final inspectionClause = inspectionWhere.isEmpty
        ? ''
        : 'WHERE ${inspectionWhere.join(' AND ')}';

    // Vistorias e conformidade seguem empresa/obra/período.
    // O filtro de prioridade é aplicado aos indicadores do Plano de Ação.
    final totalInspections = Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) '
            'FROM inspections i '
            '$inspectionClause',
            inspectionArgs,
          ),
        ) ??
        0;

    final answerWhere = <String>[
      ...inspectionWhere,
    ];
    final answerArgs = <Object?>[
      ...inspectionArgs,
    ];

    final answerClause = answerWhere.isEmpty
        ? ''
        : 'AND ${answerWhere.join(' AND ')}';

    final conformes = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Conforme' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final naoConformes = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Não Conforme' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final naoAplicaveis = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM answers r "
            "JOIN inspections i ON i.id = r.inspection_id "
            "WHERE r.status = 'Não se aplica' "
            "$answerClause",
            answerArgs,
          ),
        ) ??
        0;

    final considered = conformes + naoConformes;
    final conformity = considered == 0
        ? 0
        : ((conformes / considered) * 100).round();

    // Filtros do Plano de Ação.
    final actionWhere = <String>[
      ...inspectionWhere,
    ];
    final actionArgs = <Object?>[
      ...inspectionArgs,
    ];

    if (priority != null &&
        priority.isNotEmpty &&
        priority != 'Todas') {
      actionWhere.add('a.priority = ?');
      actionArgs.add(priority);
    }

    final actionClause = actionWhere.isEmpty
        ? ''
        : 'AND ${actionWhere.join(' AND ')}';

    final pending = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status <> 'Concluído' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    final completed = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status = 'Concluído' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    final overdueArgs = <Object?>[
      today.toIso8601String(),
      ...actionArgs,
    ];

    final overdue = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status <> 'Concluído' "
            "AND a.due_date IS NOT NULL "
            "AND a.due_date < ? "
            "$actionClause",
            overdueArgs,
          ),
        ) ??
        0;

    final inProgress = Sqflite.firstIntValue(
          await db.rawQuery(
            "SELECT COUNT(*) "
            "FROM action_plans a "
            "JOIN inspections i ON i.id = a.inspection_id "
            "WHERE a.status = 'Em andamento' "
            "$actionClause",
            actionArgs,
          ),
        ) ??
        0;

    // Distribuição por prioridade usa empresa/obra/período, mas ignora
    // o filtro de prioridade escolhido para permitir comparar as faixas.
    final baseActionWhere = <String>[
      ...inspectionWhere,
    ];
    final baseActionArgs = <Object?>[
      ...inspectionArgs,
    ];

    final baseActionClause = baseActionWhere.isEmpty
        ? ''
        : 'AND ${baseActionWhere.join(' AND ')}';

    Future<int> priorityCount(String value) async {
      return Sqflite.firstIntValue(
            await db.rawQuery(
              "SELECT COUNT(*) "
              "FROM action_plans a "
              "JOIN inspections i ON i.id = a.inspection_id "
              "WHERE a.priority = ? "
              "$baseActionClause",
              [value, ...baseActionArgs],
            ),
          ) ??
          0;
    }

    final critical = await priorityCount('Crítica');
    final high = await priorityCount('Alta');
    final medium = await priorityCount('Média');
    final low = await priorityCount('Baixa');

    return {
      'inspections': totalInspections,
      'pending': pending,
      'overdue': overdue,
      'completed': completed,
      'inProgress': inProgress,
      'conformes': conformes,
      'naoConformes': naoConformes,
      'naoAplicaveis': naoAplicaveis,
      'conformity': conformity,
      'critical': critical,
      'high': high,
      'medium': medium,
      'low': low,
    };
  }

  Future<int> pendingActionsCount() async {
    final summary = await getDashboardSummary();
    return summary['pending'] ?? 0;
  }

  // GOOGLE DRIVE QUEUE
  Future<void> enqueueDriveUpload({
    required String id,
    required String inspectionId,
    required String localPath,
    required String fileName,
    required String companyName,
    String status = 'Pendente',
    String lastError = '',
  }) async {
    final db = await database;
    await db.insert(
      'drive_upload_queue',
      {
        'id': id,
        'inspection_id': inspectionId,
        'local_path': localPath,
        'file_name': fileName,
        'company_name': companyName,
        'created_at': DateTime.now().toIso8601String(),
        'status': status,
        'last_error': lastError,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, Object?>>> getPendingDriveUploads() async {
    final db = await database;
    return db.query(
      'drive_upload_queue',
      where: "status <> 'Enviado'",
      orderBy: 'created_at ASC',
    );
  }

  Future<int> pendingDriveUploadsCount() async {
    final db = await database;
    final result = await db.rawQuery(
      "SELECT COUNT(*) FROM drive_upload_queue WHERE status <> 'Enviado'",
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> markDriveUploadSent(String id) async {
    final db = await database;
    await db.update(
      'drive_upload_queue',
      {
        'status': 'Enviado',
        'last_error': '',
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> markDriveUploadFailed(String id, String error) async {
    final db = await database;
    await db.update(
      'drive_upload_queue',
      {
        'status': 'Pendente',
        'last_error': error,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }


  Future<Map<String, Object?>?> getDriveUploadForInspection(
    String inspectionId,
  ) async {
    final db = await database;
    final rows = await db.query(
      'drive_upload_queue',
      where: 'inspection_id = ?',
      whereArgs: [inspectionId],
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }


  Future<void> deleteInspection(String inspectionId) async {
    final db = await database;

    await db.transaction((txn) async {
      final answerRows = await txn.query(
        'answers',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      final actionRows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final row in actionRows) {
        final actionId = row['id'] as String;

        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [actionId],
        );
      }

      await txn.delete(
        'action_plans',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      for (final row in answerRows) {
        final answerId = row['id'] as String;

        await txn.delete(
          'evidence_photos',
          where: 'answer_id = ?',
          whereArgs: [answerId],
        );
      }

      await txn.delete(
        'answers',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'drive_upload_queue',
        where: 'inspection_id = ?',
        whereArgs: [inspectionId],
      );

      await txn.delete(
        'inspections',
        where: 'id = ?',
        whereArgs: [inspectionId],
      );
    });
  }


  // EDIT EXISTING INSPECTIONS
  Future<ActionPlan?> getActionForAnswer(String answerId) async {
    final db = await database;
    final rows = await db.query(
      'action_plans',
      where: 'answer_id = ?',
      whereArgs: [answerId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ActionPlan.fromMap(rows.first);
  }

  Future<void> upsertAnswer(InspectionAnswer answer) async {
    final db = await database;
    await db.insert(
      'answers',
      answer.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> replaceEvidencePhotos({
    required String answerId,
    required List<EvidencePhoto> photos,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'evidence_photos',
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
      for (final photo in photos) {
        await txn.insert('evidence_photos', photo.toMap());
      }
    });
  }

  Future<void> deleteActionForAnswer(String answerId) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query(
        'action_plans',
        columns: ['id'],
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
      for (final row in rows) {
        await txn.delete(
          'completion_photos',
          where: 'action_id = ?',
          whereArgs: [row['id']],
        );
      }
      await txn.delete(
        'action_plans',
        where: 'answer_id = ?',
        whereArgs: [answerId],
      );
    });
  }

  Future<void> remapStoredPaths({
    required String oldDocumentsPath,
    required String newDocumentsPath,
  }) async {
    if (oldDocumentsPath.isEmpty ||
        oldDocumentsPath == newDocumentsPath) {
      return;
    }

    final db = await database;
    final likePattern = '$oldDocumentsPath%';

    await db.transaction((txn) async {
      await txn.rawUpdate(
        'UPDATE companies SET logo_path = REPLACE(logo_path, ?, ?) '
        'WHERE logo_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE evidence_photos SET path = REPLACE(path, ?, ?) '
        'WHERE path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE completion_photos SET path = REPLACE(path, ?, ?) '
        'WHERE path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE inspections SET technician_signature_path = '
        'REPLACE(technician_signature_path, ?, ?) '
        'WHERE technician_signature_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE inspections SET responsible_signature_path = '
        'REPLACE(responsible_signature_path, ?, ?) '
        'WHERE responsible_signature_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );

      await txn.rawUpdate(
        'UPDATE drive_upload_queue SET local_path = REPLACE(local_path, ?, ?) '
        'WHERE local_path LIKE ?',
        [oldDocumentsPath, newDocumentsPath, likePattern],
      );
    });
  }

}
