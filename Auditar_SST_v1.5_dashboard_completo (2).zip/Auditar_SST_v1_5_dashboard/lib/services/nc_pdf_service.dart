import 'dart:io';
import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../database.dart';

class NcPdfService {
  static Future<Uint8List> generate(String ncId) async {
    final db = AppDatabase.instance;
    final row = await db.getNonConformityDetailRow(ncId);
    if (row == null) throw Exception('Não conformidade não encontrada.');

    final nc = await db.getNonConformity(ncId);
    if (nc == null) throw Exception('Não conformidade não encontrada.');

    final photos = await db.getPhotosForAnswer(nc.answerId);
    final actions = await db.getActionsForNonConformity(ncId);
    final doc = pw.Document();

    final date = DateTime.tryParse('${row['inspection_date'] ?? ''}');
    final dateText = date == null ? '-' : DateFormat('dd/MM/yyyy HH:mm').format(date);

    final widgets = <pw.Widget>[
      pw.Container(
        padding: const pw.EdgeInsets.only(bottom: 10),
        decoration: const pw.BoxDecoration(
          border: pw.Border(bottom: pw.BorderSide(color: PdfColors.green800, width: 2)),
        ),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('AUDITAR SST', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: PdfColors.blue900)),
                pw.SizedBox(height: 2),
                pw.Text('RELATÓRIO DE NÃO CONFORMIDADE', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColors.green800)),
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text(nc.code, style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                pw.Text('Status: ${nc.status}', style: const pw.TextStyle(fontSize: 9)),
              ],
            ),
          ],
        ),
      ),
      pw.SizedBox(height: 14),
      _section('IDENTIFICAÇÃO'),
      _table([
        ['Empresa', '${row['company_name'] ?? '-'}'],
        if ('${row['company_cnpj'] ?? ''}'.trim().isNotEmpty) ['CNPJ', '${row['company_cnpj']}'],
        if ('${row['sector_name'] ?? ''}'.trim().isNotEmpty) ['Setor', '${row['sector_name']}'],
        if ('${row['worksite_name'] ?? ''}'.trim().isNotEmpty) ['Obra / Unidade', '${row['worksite_name']}'],
        ['Área / Local', '${row['area'] ?? '-'}'],
        ['Data da inspeção', dateText],
        ['Técnico responsável', '${row['technician_name'] ?? '-'}'],
        if ('${row['responsible_name'] ?? ''}'.trim().isNotEmpty) ['Responsável da empresa', '${row['responsible_name']}'],
      ]),
      pw.SizedBox(height: 12),
      _section('NÃO CONFORMIDADE'),
      _box('Item verificado', '${row['question_text'] ?? '-'}'),
      if ('${row['question_category'] ?? ''}'.trim().isNotEmpty)
        _box('Categoria', '${row['question_category']}'),
      if ('${row['question_reference'] ?? ''}'.trim().isNotEmpty)
        _box('Referência normativa', '${row['question_reference']}'),
      _box('Situação encontrada', nc.description),
      _box('Risco identificado', nc.riskIdentified.isEmpty ? 'Não informado.' : nc.riskIdentified),
      _box('Recomendação técnica', nc.recommendation.isEmpty ? 'Não informada.' : nc.recommendation),
      _box('Classificação / prioridade', nc.classification),
      pw.SizedBox(height: 12),
      _section('EVIDÊNCIAS FOTOGRÁFICAS'),
    ];

    if (photos.isEmpty) {
      widgets.add(pw.Text('Nenhuma evidência fotográfica anexada.'));
    } else {
      for (var i = 0; i < photos.length; i += 2) {
        final pair = photos.skip(i).take(2).toList();
        widgets.add(
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: pair.asMap().entries.map((entry) {
              final file = File(entry.value.path);
              return pw.Expanded(
                child: pw.Padding(
                  padding: pw.EdgeInsets.only(right: entry.key == 0 && pair.length > 1 ? 8 : 0, bottom: 8),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text('Foto ${i + entry.key + 1}', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 4),
                      if (file.existsSync())
                        pw.Container(
                          height: 210,
                          width: double.infinity,
                          decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400)),
                          child: pw.Image(pw.MemoryImage(file.readAsBytesSync()), fit: pw.BoxFit.contain),
                        )
                      else
                        pw.Container(height: 80, alignment: pw.Alignment.center, child: pw.Text('Foto indisponível')),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        );
      }
    }

    widgets.addAll([
      pw.SizedBox(height: 12),
      _section('PLANO DE AÇÃO VINCULADO'),
    ]);

    if (actions.isEmpty) {
      widgets.add(pw.Text('Nenhum plano de ação foi criado para esta NC.'));
    } else {
      for (var i = 0; i < actions.length; i++) {
        final action = actions[i];
        widgets.add(
          pw.Container(
            margin: const pw.EdgeInsets.only(bottom: 8),
            padding: const pw.EdgeInsets.all(8),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.grey400),
              borderRadius: pw.BorderRadius.circular(4),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('Ação ${i + 1}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.blue900)),
                pw.SizedBox(height: 4),
                pw.Text(action.correctiveAction),
                pw.SizedBox(height: 4),
                pw.Text('Responsável: ${action.responsible.isEmpty ? '-' : action.responsible}   |   Prioridade: ${action.priority}   |   Status: ${action.status}', style: const pw.TextStyle(fontSize: 9)),
                pw.Text('Prazo: ${action.dueDate == null ? '-' : DateFormat('dd/MM/yyyy').format(action.dueDate!)}', style: const pw.TextStyle(fontSize: 9)),
              ],
            ),
          ),
        );
      }
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(34, 34, 34, 38),
        footer: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 6),
          decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey300))),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Auditar SST • ${row['company_name'] ?? ''}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
              pw.Text('Página ${context.pageNumber} de ${context.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
            ],
          ),
        ),
        build: (_) => widgets,
      ),
    );

    return doc.save();
  }

  static pw.Widget _section(String title) => pw.Container(
        width: double.infinity,
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        margin: const pw.EdgeInsets.only(bottom: 6),
        color: PdfColors.green50,
        child: pw.Text(title, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.green900, fontSize: 10)),
      );

  static pw.Widget _table(List<List<String>> rows) => pw.Table(
        border: pw.TableBorder.all(color: PdfColors.grey300),
        columnWidths: const {0: pw.FlexColumnWidth(1.2), 1: pw.FlexColumnWidth(3.4)},
        children: rows
            .map(
              (r) => pw.TableRow(
                children: [
                  pw.Container(color: PdfColors.grey100, padding: const pw.EdgeInsets.all(6), child: pw.Text(r[0], style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold))),
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text(r[1], style: const pw.TextStyle(fontSize: 9))),
                ],
              ),
            )
            .toList(),
      );

  static pw.Widget _box(String title, String value) => pw.Container(
        width: double.infinity,
        margin: const pw.EdgeInsets.only(bottom: 6),
        padding: const pw.EdgeInsets.all(8),
        decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300), borderRadius: pw.BorderRadius.circular(4)),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(title.toUpperCase(), style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.grey700)),
            pw.SizedBox(height: 3),
            pw.Text(value.isEmpty ? '-' : value, style: const pw.TextStyle(fontSize: 10)),
          ],
        ),
      );
}
