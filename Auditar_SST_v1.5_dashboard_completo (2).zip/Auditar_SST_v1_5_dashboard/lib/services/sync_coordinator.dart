import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import '../database.dart';
import 'drive_service.dart';

class SyncCoordinator extends StatefulWidget {
  final Widget child;

  const SyncCoordinator({
    super.key,
    required this.child,
  });

  @override
  State<SyncCoordinator> createState() => _SyncCoordinatorState();
}

class _SyncCoordinatorState extends State<SyncCoordinator>
    with WidgetsBindingObserver {
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  bool _syncing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _subscription = Connectivity()
        .onConnectivityChanged
        .listen(_handleConnectivity);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _trySync();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _trySync();
    }
  }

  void _handleConnectivity(List<ConnectivityResult> results) {
    final hasNetwork = results.any(
      (result) => result != ConnectivityResult.none,
    );

    if (hasNetwork) {
      _trySync();
    }
  }

  Future<void> _trySync() async {
    if (_syncing) return;

    final db = AppDatabase.instance;

    final driveEnabled = await db.getSetting(
      'drive_enabled',
      fallback: 'false',
    );

    final autoUpload = await db.getSetting(
      'drive_auto_upload',
      fallback: 'true',
    );

    if (driveEnabled != 'true' || autoUpload != 'true') {
      return;
    }

    final pending = await db.pendingDriveUploadsCount();
    if (pending == 0) return;

    _syncing = true;

    try {
      // Não abre tela de login. Usa apenas autenticação leve já autorizada.
      await DriveService.syncPending(interactive: false);
    } catch (_) {
      // Os itens continuam na fila para a próxima tentativa.
    } finally {
      _syncing = false;
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
