import 'dart:io';

import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../database.dart';
import 'pdf_service.dart';

class ReportFileService {
  static String _safe(String value) {
    return value
        .replaceAll(RegExp(r'[^A-Za-z0-9À-ÿ _-]'), '')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
  }

  static Future<String> savePdfLocally(String inspectionId) async {
    final header =
        await AppDatabase.instance.getInspectionHeader(inspectionId);

    if (header == null) {
      throw Exception('Vistoria não encontrada.');
    }

    final bytes = await PdfService.generateInspectionPdf(inspectionId);
    final base = await getApplicationDocumentsDirectory();

    final company = _safe(
      '${header['company_name'] ?? 'Empresa'}',
    );

    final folder = Directory(
      p.join(base.path, 'relatorios', company),
    );

    if (!await folder.exists()) {
      await folder.create(recursive: true);
    }

    final date = DateTime.tryParse('${header['date'] ?? ''}') ??
        DateTime.now();

    final stamp = DateFormat('yyyyMMdd_HHmm').format(date);

    final reportNumber =
        ('${header['report_number'] ?? ''}').trim();

    final fileName = reportNumber.isEmpty
        ? 'Relatorio_SST_${company}_$stamp.pdf'
        : 'Relatorio_SST_${_safe(reportNumber)}_${company}.pdf';

    final file = File(p.join(folder.path, fileName));
    await file.writeAsBytes(bytes, flush: true);

    return file.path;
  }
}
