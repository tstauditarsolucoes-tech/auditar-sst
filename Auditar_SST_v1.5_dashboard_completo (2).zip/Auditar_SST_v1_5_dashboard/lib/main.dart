import 'package:flutter/material.dart';

import 'brand.dart';
import 'screens/splash_screen.dart';
import 'services/sync_coordinator.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AuditarSstApp());
}

class AuditarSstApp extends StatelessWidget {
  const AuditarSstApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: AuditarBrand.green,
      brightness: Brightness.light,
    ).copyWith(
      primary: AuditarBrand.navy,
      onPrimary: Colors.white,
      secondary: AuditarBrand.green,
      onSecondary: Colors.white,
      error: const Color(0xFFD93025),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Auditar SST',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: AuditarBrand.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AuditarBrand.navy,
          foregroundColor: Colors.white,
          centerTitle: false,
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0.7,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFD7DCE5)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: AuditarBrand.green,
              width: 1.6,
            ),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: AuditarBrand.greenDark,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: AuditarBrand.greenDark,
          foregroundColor: Colors.white,
        ),
        navigationBarTheme: const NavigationBarThemeData(
          indicatorColor: Color(0xFFE2F5E5),
        ),
      ),
      home: const SyncCoordinator(child: SplashScreen()),
    );
  }
}
