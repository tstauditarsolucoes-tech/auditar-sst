class Company {
  final String id;
  final String name;
  final String? cnpj;
  final String? city;
  final String? uf;
  final String? contact;
  final String? phone;
  final String? logoPath;
  final bool active;

  Company({
    required this.id,
    required this.name,
    this.cnpj,
    this.city,
    this.uf,
    this.contact,
    this.phone,
    this.logoPath,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'cnpj': cnpj,
        'city': city,
        'uf': uf,
        'contact': contact,
        'phone': phone,
        'logo_path': logoPath,
        'active': active ? 1 : 0,
      };

  factory Company.fromMap(Map<String, Object?> map) => Company(
        id: map['id'] as String,
        name: map['name'] as String,
        cnpj: map['cnpj'] as String?,
        city: map['city'] as String?,
        uf: map['uf'] as String?,
        contact: map['contact'] as String?,
        phone: map['phone'] as String?,
        logoPath: map['logo_path'] as String?,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class WorkSite {
  final String id;
  final String companyId;
  final String name;
  final String type;
  final String? address;
  final bool active;

  WorkSite({
    required this.id,
    required this.companyId,
    required this.name,
    required this.type,
    this.address,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'name': name,
        'type': type,
        'address': address,
        'active': active ? 1 : 0,
      };

  factory WorkSite.fromMap(Map<String, Object?> map) => WorkSite(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        name: map['name'] as String,
        type: map['type'] as String,
        address: map['address'] as String?,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class Sector {
  final String id;
  final String companyId;
  final String name;
  final String? description;
  final bool active;

  Sector({
    required this.id,
    required this.companyId,
    required this.name,
    this.description,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'name': name,
        'description': description,
        'active': active ? 1 : 0,
      };

  factory Sector.fromMap(Map<String, Object?> map) => Sector(
        id: map['id'] as String,
        companyId: map['company_id'] as String,
        name: map['name'] as String,
        description: map['description'] as String?,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class ChecklistTemplate {
  final String id;
  final String name;
  final String category;
  final String reference;
  final bool active;

  ChecklistTemplate({
    required this.id,
    required this.name,
    required this.category,
    required this.reference,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'category': category,
        'reference': reference,
        'active': active ? 1 : 0,
      };

  factory ChecklistTemplate.fromMap(Map<String, Object?> map) =>
      ChecklistTemplate(
        id: map['id'] as String,
        name: map['name'] as String,
        category: (map['category'] as String?) ?? '',
        reference: (map['reference'] as String?) ?? '',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class ChecklistItem {
  final String id;
  final String templateId;
  final int sortOrder;
  final String category;
  final String text;
  final String reference;
  final String priority;
  final bool active;

  ChecklistItem({
    required this.id,
    required this.templateId,
    required this.sortOrder,
    required this.category,
    required this.text,
    required this.reference,
    required this.priority,
    this.active = true,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'template_id': templateId,
        'sort_order': sortOrder,
        'category': category,
        'text': text,
        'reference': reference,
        'priority': priority,
        'active': active ? 1 : 0,
      };

  factory ChecklistItem.fromMap(Map<String, Object?> map) => ChecklistItem(
        id: map['id'] as String,
        templateId: map['template_id'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
        category: (map['category'] as String?) ?? '',
        text: map['text'] as String,
        reference: (map['reference'] as String?) ?? '',
        priority: (map['priority'] as String?) ?? 'Média',
        active: (map['active'] as int? ?? 1) == 1,
      );
}

class Inspection {
  final String id;
  final String companyId;
  final String? workSiteId;
  final String? sectorId;
  final String area;
  final String checklistType;
  final String checklistTemplateId;
  final DateTime date;
  final String status;
  final String technicianName;
  final String responsibleName;
  final String? technicianSignaturePath;
  final String? responsibleSignaturePath;
  final String generalNotes;
  final String conclusion;
  final String reportNumber;

  Inspection({
    required this.id,
    required this.companyId,
    this.workSiteId,
    this.sectorId,
    required this.area,
    required this.checklistType,
    required this.checklistTemplateId,
    required this.date,
    this.status = 'Em andamento',
    this.technicianName = '',
    this.responsibleName = '',
    this.technicianSignaturePath,
    this.responsibleSignaturePath,
    this.generalNotes = '',
    this.conclusion = '',
    required this.reportNumber,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'company_id': companyId,
        'worksite_id': workSiteId,
        'sector_id': sectorId,
        'area': area,
        'checklist_type': checklistType,
        'checklist_template_id': checklistTemplateId,
        'date': date.toIso8601String(),
        'status': status,
        'technician_name': technicianName,
        'responsible_name': responsibleName,
        'technician_signature_path': technicianSignaturePath,
        'responsible_signature_path': responsibleSignaturePath,
        'general_notes': generalNotes,
        'conclusion': conclusion,
        'report_number': reportNumber,
      };
}

class InspectionAnswer {
  final String id;
  final String inspectionId;
  final String questionId;
  final String questionText;
  final String questionCategory;
  final String questionReference;
  final String status;
  final String observation;
  final String riskIdentified;
  final String recommendation;

  InspectionAnswer({
    required this.id,
    required this.inspectionId,
    required this.questionId,
    required this.questionText,
    required this.questionCategory,
    required this.questionReference,
    required this.status,
    required this.observation,
    required this.riskIdentified,
    required this.recommendation,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'question_id': questionId,
        'question_text': questionText,
        'question_category': questionCategory,
        'question_reference': questionReference,
        'status': status,
        'observation': observation,
        'risk_identified': riskIdentified,
        'recommendation': recommendation,
      };

  factory InspectionAnswer.fromMap(Map<String, Object?> map) => InspectionAnswer(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        questionId: map['question_id'] as String,
        questionText: (map['question_text'] as String?) ?? '',
        questionCategory: (map['question_category'] as String?) ?? '',
        questionReference: (map['question_reference'] as String?) ?? '',
        status: map['status'] as String,
        observation: (map['observation'] as String?) ?? '',
        riskIdentified: (map['risk_identified'] as String?) ?? '',
        recommendation: (map['recommendation'] as String?) ?? '',
      );
}

class EvidencePhoto {
  final String id;
  final String answerId;
  final String path;
  final int sortOrder;

  EvidencePhoto({
    required this.id,
    required this.answerId,
    required this.path,
    required this.sortOrder,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'answer_id': answerId,
        'path': path,
        'sort_order': sortOrder,
      };

  factory EvidencePhoto.fromMap(Map<String, Object?> map) => EvidencePhoto(
        id: map['id'] as String,
        answerId: map['answer_id'] as String,
        path: map['path'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
      );
}


class NonConformity {
  final String id;
  final String inspectionId;
  final String answerId;
  final String code;
  final String description;
  final String riskIdentified;
  final String recommendation;
  final String classification;
  final String status;
  final DateTime createdAt;

  NonConformity({
    required this.id,
    required this.inspectionId,
    required this.answerId,
    required this.code,
    required this.description,
    required this.riskIdentified,
    required this.recommendation,
    this.classification = 'Média',
    this.status = 'Aberta',
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'answer_id': answerId,
        'code': code,
        'description': description,
        'risk_identified': riskIdentified,
        'recommendation': recommendation,
        'classification': classification,
        'status': status,
        'created_at': createdAt.toIso8601String(),
      };

  factory NonConformity.fromMap(Map<String, Object?> map) => NonConformity(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        answerId: map['answer_id'] as String,
        code: (map['code'] as String?) ?? '',
        description: (map['description'] as String?) ?? '',
        riskIdentified: (map['risk_identified'] as String?) ?? '',
        recommendation: (map['recommendation'] as String?) ?? '',
        classification: (map['classification'] as String?) ?? 'Média',
        status: (map['status'] as String?) ?? 'Aberta',
        createdAt: DateTime.tryParse('${map['created_at'] ?? ''}') ?? DateTime.now(),
      );
}

class ActionPlan {
  final String id;
  final String inspectionId;
  final String answerId;
  final String? ncId;
  final String nonConformity;
  final String correctiveAction;
  final String responsible;
  final String priority;
  final DateTime? dueDate;
  final String status;
  final DateTime? completionDate;
  final String completionNote;
  final String completedBy;

  ActionPlan({
    required this.id,
    required this.inspectionId,
    required this.answerId,
    this.ncId,
    required this.nonConformity,
    required this.correctiveAction,
    required this.responsible,
    required this.priority,
    this.dueDate,
    this.status = 'Pendente',
    this.completionDate,
    this.completionNote = '',
    this.completedBy = '',
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'inspection_id': inspectionId,
        'answer_id': answerId,
        'nc_id': ncId,
        'non_conformity': nonConformity,
        'corrective_action': correctiveAction,
        'responsible': responsible,
        'priority': priority,
        'due_date': dueDate?.toIso8601String(),
        'status': status,
        'completion_date': completionDate?.toIso8601String(),
        'completion_note': completionNote,
        'completed_by': completedBy,
      };

  factory ActionPlan.fromMap(Map<String, Object?> map) => ActionPlan(
        id: map['id'] as String,
        inspectionId: map['inspection_id'] as String,
        answerId: map['answer_id'] as String,
        ncId: map['nc_id'] as String?,
        nonConformity: map['non_conformity'] as String,
        correctiveAction: map['corrective_action'] as String,
        responsible: (map['responsible'] as String?) ?? '',
        priority: map['priority'] as String,
        dueDate: map['due_date'] == null
            ? null
            : DateTime.tryParse(map['due_date'] as String),
        status: map['status'] as String,
        completionDate: map['completion_date'] == null
            ? null
            : DateTime.tryParse(map['completion_date'] as String),
        completionNote: (map['completion_note'] as String?) ?? '',
        completedBy: (map['completed_by'] as String?) ?? '',
      );
}

class CompletionPhoto {
  final String id;
  final String actionId;
  final String path;
  final int sortOrder;

  CompletionPhoto({
    required this.id,
    required this.actionId,
    required this.path,
    required this.sortOrder,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'action_id': actionId,
        'path': path,
        'sort_order': sortOrder,
      };

  factory CompletionPhoto.fromMap(Map<String, Object?> map) => CompletionPhoto(
        id: map['id'] as String,
        actionId: map['action_id'] as String,
        path: map['path'] as String,
        sortOrder: (map['sort_order'] as int?) ?? 0,
      );
}
