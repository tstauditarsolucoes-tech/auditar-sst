import 'dart:io';

import 'package:flutter/material.dart';

import '../database.dart';
import '../models.dart';
import 'sectors_screen.dart';
import 'non_conformities_screen.dart';
import 'worksites_screen.dart';

class CompanyDetailScreen extends StatefulWidget {
  final Company company;

  const CompanyDetailScreen({
    super.key,
    required this.company,
  });

  @override
  State<CompanyDetailScreen> createState() => _CompanyDetailScreenState();
}

class _CompanyDetailScreenState extends State<CompanyDetailScreen> {
  Map<String, int> summary = {};
  List<Map<String, Object?>> sectorPerformance = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);

    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);

    final result = await AppDatabase.instance.getDashboardSummary(
      companyId: widget.company.id,
      startDate: monthStart,
      endDate: now,
    );
    final sectors = await AppDatabase.instance.getCompanySectorPerformance(
      widget.company.id,
    );

    if (!mounted) return;
    setState(() {
      summary = result;
      sectorPerformance = sectors;
      loading = false;
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _load();
  }

  Widget _companyLogo() {
    final path = widget.company.logoPath;
    if (path != null && path.isNotEmpty && File(path).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.file(
          File(path),
          width: 64,
          height: 64,
          fit: BoxFit.contain,
        ),
      );
    }

    return const CircleAvatar(
      radius: 32,
      child: Icon(Icons.business, size: 32),
    );
  }

  int _intValue(Map<String, Object?> row, String key) {
    final value = row[key];
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final conformity = summary['conformity'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.company.name),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    _companyLogo(),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.company.name,
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 4),
                          if ((widget.company.cnpj ?? '').isNotEmpty)
                            Text('CNPJ: ${widget.company.cnpj}'),
                          if ((widget.company.city ?? '').isNotEmpty)
                            Text(
                              '${widget.company.city}${(widget.company.uf ?? '').isNotEmpty ? ' - ${widget.company.uf}' : ''}',
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Organização da empresa',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _shortcut(
                    icon: Icons.account_tree_outlined,
                    title: 'Setores',
                    subtitle: 'Cadastrar e organizar',
                    onTap: () => _open(
                      SectorsScreen(company: widget.company),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _shortcut(
                    icon: Icons.location_on_outlined,
                    title: 'Obras / Unidades',
                    subtitle: 'Locais da empresa',
                    onTap: () => _open(
                      WorkSitesScreen(company: widget.company),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              'Painel da empresa',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (loading)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: CircularProgressIndicator()),
                ),
              )
            else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Conformidade neste mês'),
                                const SizedBox(height: 4),
                                Text(
                                  '$conformity%',
                                  style: Theme.of(context)
                                      .textTheme
                                      .displaySmall
                                      ?.copyWith(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 66,
                            height: 66,
                            child: CircularProgressIndicator(
                              value: conformity / 100,
                              strokeWidth: 8,
                              backgroundColor: Theme.of(context)
                                  .colorScheme
                                  .surfaceContainerHighest,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: _metric(
                              'Vistorias',
                              summary['inspections'] ?? 0,
                            ),
                          ),
                          Expanded(
                            child: _metric(
                              'Pendências',
                              summary['pending'] ?? 0,
                            ),
                          ),
                          Expanded(
                            child: _metric(
                              'Vencidas',
                              summary['overdue'] ?? 0,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.warning_amber_rounded),
                  title: const Text('Não conformidades'),
                  subtitle: const Text('Registros e planos de ação desta empresa'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _open(
                    NonConformitiesScreen(companyId: widget.company.id),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              _sectorPerformanceCard(),
              const SizedBox(height: 8),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.link_outlined),
                  title: const Text('Link gerencial da empresa'),
                  subtitle: const Text(
                    'Na próxima etapa, este painel poderá ser enviado para o Google Sheets/Drive e compartilhado somente para visualização.',
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _shortcut({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 30),
              const SizedBox(height: 10),
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _metric(String label, int value) {
    return Column(
      children: [
        Text(
          '$value',
          style: Theme.of(context)
              .textTheme
              .titleLarge
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        Text(
          label,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _sectorPerformanceCard() {
    if (sectorPerformance.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              const Icon(Icons.account_tree_outlined, size: 38),
              const SizedBox(height: 8),
              const Text(
                'Cadastre os setores para começar a acompanhar a evolução de segurança separadamente.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => _open(
                  SectorsScreen(company: widget.company),
                ),
                icon: const Icon(Icons.add),
                label: const Text('Cadastrar setores'),
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Conformidade por setor',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              'Histórico das vistorias vinculadas a cada setor',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 14),
            for (var i = 0; i < sectorPerformance.length; i++) ...[
              _sectorRow(sectorPerformance[i]),
              if (i != sectorPerformance.length - 1)
                const SizedBox(height: 14),
            ],
          ],
        ),
      ),
    );
  }

  Widget _sectorRow(Map<String, Object?> row) {
    final conformes = _intValue(row, 'conformes');
    final naoConformes = _intValue(row, 'nao_conformes');
    final parciais = _intValue(row, 'parciais');
    final inspections = _intValue(row, 'inspections');
    final considered = conformes + parciais + naoConformes;
    final percentage =
        considered == 0 ? 0 : ((conformes / considered) * 100).round();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '${row['name'] ?? 'Setor'}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            Text(
              considered == 0 ? 'Sem dados' : '$percentage%',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: considered == 0 ? 0 : percentage / 100,
          minHeight: 8,
          borderRadius: BorderRadius.circular(8),
        ),
        const SizedBox(height: 4),
        Text(
          '$inspections vistoria(s) • $naoConformes NC • $parciais parcial(is)',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}
