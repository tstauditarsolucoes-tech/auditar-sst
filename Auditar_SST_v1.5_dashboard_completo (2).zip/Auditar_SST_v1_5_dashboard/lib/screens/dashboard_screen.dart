import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../database.dart';
import '../models.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() =>
      _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Company> companies = [];
  List<WorkSite> workSites = [];
  List<Sector> sectors = [];

  String? selectedCompanyId;
  String? selectedWorkSiteId;
  String? selectedSectorId;
  String selectedPeriod = 'Este mês';
  String selectedPriority = 'Todas';

  DateTime? customStart;
  DateTime? customEnd;

  Map<String, int> summary = {};
  bool loading = true;

  static const periods = <String>[
    'Todos',
    'Hoje',
    'Últimos 7 dias',
    'Este mês',
    'Últimos 30 dias',
    'Personalizado',
  ];

  static const priorities = <String>[
    'Todas',
    'Baixa',
    'Média',
    'Alta',
    'Crítica',
  ];

  @override
  void initState() {
    super.initState();
    _loadInitial();
  }

  Future<void> _loadInitial() async {
    final loadedCompanies =
        await AppDatabase.instance.getCompanies();

    if (!mounted) return;

    setState(() {
      companies = loadedCompanies;
    });

    await _refreshSummary();
  }

  DateTime? get _startDate {
    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    switch (selectedPeriod) {
      case 'Hoje':
        return today;
      case 'Últimos 7 dias':
        return today.subtract(
          const Duration(days: 6),
        );
      case 'Este mês':
        return DateTime(
          now.year,
          now.month,
          1,
        );
      case 'Últimos 30 dias':
        return today.subtract(
          const Duration(days: 29),
        );
      case 'Personalizado':
        return customStart;
      default:
        return null;
    }
  }

  DateTime? get _endDate {
    final now = DateTime.now();
    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    switch (selectedPeriod) {
      case 'Hoje':
      case 'Últimos 7 dias':
      case 'Este mês':
      case 'Últimos 30 dias':
        return today;
      case 'Personalizado':
        return customEnd;
      default:
        return null;
    }
  }

  Future<void> _refreshSummary() async {
    if (mounted) {
      setState(() => loading = true);
    }

    final result =
        await AppDatabase.instance.getDashboardSummary(
      companyId: selectedCompanyId,
      workSiteId: selectedWorkSiteId,
      sectorId: selectedSectorId,
      startDate: _startDate,
      endDate: _endDate,
      priority: selectedPriority,
    );

    if (!mounted) return;

    setState(() {
      summary = result;
      loading = false;
    });
  }

  Future<void> _changeCompany(
    String? companyId,
  ) async {
    setState(() {
      selectedCompanyId = companyId;
      selectedWorkSiteId = null;
      selectedSectorId = null;
      workSites = [];
      sectors = [];
    });

    if (companyId != null) {
      final loadedSites =
          await AppDatabase.instance.getWorkSites(
        companyId,
      );
      final loadedSectors =
          await AppDatabase.instance.getSectors(
        companyId,
      );

      if (!mounted) return;

      setState(() {
        workSites = loadedSites;
        sectors = loadedSectors;
      });
    }

    await _refreshSummary();
  }

  Future<void> _changePeriod(
    String? period,
  ) async {
    if (period == null) return;

    if (period == 'Personalizado') {
      final now = DateTime.now();

      final picked =
          await showDateRangePicker(
        context: context,
        firstDate: DateTime(now.year - 5),
        lastDate: DateTime(now.year + 2),
        initialDateRange:
            customStart != null &&
                    customEnd != null
                ? DateTimeRange(
                    start: customStart!,
                    end: customEnd!,
                  )
                : DateTimeRange(
                    start: DateTime(
                      now.year,
                      now.month,
                      1,
                    ),
                    end: now,
                  ),
        helpText: 'Escolha o período',
        saveText: 'APLICAR',
      );

      if (picked == null) return;

      setState(() {
        selectedPeriod = period;
        customStart = picked.start;
        customEnd = picked.end;
      });
    } else {
      setState(() {
        selectedPeriod = period;
      });
    }

    await _refreshSummary();
  }

  Future<void> _clearFilters() async {
    setState(() {
      selectedCompanyId = null;
      selectedWorkSiteId = null;
      selectedSectorId = null;
      workSites = [];
      sectors = [];
      selectedPeriod = 'Este mês';
      selectedPriority = 'Todas';
      customStart = null;
      customEnd = null;
    });

    await _refreshSummary();
  }

  String get _periodDetail {
    if (selectedPeriod == 'Personalizado' &&
        customStart != null &&
        customEnd != null) {
      return '${DateFormat('dd/MM/yyyy').format(customStart!)} '
          'a ${DateFormat('dd/MM/yyyy').format(customEnd!)}';
    }

    return selectedPeriod;
  }

  String get _companyLabel {
    if (selectedCompanyId == null) {
      return 'Todas as empresas';
    }

    for (final company in companies) {
      if (company.id == selectedCompanyId) {
        return company.name;
      }
    }

    return 'Empresa selecionada';
  }

  String get _workSiteLabel {
    if (selectedWorkSiteId == null) {
      return 'Todas as obras/unidades';
    }

    for (final site in workSites) {
      if (site.id == selectedWorkSiteId) {
        return site.name;
      }
    }

    return 'Local selecionado';
  }

  String get _sectorLabel {
    if (selectedSectorId == null) {
      return 'Todos os setores';
    }

    for (final sector in sectors) {
      if (sector.id == selectedSectorId) {
        return sector.name;
      }
    }

    return 'Setor selecionado';
  }

  @override
  Widget build(BuildContext context) {
    final conformity =
        summary['conformity'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Indicadores'),
        actions: [
          IconButton(
            tooltip: 'Limpar filtros',
            onPressed: _clearFilters,
            icon: const Icon(
              Icons.filter_alt_off_outlined,
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshSummary,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _filtersCard(),
            const SizedBox(height: 10),
            _activeFiltersCard(),
            const SizedBox(height: 10),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 50,
                ),
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            else ...[
              _conformityCard(conformity),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 1.85,
                shrinkWrap: true,
                physics:
                    const NeverScrollableScrollPhysics(),
                children: [
                  _metricCard(
                    'Vistorias',
                    summary['inspections'] ?? 0,
                    Icons.fact_check_outlined,
                  ),
                  _metricCard(
                    'Pendências',
                    summary['pending'] ?? 0,
                    Icons.assignment_late_outlined,
                  ),
                  _metricCard(
                    'Vencidas',
                    summary['overdue'] ?? 0,
                    Icons.warning_amber_rounded,
                  ),
                  _metricCard(
                    'Concluídas',
                    summary['completed'] ?? 0,
                    Icons.task_alt,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _prioritySection(),
              const SizedBox(height: 12),
              _detailsCard(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _filtersCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.filter_alt_outlined,
                ),
                const SizedBox(width: 8),
                Text(
                  'FILTROS',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(
                        fontWeight:
                            FontWeight.bold,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              value: selectedCompanyId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Empresa',
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text(
                    'Todas as empresas',
                  ),
                ),
                ...companies.map(
                  (company) =>
                      DropdownMenuItem<String?>(
                    value: company.id,
                    child: Text(company.name),
                  ),
                ),
              ],
              onChanged: _changeCompany,
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedWorkSiteId,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: 'Obra / Unidade',
                helperText:
                    selectedCompanyId == null
                        ? 'Selecione uma empresa para filtrar por obra.'
                        : null,
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text(
                    'Todas as obras/unidades',
                  ),
                ),
                ...workSites.map(
                  (site) =>
                      DropdownMenuItem<String?>(
                    value: site.id,
                    child: Text(site.name),
                  ),
                ),
              ],
              onChanged:
                  selectedCompanyId == null
                      ? null
                      : (value) async {
                          setState(() {
                            selectedWorkSiteId =
                                value;
                          });
                          await _refreshSummary();
                        },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedSectorId,
              isExpanded: true,
              decoration: InputDecoration(
                labelText: 'Setor',
                helperText:
                    selectedCompanyId == null
                        ? 'Selecione uma empresa para filtrar por setor.'
                        : null,
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Todos os setores'),
                ),
                ...sectors.map(
                  (sector) => DropdownMenuItem<String?>(
                    value: sector.id,
                    child: Text(sector.name),
                  ),
                ),
              ],
              onChanged: selectedCompanyId == null
                  ? null
                  : (value) async {
                      setState(() {
                        selectedSectorId = value;
                      });
                      await _refreshSummary();
                    },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedPeriod,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Período',
              ),
              items: periods
                  .map(
                    (period) =>
                        DropdownMenuItem(
                      value: period,
                      child: Text(period),
                    ),
                  )
                  .toList(),
              onChanged: _changePeriod,
            ),
            if (selectedPeriod ==
                    'Personalizado' &&
                customStart != null &&
                customEnd != null) ...[
              const SizedBox(height: 6),
              TextButton.icon(
                onPressed: () =>
                    _changePeriod(
                      'Personalizado',
                    ),
                icon: const Icon(
                  Icons.date_range_outlined,
                ),
                label: Text(_periodDetail),
              ),
            ],
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedPriority,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText:
                    'Prioridade do plano de ação',
                helperText:
                    'A prioridade filtra pendências, vencidas e concluídas.',
              ),
              items: priorities
                  .map(
                    (priority) =>
                        DropdownMenuItem(
                      value: priority,
                      child: Text(priority),
                    ),
                  )
                  .toList(),
              onChanged: (value) async {
                if (value == null) return;

                setState(() {
                  selectedPriority = value;
                });

                await _refreshSummary();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _activeFiltersCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'VISUALIZANDO',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 5),
            Text(_companyLabel),
            Text(_workSiteLabel),
            Text(_sectorLabel),
            Text('Período: $_periodDetail'),
            Text(
              'Prioridade: $selectedPriority',
            ),
          ],
        ),
      ),
    );
  }

  Widget _conformityCard(
    int conformity,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'CONFORMIDADE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment:
                  CrossAxisAlignment.end,
              children: [
                Text(
                  '$conformity%',
                  style: Theme.of(context)
                      .textTheme
                      .displaySmall
                      ?.copyWith(
                        fontWeight:
                            FontWeight.bold,
                      ),
                ),
                const SizedBox(width: 10),
                const Padding(
                  padding:
                      EdgeInsets.only(bottom: 5),
                  child: Text(
                    'dos itens avaliados',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: conformity / 100,
              minHeight: 10,
              borderRadius:
                  BorderRadius.circular(8),
            ),
            const SizedBox(height: 8),
            Text(
              '${summary['conformes'] ?? 0} conformes • '
              '${summary['naoConformes'] ?? 0} não conformes • '
              '${summary['parciais'] ?? 0} parciais • '
              '${summary['naoAplicaveis'] ?? 0} N/A',
            ),
          ],
        ),
      ),
    );
  }

  Widget _metricCard(
    String title,
    int value,
    IconData icon,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, size: 28),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  Text(
                    '$value',
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                  Text(
                    title,
                    maxLines: 1,
                    overflow:
                        TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _prioritySection() {
    final critical =
        summary['critical'] ?? 0;
    final high = summary['high'] ?? 0;
    final medium =
        summary['medium'] ?? 0;
    final low = summary['low'] ?? 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Text(
              'NÃO CONFORMIDADES POR PRIORIDADE',
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(
                    fontWeight:
                        FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Distribuição dos planos de ação no período selecionado.',
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _priorityBox(
                    'Crítica',
                    critical,
                    Icons.error_outline,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _priorityBox(
                    'Alta',
                    high,
                    Icons.priority_high,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Row(
              children: [
                Expanded(
                  child: _priorityBox(
                    'Média',
                    medium,
                    Icons.remove_circle_outline,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _priorityBox(
                    'Baixa',
                    low,
                    Icons.keyboard_arrow_down,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _priorityBox(
    String label,
    int value,
    IconData icon,
  ) {
    return Container(
      constraints:
          const BoxConstraints(minHeight: 66),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context)
              .colorScheme
              .outlineVariant,
        ),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 22),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  '$value',
                  style: const TextStyle(
                    fontWeight:
                        FontWeight.bold,
                    fontSize: 19,
                  ),
                ),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'ACOMPANHAMENTO',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            _detailRow(
              'Em andamento',
              summary['inProgress'] ?? 0,
              Icons.timelapse,
            ),
            const Divider(),
            _detailRow(
              'Pendentes',
              summary['pending'] ?? 0,
              Icons.pending_actions,
            ),
            const Divider(),
            _detailRow(
              'Vencidas',
              summary['overdue'] ?? 0,
              Icons.event_busy_outlined,
            ),
            const Divider(),
            _detailRow(
              'Concluídas',
              summary['completed'] ?? 0,
              Icons.task_alt,
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(
    String label,
    int value,
    IconData icon,
  ) {
    return Row(
      children: [
        Icon(icon, size: 21),
        const SizedBox(width: 9),
        Expanded(child: Text(label)),
        Text(
          '$value',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
