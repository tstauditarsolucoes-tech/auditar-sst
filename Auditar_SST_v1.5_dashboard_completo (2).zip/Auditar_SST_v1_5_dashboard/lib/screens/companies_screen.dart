import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import '../services/storage_service.dart';
import 'company_detail_screen.dart';
import 'sectors_screen.dart';
import 'worksites_screen.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  final ImagePicker picker = ImagePicker();
  List<Company> companies = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getCompanies(
      onlyActive: false,
    );

    if (mounted) {
      setState(() => companies = result);
    }
  }

  Future<void> _editCompany([Company? company]) async {
    final name = TextEditingController(text: company?.name ?? '');
    final cnpj = TextEditingController(text: company?.cnpj ?? '');
    final city = TextEditingController(text: company?.city ?? '');
    final uf = TextEditingController(text: company?.uf ?? 'PI');
    final contact = TextEditingController(text: company?.contact ?? '');
    final phone = TextEditingController(text: company?.phone ?? '');
    bool active = company?.active ?? true;

    final save = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(
            company == null ? 'Nova empresa' : 'Editar empresa',
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText: 'Nome da empresa *',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: cnpj,
                  decoration: const InputDecoration(
                    labelText: 'CNPJ',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: city,
                  decoration: const InputDecoration(
                    labelText: 'Cidade',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: uf,
                  decoration: const InputDecoration(
                    labelText: 'UF',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: contact,
                  decoration: const InputDecoration(
                    labelText: 'Contato / responsável',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: phone,
                  decoration: const InputDecoration(
                    labelText: 'Telefone',
                  ),
                ),
                if (company != null) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Empresa ativa'),
                    subtitle: const Text(
                      'Empresas desativadas não aparecem em novas vistorias.',
                    ),
                    value: active,
                    onChanged: (value) {
                      setDialogState(() => active = value);
                    },
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );

    if (save != true || name.text.trim().isEmpty) return;

    final updated = Company(
      id: company?.id ?? const Uuid().v4(),
      name: name.text.trim(),
      cnpj: cnpj.text.trim(),
      city: city.text.trim(),
      uf: uf.text.trim().toUpperCase(),
      contact: contact.text.trim(),
      phone: phone.text.trim(),
      logoPath: company?.logoPath,
      active: active,
    );

    if (company == null) {
      await AppDatabase.instance.insertCompany(updated);
    } else {
      await AppDatabase.instance.updateCompany(updated);
    }

    await _load();
  }

  Future<void> _chooseLogo(Company company) async {
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
      maxWidth: 1600,
    );

    if (image == null) return;

    final storedPath = await StorageService.persistImage(
      image.path,
      folder: 'logos_empresas',
    );

    await AppDatabase.instance.updateCompanyLogo(
      company.id,
      storedPath,
    );

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Logo salva. Ela será usada automaticamente nos relatórios desta empresa.',
        ),
      ),
    );
  }

  Future<void> _removeLogo(Company company) async {
    await AppDatabase.instance.updateCompanyLogo(
      company.id,
      null,
    );
    await _load();
  }

  Future<void> _deleteCompany(Company company) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir empresa?'),
        content: Text(
          'Deseja excluir “${company.name}”? '
          'Se ela já tiver vistorias registradas, o aplicativo impedirá a exclusão para preservar o histórico.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final deleted =
        await AppDatabase.instance.deleteCompanyIfUnused(
      company.id,
    );

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          deleted
              ? 'Empresa excluída.'
              : 'A empresa possui vistorias. Desative-a em vez de excluir.',
        ),
      ),
    );
  }

  Widget _logo(Company company) {
    final path = company.logoPath;

    if (path != null &&
        path.isNotEmpty &&
        File(path).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.file(
          File(path),
          width: 52,
          height: 52,
          fit: BoxFit.contain,
        ),
      );
    }

    return const CircleAvatar(
      child: Icon(Icons.business),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Empresas')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editCompany(),
        icon: const Icon(Icons.add_business),
        label: const Text('Empresa'),
      ),
      body: companies.isEmpty
          ? const Center(
              child: Text(
                'Nenhuma empresa cadastrada.',
                textAlign: TextAlign.center,
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: companies.length,
              separatorBuilder: (_, __) =>
                  const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final company = companies[i];

                final location = [
                  company.city,
                  company.uf,
                ]
                    .where(
                      (value) =>
                          value != null &&
                          value!.trim().isNotEmpty,
                    )
                    .join(' - ');

                final status =
                    company.active ? 'Ativa' : 'Desativada';

                return Card(
                  child: ListTile(
                    leading: _logo(company),
                    title: Text(company.name),
                    subtitle: Text(
                      [
                        if (location.isNotEmpty) location,
                        status,
                        company.logoPath == null
                            ? 'Logo opcional não cadastrada'
                            : 'Logo cadastrada',
                      ].join(' • '),
                    ),
                    onTap: () => Navigator.of(context)
                        .push(
                          MaterialPageRoute(
                            builder: (_) => CompanyDetailScreen(
                              company: company,
                            ),
                          ),
                        )
                        .then((_) => _load()),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') {
                          _editCompany(company);
                        } else if (value == 'logo') {
                          _chooseLogo(company);
                        } else if (value == 'remove_logo') {
                          _removeLogo(company);
                        } else if (value == 'sectors') {
                          Navigator.of(context)
                              .push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      SectorsScreen(
                                    company: company,
                                  ),
                                ),
                              )
                              .then((_) => _load());
                        } else if (value == 'locations') {
                          Navigator.of(context)
                              .push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      WorkSitesScreen(
                                    company: company,
                                  ),
                                ),
                              )
                              .then((_) => _load());
                        } else if (value == 'delete') {
                          _deleteCompany(company);
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(
                          value: 'edit',
                          child: Text('Editar empresa'),
                        ),
                        const PopupMenuItem(
                          value: 'logo',
                          child: Text(
                            'Cadastrar / trocar logo',
                          ),
                        ),
                        if (company.logoPath != null)
                          const PopupMenuItem(
                            value: 'remove_logo',
                            child: Text('Remover logo'),
                          ),
                        const PopupMenuItem(
                          value: 'sectors',
                          child: Text('Setores'),
                        ),
                        const PopupMenuItem(
                          value: 'locations',
                          child: Text('Obras / unidades'),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text('Excluir'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
