import 'dart:async';

import 'package:flutter/material.dart';

import '../brand.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    Timer(const Duration(milliseconds: 1050), () {
      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => const HomeScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ClipOval(
                child: Image.asset(
                  AuditarBrand.iconAsset,
                  width: 112,
                  height: 112,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Auditar SST',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  color: AuditarBrand.greenDark,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'MEDICINA OCUPACIONAL E\nSEGURANÇA DO TRABALHO',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AuditarBrand.navy,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: 24),
              const CircularProgressIndicator(
                color: AuditarBrand.greenDark,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
