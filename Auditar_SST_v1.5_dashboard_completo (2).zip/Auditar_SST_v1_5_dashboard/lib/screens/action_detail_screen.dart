import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../database.dart';
import '../models.dart';
import '../services/storage_service.dart';

class ActionDetailScreen extends StatefulWidget {
  final String actionId;

  const ActionDetailScreen({
    super.key,
    required this.actionId,
  });

  @override
  State<ActionDetailScreen> createState() =>
      _ActionDetailScreenState();
}

class _ActionDetailScreenState
    extends State<ActionDetailScreen> {
  final ImagePicker picker = ImagePicker();

  ActionPlan? action;
  List<EvidencePhoto> beforePhotos = [];
  List<CompletionPhoto> savedAfterPhotos = [];
  List<String> newAfterPhotos = [];

  final correctiveAction = TextEditingController();
  final responsible = TextEditingController();
  final completionNote = TextEditingController();
  final completedBy = TextEditingController();

  String priority = 'Média';
  String status = 'Pendente';
  DateTime? dueDate;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    correctiveAction.dispose();
    responsible.dispose();
    completionNote.dispose();
    completedBy.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final loadedAction =
        await db.getAction(widget.actionId);

    if (loadedAction == null) {
      if (mounted) {
        Navigator.of(context).pop();
      }
      return;
    }

    final before =
        await db.getOriginalPhotosForAction(widget.actionId);
    final after =
        await db.getCompletionPhotos(widget.actionId);

    if (!mounted) return;

    setState(() {
      action = loadedAction;
      beforePhotos = before;
      savedAfterPhotos = after;

      correctiveAction.text =
          loadedAction.correctiveAction;
      responsible.text = loadedAction.responsible;
      completionNote.text =
          loadedAction.completionNote;
      completedBy.text = loadedAction.completedBy;

      priority = loadedAction.priority;
      status = loadedAction.status;
      dueDate = loadedAction.dueDate;
      loading = false;
    });
  }

  Future<void> _takeAfterPhoto() async {
    final image = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 80,
      maxWidth: 1800,
    );

    if (image == null) return;

    final path = await StorageService.persistImage(
      image.path,
      folder: 'fotos_conclusao',
    );

    if (mounted) {
      setState(() => newAfterPhotos.add(path));
    }
  }

  Future<void> _pickAfterPhotos() async {
    final images = await picker.pickMultiImage(
      imageQuality: 80,
      maxWidth: 1800,
    );

    if (images.isEmpty) return;

    final currentCount =
        savedAfterPhotos.length + newAfterPhotos.length;
    final remaining = 10 - currentCount;

    if (remaining <= 0) return;

    final paths = <String>[];

    for (final image in images.take(remaining)) {
      paths.add(
        await StorageService.persistImage(
          image.path,
          folder: 'fotos_conclusao',
        ),
      );
    }

    if (mounted) {
      setState(() => newAfterPhotos.addAll(paths));
    }
  }

  Future<void> _chooseDueDate() async {
    final now = DateTime.now();

    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 5),
      initialDate: dueDate ?? now,
    );

    if (selected != null && mounted) {
      setState(() => dueDate = selected);
    }
  }

  Future<void> _saveBasic() async {
    final current = action;
    if (current == null) return;

    final updated = ActionPlan(
      id: current.id,
      inspectionId: current.inspectionId,
      answerId: current.answerId,
      ncId: current.ncId,
      nonConformity: current.nonConformity,
      correctiveAction:
          correctiveAction.text.trim().isEmpty
              ? current.correctiveAction
              : correctiveAction.text.trim(),
      responsible: responsible.text.trim(),
      priority: priority,
      dueDate: dueDate,
      status: status,
      completionDate: current.completionDate,
      completionNote: completionNote.text.trim(),
      completedBy: completedBy.text.trim(),
    );

    await AppDatabase.instance.updateAction(updated);
    if (updated.ncId != null) {
      await AppDatabase.instance.syncNonConformityStatus(updated.ncId!);
    }

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Plano de ação atualizado.'),
      ),
    );

    await _load();
  }

  Future<void> _saveNewAfterPhotos() async {
    final current = action;
    if (current == null || newAfterPhotos.isEmpty) {
      return;
    }

    final start = savedAfterPhotos.length;

    for (var i = 0; i < newAfterPhotos.length; i++) {
      await AppDatabase.instance.insertCompletionPhoto(
        CompletionPhoto(
          id: const Uuid().v4(),
          actionId: current.id,
          path: newAfterPhotos[i],
          sortOrder: start + i,
        ),
      );
    }

    newAfterPhotos.clear();
  }

  Future<void> _conclude() async {
    if (completedBy.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Informe quem confirmou a correção.',
          ),
        ),
      );
      return;
    }

    await _saveBasic();
    await _saveNewAfterPhotos();

    await AppDatabase.instance.concludeAction(
      actionId: widget.actionId,
      completedBy: completedBy.text.trim(),
      completionNote: completionNote.text.trim(),
    );

    if (action?.ncId != null) {
      await AppDatabase.instance.syncNonConformityStatus(action!.ncId!);
    }

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Ação concluída. As fotos de correção ficarão no relatório como “Depois”.',
        ),
      ),
    );
  }

  Future<void> _reopen() async {
    await AppDatabase.instance.reopenAction(
      widget.actionId,
    );

    if (action?.ncId != null) {
      await AppDatabase.instance.syncNonConformityStatus(action!.ncId!);
    }

    await _load();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Ação reaberta.'),
      ),
    );
  }

  Widget _photos(
    String title,
    List<String> paths,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        if (paths.isEmpty)
          const Text('Nenhuma foto.')
        else
          SizedBox(
            height: 128,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: paths.length,
              separatorBuilder: (_, __) =>
                  const SizedBox(width: 8),
              itemBuilder: (_, index) {
                final file = File(paths[index]);

                return ClipRRect(
                  borderRadius:
                      BorderRadius.circular(10),
                  child: file.existsSync()
                      ? Image.file(
                          file,
                          width: 128,
                          height: 128,
                          fit: BoxFit.cover,
                        )
                      : Container(
                          width: 128,
                          height: 128,
                          alignment: Alignment.center,
                          child: const Text(
                            'Foto indisponível',
                          ),
                        ),
                );
              },
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading || action == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final current = action!;

    final beforePaths =
        beforePhotos.map((photo) => photo.path).toList();

    final afterPaths = [
      ...savedAfterPhotos.map(
        (photo) => photo.path,
      ),
      ...newAfterPhotos,
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ação corretiva'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Text(
                    'NÃO CONFORMIDADE',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(current.nonConformity),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _photos(
            'ANTES — evidências da vistoria',
            beforePaths,
          ),
          const SizedBox(height: 18),
          TextField(
            controller: correctiveAction,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Ação corretiva',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: responsible,
            decoration: const InputDecoration(
              labelText: 'Responsável',
            ),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: priority,
            decoration: const InputDecoration(
              labelText: 'Prioridade',
            ),
            items: const [
              DropdownMenuItem(
                value: 'Baixa',
                child: Text('Baixa'),
              ),
              DropdownMenuItem(
                value: 'Média',
                child: Text('Média'),
              ),
              DropdownMenuItem(
                value: 'Alta',
                child: Text('Alta'),
              ),
              DropdownMenuItem(
                value: 'Crítica',
                child: Text('Crítica'),
              ),
            ],
            onChanged: (value) {
              if (value != null) {
                setState(() => priority = value);
              }
            },
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _chooseDueDate,
            icon: const Icon(Icons.calendar_month),
            label: Text(
              dueDate == null
                  ? 'DEFINIR PRAZO'
                  : 'Prazo: ${DateFormat('dd/MM/yyyy').format(dueDate!)}',
            ),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: status,
            decoration: const InputDecoration(
              labelText: 'Status',
            ),
            items: const [
              DropdownMenuItem(
                value: 'Pendente',
                child: Text('Pendente'),
              ),
              DropdownMenuItem(
                value: 'Em andamento',
                child: Text('Em andamento'),
              ),
              DropdownMenuItem(
                value: 'Concluído',
                child: Text('Concluído'),
              ),
            ],
            onChanged: current.status == 'Concluído'
                ? null
                : (value) {
                    if (value != null) {
                      setState(() => status = value);
                    }
                  },
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _saveBasic,
            icon: const Icon(Icons.save),
            label: const Text('SALVAR ALTERAÇÕES'),
          ),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 10),
          Text(
            'CONCLUSÃO DA AÇÃO',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: completedBy,
            decoration: const InputDecoration(
              labelText: 'Quem confirmou a correção',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: completionNote,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Observação da correção',
              hintText:
                  'Ex.: Proteção reinstalada e testada.',
            ),
          ),
          const SizedBox(height: 14),
          _photos(
            'DEPOIS — evidências da correção',
            afterPaths,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed:
                    afterPaths.length >= 10
                        ? null
                        : _takeAfterPhoto,
                icon: const Icon(Icons.camera_alt),
                label: const Text('TIRAR FOTO'),
              ),
              OutlinedButton.icon(
                onPressed:
                    afterPaths.length >= 10
                        ? null
                        : _pickAfterPhotos,
                icon: const Icon(
                  Icons.photo_library_outlined,
                ),
                label: const Text('GALERIA'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (current.status != 'Concluído')
            FilledButton.icon(
              onPressed: _conclude,
              icon: const Icon(Icons.task_alt),
              label: const Padding(
                padding:
                    EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'MARCAR AÇÃO COMO CONCLUÍDA',
                ),
              ),
            )
          else
            OutlinedButton.icon(
              onPressed: _reopen,
              icon: const Icon(Icons.replay),
              label: const Text('REABRIR AÇÃO'),
            ),
          if (current.completionDate != null) ...[
            const SizedBox(height: 8),
            Text(
              'Concluída em ${DateFormat('dd/MM/yyyy HH:mm').format(current.completionDate!)}',
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}
