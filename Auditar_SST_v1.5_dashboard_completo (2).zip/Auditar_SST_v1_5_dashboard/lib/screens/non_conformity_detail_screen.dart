import 'dart:io';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../database.dart';
import '../models.dart';
import '../services/nc_pdf_service.dart';
import 'action_detail_screen.dart';
import 'create_action_screen.dart';

class NonConformityDetailScreen extends StatefulWidget {
  final String ncId;

  const NonConformityDetailScreen({super.key, required this.ncId});

  @override
  State<NonConformityDetailScreen> createState() => _NonConformityDetailScreenState();
}

class _NonConformityDetailScreenState extends State<NonConformityDetailScreen> {
  Map<String, Object?>? row;
  NonConformity? nc;
  List<EvidencePhoto> photos = [];
  List<ActionPlan> actions = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final loadedNc = await db.getNonConformity(widget.ncId);
    final loadedRow = await db.getNonConformityDetailRow(widget.ncId);
    if (loadedNc == null || loadedRow == null) {
      if (mounted) Navigator.pop(context);
      return;
    }
    final loadedPhotos = await db.getPhotosForAnswer(loadedNc.answerId);
    final loadedActions = await db.getActionsForNonConformity(widget.ncId);
    if (!mounted) return;
    setState(() {
      nc = loadedNc;
      row = loadedRow;
      photos = loadedPhotos;
      actions = loadedActions;
      loading = false;
    });
  }

  Future<void> _createAction() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => CreateActionScreen(ncId: widget.ncId)),
    );
    if (changed == true) await _load();
  }

  Future<void> _sharePdf() async {
    final bytes = await NcPdfService.generate(widget.ncId);
    await Printing.sharePdf(
      bytes: bytes,
      filename: '${nc?.code ?? 'NC'}.pdf',
    );
  }

  Widget _field(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.labelMedium),
          const SizedBox(height: 2),
          Text(value.trim().isEmpty ? '-' : value),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final current = nc!;
    final detail = row!;

    return Scaffold(
      appBar: AppBar(title: Text(current.code)),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Não Conformidade',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Chip(label: Text(current.status)),
                      ],
                    ),
                    const Divider(),
                    _field('Empresa', '${detail['company_name'] ?? '-'}'),
                    if ('${detail['sector_name'] ?? ''}'.trim().isNotEmpty)
                      _field('Setor', '${detail['sector_name']}'),
                    if ('${detail['worksite_name'] ?? ''}'.trim().isNotEmpty)
                      _field('Obra / Unidade', '${detail['worksite_name']}'),
                    _field('Área / Local', '${detail['area'] ?? '-'}'),
                    _field('Item verificado', '${detail['question_text'] ?? '-'}'),
                    if ('${detail['question_reference'] ?? ''}'.trim().isNotEmpty)
                      _field('Referência', '${detail['question_reference']}'),
                    _field('Situação encontrada', current.description),
                    _field('Risco identificado', current.riskIdentified),
                    _field('Recomendação técnica', current.recommendation),
                    _field('Classificação / prioridade', current.classification),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('EVIDÊNCIAS', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (photos.isEmpty)
                      const Text('Nenhuma foto anexada.')
                    else
                      SizedBox(
                        height: 150,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: photos.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, index) {
                            final file = File(photos[index].path);
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: file.existsSync()
                                  ? Image.file(file, width: 150, height: 150, fit: BoxFit.cover)
                                  : Container(width: 150, alignment: Alignment.center, child: const Text('Foto indisponível')),
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(child: Text('PLANOS DE AÇÃO', style: TextStyle(fontWeight: FontWeight.bold))),
                        TextButton.icon(
                          onPressed: _createAction,
                          icon: const Icon(Icons.add),
                          label: const Text('Nova ação'),
                        ),
                      ],
                    ),
                    if (actions.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Text('Nenhum plano de ação criado. A NC pode existir sem plano de ação.'),
                      )
                    else
                      ...actions.map(
                        (action) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(action.status == 'Concluído' ? Icons.task_alt : Icons.assignment_outlined),
                          title: Text(action.correctiveAction),
                          subtitle: Text('Responsável: ${action.responsible.isEmpty ? '-' : action.responsible}\nPrioridade: ${action.priority} • ${action.status}'),
                          isThreeLine: true,
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.of(context)
                              .push(MaterialPageRoute(builder: (_) => ActionDetailScreen(actionId: action.id)))
                              .then((_) => _load()),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _sharePdf,
              icon: const Icon(Icons.picture_as_pdf),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 13),
                child: Text('GERAR / COMPARTILHAR PDF DA NC'),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _createAction,
              icon: const Icon(Icons.add_task),
              label: const Text('CRIAR NOVO PLANO DE AÇÃO'),
            ),
          ],
        ),
      ),
    );
  }
}
