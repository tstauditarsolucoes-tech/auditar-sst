import 'package:flutter/material.dart';

import '../database.dart';
import 'non_conformity_detail_screen.dart';

class NonConformitiesScreen extends StatefulWidget {
  final String? companyId;
  final String? inspectionId;

  const NonConformitiesScreen({
    super.key,
    this.companyId,
    this.inspectionId,
  });

  @override
  State<NonConformitiesScreen> createState() => _NonConformitiesScreenState();
}

class _NonConformitiesScreenState extends State<NonConformitiesScreen> {
  List<Map<String, Object?>> rows = [];
  bool includeClosed = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await AppDatabase.instance.getNonConformityRows(
      companyId: widget.companyId,
      inspectionId: widget.inspectionId,
      includeClosed: includeClosed,
    );
    if (mounted) setState(() => rows = result);
  }

  Color _priorityColor(String priority) {
    switch (priority) {
      case 'Crítica':
        return Colors.red.shade900;
      case 'Alta':
        return Colors.red.shade600;
      case 'Média':
        return Colors.orange.shade700;
      default:
        return Colors.green.shade700;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Não conformidades'),
        actions: [
          IconButton(
            tooltip: includeClosed ? 'Ocultar encerradas' : 'Mostrar encerradas',
            onPressed: () {
              setState(() => includeClosed = !includeClosed);
              _load();
            },
            icon: Icon(includeClosed ? Icons.visibility_off_outlined : Icons.visibility_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: rows.isEmpty
            ? ListView(
                children: const [
                  SizedBox(height: 180),
                  Center(child: Text('Nenhuma não conformidade registrada.')),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: rows.length,
                itemBuilder: (_, index) {
                  final row = rows[index];
                  final priority = '${row['classification'] ?? 'Média'}';
                  final sector = '${row['sector_name'] ?? ''}'.trim();
                  final site = '${row['worksite_name'] ?? ''}'.trim();
                  final openActions = int.tryParse('${row['open_action_count'] ?? 0}') ?? 0;
                  final actionCount = int.tryParse('${row['action_count'] ?? 0}') ?? 0;

                  return Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(14),
                      leading: CircleAvatar(
                        backgroundColor: _priorityColor(priority).withValues(alpha: 0.12),
                        child: Icon(Icons.warning_amber_rounded, color: _priorityColor(priority)),
                      ),
                      title: Text(
                        '${row['code'] ?? 'NC'}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        [
                          '${row['company_name'] ?? '-'}',
                          if (sector.isNotEmpty) 'Setor: $sector',
                          if (site.isNotEmpty) 'Obra / Unidade: $site',
                          '${row['description'] ?? ''}',
                          'Prioridade: $priority • Status: ${row['status'] ?? '-'}',
                          actionCount == 0
                              ? 'Sem plano de ação'
                              : '$actionCount ação(ões) • $openActions aberta(s)',
                        ].join('\n'),
                        maxLines: 7,
                        overflow: TextOverflow.ellipsis,
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => NonConformityDetailScreen(ncId: '${row['id']}')))
                          .then((_) => _load()),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
