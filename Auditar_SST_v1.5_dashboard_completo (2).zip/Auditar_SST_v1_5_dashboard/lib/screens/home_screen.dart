import 'package:flutter/material.dart';

import '../brand.dart';
import '../database.dart';
import 'action_plan_screen.dart';
import 'checklist_templates_screen.dart';
import 'companies_screen.dart';
import 'dashboard_screen.dart';
import 'history_screen.dart';
import 'new_inspection_screen.dart';
import 'non_conformities_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int pending = 0;
  int overdue = 0;
  int openNcs = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final summary = await AppDatabase.instance.getDashboardSummary();
    final ncRows = await AppDatabase.instance.getNonConformityRows(
      includeClosed: false,
    );

    if (mounted) {
      setState(() {
        pending = summary['pending'] ?? 0;
        overdue = summary['overdue'] ?? 0;
        openNcs = ncRows.length;
      });
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Auditar SST',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: [
          IconButton(
            tooltip: 'Configurações',
            onPressed: () => _open(const SettingsScreen()),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    ClipOval(
                      child: Image.asset(
                        AuditarBrand.iconAsset,
                        width: 64,
                        height: 64,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Auditar SST',
                            style: TextStyle(
                              fontSize: 23,
                              fontWeight: FontWeight.w800,
                              color: AuditarBrand.navy,
                            ),
                          ),
                          SizedBox(height: 3),
                          Text(
                            'Vistorias, não conformidades e gestão de segurança.',
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Versão 2.2.3',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.black45,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _statusCard(
                    value: openNcs,
                    label: 'NC abertas',
                    icon: Icons.warning_amber_rounded,
                    color: const Color(0xFFD93025),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statusCard(
                    value: pending,
                    label: 'Ações pendentes',
                    icon: Icons.assignment_late_outlined,
                    color: const Color(0xFFF29D18),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statusCard(
                    value: overdue,
                    label: 'Vencidas',
                    icon: Icons.schedule,
                    color: const Color(0xFFD93025),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            _sectionTitle('VISTORIAS E SEGURANÇA'),
            const SizedBox(height: 10),
            _menuGrid([
              _MenuData(
                'Nova vistoria',
                'Iniciar inspeção',
                Icons.playlist_add_check,
                AuditarBrand.greenDark,
                () => _open(const NewInspectionScreen()),
              ),
              _MenuData(
                'Não conformidades',
                'Registrar e acompanhar',
                Icons.warning_amber_rounded,
                const Color(0xFFD93025),
                () => _open(const NonConformitiesScreen()),
              ),
              _MenuData(
                'Plano de ação',
                'Ações e pendências',
                Icons.assignment_turned_in_outlined,
                const Color(0xFFF29D18),
                () => _open(const ActionPlanScreen()),
              ),
              _MenuData(
                'Relatórios',
                'Histórico e PDFs',
                Icons.picture_as_pdf_outlined,
                AuditarBrand.navy,
                () => _open(const HistoryScreen()),
              ),
              _MenuData(
                'Indicadores',
                'Gráficos e evolução',
                Icons.bar_chart_rounded,
                AuditarBrand.navy,
                () => _open(const DashboardScreen()),
              ),
            ]),
            const SizedBox(height: 22),
            _sectionTitle('GESTÃO SST'),
            const SizedBox(height: 10),
            _menuGrid([
              _MenuData(
                'Empresas e setores',
                'Organizar clientes',
                Icons.business_outlined,
                AuditarBrand.navy,
                () => _open(const CompaniesScreen()),
              ),
              _MenuData(
                'Biblioteca de checklists',
                'Prontos e editáveis',
                Icons.fact_check_outlined,
                AuditarBrand.greenDark,
                () => _open(const ChecklistTemplatesScreen()),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: AuditarBrand.navy,
        fontSize: 13,
        fontWeight: FontWeight.w800,
        letterSpacing: .7,
      ),
    );
  }

  Widget _statusCard({
    required int value,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 5),
            Text(
              '$value',
              style: TextStyle(
                color: color,
                fontSize: 22,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menuGrid(List<_MenuData> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = 10.0;
        final width = (constraints.maxWidth - gap) / 2;

        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: items
              .map(
                (item) => SizedBox(
                  width: width,
                  child: Card(
                    margin: EdgeInsets.zero,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: item.onTap,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: item.color.withOpacity(.10),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(item.icon, color: item.color),
                            ),
                            const SizedBox(height: 13),
                            Text(
                              item.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              item.subtitle,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _MenuData {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _MenuData(
    this.title,
    this.subtitle,
    this.icon,
    this.color,
    this.onTap,
  );
}
