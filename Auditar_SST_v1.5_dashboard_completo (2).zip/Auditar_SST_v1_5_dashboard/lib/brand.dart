import 'package:flutter/material.dart';

class AuditarBrand {
  static const navy = Color(0xFF14265B);
  static const navyDark = Color(0xFF0C1B43);
  static const green = Color(0xFF2DBB42);
  static const greenDark = Color(0xFF17812B);
  static const background = Color(0xFFF7F8FA);

  static const iconAsset = 'assets/branding/auditar_icon.png';
  static const logoAsset = 'assets/branding/auditar_logo.jpg';
}
