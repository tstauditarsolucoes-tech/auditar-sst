import 'package:flutter/material.dart';

import '../brand.dart';
import '../models.dart';

class ChecklistPickerScreen extends StatefulWidget {
  final List<ChecklistTemplate> templates;

  const ChecklistPickerScreen({
    super.key,
    required this.templates,
  });

  @override
  State<ChecklistPickerScreen> createState() =>
      _ChecklistPickerScreenState();
}

class _ChecklistPickerScreenState extends State<ChecklistPickerScreen> {
  final TextEditingController searchController = TextEditingController();
  String selectedCategory = 'Todos';

  @override
  void initState() {
    super.initState();
    searchController.addListener(_refresh);
  }

  @override
  void dispose() {
    searchController.removeListener(_refresh);
    searchController.dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  List<String> get categories {
    final values = widget.templates
        .map((template) => template.category.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    return ['Todos', ...values];
  }

  List<ChecklistTemplate> get visibleTemplates {
    final query = searchController.text.trim().toLowerCase();

    return widget.templates.where((template) {
      if (selectedCategory != 'Todos' &&
          template.category != selectedCategory) {
        return false;
      }

      if (query.isEmpty) return true;

      return template.name.toLowerCase().contains(query) ||
          template.category.toLowerCase().contains(query) ||
          template.reference.toLowerCase().contains(query);
    }).toList();
  }

  IconData _checklistIcon(String category) {
    switch (category) {
      case 'Construção Civil':
        return Icons.construction;
      case 'Panificação':
        return Icons.bakery_dining;
      case 'Cerâmica':
        return Icons.factory_outlined;
      case 'Máquinas e Equipamentos':
        return Icons.precision_manufacturing_outlined;
      case 'Incêndio e Emergência':
        return Icons.local_fire_department_outlined;
      case 'Elétrica':
        return Icons.electrical_services_outlined;
      case 'EPI':
        return Icons.health_and_safety_outlined;
      case 'Ergonomia':
        return Icons.accessibility_new;
      case 'Produtos Químicos':
        return Icons.science_outlined;
      case 'Espaço Confinado':
        return Icons.sensor_door_outlined;
      default:
        return Icons.fact_check_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleTemplates;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Selecionar checklist'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
              child: TextField(
                controller: searchController,
                autofocus: false,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Buscar checklist...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: searchController.text.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Limpar busca',
                          onPressed: searchController.clear,
                          icon: const Icon(Icons.close),
                        ),
                ),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final category = categories[index];
                  final selected = selectedCategory == category;

                  return FilterChip(
                    label: Text(category),
                    selected: selected,
                    showCheckmark: selected,
                    selectedColor: AuditarBrand.green.withValues(alpha: .16),
                    onSelected: (_) {
                      if (!mounted) return;
                      setState(() => selectedCategory = category);
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            const Divider(height: 1),
            Expanded(
              child: visible.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Nenhum checklist encontrado.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
                      itemCount: visible.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 6),
                      itemBuilder: (context, index) {
                        final template = visible[index];

                        return Card(
                          margin: EdgeInsets.zero,
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 6,
                            ),
                            leading: CircleAvatar(
                              backgroundColor:
                                  AuditarBrand.green.withValues(alpha: .14),
                              foregroundColor: AuditarBrand.greenDark,
                              child: Icon(
                                _checklistIcon(template.category),
                              ),
                            ),
                            title: Text(
                              template.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: [
                              if (template.category.isNotEmpty)
                                template.category,
                              if (template.reference.isNotEmpty)
                                template.reference,
                            ].isEmpty
                                ? null
                                : Text(
                                    [
                                      if (template.category.isNotEmpty)
                                        template.category,
                                      if (template.reference.isNotEmpty)
                                        template.reference,
                                    ].join(' • '),
                                  ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () {
                              FocusScope.of(context).unfocus();
                              Navigator.of(context).pop(template);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
